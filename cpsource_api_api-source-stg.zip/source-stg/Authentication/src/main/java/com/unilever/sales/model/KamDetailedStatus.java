package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INT_DETAILED_STATUS")
public class KamDetailedStatus implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7215595271619726785L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="BRANCH")
    private String branch;
	
	@Column(name="CATEGORY")
    private String category;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="USERNAME")
    private String username;
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="PO_NUMBER")
    private String poNumber;
	
	@Column(name="CIC_NO")
    private String cicNo;
	
	@Column(name="STATUS")
    private String status;
	
	@Column(name="PO_VALUE")
    private Double poValue;
	
	@Column(name="LINE_COUNT")
    private Integer lineCount;
	
	@Column(name="PO_DATE")
    private String poDate;
	
	@Column(name="DEPOT")
    private String depot;
	
	@Column(name="ALLOCATED_SUM")
    private Double allocatedSum;
	
	@Column(name="INVOICED_SUM")
    private Double invoicedSum;
	
	@Column(name="DELIVERY_DATE")
    private String delivaryDate;

	public KamDetailedStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KamDetailedStatus(Integer rECORD_ID, String branch, String category, String account, String username,
			String moc, String poNumber, String cicNo, String status, Double poValue, Integer lineCount, String poDate,
			String depot, Double allocatedSum, Double invoicedSum, String delivaryDate) {
		super();
		RECORD_ID = rECORD_ID;
		this.branch = branch;
		this.category = category;
		this.account = account;
		this.username = username;
		this.moc = moc;
		this.poNumber = poNumber;
		this.cicNo = cicNo;
		this.status = status;
		this.poValue = poValue;
		this.lineCount = lineCount;
		this.poDate = poDate;
		this.depot = depot;
		this.allocatedSum = allocatedSum;
		this.invoicedSum = invoicedSum;
		this.delivaryDate = delivaryDate;
	}

	
	public KamDetailedStatus(Double poValue, Double allocatedSum, Double invoicedSum,String poNumber, String poDate,
			String depot, String delivaryDate,String status) {
		this.poValue = poValue;
		this.allocatedSum = allocatedSum;
		this.invoicedSum = invoicedSum;
		this.invoicedSum = invoicedSum;
		this.poNumber = poNumber;
		this.poDate = poDate;
		this.depot = depot;
		this.delivaryDate = delivaryDate;
		this.status = status;
		
	}
	
	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getCicNo() {
		return cicNo;
	}

	public void setCicNo(String cicNo) {
		this.cicNo = cicNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getPoValue() {
		return poValue;
	}

	public void setPoValue(Double poValue) {
		this.poValue = poValue;
	}

	public Integer getLineCount() {
		return lineCount;
	}

	public void setLineCount(Integer lineCount) {
		this.lineCount = lineCount;
	}

	public String getPoDate() {
		return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public String getDepot() {
		return depot;
	}

	public void setDepot(String depot) {
		this.depot = depot;
	}

	public Double getAllocatedSum() {
		return allocatedSum;
	}

	public void setAllocatedSum(Double allocatedSum) {
		this.allocatedSum = allocatedSum;
	}

	public Double getInvoicedSum() {
		return invoicedSum;
	}

	public void setInvoicedSum(Double invoicedSum) {
		this.invoicedSum = invoicedSum;
	}

	public String getDelivaryDate() {
		return delivaryDate;
	}

	public void setDelivaryDate(String delivaryDate) {
		this.delivaryDate = delivaryDate;
	}
	
	
	

}
