package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INT_QGP_DATA")
public class KamQgpData implements Serializable {
	
private static final long serialVersionUID = -2223060043288637646L;
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="BRANCH")
    private String branch;
	
	@Column(name="CATEGORY")
    private String category;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="USERNAME")
    private String username;	
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="CHANNEL")
    private String channel;
	
	@Column(name="BASEPACK")
    private String basepack;
	
	@Column(name="VP_CATEGORY")
    private String vpCategory;
	
	@Column(name="CLUSTER")
    private String cluster;
	
	@Column(name="CUSTOMER_CHAIN")
    private String customerChain;
	
	@Column(name="SALES_TARGET")
    private Double salesTarget;
	
	@Column(name="SALES_ACHIEVEMENT")
    private Double salesAchiveMent;
	
	@Column(name="ARC_PERCENT")
    private Double arcPercent;

	public KamQgpData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KamQgpData(Integer rECORD_ID, String branch, String category, String account, String username, String moc,
			String channel, String basepack, String vpCategory, String cluster, String customerChain,
			Double salesTarget, Double salesAchiveMent, Double arcPercent) {
		super();
		RECORD_ID = rECORD_ID;
		this.branch = branch;
		this.category = category;
		this.account = account;
		this.username = username;
		this.moc = moc;
		this.channel = channel;
		this.basepack = basepack;
		this.vpCategory = vpCategory;
		this.cluster = cluster;
		this.customerChain = customerChain;
		this.salesTarget = salesTarget;
		this.salesAchiveMent = salesAchiveMent;
		this.arcPercent = arcPercent;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getBasepack() {
		return basepack;
	}

	public void setBasepack(String basepack) {
		this.basepack = basepack;
	}

	public String getVpCategory() {
		return vpCategory;
	}

	public void setVpCategory(String vpCategory) {
		this.vpCategory = vpCategory;
	}

	public String getCluster() {
		return cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	public String getCustomerChain() {
		return customerChain;
	}

	public void setCustomerChain(String customerChain) {
		this.customerChain = customerChain;
	}

	public Double getSalesTarget() {
		return salesTarget;
	}

	public void setSalesTarget(Double salesTarget) {
		this.salesTarget = salesTarget;
	}

	public Double getSalesAchiveMent() {
		return salesAchiveMent;
	}

	public void setSalesAchiveMent(Double salesAchiveMent) {
		this.salesAchiveMent = salesAchiveMent;
	}

	public Double getArcPercent() {
		return arcPercent;
	}

	public void setArcPercent(Double arcPercent) {
		this.arcPercent = arcPercent;
	}
	
	


}
