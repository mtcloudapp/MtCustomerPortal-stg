package com.unilever.asset.commercialB2C.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValueNext;
import com.unilever.global.GlobalVariables;

@Repository
public interface CommB2CDepotConnectedAssetValueNextReposiory  extends JpaRepository<CommB2CDepotConnectedAssetValueNext, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_DEPOT_CONNECTED_ASSETS_VALUE_NEXT", nativeQuery = true)
	List<CommB2CDepotConnectedAssetValueNext> findAllDepotConnectedAssetValueNextDetails();
}
