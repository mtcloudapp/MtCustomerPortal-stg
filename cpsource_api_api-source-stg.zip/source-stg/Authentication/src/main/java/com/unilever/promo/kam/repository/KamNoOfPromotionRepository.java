package com.unilever.promo.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.kam.model.KamNoOfPromotion;

@Repository
public interface KamNoOfPromotionRepository extends JpaRepository<KamNoOfPromotion, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NO_OF_PROMOTIONS tac where tac.USERNAME=:username", nativeQuery = true)
	List<KamNoOfPromotion> findAllNoOfPromotion(@Param("username") String username);
	
	@Transactional
    @Query(value ="select cnf.NO_OF_PROMOTIONS from "+GlobalVariables.schemaName+".INT_NO_OF_PROMOTIONS cnf where cnf.ACCOUNT_NAME in :account "
    		+ "and cnf.MOC in :moc and cnf.REGION_NAME in :region and cnf.CATEGORY_NAME in :category and cnf.USERNAME=:username", nativeQuery = true)
	List<String> findDistinctkamNoOfPromotion(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,@Param("username") String username);

}
