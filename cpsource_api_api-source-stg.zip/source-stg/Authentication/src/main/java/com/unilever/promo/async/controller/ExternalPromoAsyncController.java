package com.unilever.promo.async.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.promo.async.service.ExternalPromoAsyncService;
import com.unilever.promo.external.model.ExtenalTotalUtilizeVolume;
import com.unilever.promo.external.model.ExternalNoOfPromotion;
import com.unilever.promo.external.model.ExternalPromoJson;
import com.unilever.promo.external.model.ExternalTotalPlannedBudget;
import com.unilever.promo.external.model.ExternalTotalPlannedPromoVolume;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class ExternalPromoAsyncController {
	
	private static Logger log = LoggerFactory.getLogger(ExternalPromoAsyncController.class);


	@Autowired
	private ExternalPromoAsyncService externalPromoAsyncService;
	
	
	@RequestMapping(value = "/getCurrentMOCExternalPromoData", method = RequestMethod.GET)
	public String getCurrentMOCExternalPromoData(@RequestParam("account") String account, @RequestParam("region") List<String> region, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
	   
		try{
			 
			CompletableFuture<Integer> noOfsolCode = externalPromoAsyncService.getAllExternalNoOfPromotion(account, region, moc, category);
			CompletableFuture<ExternalTotalPlannedBudget> totalPlannedBudget = externalPromoAsyncService.getAllExternalTotalPlannedBudget(account, region, moc, category);
			CompletableFuture<ExternalTotalPlannedPromoVolume> totalPlannedvolume = externalPromoAsyncService.getAllExternalTotalPlannedPromoVolume(account, region, moc, category);
			CompletableFuture<ExtenalTotalUtilizeVolume> totalUtilizedVolume = externalPromoAsyncService.getAllExtenalTotalUtilizeVolume(account, region, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfsolCode, totalPlannedBudget,totalPlannedvolume,totalUtilizedVolume).join();

			log.info("External noOfsolCode--> " + noOfsolCode.get());
			log.info("External totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("External totalPlannedvolume--> " + totalPlannedvolume.get());
			log.info("External totalUtilizedVolume--> " + totalUtilizedVolume.get());
			
			ExternalPromoJson obj = new ExternalPromoJson();
			Gson gson = new Gson();

			obj.setNoOfSolCode(noOfsolCode.get().intValue());
			obj.setTotalPlannedBudget(totalPlannedBudget.get().getTotalPlannedBudget());
			obj.setTotalPlannedPromoVolume(totalPlannedvolume.get().getTotalPlannedPromoVolume());
			obj.setTotalUtilizedVolume(totalUtilizedVolume.get().getTotalUtilizedVolume());
			
			json = gson.toJson(obj); 

		}  catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	
	@RequestMapping(value = "/getPreviousMOCExternalPromoData", method = RequestMethod.GET)
	public String getPreviousMOCExternalPromoData(@RequestParam("account") String account, @RequestParam("region") List<String> region, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
	   
		try{
			 
			CompletableFuture<Integer> noOfsolCode = externalPromoAsyncService.getAllExternalNoOfPromotion(account, region, moc, category);
			CompletableFuture<ExternalTotalPlannedBudget> totalPlannedBudget = externalPromoAsyncService.getAllExternalTotalPlannedBudget(account, region, moc, category);
			CompletableFuture<ExternalTotalPlannedPromoVolume> totalPlannedvolume = externalPromoAsyncService.getAllExternalTotalPlannedPromoVolume(account, region, moc, category);
			CompletableFuture<ExtenalTotalUtilizeVolume> totalUtilizedVolume = externalPromoAsyncService.getAllExtenalTotalUtilizeVolume(account, region, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfsolCode, totalPlannedBudget,totalPlannedvolume,totalUtilizedVolume).join();

			log.info("External noOfsolCode--> " + noOfsolCode.get());
			log.info("External totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("External totalPlannedvolume--> " + totalPlannedvolume.get());
			log.info("External totalUtilizedVolume--> " + totalUtilizedVolume.get());
			
			ExternalPromoJson obj = new ExternalPromoJson();
			Gson gson = new Gson();

			obj.setNoOfSolCode(noOfsolCode.get().intValue());
			obj.setTotalPlannedBudget(totalPlannedBudget.get().getTotalPlannedBudget());
			obj.setTotalPlannedPromoVolume(totalPlannedvolume.get().getTotalPlannedPromoVolume());
			obj.setTotalUtilizedVolume(totalUtilizedVolume.get().getTotalUtilizedVolume());
			
			json = gson.toJson(obj); 

		}  catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	
	@RequestMapping(value = "/getNextMOCExternalPromoData", method = RequestMethod.GET)
	public String getNextMOCExternalPromoData(@RequestParam("account") String account, @RequestParam("region") List<String> region, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
	   
		try{
			 
			CompletableFuture<Integer> noOfsolCode = externalPromoAsyncService.getAllExternalNoOfPromotion(account, region, moc, category);
			CompletableFuture<ExternalTotalPlannedBudget> totalPlannedBudget = externalPromoAsyncService.getAllExternalTotalPlannedBudget(account, region, moc, category);
			CompletableFuture<ExternalTotalPlannedPromoVolume> totalPlannedvolume = externalPromoAsyncService.getAllExternalTotalPlannedPromoVolume(account, region, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfsolCode, totalPlannedBudget,totalPlannedvolume).join();

			log.info("External noOfsolCode--> " + noOfsolCode.get());
			log.info("External totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("External totalPlannedvolume--> " + totalPlannedvolume.get());
			
			ExternalPromoJson obj = new ExternalPromoJson();
			Gson gson = new Gson();

			obj.setNoOfSolCode(noOfsolCode.get().intValue());
			obj.setTotalPlannedBudget(totalPlannedBudget.get().getTotalPlannedBudget());
			obj.setTotalPlannedPromoVolume(totalPlannedvolume.get().getTotalPlannedPromoVolume());
			
			json = gson.toJson(obj); 

		}  catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	


}
