package com.unilever.promo.claim.external.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PosDataFieldMapping;

public interface PosDataFieldMappingRepository extends JpaRepository<PosDataFieldMapping, Integer> {
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".POS_DATA_FIELDS_MAPPING pcs where pcs.ACCOUNT_NAME=:accountName", nativeQuery = true)
	List<PosDataFieldMapping> getPosFileColumnValuesByAccount(@Param("accountName") String accountName);

}
