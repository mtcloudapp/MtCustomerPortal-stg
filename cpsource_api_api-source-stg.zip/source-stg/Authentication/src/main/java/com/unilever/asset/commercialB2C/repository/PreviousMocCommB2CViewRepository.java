package com.unilever.asset.commercialB2C.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CurrentMocCommB2CView;
import com.unilever.asset.commercialB2C.model.NextMocCommB2CView;
import com.unilever.asset.commercialB2C.model.PreviousMocCommB2CView;
import com.unilever.global.GlobalVariables;

public interface PreviousMocCommB2CViewRepository extends PagingAndSortingRepository<PreviousMocCommB2CView, String>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.ACCOUNT in :accounts", nativeQuery = true)
	List<PreviousMocCommB2CView> findAllPreviousMocViewByAccounts(@Param("accounts") List<String> accounts);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm", nativeQuery = true)
	List<PreviousMocCommB2CView> findAllPreviousMocViewDetails();
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMoc(@Param("moc") List<String> moc,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm where icm.MOC in :moc", nativeQuery = true)
	List<PreviousMocCommB2CView> findCountByMoc(@Param("moc") List<String> moc);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	List<PreviousMocCommB2CView> findCountByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	List<PreviousMocCommB2CView> findCountByAccount(@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMocAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	List<PreviousMocCommB2CView> findCountByAccountMocCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	List<PreviousMocCommB2CView> findCountByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMocAccountRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	List<PreviousMocCommB2CView> findCountByAccountMocRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<PreviousMocCommB2CView> findAllCountPreviousMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<PreviousMocCommB2CView> findAllPreviousMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<PreviousMocCommB2CView> findAllCountPreviousMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);
	
	

}
