package com.unilever.asset.commercialB2C.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValueNext;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetVolumeNext;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalCount;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalValue;
import com.unilever.asset.commercialB2C.repository.CommB2CDepotConnectedAssetValueNextReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CDepotConnectedAssetVolumeNextReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CPlannedAssetValueReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CPlannedAssetVolumeReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CStoreListTotalCountReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CStoreListTotalValueReposiory;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetVolume;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.asset.kam.repository.DepotConnetedAssetValueRepository;
import com.unilever.asset.kam.repository.DepotConnetedAssetVolumeRepository;
import com.unilever.asset.kam.repository.PlannedAssetValueRepository;
import com.unilever.asset.kam.repository.PlannedAssetVolumeRepository;
import com.unilever.asset.kam.repository.StoreListTotalCountRepository;
import com.unilever.asset.kam.repository.StoreListTotalValueRepository;

@Service
public class CommercialB2CNextMocService {

	@Autowired
	StoreListTotalCountRepository storeListTotalCountRepository;

	@Autowired
	StoreListTotalValueRepository storeListTotalValueRepository;

	@Autowired
	PlannedAssetValueRepository plannedAssetValueRepository;

	@Autowired
	PlannedAssetVolumeRepository plannedAssetVolumeRepository;
	
	@Autowired
	DepotConnetedAssetValueRepository depotConnetedAssetValueRepository;

	@Autowired
	DepotConnetedAssetVolumeRepository depotConnetedAssetVolumeRepository;

	@Autowired
	CommB2CStoreListTotalCountReposiory commB2CStoreListTotalCountReposiory;
	
	@Autowired
	CommB2CStoreListTotalValueReposiory commB2CStoreListTotalValueReposiory;


	@Autowired
	CommB2CPlannedAssetValueReposiory commB2CPlannedAssetValueReposiory;
	
	@Autowired
	CommB2CPlannedAssetVolumeReposiory commB2CPlannedAssetVolumeReposiory;

	@Autowired
	CommB2CDepotConnectedAssetValueNextReposiory commB2CDepotConnectedAssetValueNextReposiory;
	
	@Autowired
	CommB2CDepotConnectedAssetVolumeNextReposiory commB2CDepotConnectedAssetVolumeNextReposiory;

	///======================================Start Store List Count=========================================

	public CommB2CStoreListTotalCount getStoreListTotalCount(List<String> region,List<String> account,List<String> moc,List<String> category){

		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CStoreListTotalCount totalAssetAmountSum = new CommB2CStoreListTotalCount();


		try{

			List<CommB2CStoreListTotalCount> totalAssetValues = new ArrayList<CommB2CStoreListTotalCount>();
			List<CommB2CStoreListTotalCount> totalStoreListCountByUsername = new ArrayList<CommB2CStoreListTotalCount>();
			List<CommB2CStoreListTotalCount> mocList = new ArrayList<CommB2CStoreListTotalCount>();

			List<CommB2CStoreListTotalCount> regionList = new ArrayList<CommB2CStoreListTotalCount>();
			List<CommB2CStoreListTotalCount> regionListOne = new ArrayList<CommB2CStoreListTotalCount>();
			List<CommB2CStoreListTotalCount> regionListTwo = new ArrayList<CommB2CStoreListTotalCount>();
			List<CommB2CStoreListTotalCount> regionListThree = new ArrayList<CommB2CStoreListTotalCount>();
			List<CommB2CStoreListTotalCount> regionListFour = new ArrayList<CommB2CStoreListTotalCount>();
			List<CommB2CStoreListTotalCount> regionListFive = new ArrayList<CommB2CStoreListTotalCount>();


			totalStoreListCountByUsername = commB2CStoreListTotalCountReposiory.findAllStoreListTotalCountDetails();

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				for(CommB2CStoreListTotalCount t : mocList){
					totalAssetAmount += t.getStoreListTotalCount();

				}

				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);

			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CStoreListTotalCount> categoryList = new ArrayList<CommB2CStoreListTotalCount>();

				//filtered by category

				for(String c : category){
					for(CommB2CStoreListTotalCount cat : totalStoreListCountByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalCount mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CStoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();

				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CStoreListTotalCount> accountList = new ArrayList<CommB2CStoreListTotalCount>();

				for(String accnt : account){
					for(CommB2CStoreListTotalCount acc : totalStoreListCountByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalCount mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CStoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();

				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CStoreListTotalCount> accountList = new ArrayList<CommB2CStoreListTotalCount>();
				List<CommB2CStoreListTotalCount> filteredAccountCategoryList = new ArrayList<CommB2CStoreListTotalCount>();


				//filterd by account
				for(String accnt : account){
					for(CommB2CStoreListTotalCount acc : totalStoreListCountByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CStoreListTotalCount cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalCount mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CStoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();
				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CStoreListTotalCount reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CStoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if


				totalAssetValues.addAll(regionList);
				for(CommB2CStoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();
				}

				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CStoreListTotalCount> filteredRegionAccountList = new ArrayList<CommB2CStoreListTotalCount>();

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CStoreListTotalCount reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}

					regionList.addAll(regionListOne);


				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CStoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}



							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if



				//filtered by account

				for(String accnt : account){
					for(CommB2CStoreListTotalCount acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}



				totalAssetValues.addAll(filteredRegionAccountList);

				for(CommB2CStoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();

				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CStoreListTotalCount> filteredRegionCategoryList = new ArrayList<CommB2CStoreListTotalCount>();

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CStoreListTotalCount reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}

					regionList.addAll(regionListOne);


				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CStoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}



							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CStoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if


				//filtered by category

				for(String c : category){
					for(CommB2CStoreListTotalCount cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}


				totalAssetValues.addAll(filteredRegionCategoryList);
				for(CommB2CStoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();
				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CStoreListTotalCount> accountList = new ArrayList<CommB2CStoreListTotalCount>();
				List<CommB2CStoreListTotalCount> filteredRegionCategoryList = new ArrayList<CommB2CStoreListTotalCount>();


				if(totalStoreListCountByUsername !=null)	{

					//filtered by MOC
					for(String m : moc){
						for(CommB2CStoreListTotalCount mocc : totalStoreListCountByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					// filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CStoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}

						regionList.addAll(regionListOne);


					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CStoreListTotalCount reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}



								regionList.addAll(regionListOne);


							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CStoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}

								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);

							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CStoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);

							}


							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CStoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);

							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CStoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);

							}


							count++;

						}

					}// end of if


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CStoreListTotalCount acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CStoreListTotalCount cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}



					totalAssetValues.addAll(filteredRegionCategoryList);

					for(CommB2CStoreListTotalCount t : totalAssetValues){
						totalAssetAmount += t.getStoreListTotalCount();
					}

					totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);

				}//end of if

			}// end of else if
		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}


	//===========================================Start Store List Valuee==============================================	



	public CommB2CStoreListTotalValue getStoreListTotalValue(List<String> region,List<String> account,List<String> moc,List<String> category){

		double totalAssetVolume = 0.00;
		CommB2CStoreListTotalValue totalAssetVolumeSum= new CommB2CStoreListTotalValue();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CommB2CStoreListTotalValue> totalAssetVolumes = new ArrayList<CommB2CStoreListTotalValue>();
			List<CommB2CStoreListTotalValue> totalStoreListValueByUsername = new ArrayList<CommB2CStoreListTotalValue>();
			List<CommB2CStoreListTotalValue> mocList = new ArrayList<CommB2CStoreListTotalValue>();

			List<CommB2CStoreListTotalValue> regionList = new ArrayList<CommB2CStoreListTotalValue>();
			List<CommB2CStoreListTotalValue> regionListOne = new ArrayList<CommB2CStoreListTotalValue>();
			List<CommB2CStoreListTotalValue> regionListTwo = new ArrayList<CommB2CStoreListTotalValue>();
			List<CommB2CStoreListTotalValue> regionListThree = new ArrayList<CommB2CStoreListTotalValue>();
			List<CommB2CStoreListTotalValue> regionListFour = new ArrayList<CommB2CStoreListTotalValue>();
			List<CommB2CStoreListTotalValue> regionListFive = new ArrayList<CommB2CStoreListTotalValue>();


			totalStoreListValueByUsername = commB2CStoreListTotalValueReposiory.findAllStoreListTotalValueDetails();

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(CommB2CStoreListTotalValue t : mocList){
					totalAssetVolume += t.getStoreListTotalValue();

				}

				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CStoreListTotalValue> categoryList = new ArrayList<CommB2CStoreListTotalValue>();


				//filtered by category

				for(String c : category){
					for(CommB2CStoreListTotalValue cat : totalStoreListValueByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CStoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();

				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CStoreListTotalValue> accountList = new ArrayList<CommB2CStoreListTotalValue>();

				for(String accnt : account){
					for(CommB2CStoreListTotalValue acc : totalStoreListValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CStoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();

				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CStoreListTotalValue> accountList = new ArrayList<CommB2CStoreListTotalValue>();
				List<CommB2CStoreListTotalValue> filteredAccountCategoryList = new ArrayList<CommB2CStoreListTotalValue>();


				//filterd by account
				for(String accnt : account){
					for(CommB2CStoreListTotalValue acc : totalStoreListValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CStoreListTotalValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}



				totalAssetVolumes.addAll(mocList);

				for(CommB2CStoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();
				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5


				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CStoreListTotalValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CStoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if


				totalAssetVolumes.addAll(regionList);
				for(CommB2CStoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();
				}

				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CStoreListTotalValue> filteredRegionAccountList = new ArrayList<CommB2CStoreListTotalValue>();


				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CStoreListTotalValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CStoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if


				//filtered by account

				for(String accnt : account){
					for(CommB2CStoreListTotalValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}



				totalAssetVolumes.addAll(filteredRegionAccountList);

				for(CommB2CStoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();

				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CStoreListTotalValue> filteredRegionCategoryList = new ArrayList<CommB2CStoreListTotalValue>();

				//filtered by MOC
				for(String m : moc){
					for(CommB2CStoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CStoreListTotalValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CStoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CStoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if




				//filtered by category

				for(String c : category){
					for(CommB2CStoreListTotalValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}


				totalAssetVolumes.addAll(filteredRegionCategoryList);
				for(CommB2CStoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();
				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
				List<CommB2CStoreListTotalValue> accountList = new ArrayList<CommB2CStoreListTotalValue>();
				List<CommB2CStoreListTotalValue> filteredRegionCategoryList = new ArrayList<CommB2CStoreListTotalValue>();

				if(totalStoreListValueByUsername !=null)	{

					//filtered by MOC
					for(String m : moc){
						for(CommB2CStoreListTotalValue mocc : totalStoreListValueByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					// filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CStoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);

					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CStoreListTotalValue reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);


							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CStoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}

								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);

							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CStoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);

							}


							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CStoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);

							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CStoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);

							}


							count++;

						}

					}// end of if


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CStoreListTotalValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CStoreListTotalValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}



					totalAssetVolumes.addAll(filteredRegionCategoryList);

					for(CommB2CStoreListTotalValue t : totalAssetVolumes){
						totalAssetVolume += t.getStoreListTotalValue();
					}

					totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);

				}//end of if

			}// end of else if



		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//=================================================Planned Asset Value===============================================
	public CommB2CPlannedAssetValue getAllPlannedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category){

		double totalAssetValue = 0.00;
		CommB2CPlannedAssetValue totalAssetValueSum= new CommB2CPlannedAssetValue();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CommB2CPlannedAssetValue> totalAssetVolumes = new ArrayList<CommB2CPlannedAssetValue>();
			List<CommB2CPlannedAssetValue> totalCommB2CPlannedAssetValueByUsername = new ArrayList<CommB2CPlannedAssetValue>();
			List<CommB2CPlannedAssetValue> mocList = new ArrayList<CommB2CPlannedAssetValue>();

			List<CommB2CPlannedAssetValue> regionList = new ArrayList<CommB2CPlannedAssetValue>();
			List<CommB2CPlannedAssetValue> regionListOne = new ArrayList<CommB2CPlannedAssetValue>();
			List<CommB2CPlannedAssetValue> regionListTwo = new ArrayList<CommB2CPlannedAssetValue>();
			List<CommB2CPlannedAssetValue> regionListThree = new ArrayList<CommB2CPlannedAssetValue>();
			List<CommB2CPlannedAssetValue> regionListFour = new ArrayList<CommB2CPlannedAssetValue>();
			List<CommB2CPlannedAssetValue> regionListFive = new ArrayList<CommB2CPlannedAssetValue>();


			totalCommB2CPlannedAssetValueByUsername = commB2CPlannedAssetValueReposiory.findAllPlannedAssetValueDetails();

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetValue mocc : totalCommB2CPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(CommB2CPlannedAssetValue t : mocList){
					totalAssetValue += t.getPlannedAssetValue();

				}

				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);

			}
			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CPlannedAssetValue> categoryList = new ArrayList<CommB2CPlannedAssetValue>();

				//filtered by category

				for(String c : category){
					for(CommB2CPlannedAssetValue cat : totalCommB2CPlannedAssetValueByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC

				for(String m : moc){
					for(CommB2CPlannedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CPlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();

				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CPlannedAssetValue> accountList = new ArrayList<CommB2CPlannedAssetValue>();

				for(String accnt : account){
					for(CommB2CPlannedAssetValue acc : totalCommB2CPlannedAssetValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC

				for(String m : moc){
					for(CommB2CPlannedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(CommB2CPlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();

				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}



			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CPlannedAssetValue> accountList = new ArrayList<CommB2CPlannedAssetValue>();
				List<CommB2CPlannedAssetValue> filteredAccountCategoryList = new ArrayList<CommB2CPlannedAssetValue>();



				//filterd by account
				for(String accnt : account){
					for(CommB2CPlannedAssetValue acc : totalCommB2CPlannedAssetValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CPlannedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC

				for(String m : moc){
					for(CommB2CPlannedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}



				totalAssetVolumes.addAll(mocList);

				for(CommB2CPlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();
				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5


				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetValue mocc : totalCommB2CPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CPlannedAssetValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CPlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if






				totalAssetVolumes.addAll(regionList);
				for(CommB2CPlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();
				}

				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CPlannedAssetValue> filteredRegionAccountList = new ArrayList<CommB2CPlannedAssetValue>();

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetValue mocc : totalCommB2CPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CPlannedAssetValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CPlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if



				//filtered by account

				for(String accnt : account){
					for(CommB2CPlannedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				totalAssetVolumes.addAll(filteredRegionAccountList);

				for(CommB2CPlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();

				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CPlannedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CPlannedAssetValue>();

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetValue mocc : totalCommB2CPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CPlannedAssetValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CPlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CPlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if




				//filtered by category

				for(String c : category){
					for(CommB2CPlannedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				totalAssetVolumes.addAll(filteredRegionCategoryList);
				for(CommB2CPlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();
				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CPlannedAssetValue> accountList = new ArrayList<CommB2CPlannedAssetValue>();
				List<CommB2CPlannedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CPlannedAssetValue>();

				if(totalCommB2CPlannedAssetValueByUsername !=null)	{


					//filtered by MOC
					for(String m : moc){
						for(CommB2CPlannedAssetValue mocc : totalCommB2CPlannedAssetValueByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					// filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CPlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);

					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CPlannedAssetValue reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);


							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CPlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}

								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);

							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CPlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);

							}


							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CPlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);

							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CPlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);

							}


							count++;

						}

					}// end of if






					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CPlannedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CPlannedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}


					totalAssetVolumes.addAll(filteredRegionCategoryList);

					for(CommB2CPlannedAssetValue t : totalAssetVolumes){
						totalAssetValue += t.getPlannedAssetValue();
					}

					totalAssetValueSum.setPlannedAssetValue(totalAssetValue);

				}//end of if

			}// end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetValueSum;

	}


	//================================================Planned Asset Volume================================================

	public CommB2CPlannedAssetVolume getAllPlannedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		CommB2CPlannedAssetVolume totalAssetVolumeSum= new CommB2CPlannedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CommB2CPlannedAssetVolume> totalAssetVolumes = new ArrayList<CommB2CPlannedAssetVolume>();
			List<CommB2CPlannedAssetVolume> totalCommB2CPlannedAssetVolumeByUsername = new ArrayList<CommB2CPlannedAssetVolume>();
			List<CommB2CPlannedAssetVolume> mocList = new ArrayList<CommB2CPlannedAssetVolume>();

			List<CommB2CPlannedAssetVolume> regionList = new ArrayList<CommB2CPlannedAssetVolume>();
			List<CommB2CPlannedAssetVolume> regionListOne = new ArrayList<CommB2CPlannedAssetVolume>();
			List<CommB2CPlannedAssetVolume> regionListTwo = new ArrayList<CommB2CPlannedAssetVolume>();
			List<CommB2CPlannedAssetVolume> regionListThree = new ArrayList<CommB2CPlannedAssetVolume>();
			List<CommB2CPlannedAssetVolume> regionListFour = new ArrayList<CommB2CPlannedAssetVolume>();
			List<CommB2CPlannedAssetVolume> regionListFive = new ArrayList<CommB2CPlannedAssetVolume>();

			totalCommB2CPlannedAssetVolumeByUsername = commB2CPlannedAssetVolumeReposiory.findAllPlannedAssetVolumeDetails();


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetVolume mocc : totalCommB2CPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(CommB2CPlannedAssetVolume t : mocList){
					totalAssetVolume += t.getPlannedAssetVolume();

				}

				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CPlannedAssetVolume> categoryList = new ArrayList<CommB2CPlannedAssetVolume>();


				//filtered by category

				for(String c : category){
					for(CommB2CPlannedAssetVolume cat : totalCommB2CPlannedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CPlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();

				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CPlannedAssetVolume> accountList = new ArrayList<CommB2CPlannedAssetVolume>();

				for(String accnt : account){
					for(CommB2CPlannedAssetVolume acc : totalCommB2CPlannedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CPlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();

				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CPlannedAssetVolume> accountList = new ArrayList<CommB2CPlannedAssetVolume>();
				List<CommB2CPlannedAssetVolume> filteredAccountCategoryList = new ArrayList<CommB2CPlannedAssetVolume>();

				//filterd by account
				for(String accnt : account){
					for(CommB2CPlannedAssetVolume acc : totalCommB2CPlannedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CPlannedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CPlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();
				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5


				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetVolume mocc : totalCommB2CPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CPlannedAssetVolume reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CPlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if


				totalAssetVolumes.addAll(regionList);
				for(CommB2CPlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();
				}

				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CPlannedAssetVolume> filteredRegionAccountList = new ArrayList<CommB2CPlannedAssetVolume>();

				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetVolume mocc : totalCommB2CPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CPlannedAssetVolume reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CPlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if




				//filtered by account

				for(String accnt : account){
					for(CommB2CPlannedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}


				totalAssetVolumes.addAll(filteredRegionAccountList);

				for(CommB2CPlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();

				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CPlannedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CPlannedAssetVolume>();


				//filtered by MOC
				for(String m : moc){
					for(CommB2CPlannedAssetVolume mocc : totalCommB2CPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				// filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(CommB2CPlannedAssetVolume reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);

				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(CommB2CPlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);


						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}

							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);

						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);

						}


						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);

						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(CommB2CPlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);

						}


						count++;

					}

				}// end of if









				//filtered by category

				for(String c : category){
					for(CommB2CPlannedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}



				totalAssetVolumes.addAll(filteredRegionCategoryList);
				for(CommB2CPlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();
				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}	



			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CPlannedAssetVolume> accountList = new ArrayList<CommB2CPlannedAssetVolume>();
				List<CommB2CPlannedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CPlannedAssetVolume>();

				if(totalCommB2CPlannedAssetVolumeByUsername !=null)	{
					//filtered by MOC
					for(String m : moc){
						for(CommB2CPlannedAssetVolume mocc : totalCommB2CPlannedAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					// filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CPlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);

					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CPlannedAssetVolume reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);


							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CPlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}

								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);

							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CPlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);

							}


							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CPlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);

							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CPlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);

							}


							count++;

						}

					}// end of if



					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CPlannedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CPlannedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}



					totalAssetVolumes.addAll(filteredRegionCategoryList);

					for(CommB2CPlannedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getPlannedAssetVolume();
					}

					totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//=======================Start Depot connected Asset Value===========================================//


		public CommB2CDepotConnectedAssetValueNext getNextMocAllDepotConnectedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			CommB2CDepotConnectedAssetValueNext totalAssetAmountSum = new CommB2CDepotConnectedAssetValueNext();


			try{

				List<CommB2CDepotConnectedAssetValueNext> totalAssetValues = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				List<CommB2CDepotConnectedAssetValueNext> totalDepotAssetValuesByUsername = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				List<CommB2CDepotConnectedAssetValueNext> mocList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				
				List<CommB2CDepotConnectedAssetValueNext> regionList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				List<CommB2CDepotConnectedAssetValueNext> regionListOne = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				List<CommB2CDepotConnectedAssetValueNext> regionListTwo = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				List<CommB2CDepotConnectedAssetValueNext> regionListThree = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				List<CommB2CDepotConnectedAssetValueNext> regionListFour = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				List<CommB2CDepotConnectedAssetValueNext> regionListFive = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
				
				
				totalDepotAssetValuesByUsername = commB2CDepotConnectedAssetValueNextReposiory.findAllDepotConnectedAssetValueNextDetails();
		           

				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					for(CommB2CDepotConnectedAssetValueNext t : mocList){
						totalAssetAmount += t.getDepotConnetedAssetValue();

					}

					totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<CommB2CDepotConnectedAssetValueNext> categoryList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
					
					//filtered by category

					for(String c : category){
						for(CommB2CDepotConnectedAssetValueNext cat : totalDepotAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValueNext mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);
					for(CommB2CDepotConnectedAssetValueNext t : totalAssetValues){
						totalAssetAmount += t.getDepotConnetedAssetValue();

					}
					totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<CommB2CDepotConnectedAssetValueNext> accountList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
					
					for(String accnt : account){
						for(CommB2CDepotConnectedAssetValueNext acc : totalDepotAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValueNext mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(CommB2CDepotConnectedAssetValueNext t : totalAssetValues){
						totalAssetAmount += t.getDepotConnetedAssetValue();

					}
					totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);
				}
				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<CommB2CDepotConnectedAssetValueNext> accountList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
					List<CommB2CDepotConnectedAssetValueNext> filteredAccountCategoryList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();

					

					//filterd by account
					for(String accnt : account){
						for(CommB2CDepotConnectedAssetValueNext acc : totalDepotAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(CommB2CDepotConnectedAssetValueNext cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValueNext mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(CommB2CDepotConnectedAssetValueNext t : totalAssetValues){
						totalAssetAmount += t.getDepotConnetedAssetValue();
					}
					totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CDepotConnectedAssetValueNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CDepotConnectedAssetValueNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					
		
					
					totalAssetValues.addAll(regionList);
					for(CommB2CDepotConnectedAssetValueNext t : totalAssetValues){
						totalAssetAmount += t.getDepotConnetedAssetValue();
					}

					totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<CommB2CDepotConnectedAssetValueNext> filteredRegionAccountList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CDepotConnectedAssetValueNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CDepotConnectedAssetValueNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					
					//filtered by account

					for(String accnt : account){
						for(CommB2CDepotConnectedAssetValueNext acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					

					totalAssetValues.addAll(filteredRegionAccountList);

					for(CommB2CDepotConnectedAssetValueNext t : totalAssetValues){
						totalAssetAmount += t.getDepotConnetedAssetValue();

					}
					totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);
				}
				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<CommB2CDepotConnectedAssetValueNext> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CDepotConnectedAssetValueNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CDepotConnectedAssetValueNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					
					
					//filtered by category

					for(String c : category){
						for(CommB2CDepotConnectedAssetValueNext cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
				


					totalAssetValues.addAll(filteredRegionCategoryList);
					for(CommB2CDepotConnectedAssetValueNext t : totalAssetValues){
						totalAssetAmount += t.getDepotConnetedAssetValue();
					}
					totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);
				}	
				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<CommB2CDepotConnectedAssetValueNext> accountList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
					List<CommB2CDepotConnectedAssetValueNext> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetValueNext>();
					
					if(totalDepotAssetValuesByUsername !=null)	{
						
						//filtered by MOC
						for(String m : moc){
							for(CommB2CDepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}
							
						}
						 // filterd by region		

						if(region.size() == 1){
							//filter by region
							for(String regon : region){
								for(CommB2CDepotConnectedAssetValueNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find()){
										regionListOne.add(reg); 
									}

								}

							}
							regionList.addAll(regionListOne);
		                      
						}

						if(region.size()>1){
							int count =1;
							for(String regon : region){
								if(count==1){
									for(CommB2CDepotConnectedAssetValueNext reg : mocList){
										Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher = pattern.matcher(reg.getRegionName());

										if(matcher.find() && count<mocList.size()){
											regionListOne.add(reg); 

										}
									}
									regionList.addAll(regionListOne);
								
									
								}

								if(count==2){
									regionList.clear();
									mocList.removeAll(regionListOne);

									for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListTwo.add(reg1); 

										}	

									}
									
									regionListOne.addAll(regionListTwo);
									regionList.addAll(regionListOne);
									
								}

								if(count==3){
									regionList.clear();
									mocList.removeAll(regionListTwo);
									for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListThree.add(reg1); 

										}	

									}
									regionListOne.addAll(regionListThree);
									regionList.addAll(regionListOne);
									
								}

		                       
								if(count==4){
									regionList.clear();
									mocList.removeAll(regionListThree);
									for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListFour.add(reg1); 

										}	

									}
									regionListOne.addAll(regionListFour);
									regionList.addAll(regionListOne);
									
								}


								if(count==5){
									regionList.clear();
									mocList.removeAll(regionListFour);
									for(CommB2CDepotConnectedAssetValueNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListFive.add(reg1); 

										}	

									}
									regionListOne.addAll(regionListFive);
									regionList.addAll(regionListOne);
									
								}


								count++;
							
							}

						}// end of if
						

						//-----filter by account------//

						for(String accnt : account){
							for(CommB2CDepotConnectedAssetValueNext acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(CommB2CDepotConnectedAssetValueNext cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						

						totalAssetValues.addAll(filteredRegionCategoryList);

						for(CommB2CDepotConnectedAssetValueNext t : totalAssetValues){
							totalAssetAmount += t.getDepotConnetedAssetValue();
						}

						totalAssetAmountSum.setDepotConnetedAssetValue(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetAmountSum;

		}


		//=======================Start Depot connected Asset Volume===========================================//

		public CommB2CDepotConnectedAssetVolumeNext getNextMocAllDepotConnectedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

			Double totalAssetVolume = 0.00;
			CommB2CDepotConnectedAssetVolumeNext totalAssetVolumeSum= new CommB2CDepotConnectedAssetVolumeNext();
			//Integer totalAssetVolumeSum = 0;

			try{
				List<CommB2CDepotConnectedAssetVolumeNext> totalAssetVolumes = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				List<CommB2CDepotConnectedAssetVolumeNext> totalDepotAssetVolumeByUsername = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				List<CommB2CDepotConnectedAssetVolumeNext> mocList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				
				List<CommB2CDepotConnectedAssetVolumeNext> regionList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				List<CommB2CDepotConnectedAssetVolumeNext> regionListOne = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				List<CommB2CDepotConnectedAssetVolumeNext> regionListTwo = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				List<CommB2CDepotConnectedAssetVolumeNext> regionListThree = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				List<CommB2CDepotConnectedAssetVolumeNext> regionListFour = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				List<CommB2CDepotConnectedAssetVolumeNext> regionListFive = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				
				
				totalDepotAssetVolumeByUsername = commB2CDepotConnectedAssetVolumeNextReposiory.findAllDepotConnectedAsstVolumeNextDetails();


				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					
					for(CommB2CDepotConnectedAssetVolumeNext t : mocList){
						totalAssetVolume += t.getDepotConnetedAssetVolume();

					}

					totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<CommB2CDepotConnectedAssetVolumeNext> categoryList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();

					
					//filtered by category

					for(String c : category){
						for(CommB2CDepotConnectedAssetVolumeNext cat : totalDepotAssetVolumeByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolumeNext mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(CommB2CDepotConnectedAssetVolumeNext t : mocList){
						totalAssetVolume += t.getDepotConnetedAssetVolume();

					}

					totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);

				
				
				
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<CommB2CDepotConnectedAssetVolumeNext> accountList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
					
					for(String accnt : account){
						for(CommB2CDepotConnectedAssetVolumeNext acc : totalDepotAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolumeNext mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					


					totalAssetVolumes.addAll(mocList);

					for(CommB2CDepotConnectedAssetVolumeNext t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnetedAssetVolume();

					}
					totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);
				}


				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<CommB2CDepotConnectedAssetVolumeNext> accountList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
					List<CommB2CDepotConnectedAssetVolumeNext> filteredAccountCategoryList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();


					//filterd by account
					for(String accnt : account){
						for(CommB2CDepotConnectedAssetVolumeNext acc : totalDepotAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(CommB2CDepotConnectedAssetVolumeNext cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolumeNext mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(CommB2CDepotConnectedAssetVolumeNext t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnetedAssetVolume();
					}
					totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					
					
					totalAssetVolumes.addAll(regionList);
					for(CommB2CDepotConnectedAssetVolumeNext t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnetedAssetVolume();
					}

					totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);
				}

				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<CommB2CDepotConnectedAssetVolumeNext> filteredRegionAccountList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					
					//filtered by account

					for(String accnt : account){
						for(CommB2CDepotConnectedAssetVolumeNext acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					

					totalAssetVolumes.addAll(filteredRegionAccountList);

					for(CommB2CDepotConnectedAssetVolumeNext t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnetedAssetVolume();

					}
					totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<CommB2CDepotConnectedAssetVolumeNext> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
				
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					
					

					//filtered by category

					for(String c : category){
						for(CommB2CDepotConnectedAssetVolumeNext cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					
					totalAssetVolumes.addAll(filteredRegionCategoryList);
					for(CommB2CDepotConnectedAssetVolumeNext t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnetedAssetVolume();
					}
					totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);
				}	


				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<CommB2CDepotConnectedAssetVolumeNext> accountList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
					List<CommB2CDepotConnectedAssetVolumeNext> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetVolumeNext>();
					
					if(totalDepotAssetVolumeByUsername !=null)	{
						
						//filtered by MOC
						for(String m : moc){
							for(CommB2CDepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}
							
						}
						 // filterd by region		

						if(region.size() == 1){
							//filter by region
							for(String regon : region){
								for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find()){
										regionListOne.add(reg); 
									}

								}

							}
							regionList.addAll(regionListOne);
		                      
						}

						if(region.size()>1){
							int count =1;
							for(String regon : region){
								if(count==1){
									for(CommB2CDepotConnectedAssetVolumeNext reg : mocList){
										Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher = pattern.matcher(reg.getRegionName());

										if(matcher.find() && count<mocList.size()){
											regionListOne.add(reg); 

										}
									}
									regionList.addAll(regionListOne);
								
									
								}

								if(count==2){
									regionList.clear();
									mocList.removeAll(regionListOne);

									for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListTwo.add(reg1); 

										}	

									}
									
									regionListOne.addAll(regionListTwo);
									regionList.addAll(regionListOne);
									
								}

								if(count==3){
									regionList.clear();
									mocList.removeAll(regionListTwo);
									for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListThree.add(reg1); 

										}	

									}
									regionListOne.addAll(regionListThree);
									regionList.addAll(regionListOne);
									
								}

		                       
								if(count==4){
									regionList.clear();
									mocList.removeAll(regionListThree);
									for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListFour.add(reg1); 

										}	

									}
									regionListOne.addAll(regionListFour);
									regionList.addAll(regionListOne);
									
								}


								if(count==5){
									regionList.clear();
									mocList.removeAll(regionListFour);
									for(CommB2CDepotConnectedAssetVolumeNext reg1 : mocList){
										Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
										Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

										if(matcher1.find() ){
											regionListFive.add(reg1); 

										}	

									}
									regionListOne.addAll(regionListFive);
									regionList.addAll(regionListOne);
									
								}


								count++;
							
							}

						}// end of if
						
						
						
						
						//-----filter by account------//

						for(String accnt : account){
							for(CommB2CDepotConnectedAssetVolumeNext acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(CommB2CDepotConnectedAssetVolumeNext cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						
						totalAssetVolumes.addAll(filteredRegionCategoryList);

						for(CommB2CDepotConnectedAssetVolumeNext t : totalAssetVolumes){
							totalAssetVolume += t.getDepotConnetedAssetVolume();
						}

						totalAssetVolumeSum.setDepotConnetedAssetVolume(totalAssetVolume);

					}//end of if

				}// end of else if
			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetVolumeSum;

		}










}
