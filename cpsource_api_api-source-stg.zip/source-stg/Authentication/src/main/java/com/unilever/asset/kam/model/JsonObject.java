package com.unilever.asset.kam.model;

public class JsonObject {

	private Double totalAssetValue;
	private Integer totalAssetVolume;
	private Double depotConnectedAssetValue;
	private Integer depotConnectedAssetVolume;
	private Double deployedAssetValue;
	private Integer deployedAssetVolume;
	private Double complieddAssetValue;
	private Integer compliedAssetVolume;
	private Double notComplieddAssetValue;
	private Integer notCompliedAssetVolume;
	
	
	public JsonObject() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Double getTotalAssetValue() {
		return totalAssetValue;
	}
	public void setTotalAssetValue(Double totalAssetValue) {
		this.totalAssetValue = totalAssetValue;
	}
	public Integer getTotalAssetVolume() {
		return totalAssetVolume;
	}
	public void setTotalAssetVolume(Integer totalAssetVolume) {
		this.totalAssetVolume = totalAssetVolume;
	}


	public Double getDepotConnectedAssetValue() {
		return depotConnectedAssetValue;
	}


	public void setDepotConnectedAssetValue(Double depotConnectedAssetValue) {
		this.depotConnectedAssetValue = depotConnectedAssetValue;
	}


	public Integer getDepotConnectedAssetVolume() {
		return depotConnectedAssetVolume;
	}


	public void setDepotConnectedAssetVolume(Integer depotConnectedAssetVolume) {
		this.depotConnectedAssetVolume = depotConnectedAssetVolume;
	}


	public Double getDeployedAssetValue() {
		return deployedAssetValue;
	}


	public void setDeployedAssetValue(Double deployedAssetValue) {
		this.deployedAssetValue = deployedAssetValue;
	}


	public Integer getDeployedAssetVolume() {
		return deployedAssetVolume;
	}


	public void setDeployedAssetVolume(Integer deployedAssetVolume) {
		this.deployedAssetVolume = deployedAssetVolume;
	}


	public Double getComplieddAssetValue() {
		return complieddAssetValue;
	}


	public void setComplieddAssetValue(Double complieddAssetValue) {
		this.complieddAssetValue = complieddAssetValue;
	}


	public Integer getCompliedAssetVolume() {
		return compliedAssetVolume;
	}


	public void setCompliedAssetVolume(Integer compliedAssetVolume) {
		this.compliedAssetVolume = compliedAssetVolume;
	}


	public Double getNotComplieddAssetValue() {
		return notComplieddAssetValue;
	}


	public void setNotComplieddAssetValue(Double notComplieddAssetValue) {
		this.notComplieddAssetValue = notComplieddAssetValue;
	}


	public Integer getNotCompliedAssetVolume() {
		return notCompliedAssetVolume;
	}


	public void setNotCompliedAssetVolume(Integer notCompliedAssetVolume) {
		this.notCompliedAssetVolume = notCompliedAssetVolume;
	}
	
	
	
	
	
}
