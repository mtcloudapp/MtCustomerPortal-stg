package com.unilever.asset.commercialB2C.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalCount;
import com.unilever.global.GlobalVariables;

@Repository
public interface CommB2CStoreListTotalCountReposiory extends JpaRepository<CommB2CStoreListTotalCount, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_STORE_LIST_TOTAL_COUNT", nativeQuery = true)
	List<CommB2CStoreListTotalCount> findAllStoreListTotalCountDetails();
}
