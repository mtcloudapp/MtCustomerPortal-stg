package com.unilever.claims.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.kam.model.GreenClaimVolume;
import com.unilever.global.GlobalVariables;

@Repository
public interface GreenClaimsVolumeRepository extends JpaRepository<GreenClaimVolume, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_GREEN_CLAIMS_VOLUME tac where tac.USERNAME=:username", nativeQuery = true)
	List<GreenClaimVolume> findAllGreenClaimVolume(@Param("username") String username);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_GREEN_CLAIMS_VOLUME", nativeQuery = true)
	List<GreenClaimVolume> findAllGreenClaimVolumeDetails();
	

}
