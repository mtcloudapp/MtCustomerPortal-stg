package com.unilever.promo.commb2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "COMMB2C_TOTAL_PLANNED_PROMO_VALUE")
public class CommB2CTotalPlannedPromoValue implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7863390757242576326L;
	

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	
	@Column(name="ACCOUNT_NAME")
    private String accountName;
	
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="TOTAL_PLANNED_PROMO_VALUE")
    private Double totalPlannedPromoValue;

	public CommB2CTotalPlannedPromoValue() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommB2CTotalPlannedPromoValue(Integer rECORD_ID, String regionName, String accountName, String categoryNaame,
			String moc, Double totalPlannedPromoValue) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.accountName = accountName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.totalPlannedPromoValue = totalPlannedPromoValue;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getTotalPlannedPromoValue() {
		return totalPlannedPromoValue;
	}

	public void setTotalPlannedPromoValue(Double totalPlannedPromoValue) {
		this.totalPlannedPromoValue = totalPlannedPromoValue;
	}
	
	
	

}
