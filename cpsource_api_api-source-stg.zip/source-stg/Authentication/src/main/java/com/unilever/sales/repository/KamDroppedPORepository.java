package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.KamDroppedPO;

@Repository
public interface KamDroppedPORepository extends JpaRepository<KamDroppedPO, Integer>{
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.USERNAME in :username", nativeQuery = true)
	Integer findKamNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,
			@Param("category") List<String> category,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.USERNAME in :username and tac.REASON=:reason", nativeQuery = true)
	List<Integer> findKamNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("username") List<String> username,@Param("reason") String reason);
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.USERNAME in :username and tac.REASON=:reason and tac.PO_NUMBER in :poNumber", nativeQuery = true)
	List<Integer> findKamNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("username") List<String> username,@Param("reason") String reason,@Param("poNumber") List<String> poNumber);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch  and tac.USERNAME in :username", nativeQuery = true)
	Integer findkamDroppedPONoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch
			,@Param("username") List<String> username);
	
	//=====================================================================================================================
		@Transactional
	    @Query(value ="select DISTINCT tac.REASON from "+GlobalVariables.schemaName+".INT_DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
	    		+ " tac.BRANCH in :branch and tac.USERNAME in :username", nativeQuery = true)
		List<String> findkamReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("username") List<String> username);
		
		@Transactional
	    @Query(value ="select DISTINCT tac.REASON from "+GlobalVariables.schemaName+".INT_DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
	    		+ " tac.BRANCH in :branch and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
		List<String> findKamReasonByPoNumber(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);
		
	

}
