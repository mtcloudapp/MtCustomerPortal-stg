package com.unilever.promo.claim.kam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.kam.service.PromoClaimKamService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimKamController {

	@Autowired
	PromoClaimKamService promoClaimKamService;

	@PutMapping("/updateNosolCodeByKAM")
	public ResponseMessage updateNosolCodeByKAM(@RequestParam("solcodeRevised") Integer solcodeRevised,@RequestParam("solcode") Integer solcode, 
			@RequestParam("basepack") Integer basepack,@RequestParam("articleCode") Integer articleCode){

		ResponseMessage response = new ResponseMessage();
		try{
			response = promoClaimKamService.updateNoSoleCodeByKam(solcode, basepack, articleCode, solcodeRevised);

		   }
		catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}

	@PutMapping("/updateNoBasepackByKAM")
	public ResponseMessage updateNoBasepackByKAM(@RequestParam("basepackRevised") Integer basepackRevised,@RequestParam("solcode") Integer solcode, 
			@RequestParam("basepack") Integer basepack,@RequestParam("articleCode") Integer articleCode){

		ResponseMessage response = new ResponseMessage();
		try{
			response = promoClaimKamService.updateNoBasepackByKam(solcode, basepack, articleCode, basepackRevised);

		   }
		catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}
	
	//Added By Sarin Nov2021 - Claim File KAM Approval - Starts
	@PostMapping("/updatePromoClaimKamApproval")
	public ResponseMessage updatePromoClaimKamApproval(@RequestParam("account") String accountName, @RequestParam("moc") String moc,
			@RequestParam("kamUsername") String kamUsername, @RequestParam("kamAction") String kamAction,
			@RequestParam("claimType") String claimType) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = promoClaimKamService.doPromoClaimKamApproval(accountName, moc, kamUsername, kamAction, claimType);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}
	
	@GetMapping(path = "/getKamClaimNotification")
	public String getKamClaimNotification(@RequestParam("accountName") String accountName, @RequestParam("moc") String moc,
			@RequestParam("kamUsername") String kamUsername) {
		return promoClaimKamService.getKamClaimNotificationCount(accountName, moc, kamUsername);
	}
	//Added By Sarin Nov2021 - Claim File KAM Approval - Ends

	//Added By Sarin Mar2022 - POS File KAM Approval - Starts
	@PostMapping("/updatePosFileKamApproval")
	public ResponseMessage updatePosFileKamApproval(@RequestParam("account") String accountName, @RequestParam("moc") String moc,
			@RequestParam("kamUsername") String kamUsername, @RequestParam("kamAction") String kamAction,
			@RequestParam("claimType") String claimType) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = promoClaimKamService.doPosFileKamApproval(accountName, moc, kamUsername, kamAction, claimType);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}
	
	@GetMapping(path = "/getKamPosNotification")
	public String getKamPosNotification(@RequestParam("accountName") String accountName, @RequestParam("moc") String moc,
			@RequestParam("kamUsername") String kamUsername) {
		return promoClaimKamService.getKamPosNotificationCount(accountName, moc, kamUsername);
	}
	//Added By Sarin Mar2022 - POS File KAM Approval - Ends
}
