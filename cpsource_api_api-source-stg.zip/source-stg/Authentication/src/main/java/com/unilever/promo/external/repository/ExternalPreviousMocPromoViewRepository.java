package com.unilever.promo.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.external.model.PreviousMocExternalPromoView;

@Repository
public interface ExternalPreviousMocPromoViewRepository extends PagingAndSortingRepository<PreviousMocExternalPromoView, String> {
	
	//==================================================================================================================================
			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account", nativeQuery = true)
			Page<PreviousMocExternalPromoView> findExternalPreviousMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account,Pageable pageable);
		    
			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account", nativeQuery = true)
			List<PreviousMocExternalPromoView> findCountExternalPreviousMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account);

		//=======================================================================	
			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.CATEGORY in :category", nativeQuery = true)
			Page<PreviousMocExternalPromoView> findExternalPreviousMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,Pageable pageable);

			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.CATEGORY in :category", nativeQuery = true)
			List<PreviousMocExternalPromoView> findCountExternalPreviousMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category);

		//=======================================
			
			
			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.REGION in :region", nativeQuery = true)
			Page<PreviousMocExternalPromoView> findExternalPreviousMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,Pageable pageable);

			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.REGION in :region", nativeQuery = true)
			List<PreviousMocExternalPromoView> findCountExternalPreviousMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region);

			
		//======================================================	
			
			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L2_CUSTOMER=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
			Page<PreviousMocExternalPromoView> findExternalPreviousMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region,Pageable pageable);


			@Transactional
			@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_PREV_PROMO ecn  where ecn.MOC in :moc and ecn.L2_CUSTOMER=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
			List<PreviousMocExternalPromoView> findCountExternalPreviousMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region);


}
