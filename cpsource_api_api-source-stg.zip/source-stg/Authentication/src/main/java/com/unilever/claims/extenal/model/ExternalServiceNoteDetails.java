package com.unilever.claims.extenal.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_SERVICE_NOTE_DETAILS")
public class ExternalServiceNoteDetails implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6971680989174696948L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
    private Integer id;
	
	@Column(name="SOL_CODE")
    private String solCOde;
	
	@Column(name="STATE")
    private String state;
	
	@Column(name="FILE_NAME")
    private String fileName;
	
	@Column(name="UPLOAD_TIMESTAMP")
    private String uploadTime;
	
	@Column(name="INVOICE_NO")
    private String invoiceNo;
	

	public ExternalServiceNoteDetails() {
		super();
		// TODO Auto-generated constructor stub
	}


	

	public ExternalServiceNoteDetails(Integer id, String solCOde, String state, String fileName, String uploadTime,
			String invoiceNo) {
		super();
		this.id = id;
		this.solCOde = solCOde;
		this.state = state;
		this.fileName = fileName;
		this.uploadTime = uploadTime;
		this.invoiceNo = invoiceNo;
	}




	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSolCOde() {
		return solCOde;
	}

	public void setSolCOde(String solCOde) {
		this.solCOde = solCOde;
	}

	
	
	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	
}
