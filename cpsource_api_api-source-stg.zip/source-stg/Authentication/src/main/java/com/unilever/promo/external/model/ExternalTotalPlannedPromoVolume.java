package com.unilever.promo.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_TOTAL_PLANNED_PROMO_VOLUME")
public class ExternalTotalPlannedPromoVolume implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5761873596214793851L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="USERNAME")
    private String userName;
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="TOTAL_PLANNED_PROMO_VOLUME")
    private Double totalPlannedPromoVolume;

	public ExternalTotalPlannedPromoVolume() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExternalTotalPlannedPromoVolume(Integer rECORD_ID, String regionName, String userName, String categoryNaame,
			String moc, Double totalPlannedPromoVolume) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.userName = userName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.totalPlannedPromoVolume = totalPlannedPromoVolume;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getTotalPlannedPromoVolume() {
		return totalPlannedPromoVolume;
	}

	public void setTotalPlannedPromoVolume(Double totalPlannedPromoVolume) {
		this.totalPlannedPromoVolume = totalPlannedPromoVolume;
	}
	
	

}
