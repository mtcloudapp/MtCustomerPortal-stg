package com.unilever.asset.commercialB2C.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "COMMB2C_COMPLIED_ASSETS_VOLUME")
public class CommB2CCompliedAssetVolume implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2456789677979549211L;
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	
	@Column(name="ACCOUNT_NAME")
    private String accountName;
	
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="COMPLIED_ASSETS_VOLUME")
    private Double totalCompliedAssetVolume;

	public CommB2CCompliedAssetVolume() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getTotalCompliedAssetVolume() {
		return totalCompliedAssetVolume;
	}

	public void setTotalCompliedAssetVolume(Double totalCompliedAssetVolume) {
		this.totalCompliedAssetVolume = totalCompliedAssetVolume;
	}
	
}
