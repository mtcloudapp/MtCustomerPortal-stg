package com.unilever.promo.claim.external.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaimsExceptionAttachment;

@Repository
public interface PromoClaimsExceptionAttachmntRepository extends JpaRepository<PromoClaimsExceptionAttachment, Integer>{

	@Transactional 
    @Query(value ="select cmf.UPLOADED_FILE_NAME  from "+GlobalVariables.schemaName+".PROMO_CLAIMS_EXCEPTION_ATTACHMENT cmf where cmf.ACCOUNT_NAME=:account and cmf.MOC=:moc", nativeQuery = true)
	Set<String> findFilesByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
	
}
