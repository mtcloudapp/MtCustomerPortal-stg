package com.unilever.sales.async.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.unilever.claims.asyncs.service.AssetClaimAsyncsService;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPayableCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPlannedCommb2c;
import com.unilever.claims.commecialB2C.service.CommercialB2CClaimsService;
import com.unilever.claims.extenal.model.ApprovedExceptionClaimsValueExternal;
import com.unilever.claims.extenal.model.ApprovedExceptionClaimsVolumeExternal;
import com.unilever.claims.extenal.model.RejectedClaimValueExternal;
import com.unilever.claims.extenal.model.RejectedClaimVolumeExternal;
import com.unilever.claims.extenal.model.UnpaidClaimsValueExternal;
import com.unilever.claims.external.service.ExternalAssetClaimsService;
import com.unilever.claims.kam.model.ApprovedExceptionClaimValue;
import com.unilever.claims.kam.model.ApprovedExceptionClaimVolume;
import com.unilever.claims.kam.model.ClaimsRaised;
import com.unilever.claims.kam.model.GreenClaimValue;
import com.unilever.claims.kam.model.GreenClaimVolume;
import com.unilever.claims.kam.model.RedClaimValue;
import com.unilever.claims.kam.model.RedClaimVolume;
import com.unilever.claims.kam.model.TotalAmountPaid;
import com.unilever.claims.kam.model.TotalAmountPayable;
import com.unilever.claims.kam.model.TotalAmountPending;
import com.unilever.claims.kam.model.TotalAmountPlanned;
import com.unilever.claims.kam.service.AssetClaimsService;
import com.unilever.sales.service.SalesService;

@Service
public class SalesAsyncService {
	
private static Logger log = LoggerFactory.getLogger(AssetClaimAsyncsService.class);
	
	@Autowired
	SalesService salesService;
	
	@Autowired
	CommercialB2CClaimsService commercialB2CService;
	
	@Autowired
	ExternalAssetClaimsService externalAssetClaimsService;
	
	
	//================================ KAM Service =====================================//
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoCount=0;
		try{
			log.info("Total Po Count starts");

			totalPoCount = salesService.getTotalPoCount(username, region, account, moc, category);
			log.info("totalPoCountData, {}", totalPoCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoLineCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

  		Integer totalPoLineCount=0;
		try{
			log.info("Total Po Count starts");

			totalPoLineCount = salesService.getPoLineCount(username, region, account, moc, category);
			log.info("totalPoLineCountData, {}", totalPoLineCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoLineCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoLineCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoValueCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoValueCount=0;
		try{
			log.info("Total Po Value starts");

			totalPoValueCount = salesService.getTotalPoValue(username, region, account, moc, category);
			log.info("totalPoValueCountData, {}", totalPoValueCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoValueCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoValueCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoDroppedCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category,boolean isAll) throws InterruptedException{ 

		Integer totalPoDroppedCount=0;
		try{
			log.info("Total Po Dropped count starts");

			totalPoDroppedCount = salesService.getPoDroppedCount(username, region, account, moc, category,isAll);
			log.info("totalPoDroppedCountData, {}", totalPoDroppedCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoDroppedCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoDroppedCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoAllocatedCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoAllocatedCount=0;
		try{
			log.info("Total Po Allocated count starts");

			totalPoAllocatedCount = salesService.getPoAllocatedCount(username, region, account, moc, category);
			log.info("totalPoAllocatedCountData, {}", totalPoAllocatedCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoAllocatedCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoAllocatedCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Double> getTotalPoAllocatedValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalPoAllocatedValue=0.00;
		try{
			log.info("Total Po Allocated value starts");

			totalPoAllocatedValue = salesService.getPoAllocatedValue(username, region, account, moc, category);
			log.info("totalPoAllocatedValueData, {}", totalPoAllocatedValue);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoAllocatedValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoAllocatedValue);
	}

	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoInvoicedCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoInvoicedCount=0;
		try{
			log.info("Total Po Allocated value starts");

			totalPoInvoicedCount = salesService.getPoInvoicedCount(username, region, account, moc, category);
			log.info("totalPoInvoicedCountData, {}", totalPoInvoicedCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoInvoicedCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoInvoicedCount);
	}

	@Async("asyncExecutor")
	public CompletableFuture<Double> getTotalPoInvoicedValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalPoInvoicedValue=0.00;
		try{
			log.info("Total Po Allocated value starts");

			totalPoInvoicedValue = salesService.getPoInvoicedValue(username, region, account, moc, category);
			log.info("totalPoInvoicedValueData, {}", totalPoInvoicedValue);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoInvoicedValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoInvoicedValue);
	}

	
	//============================================B2C Service =========================================================//
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoCountB2c(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoCount=0;
		try{
			log.info("Total Po Count starts");

			totalPoCount = salesService.getTotalPoCountB2c(region, account, moc, category);
			log.info("totalPoCountData, {}", totalPoCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoLineCountB2c(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

  		Integer totalPoLineCount=0;
		try{
			log.info("Total Po Count starts");

			totalPoLineCount = salesService.getPoLineCountB2c(region, account, moc, category);
			log.info("totalPoLineCountData, {}", totalPoLineCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoLineCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoLineCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoValueCountB2c(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoValueCount=0;
		try{
			log.info("Total Po Value starts");

			totalPoValueCount = salesService.getTotalPoValueB2c(region, account, moc, category);
			log.info("totalPoValueCountData, {}", totalPoValueCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoValueCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoValueCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoDroppedCountB2c(List<String> region,List<String> account,List<String> moc,List<String> category,boolean isAll) throws InterruptedException{ 

		Integer totalPoDroppedCount=0;
		try{
			log.info("Total Po Dropped count starts");

			totalPoDroppedCount = salesService.getPoDroppedCountB2c(region, account, moc, category,isAll);
			log.info("totalPoDroppedCountData, {}", totalPoDroppedCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoDroppedCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoDroppedCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoAllocatedCountB2c(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoAllocatedCount=0;
		try{
			log.info("Total Po Allocated count starts");

			totalPoAllocatedCount = salesService.getPoAllocatedCountB2c(region, account, moc, category);
			log.info("totalPoAllocatedCountData, {}", totalPoAllocatedCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoAllocatedCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoAllocatedCount);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Double> getTotalPoAllocatedValueB2c(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalPoAllocatedValue=0.00;
		try{
			log.info("Total Po Allocated value starts");

			totalPoAllocatedValue = salesService.getPoAllocatedValueB2c(region, account, moc, category);
			log.info("totalPoAllocatedValueData, {}", totalPoAllocatedValue);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoAllocatedValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoAllocatedValue);
	}

	@Async("asyncExecutor")
	public CompletableFuture<Integer> getTotalPoInvoicedCountB2c(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer totalPoInvoicedCount=0;
		try{
			log.info("Total Po Allocated value starts");

			totalPoInvoicedCount = salesService.getPoInvoicedCountB2c(region, account, moc, category);
			log.info("totalPoInvoicedCountData, {}", totalPoInvoicedCount);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoInvoicedCount completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoInvoicedCount);
	}

	@Async("asyncExecutor")
	public CompletableFuture<Double> getTotalPoInvoicedValueB2c(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalPoInvoicedValue=0.00;
		try{
			log.info("Total Po Allocated value starts");

			totalPoInvoicedValue = salesService.getPoInvoicedValueB2c(region, account, moc, category);
			log.info("totalPoInvoicedValueData, {}", totalPoInvoicedValue);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalPoInvoicedValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalPoInvoicedValue);
	}
	
	
	//============================================External Service =========================================================//
	
		@Async("asyncExecutor")
		public CompletableFuture<Integer> getTotalPoCountExternal(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

			Integer totalPoCount=0;
			try{
				log.info("Total Po Count starts");

				totalPoCount = salesService.getTotalPoCountExternal(username, region, moc, category);
				log.info("totalPoCountData, {}", totalPoCount);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoCount completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoCount);
		}
		
		@Async("asyncExecutor")
		public CompletableFuture<Integer> getTotalPoLineCountExternal(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

	  		Integer totalPoLineCount=0;
			try{
				log.info("Total Po Count starts");

				totalPoLineCount = salesService.getPoLineCountExternal(username, region, moc, category);
				log.info("totalPoLineCountData, {}", totalPoLineCount);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoLineCount completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoLineCount);
		}
		
		@Async("asyncExecutor")
		public CompletableFuture<Integer> getTotalPoValueCountExternal(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

			Integer totalPoValueCount=0;
			try{
				log.info("Total Po Value starts");

				totalPoValueCount = salesService.getTotalPoValueExternal(username, region, moc, category);
				log.info("totalPoValueCountData, {}", totalPoValueCount);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoValueCount completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoValueCount);
		}
		
		@Async("asyncExecutor")
		public CompletableFuture<Integer> getTotalPoDroppedCountExternal(String username,List<String> region,List<String> moc,List<String> category,boolean isAll) throws InterruptedException{ 

			Integer totalPoDroppedCount=0;
			try{
				log.info("Total Po Dropped count starts");

				totalPoDroppedCount = salesService.getPoDroppedCountExternal(username, region, moc, category,isAll);
				log.info("totalPoDroppedCountData, {}", totalPoDroppedCount);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoDroppedCount completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoDroppedCount);
		}
		
		@Async("asyncExecutor")
		public CompletableFuture<Integer> getTotalPoAllocatedCountExternal(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

			Integer totalPoAllocatedCount=0;
			try{
				log.info("Total Po Allocated count starts");

				totalPoAllocatedCount = salesService.getPoAllocatedCountExternal(username, region, moc, category);
				log.info("totalPoAllocatedCountData, {}", totalPoAllocatedCount);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoAllocatedCount completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoAllocatedCount);
		}
		
		@Async("asyncExecutor")
		public CompletableFuture<Double> getTotalPoAllocatedValueExternal(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

			Double totalPoAllocatedValue=0.00;
			try{
				log.info("Total Po Allocated value starts");

				totalPoAllocatedValue = salesService.getPoAllocatedValueExternal(username, region, moc, category);
				log.info("totalPoAllocatedValueData, {}", totalPoAllocatedValue);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoAllocatedValue completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoAllocatedValue);
		}

		@Async("asyncExecutor")
		public CompletableFuture<Integer> getTotalPoInvoicedCountExternal(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

			Integer totalPoInvoicedCount=0;
			try{
				log.info("Total Po Allocated value starts");

				totalPoInvoicedCount = salesService.getPoInvoicedCountExternal(username, region, moc, category);
				log.info("totalPoInvoicedCountData, {}", totalPoInvoicedCount);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoInvoicedCount completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoInvoicedCount);
		}

		@Async("asyncExecutor")
		public CompletableFuture<Double> getTotalPoInvoicedValueExternal(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

			Double totalPoInvoicedValue=0.00;
			try{
				log.info("Total Po Allocated value starts");

				totalPoInvoicedValue = salesService.getPoInvoicedValueExternal(username, region, moc, category);
				log.info("totalPoInvoicedValueData, {}", totalPoInvoicedValue);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalPoInvoicedValue completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalPoInvoicedValue);
		}


		
	
	
}
