package com.unilever.asset.external.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.unilever.asset.external.model.CustomerNonCompliantValue;
import com.unilever.asset.external.model.CustomerNonCompliantVolume;
import com.unilever.asset.external.model.ExternalCurentView;
import com.unilever.asset.external.model.ExternalCurrentMocViewDto;
import com.unilever.asset.external.model.ExternalCustomerNonCompliedAssetValuePrev;
import com.unilever.asset.external.model.ExternalCustomerNonCompliedAssetVolumePrev;
import com.unilever.asset.external.model.ExternalNextMocView;
import com.unilever.asset.external.model.ExternalNextMocViewDto;
import com.unilever.asset.external.model.ExternalOtherIssuseValuePrev;
import com.unilever.asset.external.model.ExternalOtherIssuseVolumePrev;
import com.unilever.asset.external.model.ExternalPreviousMocView;
import com.unilever.asset.external.model.ExternalPreviousMocViewDto;
import com.unilever.asset.external.model.OtherIssuesValue;
import com.unilever.asset.external.model.OtherIssuesVolume;
import com.unilever.asset.external.model.StoreListCount;
import com.unilever.asset.external.model.StoreListValue;
import com.unilever.asset.external.model.TotalAssetPlannedValue;
import com.unilever.asset.external.model.TotalAssetPlannedVolume;
import com.unilever.asset.external.model.TotalAssetValueExternal;
import com.unilever.asset.external.model.TotalAssetVolumeExternal;
import com.unilever.asset.external.model.TrackAndCompliedValue;
import com.unilever.asset.external.model.TrackAndCompliedVolume;
import com.unilever.asset.external.repository.CurrentNextMocViewRepository;
import com.unilever.asset.external.repository.CustomerNonCompientValuePrevRepository;
import com.unilever.asset.external.repository.CustomerNonComplientValueRepository;
import com.unilever.asset.external.repository.CustomerNonComplientVolumePrevRepository;
import com.unilever.asset.external.repository.CustomerNonComplientVolumeRepository;
import com.unilever.asset.external.repository.ExternalNextMocViewRepository;
import com.unilever.asset.external.repository.OtherIssuseValuePrevRepository;
import com.unilever.asset.external.repository.OtherIssuseValueRepository;
import com.unilever.asset.external.repository.OtherIssuseVolumePrevRepository;
import com.unilever.asset.external.repository.OtherIssuseVolumeRepository;
import com.unilever.asset.external.repository.PriviousMocViewRepository;
import com.unilever.asset.external.repository.StoreListCountRepository;
import com.unilever.asset.external.repository.StoreListValueRepository;
import com.unilever.asset.external.repository.TotalAssetCreatedValueExternalRepository;
import com.unilever.asset.external.repository.TotalAssetCreatedVolumeExternalRepository;
import com.unilever.asset.external.repository.TotalAssetPlannedValueRepository;
import com.unilever.asset.external.repository.TotalAssetPlannedVolumeRepository;
import com.unilever.asset.external.repository.TrackAndCompliedValueRepository;
import com.unilever.asset.external.repository.TrackAndCompliedVolumeRepository;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.asset.kam.model.NextMocViewDto;

@Service
public class ExternalAssetService {

	@Autowired
	TotalAssetCreatedValueExternalRepository totalAssetCreatedValueExternalRepository;

	@Autowired
	TotalAssetCreatedVolumeExternalRepository totalAssetCreatedVolumeExternalRepository;

	@Autowired
	TrackAndCompliedValueRepository trackAndCompliedValueRepository;

	@Autowired
	TrackAndCompliedVolumeRepository trackAndCompliedVolumeRepository;

	@Autowired
	CustomerNonComplientValueRepository customerNonComplientValueRepository;

	@Autowired
	CustomerNonComplientVolumeRepository customerNonComplientVolumeRepository;

	@Autowired
	OtherIssuseValueRepository otherIssuseValueRepository;

	@Autowired
	OtherIssuseVolumeRepository otherIssuseVolumeRepository;

	@Autowired
	StoreListValueRepository storeListValueRepository;

	@Autowired
	StoreListCountRepository storeListCountRepository;

	@Autowired
	TotalAssetPlannedValueRepository totalAssetPlannedValueRepository;

	@Autowired
	TotalAssetPlannedVolumeRepository totalAssetPlannedVolumeRepository;

	@Autowired
	CurrentNextMocViewRepository currentNextMocViewRepository;

	@Autowired
	PriviousMocViewRepository priviousMocViewRepository;
	
	@Autowired
	ExternalNextMocViewRepository nextMocViewRepository;
	
	@Autowired
	CustomerNonCompientValuePrevRepository customerNonCompientValuePrevRepository;
	
	@Autowired
	CustomerNonComplientVolumePrevRepository customerNonComplientVolumePrevRepository;

	@Autowired
	OtherIssuseValuePrevRepository otherIssuseValuePrevRepository;
	
	@Autowired
	OtherIssuseVolumePrevRepository otherIssuseVolumePrevRepository;


	public TotalAssetValueExternal getExternalTotalAssetCreatedValue(String username,List<String> region,List<String> moc,List<String> category){


		Integer totalAssetAmount = 0;
		//Integer totalAssetAmountSum = 0;
		TotalAssetValueExternal totalAssetAmountSum = new TotalAssetValueExternal();


		try{

			List<TotalAssetValueExternal> totalAssetValues = new ArrayList<TotalAssetValueExternal>();
			List<TotalAssetValueExternal> totalExternalData = new ArrayList<TotalAssetValueExternal>();
			List<TotalAssetValueExternal> mocList = new ArrayList<TotalAssetValueExternal>();

			totalExternalData = totalAssetCreatedValueExternalRepository.findAllTotalAssetCreatedValueExternalDetails(username);



			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetValueExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(TotalAssetValueExternal t : mocList){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}

				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<TotalAssetValueExternal> categoryList = new ArrayList<TotalAssetValueExternal>();

				//filtered by category

				for(String c : category){
					for(TotalAssetValueExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetValueExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(TotalAssetValueExternal t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}

				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<TotalAssetValueExternal> regionList = new ArrayList<TotalAssetValueExternal>();

				//filter by region
				for(String regon : region){
					for(TotalAssetValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetValueExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAssetValueExternal t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}

				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);

			}
			else if(region != null && moc !=null && category !=null  ){  //4
				List<TotalAssetValueExternal> regionList = new ArrayList<TotalAssetValueExternal>();
				List<TotalAssetValueExternal> filteredRegionCategoryList = new ArrayList<TotalAssetValueExternal>();

				//filterd by region

				for(String regon : region){
					for(TotalAssetValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(TotalAssetValueExternal cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetValueExternal mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAssetValueExternal t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}//end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	public TotalAssetVolumeExternal getExternalTotalAssetCreatedVolume(String username,List<String> region,List<String> moc,List<String> category){

		Integer totalAssetVolume = 0;
		TotalAssetVolumeExternal totalAssetVolumeSum= new TotalAssetVolumeExternal();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<TotalAssetVolumeExternal> totalExternalData = new ArrayList<TotalAssetVolumeExternal>();
			List<TotalAssetVolumeExternal> mocList = new ArrayList<TotalAssetVolumeExternal>();
			List<TotalAssetVolumeExternal> filteredList = new ArrayList<TotalAssetVolumeExternal>();


			totalExternalData = totalAssetCreatedVolumeExternalRepository.findAllTotalAssetCreatedVolumeExternalDetails(username);


			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetVolumeExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				for(TotalAssetVolumeExternal t : mocList){
					totalAssetVolume += t.getTotalAssetCreatedVolume();
				}

				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<TotalAssetVolumeExternal> categoryList = new ArrayList<TotalAssetVolumeExternal>();


				//filtered by category

				for(String c : category){
					for(TotalAssetVolumeExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetVolumeExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(TotalAssetVolumeExternal t : filteredList){
					totalAssetVolume += t.getTotalAssetCreatedVolume();
				}

				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<TotalAssetVolumeExternal> regionList = new ArrayList<TotalAssetVolumeExternal>();

				//filter by region
				for(String regon : region){
					for(TotalAssetVolumeExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetVolumeExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);
				for(TotalAssetVolumeExternal t : filteredList){
					totalAssetVolume += t.getTotalAssetCreatedVolume();
				}

				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);

			}


			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{
					List<TotalAssetVolumeExternal> regionList = new ArrayList<TotalAssetVolumeExternal>();
					List<TotalAssetVolumeExternal> filteredRegionCategoryList = new ArrayList<TotalAssetVolumeExternal>();

					//filterd by region

					for(String regon : region){
						for(TotalAssetVolumeExternal reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(TotalAssetVolumeExternal cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TotalAssetVolumeExternal mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);
					for(TotalAssetVolumeExternal t : filteredList){
						totalAssetVolume += t.getTotalAssetCreatedVolume();
					}

					totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}//Done

	//==========================================Track And Complied Value ====================================================

	public TrackAndCompliedValue getExternalTrackAndCompliedValue(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TrackAndCompliedValue totalAssetAmountSum = new TrackAndCompliedValue();


		try{

			List<TrackAndCompliedValue> totalExternalData = new ArrayList<TrackAndCompliedValue>();
			List<TrackAndCompliedValue> mocList = new ArrayList<TrackAndCompliedValue>();
			List<TrackAndCompliedValue> filteredList = new ArrayList<TrackAndCompliedValue>();

			totalExternalData = trackAndCompliedValueRepository.findAllTrackAndCompliedValueExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(TrackAndCompliedValue mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);
				for(TrackAndCompliedValue t : filteredList){
					totalAssetAmount += t.getCompliedAssetValue();
				}

				totalAssetAmountSum.setCompliedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null  ){   //2

				List<TrackAndCompliedValue> categoryList = new ArrayList<TrackAndCompliedValue>();

				//filtered by category

				for(String c : category){
					for(TrackAndCompliedValue cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TrackAndCompliedValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(TrackAndCompliedValue t : filteredList){
					totalAssetAmount += t.getCompliedAssetValue();
				}

				totalAssetAmountSum.setCompliedAssetValue(totalAssetAmount);

			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<TrackAndCompliedValue> regionList = new ArrayList<TrackAndCompliedValue>();

				//filter by region
				for(String regon : region){
					for(TrackAndCompliedValue reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TrackAndCompliedValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(TrackAndCompliedValue t : filteredList){
					totalAssetAmount += t.getCompliedAssetValue();
				}

				totalAssetAmountSum.setCompliedAssetValue(totalAssetAmount);

			}

			else if(region != null && moc !=null && category !=null  ){  //4

				if(totalExternalData !=null)	{
					List<TrackAndCompliedValue> regionList = new ArrayList<TrackAndCompliedValue>();
					List<TrackAndCompliedValue> filteredRegionCategoryList = new ArrayList<TrackAndCompliedValue>();

					//filterd by region

					for(String regon : region){
						for(TrackAndCompliedValue reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(TrackAndCompliedValue cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TrackAndCompliedValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);
					for(TrackAndCompliedValue t : filteredList){
						totalAssetAmount += t.getCompliedAssetValue();
					}

					totalAssetAmountSum.setCompliedAssetValue(totalAssetAmount);

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	//==========================================Track And Complied Volume ====================================================


	public TrackAndCompliedVolume getExternalTrackAndCompliedVolume(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TrackAndCompliedVolume totalAssetAmountSum = new TrackAndCompliedVolume();


		try{

			List<TrackAndCompliedVolume> totalExternalData = new ArrayList<TrackAndCompliedVolume>();
			List<TrackAndCompliedVolume> mocList = new ArrayList<TrackAndCompliedVolume>();
			List<TrackAndCompliedVolume> filteredList = new ArrayList<TrackAndCompliedVolume>();

			totalExternalData = trackAndCompliedVolumeRepository.findAllTrackAndCompliedVolumeExternalDetails(username);


			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(TrackAndCompliedVolume mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(TrackAndCompliedVolume t : filteredList){
					totalAssetAmount += t.getCompliedAssetVolume();
				}

				totalAssetAmountSum.setCompliedAssetVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<TrackAndCompliedVolume> categoryList = new ArrayList<TrackAndCompliedVolume>();

				//filtered by category

				for(String c : category){
					for(TrackAndCompliedVolume cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TrackAndCompliedVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(TrackAndCompliedVolume t : filteredList){
					totalAssetAmount += t.getCompliedAssetVolume();
				}

				totalAssetAmountSum.setCompliedAssetVolume(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<TrackAndCompliedVolume> regionList = new ArrayList<TrackAndCompliedVolume>();

				//filter by region
				for(String regon : region){
					for(TrackAndCompliedVolume reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TrackAndCompliedVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);


				for(TrackAndCompliedVolume t : filteredList){
					totalAssetAmount += t.getCompliedAssetVolume();
				}

				totalAssetAmountSum.setCompliedAssetVolume(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{
					List<TrackAndCompliedVolume> regionList = new ArrayList<TrackAndCompliedVolume>();
					List<TrackAndCompliedVolume> filteredRegionCategoryList = new ArrayList<TrackAndCompliedVolume>();

					//filterd by region

					for(String regon : region){
						for(TrackAndCompliedVolume reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(TrackAndCompliedVolume cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TrackAndCompliedVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(TrackAndCompliedVolume t : filteredList){
						totalAssetAmount += t.getCompliedAssetVolume();
					}

					totalAssetAmountSum.setCompliedAssetVolume(totalAssetAmount);

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}



	//=======================================Not Complient Asset Value======================================================

	public CustomerNonCompliantValue getExternalCustomerNonCompliantValueValue(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CustomerNonCompliantValue totalAssetAmountSum = new CustomerNonCompliantValue();


		try{

			List<CustomerNonCompliantValue> totalExternalData = new ArrayList<CustomerNonCompliantValue>();
			List<CustomerNonCompliantValue> mocList = new ArrayList<CustomerNonCompliantValue>();
			List<CustomerNonCompliantValue> filteredList = new ArrayList<CustomerNonCompliantValue>();

			totalExternalData = customerNonComplientValueRepository.findAllCustomerNonCompliantValueExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(CustomerNonCompliantValue mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);


				for(CustomerNonCompliantValue t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetValue();
				}

				totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null  ){   //2

				List<CustomerNonCompliantValue> categoryList = new ArrayList<CustomerNonCompliantValue>();

				//filtered by category

				for(String c : category){
					for(CustomerNonCompliantValue cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CustomerNonCompliantValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(CustomerNonCompliantValue t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetValue();
				}

				totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);

			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<CustomerNonCompliantValue> regionList = new ArrayList<CustomerNonCompliantValue>();

				//filter by region
				for(String regon : region){
					for(CustomerNonCompliantValue reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CustomerNonCompliantValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(CustomerNonCompliantValue t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetValue();
				}

				totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);

			}

			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{

					List<CustomerNonCompliantValue> regionList = new ArrayList<CustomerNonCompliantValue>();
					List<CustomerNonCompliantValue> filteredRegionCategoryList = new ArrayList<CustomerNonCompliantValue>();

					//filterd by region

					for(String regon : region){
						for(CustomerNonCompliantValue reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(CustomerNonCompliantValue cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(CustomerNonCompliantValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(CustomerNonCompliantValue t : filteredList){
						totalAssetAmount += t.getNonCompliedAssetValue();
					}

					totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);


				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	//=======================================Not Complient Asset Volume=======================================================

	public CustomerNonCompliantVolume getExternalCustomerNonCompliantVolume(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CustomerNonCompliantVolume totalAssetAmountSum = new CustomerNonCompliantVolume();


		try{

			List<CustomerNonCompliantVolume> totalExternalData = new ArrayList<CustomerNonCompliantVolume>();
			List<CustomerNonCompliantVolume> mocList = new ArrayList<CustomerNonCompliantVolume>();
			List<CustomerNonCompliantVolume> filteredList = new ArrayList<CustomerNonCompliantVolume>();

			totalExternalData = customerNonComplientVolumeRepository.findAllCustomerNonCompliantVolumeExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1


				//filtered by MOC
				for(String m : moc){
					for(CustomerNonCompliantVolume mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(CustomerNonCompliantVolume t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetVolume();
				}

				totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<CustomerNonCompliantVolume> categoryList = new ArrayList<CustomerNonCompliantVolume>();

				//filtered by category

				for(String c : category){
					for(CustomerNonCompliantVolume cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CustomerNonCompliantVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);
				for(CustomerNonCompliantVolume t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetVolume();
				}

				totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<CustomerNonCompliantVolume> regionList = new ArrayList<CustomerNonCompliantVolume>();

				//filter by region
				for(String regon : region){
					for(CustomerNonCompliantVolume reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CustomerNonCompliantVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(CustomerNonCompliantVolume t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetVolume();
				}

				totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{
					List<CustomerNonCompliantVolume> regionList = new ArrayList<CustomerNonCompliantVolume>();
					List<CustomerNonCompliantVolume> filteredRegionCategoryList = new ArrayList<CustomerNonCompliantVolume>();

					//filterd by region

					for(String regon : region){
						for(CustomerNonCompliantVolume reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(CustomerNonCompliantVolume cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(CustomerNonCompliantVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(CustomerNonCompliantVolume t : filteredList){
						totalAssetAmount += t.getNonCompliedAssetVolume();
					}

					totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	//============================================Other Issuses Value==========================================================

	public OtherIssuesValue getExternalOtherIssuesValue(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		OtherIssuesValue totalAssetAmountSum = new OtherIssuesValue();


		try{

			List<OtherIssuesValue> totalExternalData = new ArrayList<OtherIssuesValue>();
			List<OtherIssuesValue> mocList = new ArrayList<OtherIssuesValue>();
			List<OtherIssuesValue> filteredList = new ArrayList<OtherIssuesValue>();

			totalExternalData = otherIssuseValueRepository.findAllOtherIssuesValueExternalDetails(username);


			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1


				//filtered by MOC
				for(String m : moc){
					for(OtherIssuesValue mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);
				for(OtherIssuesValue t : filteredList){
					totalAssetAmount += t.getOtheIssuesValue();
				}

				totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<OtherIssuesValue> categoryList = new ArrayList<OtherIssuesValue>();

				//filtered by category

				for(String c : category){
					for(OtherIssuesValue cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(OtherIssuesValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);
				for(OtherIssuesValue t : filteredList){
					totalAssetAmount += t.getOtheIssuesValue();
				}

				totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);

			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<OtherIssuesValue> regionList = new ArrayList<OtherIssuesValue>();

				//filter by region
				for(String regon : region){
					for(OtherIssuesValue reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(OtherIssuesValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(OtherIssuesValue t : filteredList){
					totalAssetAmount += t.getOtheIssuesValue();
				}

				totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);

			}

			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{

					List<OtherIssuesValue> regionList = new ArrayList<OtherIssuesValue>();
					List<OtherIssuesValue> filteredRegionCategoryList = new ArrayList<OtherIssuesValue>();

					//filterd by region

					for(String regon : region){
						for(OtherIssuesValue reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(OtherIssuesValue cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(OtherIssuesValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(OtherIssuesValue t : filteredList){
						totalAssetAmount += t.getOtheIssuesValue();
					}

					totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);


				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}



	//============================================Other Issuses Volumee==========================================================

	public OtherIssuesVolume getExternalOtherIssuesVolume(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		OtherIssuesVolume totalAssetAmountSum = new OtherIssuesVolume();


		try{

			List<OtherIssuesVolume> totalExternalData = new ArrayList<OtherIssuesVolume>();
			List<OtherIssuesVolume> mocList = new ArrayList<OtherIssuesVolume>();
			List<OtherIssuesVolume> filteredList = new ArrayList<OtherIssuesVolume>();

			totalExternalData = otherIssuseVolumeRepository.findAllOtherIssuesVolumeExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(OtherIssuesVolume mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(OtherIssuesVolume t : filteredList){
					totalAssetAmount += t.getOtheIssuesVolume();
				}

				totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<OtherIssuesVolume> categoryList = new ArrayList<OtherIssuesVolume>();

				//filtered by category

				for(String c : category){
					for(OtherIssuesVolume cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(OtherIssuesVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(OtherIssuesVolume t : filteredList){
					totalAssetAmount += t.getOtheIssuesVolume();
				}

				totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<OtherIssuesVolume> regionList = new ArrayList<OtherIssuesVolume>();

				//filter by region
				for(String regon : region){
					for(OtherIssuesVolume reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(OtherIssuesVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(OtherIssuesVolume t : filteredList){
					totalAssetAmount += t.getOtheIssuesVolume();
				}

				totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null){  //4


				if(totalExternalData !=null)	{
					List<OtherIssuesVolume> regionList = new ArrayList<OtherIssuesVolume>();
					List<OtherIssuesVolume> filteredRegionCategoryList = new ArrayList<OtherIssuesVolume>();

					//filterd by region

					for(String regon : region){
						for(OtherIssuesVolume reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(OtherIssuesVolume cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(OtherIssuesVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(OtherIssuesVolume t : filteredList){
						totalAssetAmount += t.getOtheIssuesVolume();
					}

					totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);	

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	
	//============================================================External Next Moc Kpi=============================================================================
	//============================================Store List Count==========================================================

	public StoreListCount getExternalStoreListCount(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		StoreListCount totalAssetAmountSum = new StoreListCount();


		try{

			List<StoreListCount> totalExternalData = new ArrayList<StoreListCount>();
			List<StoreListCount> mocList = new ArrayList<StoreListCount>();
			List<StoreListCount> filteredList = new ArrayList<StoreListCount>();
			
			List<StoreListCount> regionList = new ArrayList<StoreListCount>();
			List<StoreListCount> regionListOne = new ArrayList<StoreListCount>();
			List<StoreListCount> regionListTwo = new ArrayList<StoreListCount>();
			List<StoreListCount> regionListThree = new ArrayList<StoreListCount>();
			List<StoreListCount> regionListFour = new ArrayList<StoreListCount>();
			List<StoreListCount> regionListFive = new ArrayList<StoreListCount>();
			

			totalExternalData = storeListCountRepository.findAllStoreListCountExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(StoreListCount mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(StoreListCount t : filteredList){
					totalAssetAmount += t.getStoreListTotalCount();
				}

				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<StoreListCount> categoryList = new ArrayList<StoreListCount>();

				//filtered by category

				for(String c : category){
					for(StoreListCount cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(StoreListCount mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(StoreListCount t : filteredList){
					totalAssetAmount += t.getStoreListTotalCount();
				}

				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3


				//filtered by MOC
				for(String m : moc){
					for(StoreListCount mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}

				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListCount reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if

				
				
				for(StoreListCount t : regionList){
					totalAssetAmount += t.getStoreListTotalCount();
				}

				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null){  //4


				if(totalExternalData !=null)	{
					List<StoreListCount> filteredRegionCategoryList = new ArrayList<StoreListCount>();


					//filtered by MOC
					for(String m : moc){
						for(StoreListCount mocc : totalExternalData){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}

					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(StoreListCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(StoreListCount reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(StoreListCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(StoreListCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(StoreListCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(StoreListCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if

					
				
					//filtered by category

					for(String c : category){
						for(StoreListCount cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					

					filteredList.addAll(filteredRegionCategoryList);

					for(StoreListCount t : filteredList){
						totalAssetAmount += t.getStoreListTotalCount();
					}

					totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);	

				}//end of if

			}//end of else if




		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	//============================================Store List Value==========================================================

	public StoreListValue getExternalStoreListValuee(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		StoreListValue totalAssetAmountSum = new StoreListValue();


		try{

			List<StoreListValue> totalExternalData = new ArrayList<StoreListValue>();
			List<StoreListValue> mocList = new ArrayList<StoreListValue>();
			List<StoreListValue> filteredList = new ArrayList<StoreListValue>();
			
			List<StoreListValue> regionList = new ArrayList<StoreListValue>();
			List<StoreListValue> regionListOne = new ArrayList<StoreListValue>();
			List<StoreListValue> regionListTwo = new ArrayList<StoreListValue>();
			List<StoreListValue> regionListThree = new ArrayList<StoreListValue>();
			List<StoreListValue> regionListFour = new ArrayList<StoreListValue>();
			List<StoreListValue> regionListFive = new ArrayList<StoreListValue>();
			
			
			totalExternalData = storeListValueRepository.findAllStoreListValueExternalDetails(username);
			
			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(StoreListValue mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(StoreListValue t : filteredList){
					totalAssetAmount += t.getStoreListTotalValue();
				}

				totalAssetAmountSum.setStoreListTotalValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<StoreListValue> categoryList = new ArrayList<StoreListValue>();

				//filtered by category

				for(String c : category){
					for(StoreListValue cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(StoreListValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(StoreListValue t : filteredList){
					totalAssetAmount += t.getStoreListTotalValue();
				}

				totalAssetAmountSum.setStoreListTotalValue(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3
				
				//filtered by MOC
				for(String m : moc){
					for(StoreListValue mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}

				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if

				

				
				for(StoreListValue t : regionList){
					totalAssetAmount += t.getStoreListTotalValue();
				}

				totalAssetAmountSum.setStoreListTotalValue(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null){  //4
				
				List<StoreListValue> filteredRegionCategoryList = new ArrayList<StoreListValue>();


				if(totalExternalData !=null)	{
					

					//filtered by MOC
					for(String m : moc){
						for(StoreListValue mocc : totalExternalData){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}

					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(StoreListValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(StoreListValue reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(StoreListValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(StoreListValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(StoreListValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(StoreListValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if

					
					
					
					
					//filtered by category

					for(String c : category){
						for(StoreListValue cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					

					filteredList.addAll(filteredRegionCategoryList);

					for(StoreListValue t : filteredList){
						totalAssetAmount += t.getStoreListTotalValue();
					}

					totalAssetAmountSum.setStoreListTotalValue(totalAssetAmount);	

				}//end of if

			}//end of else if
		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	//============================================Total Asset planned Value==========================================================


	public TotalAssetPlannedValue getExternalTotalAssetPlannedValue(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TotalAssetPlannedValue totalAssetAmountSum = new TotalAssetPlannedValue();


		try{

			List<TotalAssetPlannedValue> totalExternalData = new ArrayList<TotalAssetPlannedValue>();
			List<TotalAssetPlannedValue> mocList = new ArrayList<TotalAssetPlannedValue>();
			List<TotalAssetPlannedValue> filteredList = new ArrayList<TotalAssetPlannedValue>();
			
            List<TotalAssetPlannedValue> regionList = new ArrayList<TotalAssetPlannedValue>();
			List<TotalAssetPlannedValue> regionListOne = new ArrayList<TotalAssetPlannedValue>();
			List<TotalAssetPlannedValue> regionListTwo = new ArrayList<TotalAssetPlannedValue>();
			List<TotalAssetPlannedValue> regionListThree = new ArrayList<TotalAssetPlannedValue>();
			List<TotalAssetPlannedValue> regionListFour = new ArrayList<TotalAssetPlannedValue>();
			List<TotalAssetPlannedValue> regionListFive = new ArrayList<TotalAssetPlannedValue>();
			

			totalExternalData = totalAssetPlannedValueRepository.findAllTotalAssetPlannedValueExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetPlannedValue mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(TotalAssetPlannedValue t : filteredList){
					totalAssetAmount += t.getPlannedAssetValue();
				}

				totalAssetAmountSum.setPlannedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<TotalAssetPlannedValue> categoryList = new ArrayList<TotalAssetPlannedValue>();

				//filtered by category

				for(String c : category){
					for(TotalAssetPlannedValue cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetPlannedValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(TotalAssetPlannedValue t : filteredList){
					totalAssetAmount += t.getPlannedAssetValue();
				}

				totalAssetAmountSum.setPlannedAssetValue(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3


				
				//filtered by MOC
				for(String m : moc){
					for(TotalAssetPlannedValue mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}

				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(TotalAssetPlannedValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(TotalAssetPlannedValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(TotalAssetPlannedValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(TotalAssetPlannedValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(TotalAssetPlannedValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(TotalAssetPlannedValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if

				

				filteredList.addAll(mocList);

				for(TotalAssetPlannedValue t : regionList){
					totalAssetAmount += t.getPlannedAssetValue();
				}

				totalAssetAmountSum.setPlannedAssetValue(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null){  //4


				if(totalExternalData !=null)	{
					List<TotalAssetPlannedValue> filteredRegionCategoryList = new ArrayList<TotalAssetPlannedValue>();

					//filtered by MOC
					for(String m : moc){
						for(TotalAssetPlannedValue mocc : totalExternalData){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}

					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(TotalAssetPlannedValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(TotalAssetPlannedValue reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(TotalAssetPlannedValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(TotalAssetPlannedValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(TotalAssetPlannedValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(TotalAssetPlannedValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if

	
					//filtered by category

					for(String c : category){
						for(TotalAssetPlannedValue cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					

					filteredList.addAll(filteredRegionCategoryList);

					for(TotalAssetPlannedValue t : filteredList){
						totalAssetAmount += t.getPlannedAssetValue();
					}

					totalAssetAmountSum.setPlannedAssetValue(totalAssetAmount);	

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	//===========================================Total Asset Planned Volume====================================================================================

	public TotalAssetPlannedVolume getExternalTotalAssetPlannedVolume(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TotalAssetPlannedVolume totalAssetAmountSum = new TotalAssetPlannedVolume();


		try{

			List<TotalAssetPlannedVolume> totalExternalData = new ArrayList<TotalAssetPlannedVolume>();
			List<TotalAssetPlannedVolume> mocList = new ArrayList<TotalAssetPlannedVolume>();
			List<TotalAssetPlannedVolume> filteredList = new ArrayList<TotalAssetPlannedVolume>();
			
            List<TotalAssetPlannedVolume> regionList = new ArrayList<TotalAssetPlannedVolume>();
			List<TotalAssetPlannedVolume> regionListOne = new ArrayList<TotalAssetPlannedVolume>();
			List<TotalAssetPlannedVolume> regionListTwo = new ArrayList<TotalAssetPlannedVolume>();
			List<TotalAssetPlannedVolume> regionListThree = new ArrayList<TotalAssetPlannedVolume>();
			List<TotalAssetPlannedVolume> regionListFour = new ArrayList<TotalAssetPlannedVolume>();
			List<TotalAssetPlannedVolume> regionListFive = new ArrayList<TotalAssetPlannedVolume>();
			
			
			totalExternalData = totalAssetPlannedVolumeRepository.findAllTotalAssetPlannedVolumeExternalDetails(username);


			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetPlannedVolume mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(TotalAssetPlannedVolume t : filteredList){
					totalAssetAmount += t.getPlannedAssetVolume();
				}

				totalAssetAmountSum.setPlannedAssetVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<TotalAssetPlannedVolume> categoryList = new ArrayList<TotalAssetPlannedVolume>();

				//filtered by category

				for(String c : category){
					for(TotalAssetPlannedVolume cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetPlannedVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(TotalAssetPlannedVolume t : filteredList){
					totalAssetAmount += t.getPlannedAssetVolume();
				}

				totalAssetAmountSum.setPlannedAssetVolume(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				
				//filtered by MOC
				for(String m : moc){
					for(TotalAssetPlannedVolume mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}

				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(TotalAssetPlannedVolume reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(TotalAssetPlannedVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(TotalAssetPlannedVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(TotalAssetPlannedVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(TotalAssetPlannedVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(TotalAssetPlannedVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if


				filteredList.addAll(regionList);

				for(TotalAssetPlannedVolume t : filteredList){
					totalAssetAmount += t.getPlannedAssetVolume();
				}

				totalAssetAmountSum.setPlannedAssetVolume(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null){  //4


				if(totalExternalData !=null)	{
					List<TotalAssetPlannedVolume> filteredRegionCategoryList = new ArrayList<TotalAssetPlannedVolume>();

					
					//filtered by MOC
					for(String m : moc){
						for(TotalAssetPlannedVolume mocc : totalExternalData){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}

					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(TotalAssetPlannedVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(TotalAssetPlannedVolume reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(TotalAssetPlannedVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(TotalAssetPlannedVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(TotalAssetPlannedVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(TotalAssetPlannedVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if

					
					//filtered by category

					for(String c : category){
						for(TotalAssetPlannedVolume cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					

					filteredList.addAll(filteredRegionCategoryList);

					for(TotalAssetPlannedVolume t : filteredList){
						totalAssetAmount += t.getPlannedAssetVolume();
					}

					totalAssetAmountSum.setPlannedAssetVolume(totalAssetAmount);	

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}



	//======================================================MOC Views==================================

	//=============================================Current Moc View ====================================
	
	public List<ExternalCurrentMocViewDto> getExternalCurrentMocView(List<String> region,List<String> moc,String account,List<String> category,Integer pageNo, Integer pageSize){
		List<ExternalCurrentMocViewDto> filteredViewList = new ArrayList<ExternalCurrentMocViewDto>();
		List<ExternalCurentView> totalRecords = new ArrayList<ExternalCurentView>();
		try{
			
			Pageable paging = PageRequest.of(pageNo, pageSize);
		
			if(region.get(0).equals("All")  && category.get(0).equals("All") && moc !=null){//1
				
				Page<ExternalCurentView> externalCurrentMocViewDetails = currentNextMocViewRepository.findExtrnalCurrentMocViewByMocAccount(moc, account, paging);
				totalRecords = currentNextMocViewRepository.findCountExtrnalCurrentMocViewByMocAccount(moc, account);
				
				for(ExternalCurentView c : externalCurrentMocViewDetails.getContent()){
					ExternalCurrentMocViewDto extCurrMocViewDto = new ExternalCurrentMocViewDto();

					extCurrMocViewDto.setRegion(c.getRegion());
					extCurrMocViewDto.setBranch(c.getBranch());
					extCurrMocViewDto.setAccount(c.getAccount());
					extCurrMocViewDto.setStoreID(c.getStoreID());
					extCurrMocViewDto.setBrand(c.getBrand());
					extCurrMocViewDto.setMoc(c.getMoc());
					extCurrMocViewDto.setCategory(c.getCategory());
					extCurrMocViewDto.setCity(c.getCity());
					extCurrMocViewDto.setAssetType(c.getAssetType());
					extCurrMocViewDto.setAssetDescription(c.getAssetDescription());
					extCurrMocViewDto.setCompliance(c.getCompliance());
					extCurrMocViewDto.setLossTree(c.getLossTree());
					extCurrMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extCurrMocViewDto);
				}
				
				
			}
			else if(region.get(0).equals("All")  && category !=null && moc !=null){//2
				
				Page<ExternalCurentView> externalCurrentMocViewDetails = currentNextMocViewRepository.findExtrnalCurrentMocViewByMocCategoryAccount(moc, account, category, paging);
				totalRecords = currentNextMocViewRepository.findCountExtrnalCurrentMocViewByMocCategoryAccount(moc, account, category);
				
				for(ExternalCurentView c : externalCurrentMocViewDetails.getContent()){
					ExternalCurrentMocViewDto extCurrMocViewDto = new ExternalCurrentMocViewDto();

					extCurrMocViewDto.setRegion(c.getRegion());
					extCurrMocViewDto.setBranch(c.getBranch());
					extCurrMocViewDto.setAccount(c.getAccount());
					extCurrMocViewDto.setStoreID(c.getStoreID());
					extCurrMocViewDto.setBrand(c.getBrand());
					extCurrMocViewDto.setMoc(c.getMoc());
					extCurrMocViewDto.setCategory(c.getCategory());
					extCurrMocViewDto.setCity(c.getCity());
					extCurrMocViewDto.setAssetType(c.getAssetType());
					extCurrMocViewDto.setAssetDescription(c.getAssetDescription());
					extCurrMocViewDto.setCompliance(c.getCompliance());
					extCurrMocViewDto.setLossTree(c.getLossTree());
					extCurrMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extCurrMocViewDto);
				}
			}
			else if(region !=null  && category.get(0).equals("All") && moc !=null){//3
				
				Page<ExternalCurentView> externalCurrentMocViewDetails = currentNextMocViewRepository.findExtrnalCurrentMocViewByMocRegionAccount(moc, account, region, paging);
				totalRecords = currentNextMocViewRepository.findCountExtrnalCurrentMocViewByMocRegionAccount(moc, account, region);
				
				for(ExternalCurentView c : externalCurrentMocViewDetails.getContent()){
					ExternalCurrentMocViewDto extCurrMocViewDto = new ExternalCurrentMocViewDto();

					extCurrMocViewDto.setRegion(c.getRegion());
					extCurrMocViewDto.setBranch(c.getBranch());
					extCurrMocViewDto.setAccount(c.getAccount());
					extCurrMocViewDto.setStoreID(c.getStoreID());
					extCurrMocViewDto.setBrand(c.getBrand());
					extCurrMocViewDto.setMoc(c.getMoc());
					extCurrMocViewDto.setCategory(c.getCategory());
					extCurrMocViewDto.setCity(c.getCity());
					extCurrMocViewDto.setAssetType(c.getAssetType());
					extCurrMocViewDto.setAssetDescription(c.getAssetDescription());
					extCurrMocViewDto.setCompliance(c.getCompliance());
					extCurrMocViewDto.setLossTree(c.getLossTree());
					extCurrMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extCurrMocViewDto);
				}
				
			}
				
			else if(region !=null  && category != null && moc !=null){//4
				
				Page<ExternalCurentView> externalCurrentMocViewDetails = currentNextMocViewRepository.findExtrnalCurrentMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
				totalRecords = currentNextMocViewRepository.findCountExtrnalCurrentMocViewByMocCategoryRegionAccount(moc, account, category, region);
				
				for(ExternalCurentView c : externalCurrentMocViewDetails.getContent()){
					ExternalCurrentMocViewDto extCurrMocViewDto = new ExternalCurrentMocViewDto();

					extCurrMocViewDto.setRegion(c.getRegion());
					extCurrMocViewDto.setBranch(c.getBranch());
					extCurrMocViewDto.setAccount(c.getAccount());
					extCurrMocViewDto.setStoreID(c.getStoreID());
					extCurrMocViewDto.setBrand(c.getBrand());
					extCurrMocViewDto.setMoc(c.getMoc());
					extCurrMocViewDto.setCategory(c.getCategory());
					extCurrMocViewDto.setCity(c.getCity());
					extCurrMocViewDto.setAssetType(c.getAssetType());
					extCurrMocViewDto.setAssetDescription(c.getAssetDescription());
					extCurrMocViewDto.setCompliance(c.getCompliance());
					extCurrMocViewDto.setLossTree(c.getLossTree());
					extCurrMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extCurrMocViewDto);
				}
			
			
			}
			

		}catch(Exception e){
			e.printStackTrace();
		}
		return filteredViewList;
	}


	//=============================================Previous Moc View ====================================
	
	public List<ExternalPreviousMocViewDto> getExternalPreviousMocView(List<String> region,List<String> moc,String account,List<String> category,Integer pageNo, Integer pageSize){
		List<ExternalPreviousMocViewDto> filteredViewList = new ArrayList<ExternalPreviousMocViewDto>();
		List<ExternalPreviousMocView> totalRecords = new ArrayList<ExternalPreviousMocView>();
		
		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);
			
			if(region.get(0).equals("All")  && category.get(0).equals("All") && moc !=null){//1
				
				Page<ExternalPreviousMocView> externalPreviousMocViewDetails = priviousMocViewRepository.findExtrnalPreviousMocViewByMocAccount(moc, account, paging);
				totalRecords = priviousMocViewRepository.findCountExtrnalPreviousMocViewByMocAccount(moc, account);
				
				for(ExternalPreviousMocView c : externalPreviousMocViewDetails.getContent()){
					ExternalPreviousMocViewDto extPrevMocViewDto = new ExternalPreviousMocViewDto();

					extPrevMocViewDto.setRegion(c.getRegion());
					extPrevMocViewDto.setBranch(c.getBranch());
					extPrevMocViewDto.setAccount(c.getAccount());
					extPrevMocViewDto.setStoreID(c.getStoreID());
					extPrevMocViewDto.setBrand(c.getBrand());
					extPrevMocViewDto.setMoc(c.getMoc());
					extPrevMocViewDto.setCategory(c.getCategory());
					extPrevMocViewDto.setCity(c.getCity());
					extPrevMocViewDto.setAssetType(c.getAssetType());
					extPrevMocViewDto.setAssetDescription(c.getAssetDescription());
					extPrevMocViewDto.setCompliance(c.getCompliance());
					extPrevMocViewDto.setLossTree(c.getLossTree());
					extPrevMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extPrevMocViewDto);
				}
				
			}
			
			else if(region.get(0).equals("All")  && category !=null && moc !=null){//2
				
				Page<ExternalPreviousMocView> externalPreviousMocViewDetails = priviousMocViewRepository.findExtrnalPreviousMocViewByMocCategoryAccount(moc, account, category, paging);
				totalRecords = priviousMocViewRepository.findCountExtrnalPreviousMocViewByMocCategoryAccount(moc, account, category);
				
				for(ExternalPreviousMocView c : externalPreviousMocViewDetails.getContent()){
					ExternalPreviousMocViewDto extPrevMocViewDto = new ExternalPreviousMocViewDto();

					extPrevMocViewDto.setRegion(c.getRegion());
					extPrevMocViewDto.setBranch(c.getBranch());
					extPrevMocViewDto.setAccount(c.getAccount());
					extPrevMocViewDto.setStoreID(c.getStoreID());
					extPrevMocViewDto.setBrand(c.getBrand());
					extPrevMocViewDto.setMoc(c.getMoc());
					extPrevMocViewDto.setCategory(c.getCategory());
					extPrevMocViewDto.setCity(c.getCity());
					extPrevMocViewDto.setAssetType(c.getAssetType());
					extPrevMocViewDto.setAssetDescription(c.getAssetDescription());
					extPrevMocViewDto.setCompliance(c.getCompliance());
					extPrevMocViewDto.setLossTree(c.getLossTree());
					extPrevMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extPrevMocViewDto);
				}
				
				
			}
			
			else if(region !=null  && category.get(0).equals("All") && moc !=null){//3
				
				Page<ExternalPreviousMocView> externalPreviousMocViewDetails = priviousMocViewRepository.findExtrnalPreviousMocViewByMocRegionAccount(moc, account, region, paging);
				totalRecords = priviousMocViewRepository.findCountExtrnalPreviousMocViewByMocRegionAccount(moc, account, region);
				
				for(ExternalPreviousMocView c : externalPreviousMocViewDetails.getContent()){
					ExternalPreviousMocViewDto extPrevMocViewDto = new ExternalPreviousMocViewDto();

					extPrevMocViewDto.setRegion(c.getRegion());
					extPrevMocViewDto.setBranch(c.getBranch());
					extPrevMocViewDto.setAccount(c.getAccount());
					extPrevMocViewDto.setStoreID(c.getStoreID());
					extPrevMocViewDto.setBrand(c.getBrand());
					extPrevMocViewDto.setMoc(c.getMoc());
					extPrevMocViewDto.setCategory(c.getCategory());
					extPrevMocViewDto.setCity(c.getCity());
					extPrevMocViewDto.setAssetType(c.getAssetType());
					extPrevMocViewDto.setAssetDescription(c.getAssetDescription());
					extPrevMocViewDto.setCompliance(c.getCompliance());
					extPrevMocViewDto.setLossTree(c.getLossTree());
					extPrevMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extPrevMocViewDto);
				}
				
			}
			
			else if(region !=null  && category != null && moc !=null){//4
				
				Page<ExternalPreviousMocView> externalPreviousMocViewDetails = priviousMocViewRepository.findExtrnalPreviousMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
				totalRecords = priviousMocViewRepository.findCountExtrnalPreviousMocViewByMocRegionAccount(moc, account, region);
				
				for(ExternalPreviousMocView c : externalPreviousMocViewDetails.getContent()){
					ExternalPreviousMocViewDto extPrevMocViewDto = new ExternalPreviousMocViewDto();

					extPrevMocViewDto.setRegion(c.getRegion());
					extPrevMocViewDto.setBranch(c.getBranch());
					extPrevMocViewDto.setAccount(c.getAccount());
					extPrevMocViewDto.setStoreID(c.getStoreID());
					extPrevMocViewDto.setBrand(c.getBrand());
					extPrevMocViewDto.setMoc(c.getMoc());
					extPrevMocViewDto.setCategory(c.getCategory());
					extPrevMocViewDto.setCity(c.getCity());
					extPrevMocViewDto.setAssetType(c.getAssetType());
					extPrevMocViewDto.setAssetDescription(c.getAssetDescription());
					extPrevMocViewDto.setCompliance(c.getCompliance());
					extPrevMocViewDto.setLossTree(c.getLossTree());
					extPrevMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(extPrevMocViewDto);
				}
				
			}
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return filteredViewList;
	}
//=====================================================================Next Moc View=============================================================

	public List<ExternalNextMocViewDto> getExternalNextMocView(List<String> region,List<String> moc,String account,List<String> category,Integer pageNo, Integer pageSize){
		List<ExternalNextMocView> regionList = new ArrayList<ExternalNextMocView>();
		List<ExternalNextMocView> filteredViewList = new ArrayList<ExternalNextMocView>();
		List<ExternalNextMocView> categoryList = new ArrayList<ExternalNextMocView>();
		List<ExternalNextMocViewDto> externalNextMocViewList = new ArrayList<>();

		try{

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<ExternalNextMocView> externalNextMocViewDetails = nextMocViewRepository.findExtrnalNextMocViewByMocAccount(moc, account, paging);

		//-----filter by region------//

		for(String r :region){
		for(ExternalNextMocView reg : externalNextMocViewDetails){
		Pattern pattern = Pattern.compile("(^|,)"+r+"(,|$)");
		Matcher matcher = pattern.matcher(reg.getRegion());
		if(matcher.find()){
		regionList.add(reg);
		}

		}

		}


		//-----filter by category------//

		for(String c : category){
		for(ExternalNextMocView cat : regionList){
		if(c.equals(cat.getCategory().trim())){
		categoryList.add(cat);
		}

		}

		}
		filteredViewList.addAll(categoryList);

		for(ExternalNextMocView c : filteredViewList){

		ExternalNextMocViewDto nextMocViewDto = new ExternalNextMocViewDto();
		nextMocViewDto.setRefNo(c.getRefNo());
		nextMocViewDto.setMoc(c.getMoc());
		nextMocViewDto.setCategory(c.getCategory());
		nextMocViewDto.setRegion(c.getRegion());
		nextMocViewDto.setCity(c.getCity());
		nextMocViewDto.setAssetDescription(c.getAssetDescription());
		nextMocViewDto.setAssetType(c.getAssetType());
		nextMocViewDto.setNoOfStores(c.getNoOfStores());
		nextMocViewDto.setAccount(c.getAccountName());
		nextMocViewDto.setTotalRecords(filteredViewList.size());

		externalNextMocViewList.add(nextMocViewDto);
		}


		}catch(Exception e){

		e.printStackTrace();
		}
		return externalNextMocViewList;
		}

// ===============================================Privious Moc Kpis=========================================================
	
	public ExternalCustomerNonCompliedAssetValuePrev getPrevExternalCustomerNonCompliantValueValue(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		ExternalCustomerNonCompliedAssetValuePrev totalAssetAmountSum = new ExternalCustomerNonCompliedAssetValuePrev();


		try{

			List<ExternalCustomerNonCompliedAssetValuePrev> totalExternalData = new ArrayList<ExternalCustomerNonCompliedAssetValuePrev>();
			List<ExternalCustomerNonCompliedAssetValuePrev> mocList = new ArrayList<ExternalCustomerNonCompliedAssetValuePrev>();
			List<ExternalCustomerNonCompliedAssetValuePrev> filteredList = new ArrayList<ExternalCustomerNonCompliedAssetValuePrev>();

			totalExternalData = customerNonCompientValuePrevRepository.findAllCustomerNonCompliantValueExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(ExternalCustomerNonCompliedAssetValuePrev mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);


				for(ExternalCustomerNonCompliedAssetValuePrev t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetValue();
				}

				totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null  ){   //2

				List<ExternalCustomerNonCompliedAssetValuePrev> categoryList = new ArrayList<ExternalCustomerNonCompliedAssetValuePrev>();

				//filtered by category

				for(String c : category){
					for(ExternalCustomerNonCompliedAssetValuePrev cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalCustomerNonCompliedAssetValuePrev mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(ExternalCustomerNonCompliedAssetValuePrev t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetValue();
				}

				totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);

			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<ExternalCustomerNonCompliedAssetValuePrev> regionList = new ArrayList<ExternalCustomerNonCompliedAssetValuePrev>();

				//filter by region
				for(String regon : region){
					for(ExternalCustomerNonCompliedAssetValuePrev reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalCustomerNonCompliedAssetValuePrev mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(ExternalCustomerNonCompliedAssetValuePrev t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetValue();
				}

				totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);

			}

			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{

					List<ExternalCustomerNonCompliedAssetValuePrev> regionList = new ArrayList<ExternalCustomerNonCompliedAssetValuePrev>();
					List<ExternalCustomerNonCompliedAssetValuePrev> filteredRegionCategoryList = new ArrayList<ExternalCustomerNonCompliedAssetValuePrev>();

					//filterd by region

					for(String regon : region){
						for(ExternalCustomerNonCompliedAssetValuePrev reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ExternalCustomerNonCompliedAssetValuePrev cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalCustomerNonCompliedAssetValuePrev mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(ExternalCustomerNonCompliedAssetValuePrev t : filteredList){
						totalAssetAmount += t.getNonCompliedAssetValue();
					}

					totalAssetAmountSum.setNonCompliedAssetValue(totalAssetAmount);


				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	
	public ExternalCustomerNonCompliedAssetVolumePrev getPrevExternalCustomerNonCompliantVolume(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		ExternalCustomerNonCompliedAssetVolumePrev totalAssetAmountSum = new ExternalCustomerNonCompliedAssetVolumePrev();


		try{

			List<ExternalCustomerNonCompliedAssetVolumePrev> totalExternalData = new ArrayList<ExternalCustomerNonCompliedAssetVolumePrev>();
			List<ExternalCustomerNonCompliedAssetVolumePrev> mocList = new ArrayList<ExternalCustomerNonCompliedAssetVolumePrev>();
			List<ExternalCustomerNonCompliedAssetVolumePrev> filteredList = new ArrayList<ExternalCustomerNonCompliedAssetVolumePrev>();

			totalExternalData = customerNonComplientVolumePrevRepository.findAllCustomerNonCompliantVolumeExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1


				//filtered by MOC
				for(String m : moc){
					for(ExternalCustomerNonCompliedAssetVolumePrev mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(ExternalCustomerNonCompliedAssetVolumePrev t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetVolume();
				}

				totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<ExternalCustomerNonCompliedAssetVolumePrev> categoryList = new ArrayList<ExternalCustomerNonCompliedAssetVolumePrev>();

				//filtered by category

				for(String c : category){
					for(ExternalCustomerNonCompliedAssetVolumePrev cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalCustomerNonCompliedAssetVolumePrev mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);
				for(ExternalCustomerNonCompliedAssetVolumePrev t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetVolume();
				}

				totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<ExternalCustomerNonCompliedAssetVolumePrev> regionList = new ArrayList<ExternalCustomerNonCompliedAssetVolumePrev>();

				//filter by region
				for(String regon : region){
					for(ExternalCustomerNonCompliedAssetVolumePrev reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalCustomerNonCompliedAssetVolumePrev mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(ExternalCustomerNonCompliedAssetVolumePrev t : filteredList){
					totalAssetAmount += t.getNonCompliedAssetVolume();
				}

				totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{
					List<ExternalCustomerNonCompliedAssetVolumePrev> regionList = new ArrayList<ExternalCustomerNonCompliedAssetVolumePrev>();
					List<ExternalCustomerNonCompliedAssetVolumePrev> filteredRegionCategoryList = new ArrayList<ExternalCustomerNonCompliedAssetVolumePrev>();

					//filterd by region

					for(String regon : region){
						for(ExternalCustomerNonCompliedAssetVolumePrev reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ExternalCustomerNonCompliedAssetVolumePrev cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalCustomerNonCompliedAssetVolumePrev mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(ExternalCustomerNonCompliedAssetVolumePrev t : filteredList){
						totalAssetAmount += t.getNonCompliedAssetVolume();
					}

					totalAssetAmountSum.setNonCompliedAssetVolume(totalAssetAmount);

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	
	
	public ExternalOtherIssuseValuePrev getPrevExternalOtherIssuesValue(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		ExternalOtherIssuseValuePrev totalAssetAmountSum = new ExternalOtherIssuseValuePrev();


		try{

			List<ExternalOtherIssuseValuePrev> totalExternalData = new ArrayList<ExternalOtherIssuseValuePrev>();
			List<ExternalOtherIssuseValuePrev> mocList = new ArrayList<ExternalOtherIssuseValuePrev>();
			List<ExternalOtherIssuseValuePrev> filteredList = new ArrayList<ExternalOtherIssuseValuePrev>();

			totalExternalData = otherIssuseValuePrevRepository.findAllOtherIssuesValueExternalDetails(username);


			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1


				//filtered by MOC
				for(String m : moc){
					for(ExternalOtherIssuseValuePrev mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);
				for(ExternalOtherIssuseValuePrev t : filteredList){
					totalAssetAmount += t.getOtheIssuesValue();
				}

				totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<ExternalOtherIssuseValuePrev> categoryList = new ArrayList<ExternalOtherIssuseValuePrev>();

				//filtered by category

				for(String c : category){
					for(ExternalOtherIssuseValuePrev cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalOtherIssuseValuePrev mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);
				for(ExternalOtherIssuseValuePrev t : filteredList){
					totalAssetAmount += t.getOtheIssuesValue();
				}

				totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);

			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<ExternalOtherIssuseValuePrev> regionList = new ArrayList<ExternalOtherIssuseValuePrev>();

				//filter by region
				for(String regon : region){
					for(ExternalOtherIssuseValuePrev reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalOtherIssuseValuePrev mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(ExternalOtherIssuseValuePrev t : filteredList){
					totalAssetAmount += t.getOtheIssuesValue();
				}

				totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);

			}

			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{

					List<ExternalOtherIssuseValuePrev> regionList = new ArrayList<ExternalOtherIssuseValuePrev>();
					List<ExternalOtherIssuseValuePrev> filteredRegionCategoryList = new ArrayList<ExternalOtherIssuseValuePrev>();

					//filterd by region

					for(String regon : region){
						for(ExternalOtherIssuseValuePrev reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ExternalOtherIssuseValuePrev cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalOtherIssuseValuePrev mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(ExternalOtherIssuseValuePrev t : filteredList){
						totalAssetAmount += t.getOtheIssuesValue();
					}

					totalAssetAmountSum.setOtheIssuesValue(totalAssetAmount);


				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	
	
	public ExternalOtherIssuseVolumePrev getPrevExternalOtherIssuesVolume(String username,List<String> region,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		ExternalOtherIssuseVolumePrev totalAssetAmountSum = new ExternalOtherIssuseVolumePrev();


		try{

			List<ExternalOtherIssuseVolumePrev> totalExternalData = new ArrayList<ExternalOtherIssuseVolumePrev>();
			List<ExternalOtherIssuseVolumePrev> mocList = new ArrayList<ExternalOtherIssuseVolumePrev>();
			List<ExternalOtherIssuseVolumePrev> filteredList = new ArrayList<ExternalOtherIssuseVolumePrev>();

			totalExternalData = otherIssuseVolumePrevRepository.findAllOtherIssuesVolumeExternalDetails(username);

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All")){    //1

				//filtered by MOC
				for(String m : moc){
					for(ExternalOtherIssuseVolumePrev mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(ExternalOtherIssuseVolumePrev t : filteredList){
					totalAssetAmount += t.getOtheIssuesVolume();
				}

				totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<ExternalOtherIssuseVolumePrev> categoryList = new ArrayList<ExternalOtherIssuseVolumePrev>();

				//filtered by category

				for(String c : category){
					for(ExternalOtherIssuseVolumePrev cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalOtherIssuseVolumePrev mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(ExternalOtherIssuseVolumePrev t : filteredList){
					totalAssetAmount += t.getOtheIssuesVolume();
				}

				totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<ExternalOtherIssuseVolumePrev> regionList = new ArrayList<ExternalOtherIssuseVolumePrev>();

				//filter by region
				for(String regon : region){
					for(ExternalOtherIssuseVolumePrev reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ExternalOtherIssuseVolumePrev mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);

				for(ExternalOtherIssuseVolumePrev t : filteredList){
					totalAssetAmount += t.getOtheIssuesVolume();
				}

				totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);
			}

			else if(region != null && moc !=null && category !=null){  //4


				if(totalExternalData !=null)	{
					List<ExternalOtherIssuseVolumePrev> regionList = new ArrayList<ExternalOtherIssuseVolumePrev>();
					List<ExternalOtherIssuseVolumePrev> filteredRegionCategoryList = new ArrayList<ExternalOtherIssuseVolumePrev>();

					//filterd by region

					for(String regon : region){
						for(ExternalOtherIssuseVolumePrev reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ExternalOtherIssuseVolumePrev cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalOtherIssuseVolumePrev mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(ExternalOtherIssuseVolumePrev t : filteredList){
						totalAssetAmount += t.getOtheIssuesVolume();
					}

					totalAssetAmountSum.setOtheIssuesVolume(totalAssetAmount);	

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	
	
	
	

}
