package com.unilever.claims.commecialB2C.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPlannedCommb2c;
import com.unilever.claims.commb2c.repository.ApprovedExceptionClaimsValueCommb2cRepository;
import com.unilever.claims.commb2c.repository.ApprovedExceptionClaimsVolumeCommb2cRepository;
import com.unilever.claims.commb2c.repository.GreenClaimsValueCommb2cRepository;
import com.unilever.claims.commb2c.repository.GreenClaimsVolumeCommb2cRepository;
import com.unilever.claims.commb2c.repository.RedClaimsValueCommb2cRepository;
import com.unilever.claims.commb2c.repository.RedClaimsVolumeCommb2cRepository;
import com.unilever.claims.commb2c.repository.TotalAmountPayableCommb2cRepository;
import com.unilever.claims.commb2c.repository.TotalAmountPlannedCommb2cRepository;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsVolumeCommb2c;
import com.unilever.claims.kam.model.ClaimsRaised;
import com.unilever.claims.kam.model.GreenClaimValue;
import com.unilever.claims.commb2c.model.GreenClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPayableCommb2c;
import com.unilever.claims.kam.model.TotalAmountPaid;
import com.unilever.claims.commb2c.model.TotalAmountPayableCommb2c;
import com.unilever.claims.kam.model.TotalAmountPending;
import com.unilever.claims.kam.model.TotalAmountPlanned;
import com.unilever.claims.kam.repository.ApprovedExceptiobClaimsValueRepository;
import com.unilever.claims.kam.repository.ApprovedExceptiobClaimsVolumeRepository;
import com.unilever.claims.kam.repository.ClaimsRaisedRepository;
import com.unilever.claims.kam.repository.GreenClaimsValueRepository;
import com.unilever.claims.kam.repository.GreenClaimsVolumeRepository;
import com.unilever.claims.kam.repository.RedClaimsValueRepository;
import com.unilever.claims.kam.repository.RedClaimsVolumeRepository;
import com.unilever.claims.kam.repository.TotalAmountPaidRepository;
import com.unilever.claims.kam.repository.TotalAmountPayableRepository;
import com.unilever.claims.kam.repository.TotalAmountPendingRepository;
import com.unilever.claims.kam.repository.TotalAmountPlannedRepository;

@Service
public class CommercialB2CClaimsService {
	
	@Autowired
	TotalAmountPlannedCommb2cRepository totalAmountPlannedCommb2cRepository;
	
	@Autowired
	GreenClaimsValueCommb2cRepository greenClaimsValueCommb2cRepository;
	
	@Autowired
	GreenClaimsVolumeCommb2cRepository greenClaimsVolumeCommb2cRepository;
	
	@Autowired
	ApprovedExceptionClaimsValueCommb2cRepository approvedExceptiobClaimsValueCommb2cRepository;
	
	@Autowired
	ApprovedExceptionClaimsVolumeCommb2cRepository approvedExceptiobClaimsVolumeCommb2cRepository;
	
	@Autowired
	RedClaimsValueCommb2cRepository redClaimsValueCommb2cRepository;
	
	@Autowired
	RedClaimsVolumeCommb2cRepository redClaimsVolumeCommb2cRepository;
	
	@Autowired
	TotalAmountPayableCommb2cRepository totalAmountPayableCommb2cRepository;
	
	@Autowired
	TotalAmountPaidRepository totalAmountPaidRepository;
	
	@Autowired
	TotalAmountPendingRepository totalAmountPendingRepository;
	
	@Autowired
	ClaimsRaisedRepository claimsRaisedRepository;
	
	
	//=========================================================Total Amount Planned Start========================================================================
	
		public TotalAmountPlannedCommb2c getTotalAmountPlanned(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			TotalAmountPlannedCommb2c totalAssetAmountSum = new TotalAmountPlannedCommb2c();


			try{
				List<TotalAmountPlannedCommb2c> totalAssetValues = new ArrayList<TotalAmountPlannedCommb2c>();
				List<TotalAmountPlannedCommb2c> totalAssetValuesByUsername = new ArrayList<TotalAmountPlannedCommb2c>();
				List<TotalAmountPlannedCommb2c> mocList = new ArrayList<TotalAmountPlannedCommb2c>();
				
				totalAssetValuesByUsername = totalAmountPlannedCommb2cRepository.findAllTotalAmountPlanned();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlannedCommb2c mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(TotalAmountPlannedCommb2c t : mocList){
						totalAssetAmount += t.getTotalAmountPlanned();

					}

					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<TotalAmountPlannedCommb2c> categoryList = new ArrayList<TotalAmountPlannedCommb2c>();
					
					//filtered by category

					for(String c : category){
						for(TotalAmountPlannedCommb2c cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlannedCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(TotalAmountPlannedCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPlanned();

					}
					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<TotalAmountPlannedCommb2c> accountList = new ArrayList<TotalAmountPlannedCommb2c>();
					
					
					for(String accnt : account){
						for(TotalAmountPlannedCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlannedCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPlannedCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPlanned();

					}
					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<TotalAmountPlannedCommb2c> accountList = new ArrayList<TotalAmountPlannedCommb2c>();
					List<TotalAmountPlannedCommb2c> filteredAccountCategoryList = new ArrayList<TotalAmountPlannedCommb2c>();
					

					//filterd by account
					for(String accnt : account){
						for(TotalAmountPlannedCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(TotalAmountPlannedCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlannedCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPlannedCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPlanned();
					}
					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<TotalAmountPlannedCommb2c> regionList = new ArrayList<TotalAmountPlannedCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPlannedCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlannedCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPlannedCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPlanned();
					}

					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<TotalAmountPlannedCommb2c> regionList = new ArrayList<TotalAmountPlannedCommb2c>();
					List<TotalAmountPlannedCommb2c> filteredRegionAccountList = new ArrayList<TotalAmountPlannedCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPlannedCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(TotalAmountPlannedCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlannedCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAmountPlannedCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPlanned();

					}
					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<TotalAmountPlannedCommb2c> regionList = new ArrayList<TotalAmountPlannedCommb2c>();
					List<TotalAmountPlannedCommb2c> filteredRegionCategoryList = new ArrayList<TotalAmountPlannedCommb2c>();
					
					//filterd by region

					for(String regon : region){
						for(TotalAmountPlannedCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(TotalAmountPlannedCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlannedCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPlannedCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPlanned();
					}
					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<TotalAmountPlannedCommb2c> regionList = new ArrayList<TotalAmountPlannedCommb2c>();
					List<TotalAmountPlannedCommb2c> accountList = new ArrayList<TotalAmountPlannedCommb2c>();
					List<TotalAmountPlannedCommb2c> filteredRegionCategoryList = new ArrayList<TotalAmountPlannedCommb2c>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(TotalAmountPlannedCommb2c reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(TotalAmountPlannedCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(TotalAmountPlannedCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(TotalAmountPlannedCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(TotalAmountPlannedCommb2c t : totalAssetValues){
							totalAssetAmount += t.getTotalAmountPlanned();
						}

						totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		
		//=========================================================Green Claims Value Start==========================================================================
		
		public GreenClaimsValueCommb2c getGreenClaimsValue(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			GreenClaimsValueCommb2c totalAssetAmountSum = new GreenClaimsValueCommb2c();


			try{
				List<GreenClaimsValueCommb2c> totalAssetValues = new ArrayList<GreenClaimsValueCommb2c>();
				List<GreenClaimsValueCommb2c> totalAssetValuesByUsername = new ArrayList<GreenClaimsValueCommb2c>();
				List<GreenClaimsValueCommb2c> mocList = new ArrayList<GreenClaimsValueCommb2c>();
				
				totalAssetValuesByUsername = greenClaimsValueCommb2cRepository.findAllGreenClaimValue();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsValueCommb2c mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(GreenClaimsValueCommb2c t : mocList){
						totalAssetAmount += t.getGreenClaimValue();

					}

					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<GreenClaimsValueCommb2c> categoryList = new ArrayList<GreenClaimsValueCommb2c>();
					
					//filtered by category

					for(String c : category){
						for(GreenClaimsValueCommb2c cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsValueCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(GreenClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getGreenClaimValue();

					}
					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<GreenClaimsValueCommb2c> accountList = new ArrayList<GreenClaimsValueCommb2c>();
					
					
					for(String accnt : account){
						for(GreenClaimsValueCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsValueCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(GreenClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getGreenClaimValue();

					}
					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<GreenClaimsValueCommb2c> accountList = new ArrayList<GreenClaimsValueCommb2c>();
					List<GreenClaimsValueCommb2c> filteredAccountCategoryList = new ArrayList<GreenClaimsValueCommb2c>();
					

					//filterd by account
					for(String accnt : account){
						for(GreenClaimsValueCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(GreenClaimsValueCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsValueCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(GreenClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getGreenClaimValue();
					}
					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<GreenClaimsValueCommb2c> regionList = new ArrayList<GreenClaimsValueCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(GreenClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsValueCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(GreenClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getGreenClaimValue();
					}

					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<GreenClaimsValueCommb2c> regionList = new ArrayList<GreenClaimsValueCommb2c>();
					List<GreenClaimsValueCommb2c> filteredRegionAccountList = new ArrayList<GreenClaimsValueCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(GreenClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(GreenClaimsValueCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsValueCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(GreenClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getGreenClaimValue();

					}
					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<GreenClaimsValueCommb2c> regionList = new ArrayList<GreenClaimsValueCommb2c>();
					List<GreenClaimsValueCommb2c> filteredRegionCategoryList = new ArrayList<GreenClaimsValueCommb2c>();
					
					//filterd by region

					for(String regon : region){
						for(GreenClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(GreenClaimsValueCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsValueCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(GreenClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getGreenClaimValue();
					}
					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<GreenClaimsValueCommb2c> regionList = new ArrayList<GreenClaimsValueCommb2c>();
					List<GreenClaimsValueCommb2c> accountList = new ArrayList<GreenClaimsValueCommb2c>();
					List<GreenClaimsValueCommb2c> filteredRegionCategoryList = new ArrayList<GreenClaimsValueCommb2c>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(GreenClaimsValueCommb2c reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(GreenClaimsValueCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(GreenClaimsValueCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(GreenClaimsValueCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(GreenClaimsValueCommb2c t : totalAssetValues){
							totalAssetAmount += t.getGreenClaimValue();
						}

						totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		
		//=========================================================Green Claims Volume Start==========================================================================
		
		
		public GreenClaimsVolumeCommb2c getGreenClaimsVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

			Double totalAssetVolume = 0.00;
			GreenClaimsVolumeCommb2c totalAssetVolumeSum= new GreenClaimsVolumeCommb2c();
			//Integer totalAssetVolumeSum = 0;

			try{
				List<GreenClaimsVolumeCommb2c> totalAssetVolumes = new ArrayList<GreenClaimsVolumeCommb2c>();
				List<GreenClaimsVolumeCommb2c> totalAssetVolumeByUsername = new ArrayList<GreenClaimsVolumeCommb2c>();
				List<GreenClaimsVolumeCommb2c> mocList = new ArrayList<GreenClaimsVolumeCommb2c>();
				
				totalAssetVolumeByUsername = greenClaimsVolumeCommb2cRepository.findAllGreenClaimVolume();
	           

				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsVolumeCommb2c mocc : totalAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					for(GreenClaimsVolumeCommb2c t : mocList){
						totalAssetVolume += t.getGreenClaimVolume();

					}

					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<GreenClaimsVolumeCommb2c> categoryList = new ArrayList<GreenClaimsVolumeCommb2c>();

					//filtered by category

					for(String c : category){
						for(GreenClaimsVolumeCommb2c cat : totalAssetVolumeByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsVolumeCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);
					for(GreenClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getGreenClaimVolume();

					}
					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
				}
				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<GreenClaimsVolumeCommb2c> accountList = new ArrayList<GreenClaimsVolumeCommb2c>();
					
					for(String accnt : account){
						for(GreenClaimsVolumeCommb2c acc : totalAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsVolumeCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(GreenClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getGreenClaimVolume();

					}
					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<GreenClaimsVolumeCommb2c> accountList = new ArrayList<GreenClaimsVolumeCommb2c>();
					List<GreenClaimsVolumeCommb2c> filteredAccountCategoryList = new ArrayList<GreenClaimsVolumeCommb2c>();


					//filterd by account
					for(String accnt : account){
						for(GreenClaimsVolumeCommb2c acc : totalAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(GreenClaimsVolumeCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsVolumeCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(GreenClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getGreenClaimVolume();
					}
					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<GreenClaimsVolumeCommb2c> regionList = new ArrayList<GreenClaimsVolumeCommb2c>();
					
					//filter by region
					for(String regon : region){
						for(GreenClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsVolumeCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);
					for(GreenClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getGreenClaimVolume();
					}

					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
				}

				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<GreenClaimsVolumeCommb2c> regionList = new ArrayList<GreenClaimsVolumeCommb2c>();
					List<GreenClaimsVolumeCommb2c> filteredRegionAccountList = new ArrayList<GreenClaimsVolumeCommb2c>();
					
					//filter by region
					for(String regon : region){
						for(GreenClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(GreenClaimsVolumeCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsVolumeCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(GreenClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getGreenClaimVolume();

					}
					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
				}



				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<GreenClaimsVolumeCommb2c> regionList = new ArrayList<GreenClaimsVolumeCommb2c>();
					List<GreenClaimsVolumeCommb2c> filteredRegionCategoryList = new ArrayList<GreenClaimsVolumeCommb2c>();
				
					//filterd by region

					for(String regon : region){
						for(GreenClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(GreenClaimsVolumeCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimsVolumeCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);
					for(GreenClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getGreenClaimVolume();
					}
					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<GreenClaimsVolumeCommb2c> regionList = new ArrayList<GreenClaimsVolumeCommb2c>();
					List<GreenClaimsVolumeCommb2c> accountList = new ArrayList<GreenClaimsVolumeCommb2c>();
					List<GreenClaimsVolumeCommb2c> filteredRegionCategoryList = new ArrayList<GreenClaimsVolumeCommb2c>();
					
					if(totalAssetVolumeByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(GreenClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(GreenClaimsVolumeCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(GreenClaimsVolumeCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(GreenClaimsVolumeCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetVolumes.addAll(mocList);

						for(GreenClaimsVolumeCommb2c t : totalAssetVolumes){
							totalAssetVolume += t.getGreenClaimVolume();
						}

						totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetVolumeSum;

		}

		
		
		//=========================================================Approved Exception Claim Value Start==========================================================================
		
		public ApprovedExceptionClaimsValueCommb2c getApprovedExceptionClaimValue(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			ApprovedExceptionClaimsValueCommb2c totalAssetAmountSum = new ApprovedExceptionClaimsValueCommb2c();


			try{
				List<ApprovedExceptionClaimsValueCommb2c> totalAssetValues = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
				List<ApprovedExceptionClaimsValueCommb2c> totalAssetValuesByUsername = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
				List<ApprovedExceptionClaimsValueCommb2c> mocList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
				
				totalAssetValuesByUsername = approvedExceptiobClaimsValueCommb2cRepository.findAllApprovedExceptionClaimValue();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsValueCommb2c mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(ApprovedExceptionClaimsValueCommb2c t : mocList){
						totalAssetAmount += t.getApprovedExceptionClaimValue();

					}

					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<ApprovedExceptionClaimsValueCommb2c> categoryList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					
					//filtered by category

					for(String c : category){
						for(ApprovedExceptionClaimsValueCommb2c cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsValueCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(ApprovedExceptionClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getApprovedExceptionClaimValue();

					}
					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<ApprovedExceptionClaimsValueCommb2c> accountList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					
					
					for(String accnt : account){
						for(ApprovedExceptionClaimsValueCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsValueCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(ApprovedExceptionClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getApprovedExceptionClaimValue();

					}
					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<ApprovedExceptionClaimsValueCommb2c> accountList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					List<ApprovedExceptionClaimsValueCommb2c> filteredAccountCategoryList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					

					//filterd by account
					for(String accnt : account){
						for(ApprovedExceptionClaimsValueCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(ApprovedExceptionClaimsValueCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsValueCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(ApprovedExceptionClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getApprovedExceptionClaimValue();
					}
					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<ApprovedExceptionClaimsValueCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(ApprovedExceptionClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsValueCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(ApprovedExceptionClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getApprovedExceptionClaimValue();
					}

					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<ApprovedExceptionClaimsValueCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					List<ApprovedExceptionClaimsValueCommb2c> filteredRegionAccountList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(ApprovedExceptionClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(ApprovedExceptionClaimsValueCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsValueCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(ApprovedExceptionClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getApprovedExceptionClaimValue();

					}
					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<ApprovedExceptionClaimsValueCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					List<ApprovedExceptionClaimsValueCommb2c> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					
					//filterd by region

					for(String regon : region){
						for(ApprovedExceptionClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ApprovedExceptionClaimsValueCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsValueCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(ApprovedExceptionClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getApprovedExceptionClaimValue();
					}
					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<ApprovedExceptionClaimsValueCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					List<ApprovedExceptionClaimsValueCommb2c> accountList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					List<ApprovedExceptionClaimsValueCommb2c> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimsValueCommb2c>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(ApprovedExceptionClaimsValueCommb2c reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(ApprovedExceptionClaimsValueCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(ApprovedExceptionClaimsValueCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(ApprovedExceptionClaimsValueCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(ApprovedExceptionClaimsValueCommb2c t : totalAssetValues){
							totalAssetAmount += t.getApprovedExceptionClaimValue();
						}

						totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		
		//=========================================================Approved Exception Claim Value Start==========================================================================
		
		
		public ApprovedExceptionClaimsVolumeCommb2c getApprovedExceptionClaimVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

			Double totalAssetVolume = 0.00;
			ApprovedExceptionClaimsVolumeCommb2c totalAssetVolumeSum= new ApprovedExceptionClaimsVolumeCommb2c();
			//Integer totalAssetVolumeSum = 0;

			try{
				List<ApprovedExceptionClaimsVolumeCommb2c> totalAssetVolumes = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
				List<ApprovedExceptionClaimsVolumeCommb2c> totalAssetVolumeByUsername = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
				List<ApprovedExceptionClaimsVolumeCommb2c> mocList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
				
				totalAssetVolumeByUsername = approvedExceptiobClaimsVolumeCommb2cRepository.findAllApprovedExceptionClaimVolume();
	           

				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeCommb2c mocc : totalAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					for(ApprovedExceptionClaimsVolumeCommb2c t : mocList){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();

					}

					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<ApprovedExceptionClaimsVolumeCommb2c> categoryList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();

					//filtered by category

					for(String c : category){
						for(ApprovedExceptionClaimsVolumeCommb2c cat : totalAssetVolumeByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);
					for(ApprovedExceptionClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();

					}
					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
				}
				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<ApprovedExceptionClaimsVolumeCommb2c> accountList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					
					for(String accnt : account){
						for(ApprovedExceptionClaimsVolumeCommb2c acc : totalAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(ApprovedExceptionClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();

					}
					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<ApprovedExceptionClaimsVolumeCommb2c> accountList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					List<ApprovedExceptionClaimsVolumeCommb2c> filteredAccountCategoryList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();


					//filterd by account
					for(String accnt : account){
						for(ApprovedExceptionClaimsVolumeCommb2c acc : totalAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(ApprovedExceptionClaimsVolumeCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(ApprovedExceptionClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();
					}
					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<ApprovedExceptionClaimsVolumeCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					
					//filter by region
					for(String regon : region){
						for(ApprovedExceptionClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);
					for(ApprovedExceptionClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();
					}

					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
				}

				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<ApprovedExceptionClaimsVolumeCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					List<ApprovedExceptionClaimsVolumeCommb2c> filteredRegionAccountList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					
					//filter by region
					for(String regon : region){
						for(ApprovedExceptionClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(ApprovedExceptionClaimsVolumeCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(ApprovedExceptionClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();

					}
					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
				}



				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<ApprovedExceptionClaimsVolumeCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					List<ApprovedExceptionClaimsVolumeCommb2c> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
				
					//filterd by region

					for(String regon : region){
						for(ApprovedExceptionClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ApprovedExceptionClaimsVolumeCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);
					for(ApprovedExceptionClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();
					}
					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<ApprovedExceptionClaimsVolumeCommb2c> regionList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					List<ApprovedExceptionClaimsVolumeCommb2c> accountList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					List<ApprovedExceptionClaimsVolumeCommb2c> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimsVolumeCommb2c>();
					
					if(totalAssetVolumeByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(ApprovedExceptionClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(ApprovedExceptionClaimsVolumeCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(ApprovedExceptionClaimsVolumeCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(ApprovedExceptionClaimsVolumeCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetVolumes.addAll(mocList);

						for(ApprovedExceptionClaimsVolumeCommb2c t : totalAssetVolumes){
							totalAssetVolume += t.getApprovedExceptionClaimVolume();
						}

						totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetVolumeSum;

		}

		
		//=========================================================Red Claim Value Start==========================================================================
		
		
		
		public RedClaimsValueCommb2c getRedClaimValue(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			RedClaimsValueCommb2c totalAssetAmountSum = new RedClaimsValueCommb2c();


			try{
				List<RedClaimsValueCommb2c> totalAssetValues = new ArrayList<RedClaimsValueCommb2c>();
				List<RedClaimsValueCommb2c> totalAssetValuesByUsername = new ArrayList<RedClaimsValueCommb2c>();
				List<RedClaimsValueCommb2c> mocList = new ArrayList<RedClaimsValueCommb2c>();
				
				totalAssetValuesByUsername = redClaimsValueCommb2cRepository.findAllRedClaimValue();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsValueCommb2c mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(RedClaimsValueCommb2c t : mocList){
						totalAssetAmount += t.getRedClaimValue();

					}

					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<RedClaimsValueCommb2c> categoryList = new ArrayList<RedClaimsValueCommb2c>();
					
					//filtered by category

					for(String c : category){
						for(RedClaimsValueCommb2c cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(RedClaimsValueCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(RedClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getRedClaimValue();

					}
					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<RedClaimsValueCommb2c> accountList = new ArrayList<RedClaimsValueCommb2c>();
					
					
					for(String accnt : account){
						for(RedClaimsValueCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsValueCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(RedClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getRedClaimValue();

					}
					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<RedClaimsValueCommb2c> accountList = new ArrayList<RedClaimsValueCommb2c>();
					List<RedClaimsValueCommb2c> filteredAccountCategoryList = new ArrayList<RedClaimsValueCommb2c>();
					

					//filterd by account
					for(String accnt : account){
						for(RedClaimsValueCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(RedClaimsValueCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsValueCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(RedClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getRedClaimValue();
					}
					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<RedClaimsValueCommb2c> regionList = new ArrayList<RedClaimsValueCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(RedClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsValueCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(RedClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getRedClaimValue();
					}

					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<RedClaimsValueCommb2c> regionList = new ArrayList<RedClaimsValueCommb2c>();
					List<RedClaimsValueCommb2c> filteredRegionAccountList = new ArrayList<RedClaimsValueCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(RedClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(RedClaimsValueCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsValueCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(RedClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getRedClaimValue();

					}
					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<RedClaimsValueCommb2c> regionList = new ArrayList<RedClaimsValueCommb2c>();
					List<RedClaimsValueCommb2c> filteredRegionCategoryList = new ArrayList<RedClaimsValueCommb2c>();
					
					//filterd by region

					for(String regon : region){
						for(RedClaimsValueCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(RedClaimsValueCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsValueCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(RedClaimsValueCommb2c t : totalAssetValues){
						totalAssetAmount += t.getRedClaimValue();
					}
					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<RedClaimsValueCommb2c> regionList = new ArrayList<RedClaimsValueCommb2c>();
					List<RedClaimsValueCommb2c> accountList = new ArrayList<RedClaimsValueCommb2c>();
					List<RedClaimsValueCommb2c> filteredRegionCategoryList = new ArrayList<RedClaimsValueCommb2c>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(RedClaimsValueCommb2c reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(RedClaimsValueCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(RedClaimsValueCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(RedClaimsValueCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(RedClaimsValueCommb2c t : totalAssetValues){
							totalAssetAmount += t.getRedClaimValue();
						}

						totalAssetAmountSum.setRedClaimValue(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		
		//=========================================================Red Claim Volume Start==========================================================================
		
		
		public RedClaimsVolumeCommb2c getRedClaimVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

			Double totalAssetVolume = 0.00;
			RedClaimsVolumeCommb2c totalAssetVolumeSum= new RedClaimsVolumeCommb2c();
			//Integer totalAssetVolumeSum = 0;

			try{
				List<RedClaimsVolumeCommb2c> totalAssetVolumes = new ArrayList<RedClaimsVolumeCommb2c>();
				List<RedClaimsVolumeCommb2c> totalAssetVolumeByUsername = new ArrayList<RedClaimsVolumeCommb2c>();
				List<RedClaimsVolumeCommb2c> mocList = new ArrayList<RedClaimsVolumeCommb2c>();
				
				totalAssetVolumeByUsername = redClaimsVolumeCommb2cRepository.findAllRedClaimVolume();
	           

				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsVolumeCommb2c mocc : totalAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					for(RedClaimsVolumeCommb2c t : mocList){
						totalAssetVolume += t.getRedClaimVolume();

					}

					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<RedClaimsVolumeCommb2c> categoryList = new ArrayList<RedClaimsVolumeCommb2c>();

					//filtered by category

					for(String c : category){
						for(RedClaimsVolumeCommb2c cat : totalAssetVolumeByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsVolumeCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);
					for(RedClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getRedClaimVolume();

					}
					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
				}
				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<RedClaimsVolumeCommb2c> accountList = new ArrayList<RedClaimsVolumeCommb2c>();
					
					for(String accnt : account){
						for(RedClaimsVolumeCommb2c acc : totalAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsVolumeCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(RedClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getRedClaimVolume();

					}
					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<RedClaimsVolumeCommb2c> accountList = new ArrayList<RedClaimsVolumeCommb2c>();
					List<RedClaimsVolumeCommb2c> filteredAccountCategoryList = new ArrayList<RedClaimsVolumeCommb2c>();


					//filterd by account
					for(String accnt : account){
						for(RedClaimsVolumeCommb2c acc : totalAssetVolumeByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(RedClaimsVolumeCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsVolumeCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(RedClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getRedClaimVolume();
					}
					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<RedClaimsVolumeCommb2c> regionList = new ArrayList<RedClaimsVolumeCommb2c>();
					
					//filter by region
					for(String regon : region){
						for(RedClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsVolumeCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);
					for(RedClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getRedClaimVolume();
					}

					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
				}

				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<RedClaimsVolumeCommb2c> regionList = new ArrayList<RedClaimsVolumeCommb2c>();
					List<RedClaimsVolumeCommb2c> filteredRegionAccountList = new ArrayList<RedClaimsVolumeCommb2c>();
					
					//filter by region
					for(String regon : region){
						for(RedClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(RedClaimsVolumeCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsVolumeCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(RedClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getRedClaimVolume();

					}
					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
				}



				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<RedClaimsVolumeCommb2c> regionList = new ArrayList<RedClaimsVolumeCommb2c>();
					List<RedClaimsVolumeCommb2c> filteredRegionCategoryList = new ArrayList<RedClaimsVolumeCommb2c>();
				
					//filterd by region

					for(String regon : region){
						for(RedClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(RedClaimsVolumeCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimsVolumeCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);
					for(RedClaimsVolumeCommb2c t : totalAssetVolumes){
						totalAssetVolume += t.getRedClaimVolume();
					}
					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<RedClaimsVolumeCommb2c> regionList = new ArrayList<RedClaimsVolumeCommb2c>();
					List<RedClaimsVolumeCommb2c> accountList = new ArrayList<RedClaimsVolumeCommb2c>();
					List<RedClaimsVolumeCommb2c> filteredRegionCategoryList = new ArrayList<RedClaimsVolumeCommb2c>();
					
					if(totalAssetVolumeByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(RedClaimsVolumeCommb2c reg : totalAssetVolumeByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(RedClaimsVolumeCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(RedClaimsVolumeCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(RedClaimsVolumeCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetVolumes.addAll(mocList);

						for(RedClaimsVolumeCommb2c t : totalAssetVolumes){
							totalAssetVolume += t.getRedClaimVolume();
						}

						totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetVolumeSum;

		}

		
		
		//=========================================================Total Amount Payable Start==========================================================================
		
		public TotalAmountPayableCommb2c getTotalAmountPayable(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			TotalAmountPayableCommb2c totalAssetAmountSum = new TotalAmountPayableCommb2c();


			try{
				List<TotalAmountPayableCommb2c> totalAssetValues = new ArrayList<TotalAmountPayableCommb2c>();
				List<TotalAmountPayableCommb2c> totalAssetValuesByUsername = new ArrayList<TotalAmountPayableCommb2c>();
				List<TotalAmountPayableCommb2c> mocList = new ArrayList<TotalAmountPayableCommb2c>();
				
				totalAssetValuesByUsername = totalAmountPayableCommb2cRepository.findAllTotalAmountPayable();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayableCommb2c mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(TotalAmountPayableCommb2c t : mocList){
						totalAssetAmount += t.getTotalAmountPayable();

					}

					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<TotalAmountPayableCommb2c> categoryList = new ArrayList<TotalAmountPayableCommb2c>();
					
					//filtered by category

					for(String c : category){
						for(TotalAmountPayableCommb2c cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayableCommb2c mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(TotalAmountPayableCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPayable();

					}
					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<TotalAmountPayableCommb2c> accountList = new ArrayList<TotalAmountPayableCommb2c>();
					
					
					for(String accnt : account){
						for(TotalAmountPayableCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayableCommb2c mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPayableCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPayable();

					}
					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<TotalAmountPayableCommb2c> accountList = new ArrayList<TotalAmountPayableCommb2c>();
					List<TotalAmountPayableCommb2c> filteredAccountCategoryList = new ArrayList<TotalAmountPayableCommb2c>();
					

					//filterd by account
					for(String accnt : account){
						for(TotalAmountPayableCommb2c acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(TotalAmountPayableCommb2c cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayableCommb2c mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPayableCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPayable();
					}
					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<TotalAmountPayableCommb2c> regionList = new ArrayList<TotalAmountPayableCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPayableCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayableCommb2c mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPayableCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPayable();
					}

					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<TotalAmountPayableCommb2c> regionList = new ArrayList<TotalAmountPayableCommb2c>();
					List<TotalAmountPayableCommb2c> filteredRegionAccountList = new ArrayList<TotalAmountPayableCommb2c>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPayableCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(TotalAmountPayableCommb2c acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayableCommb2c mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAmountPayableCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPayable();

					}
					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<TotalAmountPayableCommb2c> regionList = new ArrayList<TotalAmountPayableCommb2c>();
					List<TotalAmountPayableCommb2c> filteredRegionCategoryList = new ArrayList<TotalAmountPayableCommb2c>();
					
					//filterd by region

					for(String regon : region){
						for(TotalAmountPayableCommb2c reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(TotalAmountPayableCommb2c cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayableCommb2c mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPayableCommb2c t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPayable();
					}
					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<TotalAmountPayableCommb2c> regionList = new ArrayList<TotalAmountPayableCommb2c>();
					List<TotalAmountPayableCommb2c> accountList = new ArrayList<TotalAmountPayableCommb2c>();
					List<TotalAmountPayableCommb2c> filteredRegionCategoryList = new ArrayList<TotalAmountPayableCommb2c>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(TotalAmountPayableCommb2c reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(TotalAmountPayableCommb2c acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(TotalAmountPayableCommb2c cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(TotalAmountPayableCommb2c mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(TotalAmountPayableCommb2c t : totalAssetValues){
							totalAssetAmount += t.getTotalAmountPayable();
						}

						totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		//=========================================================Total Amount Paid Start==========================================================================
		
		
		public TotalAmountPaid getTotalAmountPaid(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			TotalAmountPaid totalAssetAmountSum = new TotalAmountPaid();


			try{
				List<TotalAmountPaid> totalAssetValues = new ArrayList<TotalAmountPaid>();
				List<TotalAmountPaid> totalAssetValuesByUsername = new ArrayList<TotalAmountPaid>();
				List<TotalAmountPaid> mocList = new ArrayList<TotalAmountPaid>();
				
				totalAssetValuesByUsername = totalAmountPaidRepository.findAllTotalAmountPaidDetails();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPaid mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(TotalAmountPaid t : mocList){
						totalAssetAmount += t.getTotalAmountPaid();

					}

					totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<TotalAmountPaid> categoryList = new ArrayList<TotalAmountPaid>();
					
					//filtered by category

					for(String c : category){
						for(TotalAmountPaid cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPaid mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(TotalAmountPaid t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPaid();

					}
					totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<TotalAmountPaid> accountList = new ArrayList<TotalAmountPaid>();
					
					
					for(String accnt : account){
						for(TotalAmountPaid acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPaid mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPaid t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPaid();

					}
					totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<TotalAmountPaid> accountList = new ArrayList<TotalAmountPaid>();
					List<TotalAmountPaid> filteredAccountCategoryList = new ArrayList<TotalAmountPaid>();
					

					//filterd by account
					for(String accnt : account){
						for(TotalAmountPaid acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(TotalAmountPaid cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPaid mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPaid t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPaid();
					}
					totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<TotalAmountPaid> regionList = new ArrayList<TotalAmountPaid>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPaid reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPaid mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPaid t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPaid();
					}

					totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<TotalAmountPaid> regionList = new ArrayList<TotalAmountPaid>();
					List<TotalAmountPaid> filteredRegionAccountList = new ArrayList<TotalAmountPaid>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPaid reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(TotalAmountPaid acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPaid mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAmountPaid t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPaid();

					}
					totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<TotalAmountPaid> regionList = new ArrayList<TotalAmountPaid>();
					List<TotalAmountPaid> filteredRegionCategoryList = new ArrayList<TotalAmountPaid>();
					
					//filterd by region

					for(String regon : region){
						for(TotalAmountPaid reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(TotalAmountPaid cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPaid mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPaid t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPaid();
					}
					totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<TotalAmountPaid> regionList = new ArrayList<TotalAmountPaid>();
					List<TotalAmountPaid> accountList = new ArrayList<TotalAmountPaid>();
					List<TotalAmountPaid> filteredRegionCategoryList = new ArrayList<TotalAmountPaid>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(TotalAmountPaid reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(TotalAmountPaid acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(TotalAmountPaid cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(TotalAmountPaid mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(TotalAmountPaid t : totalAssetValues){
							totalAssetAmount += t.getTotalAmountPaid();
						}

						totalAssetAmountSum.setTotalAmountPaid(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		
		//=========================================================Total Amount Pending Start==========================================================================
		
		
		public TotalAmountPending getTotalAmountPending(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			TotalAmountPending totalAssetAmountSum = new TotalAmountPending();


			try{
				List<TotalAmountPending> totalAssetValues = new ArrayList<TotalAmountPending>();
				List<TotalAmountPending> totalAssetValuesByUsername = new ArrayList<TotalAmountPending>();
				List<TotalAmountPending> mocList = new ArrayList<TotalAmountPending>();
				
				totalAssetValuesByUsername = totalAmountPendingRepository.findAllTotalAmountPendingDetails();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(TotalAmountPending t : mocList){
						totalAssetAmount += t.getTotalAmountPending();

					}

					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<TotalAmountPending> categoryList = new ArrayList<TotalAmountPending>();
					
					//filtered by category

					for(String c : category){
						for(TotalAmountPending cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(TotalAmountPending t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPending();

					}
					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<TotalAmountPending> accountList = new ArrayList<TotalAmountPending>();
					
					
					for(String accnt : account){
						for(TotalAmountPending acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPending t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPending();

					}
					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<TotalAmountPending> accountList = new ArrayList<TotalAmountPending>();
					List<TotalAmountPending> filteredAccountCategoryList = new ArrayList<TotalAmountPending>();
					

					//filterd by account
					for(String accnt : account){
						for(TotalAmountPending acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(TotalAmountPending cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(TotalAmountPending t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPending();
					}
					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPending reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPending t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPending();
					}

					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
					List<TotalAmountPending> filteredRegionAccountList = new ArrayList<TotalAmountPending>();
					
					
					//filter by region
					for(String regon : region){
						for(TotalAmountPending reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(TotalAmountPending acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAmountPending t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPending();

					}
					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
					List<TotalAmountPending> filteredRegionCategoryList = new ArrayList<TotalAmountPending>();
					
					//filterd by region

					for(String regon : region){
						for(TotalAmountPending reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(TotalAmountPending cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(TotalAmountPending t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPending();
					}
					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
					List<TotalAmountPending> accountList = new ArrayList<TotalAmountPending>();
					List<TotalAmountPending> filteredRegionCategoryList = new ArrayList<TotalAmountPending>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(TotalAmountPending reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(TotalAmountPending acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(TotalAmountPending cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(TotalAmountPending mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(TotalAmountPending t : totalAssetValues){
							totalAssetAmount += t.getTotalAmountPending();
						}

						totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		
		
		//=========================================================Claims Raised Start==========================================================================
		
		
		public ClaimsRaised getClaimsRaised(List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			ClaimsRaised totalAssetAmountSum = new ClaimsRaised();


			try{
				List<ClaimsRaised> totalAssetValues = new ArrayList<ClaimsRaised>();
				List<ClaimsRaised> totalAssetValuesByUsername = new ArrayList<ClaimsRaised>();
				List<ClaimsRaised> mocList = new ArrayList<ClaimsRaised>();
				
				totalAssetValuesByUsername = claimsRaisedRepository.findAllClaimsRaisedDetails();
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(ClaimsRaised mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(ClaimsRaised t : mocList){
						totalAssetAmount += t.getClaimsRaised();

					}

					totalAssetAmountSum.setClaimsRaised(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<ClaimsRaised> categoryList = new ArrayList<ClaimsRaised>();
					
					//filtered by category

					for(String c : category){
						for(ClaimsRaised cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ClaimsRaised mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(ClaimsRaised t : totalAssetValues){
						totalAssetAmount += t.getClaimsRaised();

					}
					totalAssetAmountSum.setClaimsRaised(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<ClaimsRaised> accountList = new ArrayList<ClaimsRaised>();
					
					
					for(String accnt : account){
						for(ClaimsRaised acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(ClaimsRaised mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(ClaimsRaised t : totalAssetValues){
						totalAssetAmount += t.getClaimsRaised();

					}
					totalAssetAmountSum.setClaimsRaised(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<ClaimsRaised> accountList = new ArrayList<ClaimsRaised>();
					List<ClaimsRaised> filteredAccountCategoryList = new ArrayList<ClaimsRaised>();
					

					//filterd by account
					for(String accnt : account){
						for(ClaimsRaised acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(ClaimsRaised cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ClaimsRaised mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(ClaimsRaised t : totalAssetValues){
						totalAssetAmount += t.getClaimsRaised();
					}
					totalAssetAmountSum.setClaimsRaised(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<ClaimsRaised> regionList = new ArrayList<ClaimsRaised>();
					
					
					//filter by region
					for(String regon : region){
						for(ClaimsRaised reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ClaimsRaised mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(ClaimsRaised t : totalAssetValues){
						totalAssetAmount += t.getClaimsRaised();
					}

					totalAssetAmountSum.setClaimsRaised(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<ClaimsRaised> regionList = new ArrayList<ClaimsRaised>();
					List<ClaimsRaised> filteredRegionAccountList = new ArrayList<ClaimsRaised>();
					
					
					//filter by region
					for(String regon : region){
						for(ClaimsRaised reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(ClaimsRaised acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ClaimsRaised mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(ClaimsRaised t : totalAssetValues){
						totalAssetAmount += t.getClaimsRaised();

					}
					totalAssetAmountSum.setClaimsRaised(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<ClaimsRaised> regionList = new ArrayList<ClaimsRaised>();
					List<ClaimsRaised> filteredRegionCategoryList = new ArrayList<ClaimsRaised>();
					
					//filterd by region

					for(String regon : region){
						for(ClaimsRaised reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ClaimsRaised cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ClaimsRaised mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(ClaimsRaised t : totalAssetValues){
						totalAssetAmount += t.getClaimsRaised();
					}
					totalAssetAmountSum.setClaimsRaised(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<ClaimsRaised> regionList = new ArrayList<ClaimsRaised>();
					List<ClaimsRaised> accountList = new ArrayList<ClaimsRaised>();
					List<ClaimsRaised> filteredRegionCategoryList = new ArrayList<ClaimsRaised>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(ClaimsRaised reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(ClaimsRaised acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(ClaimsRaised cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(ClaimsRaised mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(ClaimsRaised t : totalAssetValues){
							totalAssetAmount += t.getClaimsRaised();
						}

						totalAssetAmountSum.setClaimsRaised(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		
		
		
		
		

}
