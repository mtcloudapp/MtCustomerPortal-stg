package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.AvailablePO;

@Repository
public interface AvailablePORepository extends JpaRepository<AvailablePO, Integer>{
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber", nativeQuery = true)
	List<String> findFInalReasonHeaderList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber);
	
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category", nativeQuery = true)
	List<String> findFInalReasonHeaderList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category);
	
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER2 from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne", nativeQuery = true)
	List<String> findFInalReasonHeader2List(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER2 from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne", nativeQuery = true)
	List<String> findFInalReasonHeader2List(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne);
	
	
	
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER2 in :headerTwo", nativeQuery = true)
	List<String> findFinalReasonList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerTwo") List<String> headerTwo);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER2 in :headerTwo", nativeQuery = true)
	List<String> findFinalReasonList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerTwo") List<String> headerTwo);

	
	@Transactional
    @Query(value ="select DISTINCT tac.C_ACTION from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON in :finalReason", nativeQuery = true)
	List<String> findCactionList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("finalReason") List<String> finalReason);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_ACTION from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON in :finalReason", nativeQuery = true)
	List<String> findCactionList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("finalReason") List<String> finalReason);
//===========================================================Header_1==========================================================================================
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER =:headerOne", nativeQuery = true)
	Double findCountOrderValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") String headerOne);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER =:headerOne", nativeQuery = true)
	Double findCountAllocatedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") String headerOne);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER =:headerOne", nativeQuery = true)
	Double findCountInvoicedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") String headerOne);
	
	
/////////////////////////////////////////////WITHOUT PONUMBER////////////////////////////////////////////////////////
	
	
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne", nativeQuery = true)
	Double findCountOrderValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,@Param("headerOne") String headerOne);
	
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne", nativeQuery = true)
	Double findCountAllocatedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") String headerOne);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne", nativeQuery = true)
	Double findCountInvoicedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") String headerOne);
	
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber", nativeQuery = true)
	Integer findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category", nativeQuery = true)
	Integer findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category);
	
	
	
//=======================================================================Header-2=========================================================================================
	
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo", nativeQuery = true)
	Double findCountOrderValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo", nativeQuery = true)
	Double findCountAllocatedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo", nativeQuery = true)
	Double findCountInvoicedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo);
	
	
/////////////////////////////////////////////////Without Po Number///////////////////////////////////////////////////////	
	
	
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo", nativeQuery = true)
	Double findCountOrderValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo", nativeQuery = true)
	Double findCountAllocatedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo", nativeQuery = true)
	Double findCountInvoicedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo);
	
	
	
	
	//=================================================================================================================================================================

	//===============================================cFinalReasonHeader======================================================
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason", nativeQuery = true)
	Double findCountOrderValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason", nativeQuery = true)
	Double findCountAllocatedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason", nativeQuery = true)
	Double findCountInvoicedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason);
	
	
	//====================================================Without Po Number======================================================
	
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason", nativeQuery = true)
	Double findCountOrderValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason", nativeQuery = true)
	Double findCountAllocatedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason", nativeQuery = true)
	Double findCountInvoicedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason);
	
	
	
	
	
	
	
	
	
	//===============================================================================================================================
	
	//=================================================cAction2==========================================================
	
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction", nativeQuery = true)
	Double findCountOrderValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction", nativeQuery = true)
	Double findCountAllocatedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction", nativeQuery = true)
	Double findCountInvoicedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction);
	
	
	//==================================================================================================================================
	
	//=====================================================Without Po Number===============================================
	
	@Transactional
    @Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction", nativeQuery = true)
	Double findCountOrderValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction", nativeQuery = true)
	Double findCountAllocatedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction);
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction", nativeQuery = true)
	Double findCountInvoicedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne", nativeQuery = true)
	Integer findNoOfLinesCountByHeaderOne(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo", nativeQuery = true)
	Integer findCFinalReasonNoOfLinesCountByB2C(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo);
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne "
    		+ "and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :cFinalReason", nativeQuery = true)
	Integer findCActionNoOfLinesCountByB2C(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("cFinalReason") List<String> cFinalReason);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".AVAILABLE_PO", nativeQuery = true)
	List<AvailablePO> findAvailablePoList();
	
}
