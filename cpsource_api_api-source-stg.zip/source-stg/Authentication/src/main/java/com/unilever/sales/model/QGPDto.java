package com.unilever.sales.model;

import java.io.Serializable;

public class QGPDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 7867875090715450059L;
	
	private Double qgpPercentage;
	
	
	public QGPDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Double getQgpPercentage() {
		return qgpPercentage;
	}


	public void setQgpPercentage(Double qgpPercentage) {
		this.qgpPercentage = qgpPercentage;
	}

	

}
