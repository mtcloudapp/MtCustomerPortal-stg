package com.unilever.asset.external.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.asset.external.model.CustomerNonCompliantValue;
import com.unilever.asset.external.model.CustomerNonCompliantVolume;
import com.unilever.asset.external.model.ExternalCurentView;
import com.unilever.asset.external.model.ExternalCurrentMocViewDto;
import com.unilever.asset.external.model.ExternalNextMocView;
import com.unilever.asset.external.model.ExternalNextMocViewDto;
import com.unilever.asset.external.model.ExternalPreviousMocView;
import com.unilever.asset.external.model.ExternalPreviousMocViewDto;
import com.unilever.asset.external.model.OtherIssuesValue;
import com.unilever.asset.external.model.OtherIssuesVolume;
import com.unilever.asset.external.model.StoreListCount;
import com.unilever.asset.external.model.StoreListValue;
import com.unilever.asset.external.model.TotalAssetPlannedValue;
import com.unilever.asset.external.model.TotalAssetPlannedVolume;
import com.unilever.asset.external.model.TotalAssetValueExternal;
import com.unilever.asset.external.model.TotalAssetVolumeExternal;
import com.unilever.asset.external.model.TrackAndCompliedValue;
import com.unilever.asset.external.model.TrackAndCompliedVolume;
import com.unilever.asset.external.service.ExternalAssetService;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.service.KamAssetService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class ExternalAssetController {
	
	@Autowired
	ExternalAssetService externalAssetService;
	

	@GetMapping("/getAllExtenalTotalAssetValue")
	public TotalAssetValueExternal getAllExtenalTotalAssetValue(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetValueSum=0;
		TotalAssetValueExternal totalAssetValue = new TotalAssetValueExternal();
		try{
			
		//	 totalAssetValue = externalAssetService.getExternalTotalAssetCreatedValue(username, region, moc, category);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	@GetMapping("/getAllExternalTotalAssetVolume")
	public TotalAssetVolumeExternal getAllExternalTotalAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		TotalAssetVolumeExternal totalAssetCreatedVolumeSum = new TotalAssetVolumeExternal();
		try{
			//totalAssetCreatedVolumeSum = externalAssetService.getExternalTotalAssetCreatedVolume(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedVolumeSum;		
		
	}
	//===============================================Track And Complied Asset Controller============================================
	
	
	@GetMapping("/getAllExternalTrackAndCompliedAssetValue")
	public TrackAndCompliedValue getAllExternalTrackAndCompliedAssetValue(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		TrackAndCompliedValue totalAssetCreatedValueSum = new TrackAndCompliedValue();
		try{
		//	totalAssetCreatedValueSum = externalAssetService.getExternalTrackAndCompliedValue(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedValueSum;		
		
	}


	@GetMapping("/getAllExternalTrackAndCompliedAssetVolume")
	public TrackAndCompliedVolume getAllExternalTrackAndCompliedAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		TrackAndCompliedVolume totalAssetCreatedVolumeSum = new TrackAndCompliedVolume();
		try{
			//totalAssetCreatedVolumeSum = externalAssetService.getExternalTrackAndCompliedVolume(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedVolumeSum;		
		
	}

//===============================Customer Non complied Asset================================================================

	@GetMapping("/getAllExternalCustomerNonComplienceAssetValue")
	public CustomerNonCompliantValue getAllExternalCustomerNonComplienceAssetValue(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		CustomerNonCompliantValue totalAssetCreatedValueSum = new CustomerNonCompliantValue();
		try{
			//totalAssetCreatedValueSum = externalAssetService.getExternalCustomerNonCompliantValueValue(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedValueSum;		
		
	}
	
	@GetMapping("/getAllExternalCustomerNonComplienceAssetVolume")
	public CustomerNonCompliantVolume getAllExternalCustomerNonComplienceAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		CustomerNonCompliantVolume totalAssetCreatedVolumeSum = new CustomerNonCompliantVolume();
		try{
		//	totalAssetCreatedVolumeSum = externalAssetService.getExternalCustomerNonCompliantVolume(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedVolumeSum;	
		
	}
	
//=============================================Other Issuse==================================================================	
	
	@GetMapping("/getAllExternalOtherIssusetValue")
	public OtherIssuesValue getAllExternalOtherIssusetValue(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		OtherIssuesValue totalAssetCreatedValueSum = new OtherIssuesValue();
		try{
		//	totalAssetCreatedValueSum = externalAssetService.getExternalOtherIssuesValue(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedValueSum;		
		
	}
	
	
	@GetMapping("/getAllExternalOtherIssuseVolume")
	public OtherIssuesVolume getAllExternalOtherIssuseVolume(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		OtherIssuesVolume totalAssetCreatedVolumeSum = new OtherIssuesVolume();
		try{
		//totalAssetCreatedVolumeSum = externalAssetService.getExternalOtherIssuesVolume(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedVolumeSum;	
		
	}
	


	//=============================================Store List ==================================================================	




	@GetMapping("/getAllExternalStoreListCount")
	public StoreListCount getAllExternalStoreListCount(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		StoreListCount totalAssetCreatedValueSum = new StoreListCount();
		try{
			//totalAssetCreatedValueSum = externalAssetService.getExternalStoreListCount(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedValueSum;		
		
	}




	@GetMapping("/getAllExternalStoreListValue")
	public StoreListValue getAllExternalStoreListValue(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		StoreListValue totalAssetCreatedValueSum = new StoreListValue();
		try{
			//totalAssetCreatedValueSum = externalAssetService.getExternalStoreListValuee(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedValueSum;		
		
	}



//====================================================================Planned Asset==========================================================


	@GetMapping("/getAllExternalTotalPlannedAssetValue")
	public TotalAssetPlannedValue getAllExternalTotalPlannedAssetValue(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		TotalAssetPlannedValue totalAssetCreatedValueSum = new TotalAssetPlannedValue();
		try{
			//totalAssetCreatedValueSum = externalAssetService.getExternalTotalAssetPlannedValue(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedValueSum;		
		
	}



	@GetMapping("/getAllExternalTotalPlannedAssetVolume")
	public TotalAssetPlannedVolume getAllExternalTotalPlannedAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		TotalAssetPlannedVolume totalAssetCreatedValueSum = new TotalAssetPlannedVolume();
		try{
		//	totalAssetCreatedValueSum = externalAssetService.getExternalTotalAssetPlannedVolume(username, region, moc, category);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedValueSum;		
		
	}

//==================================================MOC Views==================================================
	@GetMapping("/getExternalCurrentMocView")
	public List<ExternalCurrentMocViewDto> getExternalCurrentNextMocView(@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,@RequestParam("account") String account,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
		    @RequestParam(defaultValue = "10") Integer pageSize){
		
		List<ExternalCurrentMocViewDto> externalCurentNextView = new ArrayList<ExternalCurrentMocViewDto>();
		try{
			externalCurentNextView = externalAssetService.getExternalCurrentMocView(region,moc, account, category,pageNo,pageSize);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalCurentNextView;
	
	}


	@GetMapping("/getExternalPreviousMocView")
	public List<ExternalPreviousMocViewDto> getExternalPreviousMocView(@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,@RequestParam("account") String account,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
		    @RequestParam(defaultValue = "10") Integer pageSize){
		
		List<ExternalPreviousMocViewDto> externalPreviousMocView = new ArrayList<>();
		try{
			externalPreviousMocView = externalAssetService.getExternalPreviousMocView(region,moc, account, category,pageNo,pageSize);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalPreviousMocView;
	
	}

	@GetMapping("/getExternalNextMocView")
	public List<ExternalNextMocViewDto> getExternalNextMocView(@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,@RequestParam("account") String account,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
		    @RequestParam(defaultValue = "10") Integer pageSize){
		
		List<ExternalNextMocViewDto> externalNextMocView = new ArrayList<>();
		try{
			externalNextMocView = externalAssetService.getExternalNextMocView(region, moc, account, category,pageNo,pageSize);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalNextMocView;
	
	}




}
