package com.unilever.claims.extenal.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_PAYMENT_STATUS")
public class ExternalPaymentStatus implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 581102792258535658L;
	
	@Id
	@Column(name="INVOICE_NO")
    private String invoiceNo;
	
	@Column(name="UPDATED_PAID_AMT")
    private Double paidAmt;

	@Column(name="SOL_CODE")
    private String soleCode;
	
	@Column(name="STATE")
    private String state;
	
	@Column(name="ACTUAL_PAID_AMOUNT")
    private Double actualPaidAmt;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="REGION")
    private String region;
	
	@Column(name="CATEGORY")
    private String category;
	
	
	
	public ExternalPaymentStatus() {
		super();
		// TODO Auto-generated constructor stub
	}



	public ExternalPaymentStatus(String invoiceNo, Double paidAmt, String soleCode, String state, Double actualPaidAmt,
			String account, String moc, String region, String category) {
		super();
		this.invoiceNo = invoiceNo;
		this.paidAmt = paidAmt;
		this.soleCode = soleCode;
		this.state = state;
		this.actualPaidAmt = actualPaidAmt;
		this.account = account;
		this.moc = moc;
		this.region = region;
		this.category = category;
	}





	public Double getActualPaidAmt() {
		return actualPaidAmt;
	}



	public void setActualPaidAmt(Double actualPaidAmt) {
		this.actualPaidAmt = actualPaidAmt;
	}


	public String getSoleCode() {
		return soleCode;
	}


	public void setSoleCode(String soleCode) {
		this.soleCode = soleCode;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Double getPaidAmt() {
		return paidAmt;
	}

	public void setPaidAmt(Double paidAmt) {
		this.paidAmt = paidAmt;
	}




	public String getState() {
		return state;
	}




	public void setState(String state) {
		this.state = state;
	}



	public String getAccount() {
		return account;
	}



	public void setAccount(String account) {
		this.account = account;
	}



	public String getMoc() {
		return moc;
	}



	public void setMoc(String moc) {
		this.moc = moc;
	}



	public String getRegion() {
		return region;
	}



	public void setRegion(String region) {
		this.region = region;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}
	
	
	

}
