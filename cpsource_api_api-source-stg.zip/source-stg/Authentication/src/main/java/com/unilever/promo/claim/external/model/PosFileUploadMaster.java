package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "POS_FILE_UPLOAD_MASTER")
public class PosFileUploadMaster implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6883783567938946710L;
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name="RECORD_ID")
	 private Integer recordId;
	 
	 @Column(name="FILE_NO")
     private Integer fileNo;
	 
	 @Column(name="ACCOUNT_NAME")
     private String accountName;
	 
	 @Column(name="MOC")
     private String moc;
	 
	 @Column(name="WORKFLOW_STAGE_ID")
     private Integer workflowStageId;
	 
	 @Column(name="UPLOAD_BY")
     private String uploadBy;
	 
	 @Column(name="UPLOAD_DATE")
     private String uploadDate;
	 
	 @Column(name="AUDIT_CREATE_DATE")
     private String auditCreateDate;
	 
	 @Column(name="AUDIT_MODIFIED_DATE")
     private String auditModifiedDate;
	 
	 //Added By Sarin Jul2021 - Claim File B2C Approval
	 @Column(name="S3_PATH")
     private String s3Path;
	 
	//Added By Sarin Mar2022 - POS File KAM Approval - Starts
	@Column(name="KAM_USERNAME_APPROVER")
	private String kamApprover;
 
	@Column(name="KAM_ACTION")
	private String kamAction;
 
	@Column(name="KAM_APPROVED_DATE")
	private String kamApprovedDate;
 
	@Column(name="B2C_APPROVED_DATE")
	private String b2cApprovedDate;
	//Added By Sarin Mar2022 - POS File KAM Approval - Ends

	public PosFileUploadMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PosFileUploadMaster(Integer recordId, Integer fileNo, String accountName, String moc,
			Integer workflowStageId, String uploadBy, String uploadDate, String auditCreateDate,
			String auditModifiedDate, String s3Path) {
		super();
		this.recordId = recordId;
		this.fileNo = fileNo;
		this.accountName = accountName;
		this.moc = moc;
		this.workflowStageId = workflowStageId;
		this.uploadBy = uploadBy;
		this.uploadDate = uploadDate;
		this.auditCreateDate = auditCreateDate;
		this.auditModifiedDate = auditModifiedDate;
		this.s3Path = s3Path;  //Added By Sarin Jul2021 - Claim File B2C Approval
	}

	public Integer getRecordId() {
		return recordId;
	}

	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}

	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Integer getWorkflowStageId() {
		return workflowStageId;
	}

	public void setWorkflowStageId(Integer workflowStageId) {
		this.workflowStageId = workflowStageId;
	}

	public String getUploadBy() {
		return uploadBy;
	}

	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}

	public String getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}

	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}
	
	//Added By Sarin Jul2021 - Claim File B2C Approval - Starts
	public String getS3Path() {
		return s3Path;
	}

	public void setS3Path(String s3Path) {
		this.s3Path = s3Path;
	}
	//Added By Sarin Jul2021 - Claim File B2C Approval - Ends

	//Added By Sarin Mar2022 - POS File KAM Approval - Starts
	public String getKamApprover() {
		return kamApprover;
	}

	public void setKamApprover(String kamApprover) {
		this.kamApprover = kamApprover;
	}

	public String getKamAction() {
		return kamAction;
	}

	public void setKamAction(String kamAction) {
		this.kamAction = kamAction;
	}

	public String getKamApprovedDate() {
		return kamApprovedDate;
	}

	public void setKamApprovedDate(String kamApprovedDate) {
		this.kamApprovedDate = kamApprovedDate;
	}

	public String getB2cApprovedDate() {
		return b2cApprovedDate;
	}

	public void setB2cApprovedDate(String b2cApprovedDate) {
		this.b2cApprovedDate = b2cApprovedDate;
	}
	//Added By Sarin Mar2022 - POS File KAM Approval - Ends
}
