package com.unilever.Authentication.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.Authentication.model.SupportUser;
import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaimSummary;

@Repository
public interface SupportUserRepository extends JpaRepository<SupportUser, Integer>{
	
	
	@Transactional 
    @Query(value ="select count(*) from "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_MASTER scdm where "
    		+ "scdm.SOL_CODE=:solcode and scdm.Article_Code=:articleCode and scdm.BasePack=:basepack", nativeQuery = true)
	Integer findSupportUserBySolCode(@Param("solcode") Integer solcode,@Param("articleCode") Integer articleCode,@Param("basepack") Integer basepack);
	

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_MASTER  scdm set scdm.SOL_CODE_DESCRIPTION_NEW=:solCodeDescpNew where "
			+ "scdm.SOL_CODE=:solcode and scdm.Article_Code=:articleCode and scdm.BasePack=:basepack", nativeQuery = true)
	void updateBySupportUser(@Param("solCodeDescpNew") String solCodeDescpNew,@Param("solcode") Integer solcode,@Param("articleCode") Integer articleCode,@Param("basepack") Integer basepack);

//	@Transactional
//    @Query(value ="select * from "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_MASTER pcfm  where pcfm.Account_Name=:account and pcfm.MOC=:moc", nativeQuery = true)
//	Page<SupportUser> findSupportUserDetailsByAcntAndMoc(@Param("account") String account,@Param("moc") String moc,Pageable pageable);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_TEMP pcm where pcm.ACCOUNT_NAME=:account and pcm.MOC=:moc", nativeQuery = true)
	Page<SupportUser> findSupportUserDetailsByAcntAndMoc(@Param("account") String account,@Param("moc") String moc,Pageable pageable);
	
	
//	@Transactional 
//    @Query(value ="select * from "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_MASTER pcfm  where pcfm.Account_Name=:account and pcfm.MOC=:moc", nativeQuery = true)
//	List<SupportUser> findCountByAccountAndMoc(@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_TEMP", nativeQuery = true)
	List<SupportUser> findCountByAccountAndMoc();
	
	@Transactional 
    @Query(value ="select count(*) from "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_TEMP scdm where "
    		+ "scdm.SOL_CODE=:solcode", nativeQuery = true)
	Integer findSupportUserBySolCode(@Param("solcode") Integer solcode);
	

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_TEMP  scdm set scdm.SOL_CODE_DESCRIPTION_NEW=:solCodeDescpNew where "
			+ "scdm.SOL_CODE=:solcode", nativeQuery = true)
	void updateBySupportUser(@Param("solCodeDescpNew") String solCodeDescpNew,@Param("solcode") Integer solcode);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_TEMP  scdm set scdm.SOL_CODE=:solcode,scdm.SOL_CODE_DESCRIPTION_OLD=:solcodeDescOld,"
			+ "scdm.SOL_CODE_DESCRIPTION_NEW=:solCodeDescNew,scdm.AUDIT_MODIFIED_DATE=:modifiedDate  where "
			+ "scdm.SOL_CODE=:solcode", nativeQuery = true)
	void updateBySolcode(@Param("solcode") Integer solcode,@Param("solcodeDescOld") String solcodeDescOld,
			@Param("solCodeDescNew") String solCodeDescNew,@Param("modifiedDate") String modifiedDate);
	
	@Transactional 
    @Query(value ="select scdm.SOL_CODE from "+GlobalVariables.schemaName+".SOL_CODE_DESCRIPTION_TEMP scdm", nativeQuery = true)
	List<Integer> findSolCode();
}
