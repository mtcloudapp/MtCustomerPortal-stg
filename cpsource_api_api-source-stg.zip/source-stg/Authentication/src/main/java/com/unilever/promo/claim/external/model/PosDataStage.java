package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "POS_DATA_STAGE")
public class PosDataStage implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6089623888550316429L;
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name="RECORD_ID")
	 private String recordID;
	
	 @Column(name="FILE_NO")
     private Integer fileNo;
	 
	 @Column(name="WORKFLOW_STAGE_ID")
     private Integer workflowStageID;
	 
	 @Column(name="ACCOUNT_NAME")
	 private String accountName;

	 @Column(name="MOC")
	 private String moc;

	 @Column(name="LOAD_DATE")
	 private String loadDate;
	 
	 @Column(name="UPLOAD_BY")
	 private String uploadBy;
	 
	 @Column(name="COLUMN_A")
	 private String columnA;

	 @Column(name="COLUMN_B")
	 private String columnB;

	 @Column(name="COLUMN_C")
	 private String columnC;
	
	 @Column(name="COLUMN_D")
	 private String columnD;

	 @Column(name="COLUMN_E")
	 private String columnE;

	 @Column(name="COLUMN_F")
	 private String columnF;
	 
	 @Column(name="COLUMN_G")
	 private String columnG;

	 @Column(name="COLUMN_H")
	 private String columnH;

	 @Column(name="COLUMN_I")
	 private String columnI;
	 
	 @Column(name="COLUMN_J")
	 private String columnJ;

	 @Column(name="COLUMN_K")
	 private String columnK;

	 @Column(name="COLUMN_L")
	 private String columnL;
	 
	 @Column(name="COLUMN_M")
	 private String columnM;

	 @Column(name="COLUMN_N")
	 private String columnN;

	 @Column(name="COLUMN_O")
	 private String columnO;
	 
	 @Column(name="COLUMN_P")
	 private String columnP;

	 @Column(name="COLUMN_Q")
	 private String columnQ;

	 @Column(name="COLUMN_R")
	 private String columnR;
	 
	 @Column(name="COLUMN_S")
	 private String columnS;

	 @Column(name="COLUMN_T")
	 private String columnT;

	 @Column(name="COLUMN_U")
	 private String columnU;
	 
	 @Column(name="COLUMN_V")
	 private String columnV;

	 @Column(name="COLUMN_W")
	 private String columnW;

	 @Column(name="COLUMN_X")
	 private String columnX;
	 
	 @Column(name="COLUMN_Y")
	 private String columnY;

	 @Column(name="COLUMN_Z")
	 private String columnZ;

	 @Column(name="COLUMN_AA")
	 private String columnAA;
	 
	 @Column(name="COLUMN_AB")
	 private String columnAB;

	 @Column(name="COLUMN_AC")
	 private String columnAC;

	 @Column(name="COLUMN_AD")
	 private String columnAD;
	 
	 @Column(name="COLUMN_AE")
	 private String columnAE;

	 @Column(name="COLUMN_AF")
	 private String columnAF;

	 @Column(name="COLUMN_AG")
	 private String columnAG;
	 
	 @Column(name="COLUMN_AH")
	 private String columnAH;

	 @Column(name="COLUMN_AI")
	 private String columnAI;

	 @Column(name="COLUMN_AJ")
	 private String columnAJ;
	 
	 @Column(name="COLUMN_AK")
	 private String columnAK;

	 @Column(name="COLUMN_AL")
	 private String columnAL;

	 @Column(name="COLUMN_AM")
	 private String columnAM;
	 
	 @Column(name="COLUMN_AN")
	 private String columnAN;

	 @Column(name="COLUMN_AO")
	 private String columnAO;

	 @Column(name="COLUMN_AP")
	 private String columnAP;
	 
	 @Column(name="COLUMN_AQ")
	 private String columnAQ;

	 @Column(name="COLUMN_AR")
	 private String columnAR;

	 @Column(name="COLUMN_AS")
	 private String columnAS;
	 
	 @Column(name="COLUMN_AT")
	 private String columnAT;

	 @Column(name="COLUMN_AU")
	 private String columnAU;

	 @Column(name="COLUMN_AV")
	 private String columnAV;
	 
	 @Column(name="COLUMN_AW")
	 private String columnAW;

	 @Column(name="COLUMN_AX")
	 private String columnAX;

	 @Column(name="COLUMN_AY")
	 private String columnAY;
	 
	 @Column(name="COLUMN_AZ")
	 private String columnAZ;

	 //Added By Sarin Jun2022 - Excel file validation for POS file - begins
	 @Transient
	 private int noOfColumns;
	 
	 public int getNoOfColumns() {
		 return noOfColumns;
	 }

	 public void setNoOfColumns(int noOfColumns) {
		 this.noOfColumns = noOfColumns;
	 }
	 //Added By Sarin Jun2022 - Excel file validation for POS file - ends
	 
	public PosDataStage() {
		super();
		// TODO Auto-generated constructor stub
	}


	public PosDataStage(String recordID, Integer fileNo, Integer workflowStageID, String accountName, String moc,
			String loadDate, String uploadBy, String columnA, String columnB, String columnC, String columnD,
			String columnE, String columnF, String columnG, String columnH, String columnI, String columnJ,
			String columnK, String columnL, String columnM, String columnN, String columnO, String columnP,
			String columnQ, String columnR, String columnS, String columnT, String columnU, String columnV,
			String columnW, String columnX, String columnY, String columnZ, String columnAA, String columnAB,
			String columnAC, String columnAD, String columnAE, String columnAF, String columnAG, String columnAH,
			String columnAI, String columnAJ, String columnAK, String columnAL, String columnAM, String columnAN,
			String columnAO, String columnAP, String columnAQ, String columnAR, String columnAS, String columnAT,
			String columnAU, String columnAV, String columnAW, String columnAX, String columnAY, String columnAZ) {
		super();
		this.recordID = recordID;
		this.fileNo = fileNo;
		this.workflowStageID = workflowStageID;
		this.accountName = accountName;
		this.moc = moc;
		this.loadDate = loadDate;
		this.uploadBy = uploadBy;
		this.columnA = columnA;
		this.columnB = columnB;
		this.columnC = columnC;
		this.columnD = columnD;
		this.columnE = columnE;
		this.columnF = columnF;
		this.columnG = columnG;
		this.columnH = columnH;
		this.columnI = columnI;
		this.columnJ = columnJ;
		this.columnK = columnK;
		this.columnL = columnL;
		this.columnM = columnM;
		this.columnN = columnN;
		this.columnO = columnO;
		this.columnP = columnP;
		this.columnQ = columnQ;
		this.columnR = columnR;
		this.columnS = columnS;
		this.columnT = columnT;
		this.columnU = columnU;
		this.columnV = columnV;
		this.columnW = columnW;
		this.columnX = columnX;
		this.columnY = columnY;
		this.columnZ = columnZ;
		this.columnAA = columnAA;
		this.columnAB = columnAB;
		this.columnAC = columnAC;
		this.columnAD = columnAD;
		this.columnAE = columnAE;
		this.columnAF = columnAF;
		this.columnAG = columnAG;
		this.columnAH = columnAH;
		this.columnAI = columnAI;
		this.columnAJ = columnAJ;
		this.columnAK = columnAK;
		this.columnAL = columnAL;
		this.columnAM = columnAM;
		this.columnAN = columnAN;
		this.columnAO = columnAO;
		this.columnAP = columnAP;
		this.columnAQ = columnAQ;
		this.columnAR = columnAR;
		this.columnAS = columnAS;
		this.columnAT = columnAT;
		this.columnAU = columnAU;
		this.columnAV = columnAV;
		this.columnAW = columnAW;
		this.columnAX = columnAX;
		this.columnAY = columnAY;
		this.columnAZ = columnAZ;
	}


	public String getRecordID() {
		return recordID;
	}


	public void setRecordID(String recordID) {
		this.recordID = recordID;
	}


	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	
	
	public Integer getWorkflowStageID() {
		return workflowStageID;
	}


	public void setWorkflowStageID(Integer workflowStageID) {
		this.workflowStageID = workflowStageID;
	}


	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(String loadDate) {
		this.loadDate = loadDate;
	}
	
	

	public String getUploadBy() {
		return uploadBy;
	}



	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}



	public String getColumnA() {
		return columnA;
	}

	public void setColumnA(String columnA) {
		this.columnA = columnA;
	}

	public String getColumnB() {
		return columnB;
	}

	public void setColumnB(String columnB) {
		this.columnB = columnB;
	}

	public String getColumnC() {
		return columnC;
	}

	public void setColumnC(String columnC) {
		this.columnC = columnC;
	}

	public String getColumnD() {
		return columnD;
	}

	public void setColumnD(String columnD) {
		this.columnD = columnD;
	}

	public String getColumnE() {
		return columnE;
	}

	public void setColumnE(String columnE) {
		this.columnE = columnE;
	}

	public String getColumnF() {
		return columnF;
	}

	public void setColumnF(String columnF) {
		this.columnF = columnF;
	}

	public String getColumnG() {
		return columnG;
	}

	public void setColumnG(String columnG) {
		this.columnG = columnG;
	}

	public String getColumnH() {
		return columnH;
	}

	public void setColumnH(String columnH) {
		this.columnH = columnH;
	}

	public String getColumnI() {
		return columnI;
	}

	public void setColumnI(String columnI) {
		this.columnI = columnI;
	}

	public String getColumnJ() {
		return columnJ;
	}

	public void setColumnJ(String columnJ) {
		this.columnJ = columnJ;
	}

	public String getColumnK() {
		return columnK;
	}

	public void setColumnK(String columnK) {
		this.columnK = columnK;
	}

	public String getColumnL() {
		return columnL;
	}

	public void setColumnL(String columnL) {
		this.columnL = columnL;
	}

	public String getColumnM() {
		return columnM;
	}

	public void setColumnM(String columnM) {
		this.columnM = columnM;
	}

	public String getColumnN() {
		return columnN;
	}

	public void setColumnN(String columnN) {
		this.columnN = columnN;
	}

	public String getColumnO() {
		return columnO;
	}

	public void setColumnO(String columnO) {
		this.columnO = columnO;
	}

	public String getColumnP() {
		return columnP;
	}

	public void setColumnP(String columnP) {
		this.columnP = columnP;
	}

	public String getColumnQ() {
		return columnQ;
	}

	public void setColumnQ(String columnQ) {
		this.columnQ = columnQ;
	}

	public String getColumnR() {
		return columnR;
	}

	public void setColumnR(String columnR) {
		this.columnR = columnR;
	}

	public String getColumnS() {
		return columnS;
	}

	public void setColumnS(String columnS) {
		this.columnS = columnS;
	}

	public String getColumnT() {
		return columnT;
	}

	public void setColumnT(String columnT) {
		this.columnT = columnT;
	}

	public String getColumnU() {
		return columnU;
	}

	public void setColumnU(String columnU) {
		this.columnU = columnU;
	}

	public String getColumnV() {
		return columnV;
	}

	public void setColumnV(String columnV) {
		this.columnV = columnV;
	}

	public String getColumnW() {
		return columnW;
	}

	public void setColumnW(String columnW) {
		this.columnW = columnW;
	}

	public String getColumnX() {
		return columnX;
	}

	public void setColumnX(String columnX) {
		this.columnX = columnX;
	}

	public String getColumnY() {
		return columnY;
	}

	public void setColumnY(String columnY) {
		this.columnY = columnY;
	}

	public String getColumnZ() {
		return columnZ;
	}

	public void setColumnZ(String columnZ) {
		this.columnZ = columnZ;
	}

	public String getColumnAA() {
		return columnAA;
	}

	public void setColumnAA(String columnAA) {
		this.columnAA = columnAA;
	}

	public String getColumnAB() {
		return columnAB;
	}

	public void setColumnAB(String columnAB) {
		this.columnAB = columnAB;
	}

	public String getColumnAC() {
		return columnAC;
	}

	public void setColumnAC(String columnAC) {
		this.columnAC = columnAC;
	}

	public String getColumnAD() {
		return columnAD;
	}

	public void setColumnAD(String columnAD) {
		this.columnAD = columnAD;
	}

	public String getColumnAE() {
		return columnAE;
	}

	public void setColumnAE(String columnAE) {
		this.columnAE = columnAE;
	}

	public String getColumnAF() {
		return columnAF;
	}

	public void setColumnAF(String columnAF) {
		this.columnAF = columnAF;
	}

	public String getColumnAG() {
		return columnAG;
	}

	public void setColumnAG(String columnAG) {
		this.columnAG = columnAG;
	}

	public String getColumnAH() {
		return columnAH;
	}

	public void setColumnAH(String columnAH) {
		this.columnAH = columnAH;
	}

	public String getColumnAI() {
		return columnAI;
	}

	public void setColumnAI(String columnAI) {
		this.columnAI = columnAI;
	}

	public String getColumnAJ() {
		return columnAJ;
	}

	public void setColumnAJ(String columnAJ) {
		this.columnAJ = columnAJ;
	}

	public String getColumnAK() {
		return columnAK;
	}

	public void setColumnAK(String columnAK) {
		this.columnAK = columnAK;
	}

	public String getColumnAL() {
		return columnAL;
	}

	public void setColumnAL(String columnAL) {
		this.columnAL = columnAL;
	}

	public String getColumnAM() {
		return columnAM;
	}

	public void setColumnAM(String columnAM) {
		this.columnAM = columnAM;
	}

	public String getColumnAN() {
		return columnAN;
	}

	public void setColumnAN(String columnAN) {
		this.columnAN = columnAN;
	}

	public String getColumnAO() {
		return columnAO;
	}

	public void setColumnAO(String columnAO) {
		this.columnAO = columnAO;
	}

	public String getColumnAP() {
		return columnAP;
	}

	public void setColumnAP(String columnAP) {
		this.columnAP = columnAP;
	}

	public String getColumnAQ() {
		return columnAQ;
	}

	public void setColumnAQ(String columnAQ) {
		this.columnAQ = columnAQ;
	}

	public String getColumnAR() {
		return columnAR;
	}

	public void setColumnAR(String columnAR) {
		this.columnAR = columnAR;
	}

	public String getColumnAS() {
		return columnAS;
	}

	public void setColumnAS(String columnAS) {
		this.columnAS = columnAS;
	}

	public String getColumnAT() {
		return columnAT;
	}

	public void setColumnAT(String columnAT) {
		this.columnAT = columnAT;
	}

	public String getColumnAU() {
		return columnAU;
	}

	public void setColumnAU(String columnAU) {
		this.columnAU = columnAU;
	}

	public String getColumnAV() {
		return columnAV;
	}

	public void setColumnAV(String columnAV) {
		this.columnAV = columnAV;
	}

	public String getColumnAW() {
		return columnAW;
	}

	public void setColumnAW(String columnAW) {
		this.columnAW = columnAW;
	}

	public String getColumnAX() {
		return columnAX;
	}

	public void setColumnAX(String columnAX) {
		this.columnAX = columnAX;
	}

	public String getColumnAY() {
		return columnAY;
	}

	public void setColumnAY(String columnAY) {
		this.columnAY = columnAY;
	}

	public String getColumnAZ() {
		return columnAZ;
	}

	public void setColumnAZ(String columnAZ) {
		this.columnAZ = columnAZ;
	}


}
