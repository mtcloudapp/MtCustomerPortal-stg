package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "EXT_AVAILABLE_PO")
public class ExternalAvailablePO  implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3786005216256341018L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="BRANCH")
    private String branch;
	
	@Column(name="CATEGORY")
    private String category;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="USERNAME")
    private String username;
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="PO_NUMBER")
    private String poNumber;
	
	@Column(name="CIC_NUMBER")
    private String cicNumber;
	
	@Column(name="CIC")
    private String cic;
	
	@Column(name="C_FINAL_REASON")
    private String cFinalReason;
	
	@Column(name="C_FINAL_REASON_HEADER")
    private String cFinalReasonHeader;
	
	@Column(name="C_FINAL_REASON_HEADER2")
    private String cFinalReasonHeader2;
	
	@Column(name="C_ACTION")
    private String cAction;
	
	@Column(name="ALLOCATE_VALUE")
    private Double allocatedValue;
	
	@Column(name="INVOICE_VALUE")
    private Double invoiceValue;
	
	@Column(name="ORDER_VALUE")
    private Double orderValue;

	public ExternalAvailablePO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getCicNumber() {
		return cicNumber;
	}

	public void setCicNumber(String cicNumber) {
		this.cicNumber = cicNumber;
	}

	public String getCic() {
		return cic;
	}

	public void setCic(String cic) {
		this.cic = cic;
	}

	public String getcFinalReason() {
		return cFinalReason;
	}

	public void setcFinalReason(String cFinalReason) {
		this.cFinalReason = cFinalReason;
	}

	public String getcFinalReasonHeader() {
		return cFinalReasonHeader;
	}

	public void setcFinalReasonHeader(String cFinalReasonHeader) {
		this.cFinalReasonHeader = cFinalReasonHeader;
	}

	public String getcFinalReasonHeader2() {
		return cFinalReasonHeader2;
	}

	public void setcFinalReasonHeader2(String cFinalReasonHeader2) {
		this.cFinalReasonHeader2 = cFinalReasonHeader2;
	}

	public String getcAction() {
		return cAction;
	}

	public void setcAction(String cAction) {
		this.cAction = cAction;
	}

	public Double getAllocatedValue() {
		return allocatedValue;
	}

	public void setAllocatedValue(Double allocatedValue) {
		this.allocatedValue = allocatedValue;
	}

	public Double getInvoiceValue() {
		return invoiceValue;
	}

	public void setInvoiceValue(Double invoiceValue) {
		this.invoiceValue = invoiceValue;
	}

	public Double getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(Double orderValue) {
		this.orderValue = orderValue;
	}
	
	
	
	
}
