package com.unilever.promo.claim.kam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.external.repository.PosDataStageRepository;
import com.unilever.promo.claim.external.repository.PosFileUploadMasterRepository;
import com.unilever.promo.claim.external.repository.PromoClaimStageExternalRepository;
import com.unilever.promo.claim.external.repository.PrompClaimsFileUploadMasterRepository;
import com.unilever.promo.claim.external.service.PromoClaimStageService;
import com.unilever.promo.claim.kam.repository.PromoClaimKamRepository;

@Service
public class PromoClaimKamService {
	
	@Autowired
	PromoClaimKamRepository promoClaimKamRepository;
	
	//Added By Sarin Nov2021 - Claim File KAM Approval - Starts
	@Autowired
	PromoClaimStageExternalRepository promoClaimStageExternalRepository;
	@Autowired
	PrompClaimsFileUploadMasterRepository promoClaimsFileUploadMasterRepository;
	@Autowired
	PromoClaimStageService promoClaimStageService;
	//Added By Sarin Nov2021 - Claim File KAM Approval - Ends
	
	//Added By Sarin Mar2022 - POS File KAM Approval - Starts
	@Autowired
	PosDataStageRepository posDataStageRepository;
	@Autowired
	PosFileUploadMasterRepository posFileUploadMasterRepository;
	//Added By Sarin Mar2022 - POS File KAM Approval - Ends
	
	public ResponseMessage updateNoSoleCodeByKam(Integer solcode,Integer basepack,Integer articleCode,Integer solcodeRevised){
		
		ResponseMessage response = new ResponseMessage();
		
		try{
			if(solcode !=null && basepack !=null && articleCode !=null){
			
				promoClaimKamRepository.updateNoSolCodeByKam(solcodeRevised, solcode, articleCode, basepack);
				response.setMessage("Updated Successfully !!");
			}
		}
			catch(Exception e){
				e.printStackTrace();
				response.setMessage("Sorry !! Not Update");
				
			}
		return response;
	}
	
	public ResponseMessage updateNoBasepackByKam(Integer solcode,Integer basepack,Integer articleCode,Integer basepackRevised){
		
		ResponseMessage response = new ResponseMessage();
		
		try{
			if(solcode !=null && basepack !=null && articleCode !=null){
			
				promoClaimKamRepository.updateNoBasepackByKam(basepackRevised, solcode, articleCode, basepack);
				response.setMessage("Updated Successfully !!");
			}
		}
			catch(Exception e){
				e.printStackTrace();
				response.setMessage("Sorry !! Not Update");
				
			}
		return response;
	}
	
	//Added By Sarin Nov2021 - Claim File KAM Approval - Starts
	public ResponseMessage doPromoClaimKamApproval(String accountName, String moc, String kamUsername, String kamAction, String claimType) {
		ResponseMessage response = new ResponseMessage();
		Integer fileNo = 0;
		fileNo = promoClaimStageExternalRepository.findFileNoByAccountMoc(accountName, moc);
		try {
			promoClaimsFileUploadMasterRepository.updatePromoClaimFileUploadKAMDetailsByAccountMocFileNo(kamUsername, kamAction, accountName, moc, fileNo);
			
			Integer promoClaimFileCnt = promoClaimsFileUploadMasterRepository.findCountPromoClaimFileUploadMaster(accountName, moc);
			if (promoClaimFileCnt == 1) {
				response = promoClaimStageService.calcPromoClaims(accountName, moc, claimType);
			} else {
				response.setMessage("Promo Claims " + kamAction + " by KAM for " + accountName + " " + moc);	
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error while approving promo claims");
		}
		
		return response;
	}
	
	public String getKamClaimNotificationCount(String accountName, String moc, String kamUsername) {
		Integer claimCount = promoClaimStageExternalRepository.findKamRowCountByAccountMoc(accountName, moc, kamUsername);
		if (claimCount > 0) {
			return "1";
		} else {
			return "0";
		}
		
	}
	//Added By Sarin Nov2021 - Claim File KAM Approval - Ends
	
	//Added By Sarin Mar2022 - POS File KAM Approval - Starts
	public ResponseMessage doPosFileKamApproval(String accountName, String moc, String kamUsername, String kamAction, String claimType) {
		ResponseMessage response = new ResponseMessage();
		Integer fileNo = 0;
		fileNo = posDataStageRepository.findFileNoByAccountMoc(accountName, moc);
		try {
			posFileUploadMasterRepository.updatePOSFileUploadKAMDetailsByAccountMocFileNo(kamUsername, kamAction, accountName, moc, fileNo);
			
			Integer posFileCnt = posFileUploadMasterRepository.findCountPosFileUploadMaster(accountName, moc);
			if (posFileCnt == 1) {
				response = promoClaimStageService.calcPromoClaims(accountName, moc, claimType);
			} else {
				response.setMessage("Pos File " + kamAction + " by KAM for " + accountName + " " + moc);	
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error while approving pos claims");
		}
		
		return response;
	}
	
	public String getKamPosNotificationCount(String accountName, String moc, String kamUsername) {
		Integer posCount = posDataStageRepository.findKamRowCountByAccountMoc(accountName, moc, kamUsername);
		if (posCount > 0) {
			return "1";
		} else {
			return "0";
		}
		
	}
	//Added By Sarin Mar2022 - POS File KAM Approval - Ends
}
