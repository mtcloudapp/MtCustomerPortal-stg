package com.unilever.promo.claim.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.BaseWorking;

@Repository
public interface BaseWorkingRepository extends JpaRepository<BaseWorking, Integer>{

	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".BASE_WORKING pcfm where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNoOfBaseworking(@Param("accountName") String accountName, @Param("moc") String moc);


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".BASE_WORKING  pcfm set pcfm.WORKFLOW_STAGE_ID=:stageID  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updateBaseWorkingByAccountMocFileNo(@Param("stageID") Integer stageID,@Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".BASE_WORKING pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Page<BaseWorking> findBaseWorkingDetailsByAcntAndMoc(@Param("accountName") String accountName,@Param("moc") String moc,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".BASE_WORKING pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	List<BaseWorking> findCountByAccountAndMoc(@Param("accountName") String accountName,@Param("moc") String moc);
	

   //=================================For Deduction Bucket========================================================


	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".BASE_WORKING pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc and pcfm.DEDUCTION_BUCKET=:bucket", nativeQuery = true)
	Page<BaseWorking> findDeductionBucketDetailsByAcntMocBucket(@Param("accountName") String accountName,@Param("moc") String moc,@Param("bucket") String bucket,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".BASE_WORKING pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc and pcfm.DEDUCTION_BUCKET=:bucket", nativeQuery = true)
	List<BaseWorking> findCountByAccountMocBucket(@Param("accountName") String accountName,@Param("moc") String moc,@Param("bucket") String bucket);
	
//	@Transactional
//	@Query(value = "CALL sp_promo_claims_Base_working();", nativeQuery = true)
//	void insertIntoBaseworking();
	
//	@Transactional
//	@Procedure(procedureName = "sp_promo_claims_Base_working")
//	void insertIntoBaseworking();
	
	@Transactional
	@Procedure(procedureName = "sp_promo_claims_Base_working")
	void insertIntoBaseworking(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".BASE_WORKING  pcfm set pcfm.NET_CLAIM_VALUE_REVISED=:netClaimValueRevised,"
			+ "pcfm.NET_CLAIM_QUANTITY_REVISED=:netClaimQtyRevised,pcfm.PROMOTION_AMOUNT_REVISED=:promotionAmtRevised, pcfm.CLAIM_AMOUNT_PER_UNIT_REVISED=:claimAmtPerUnitRevised,"
			+ "pcfm.CLAIM_POS_PRIMARY_QUANTITY_REVISED=:claimPosPrimaryQtyRevised,pcfm.CUSTOMER_CLAIM_MIN_QUANTITY_REVISED=:custClaimMinQtyRevised,pcfm.DIFFERENCE_IN_CUSTOMER_CLAIMS_REVISED=:diffInCustomerClaimRevised,"
			+ "pcfm.HUL_CLAIM_REVISED=:hulClaimRevised,pcfm.NET_CLAIMS_REVISED=:netClaimRevised,pcfm.DIFFERENCE_CLAIMS_REVISED=:diffClaimsRevised "
			+ "where pcfm.SOL_CODE=:solCode and pcfm.BASEPACK=:basepack and pcfm.ARTICLE_CODE=:articleCode", nativeQuery = true)
	void updateBaseWorkingBySolCodeBasepackArticleCode(@Param("netClaimValueRevised") Double netClaimValueRevised,@Param("netClaimQtyRevised") Double netClaimQtyRevised,@Param("promotionAmtRevised") Double promotionAmtRevised,
			@Param("claimAmtPerUnitRevised") Double claimAmtPerUnitRevised,@Param("claimPosPrimaryQtyRevised") Double claimPosPrimaryQtyRevised,@Param("custClaimMinQtyRevised") Double custClaimMinQtyRevised,
			@Param("diffInCustomerClaimRevised") Double diffInCustomerClaimRevised,@Param("hulClaimRevised") Double hulClaimRevised,@Param("netClaimRevised") Double netClaimRevised,
			@Param("diffClaimsRevised") Double diffClaimsRevised,@Param("solCode") Integer solCode,@Param("basepack") Integer basepack,@Param("articleCode") Integer articleCode);

	@Transactional
	@Query(value ="select count(*) from "+GlobalVariables.schemaName+".BASE_WORKING pcfm where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findBaseworkingByAccountMOC(@Param("accountName") String accountName, @Param("moc") String moc);

	//Added By Sarin Jul2021
	@Transactional
    @Query(value ="select distinct SOL_CODE_REVISED AS SOL_CODE from "+GlobalVariables.schemaName+".BASE_WORKING pcfm where pcfm.ACCOUNT=:account and pcfm.MOC=:moc and ((SOL_CODE_REVISED LIKE '%/%' OR SOL_CODE_REVISED LIKE '%,%' OR SOL_CODE_REVISED LIKE '%&%' OR SOL_CODE_REVISED LIKE '%-%' OR SOL_CODE_REVISED LIKE '%;%') OR PROMOTION_UNIT = 'NO')", nativeQuery = true)
	List<String> findMultiAndErrorSOLCodeByAccountAndMoc(@Param("account") String account,@Param("moc") String moc);

}
