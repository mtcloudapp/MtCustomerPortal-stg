package com.unilever.promo.external.model;

public class ExternalPromoJson {
	
	private Integer noOfSolCode;
	private Double totalPlannedBudget;
	private Double totalPlannedPromoVolume;
	private Double totalUtilizedVolume;
	
	
	public ExternalPromoJson() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Integer getNoOfSolCode() {
		return noOfSolCode;
	}


	public void setNoOfSolCode(Integer noOfSolCode) {
		this.noOfSolCode = noOfSolCode;
	}


	public Double getTotalPlannedBudget() {
		return totalPlannedBudget;
	}


	public void setTotalPlannedBudget(Double totalPlannedBudget) {
		this.totalPlannedBudget = totalPlannedBudget;
	}


	public Double getTotalPlannedPromoVolume() {
		return totalPlannedPromoVolume;
	}


	public void setTotalPlannedPromoVolume(Double totalPlannedPromoVolume) {
		this.totalPlannedPromoVolume = totalPlannedPromoVolume;
	}


	public Double getTotalUtilizedVolume() {
		return totalUtilizedVolume;
	}


	public void setTotalUtilizedVolume(Double totalUtilizedVolume) {
		this.totalUtilizedVolume = totalUtilizedVolume;
	}
	
	
	

}
