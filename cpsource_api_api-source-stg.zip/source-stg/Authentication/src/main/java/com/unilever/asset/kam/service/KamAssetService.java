package com.unilever.asset.kam.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Page;
import com.unilever.asset.kam.model.CompliedAssetValue;
import com.unilever.asset.kam.model.CompliedAssetVolume;
import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.CurrentMocViewDto;
import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.asset.kam.model.NextMocViewDto;
import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.asset.kam.model.PreviousMocView;
import com.unilever.asset.kam.model.PreviousMocViewDto;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.repository.CompliedAssetValueRepository;
import com.unilever.asset.kam.repository.CompliedAssetVolumeRepository;
import com.unilever.asset.kam.repository.CurrentMocViewRepository;
import com.unilever.asset.kam.repository.DeployedAssetValueRepository;
import com.unilever.asset.kam.repository.DeployedAssetVolumeRepository;
import com.unilever.asset.kam.repository.DepotConnetedAssetValueRepository;
import com.unilever.asset.kam.repository.DepotConnetedAssetVolumeRepository;
import com.unilever.asset.kam.repository.NextMocViewRepository;
import com.unilever.asset.kam.repository.NotCompliedAssetValueRepository;
import com.unilever.asset.kam.repository.NotCompliedAssetVolumeRepository;
import com.unilever.asset.kam.repository.PreviousMocViewRepository;
import com.unilever.asset.kam.repository.TotalAssetCreatedValueRepository;
import com.unilever.asset.kam.repository.TotalAssetCreatedVolumeRepository;
import com.unilever.asset.kam.repository.ViewTableRepository;

@Service
public class KamAssetService {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	TotalAssetCreatedValueRepository totalAssetCreatedValueRepository;

	@Autowired
	TotalAssetCreatedVolumeRepository totalAssetCreatedVolumeRepository;

	@Autowired
	DepotConnetedAssetValueRepository depotConnetedAssetValueRepository;

	@Autowired
	DepotConnetedAssetVolumeRepository depotConnetedAssetVolumeRepository;

	@Autowired
	DeployedAssetValueRepository deployedAssetValueRepository;

	@Autowired
	DeployedAssetVolumeRepository deployedAssetVolumeRepository;

	@Autowired
	CompliedAssetValueRepository compliedAssetValueRepository;

	@Autowired
	CompliedAssetVolumeRepository compliedAssetVolumeRepository;

	@Autowired
	NotCompliedAssetValueRepository notCompliedAssetValueRepository;

	@Autowired
	NotCompliedAssetVolumeRepository notCompliedAssetVolumeRepository;

	@Autowired
	CurrentMocViewRepository currentMocViewRepository;

	@Autowired
	PreviousMocViewRepository previousMocViewRepository;

	@Autowired
	NextMocViewRepository nextMocViewRepository;

	@Autowired
	ViewTableRepository viewTableRepository;


	public TotalAssetCreatedValue getTotalAssetCreatedValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TotalAssetCreatedValue totalAssetAmountSum = new TotalAssetCreatedValue();


		try{
			List<TotalAssetCreatedValue> totalAssetValues = new ArrayList<TotalAssetCreatedValue>();
			List<TotalAssetCreatedValue> totalAssetValuesByUsername = new ArrayList<TotalAssetCreatedValue>();
			List<TotalAssetCreatedValue> mocList = new ArrayList<TotalAssetCreatedValue>();

			totalAssetValuesByUsername = totalAssetCreatedValueRepository.findAllTotalAssetCreatedValueDetails(username);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1


				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedValue mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(TotalAssetCreatedValue t : mocList){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}

				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<TotalAssetCreatedValue> categoryList = new ArrayList<TotalAssetCreatedValue>();

				//filtered by category

				for(String c : category){
					for(TotalAssetCreatedValue cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(TotalAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<TotalAssetCreatedValue> accountList = new ArrayList<TotalAssetCreatedValue>();


				for(String accnt : account){
					for(TotalAssetCreatedValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<TotalAssetCreatedValue> accountList = new ArrayList<TotalAssetCreatedValue>();
				List<TotalAssetCreatedValue> filteredAccountCategoryList = new ArrayList<TotalAssetCreatedValue>();


				//filterd by account
				for(String accnt : account){
					for(TotalAssetCreatedValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(TotalAssetCreatedValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<TotalAssetCreatedValue> regionList = new ArrayList<TotalAssetCreatedValue>();


				//filter by region
				for(String regon : region){
					for(TotalAssetCreatedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}

				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<TotalAssetCreatedValue> regionList = new ArrayList<TotalAssetCreatedValue>();
				List<TotalAssetCreatedValue> filteredRegionAccountList = new ArrayList<TotalAssetCreatedValue>();


				//filter by region
				for(String regon : region){
					for(TotalAssetCreatedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(TotalAssetCreatedValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(TotalAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<TotalAssetCreatedValue> regionList = new ArrayList<TotalAssetCreatedValue>();
				List<TotalAssetCreatedValue> filteredRegionCategoryList = new ArrayList<TotalAssetCreatedValue>();

				//filterd by region

				for(String regon : region){
					for(TotalAssetCreatedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(TotalAssetCreatedValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<TotalAssetCreatedValue> regionList = new ArrayList<TotalAssetCreatedValue>();
				List<TotalAssetCreatedValue> accountList = new ArrayList<TotalAssetCreatedValue>();
				List<TotalAssetCreatedValue> filteredRegionCategoryList = new ArrayList<TotalAssetCreatedValue>();

				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(TotalAssetCreatedValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(TotalAssetCreatedValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(TotalAssetCreatedValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TotalAssetCreatedValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAssetCreatedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalAssetCreatedValue();
					}

					totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	//=======================Start Total Asset Created Volume===========================================//

	public TotalAssetCreatedVolume getTotalAssetCreatedVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Integer totalAssetVolume = 0;
		TotalAssetCreatedVolume totalAssetVolumeSum= new TotalAssetCreatedVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<TotalAssetCreatedVolume> totalAssetVolumes = new ArrayList<TotalAssetCreatedVolume>();
			List<TotalAssetCreatedVolume> totalAssetVolumeByUsername = new ArrayList<TotalAssetCreatedVolume>();
			List<TotalAssetCreatedVolume> mocList = new ArrayList<TotalAssetCreatedVolume>();

			totalAssetVolumeByUsername = totalAssetCreatedVolumeRepository.findAllTotalAssetCreatedVolumeDetails(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedVolume mocc : totalAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				for(TotalAssetCreatedVolume t : mocList){
					totalAssetVolume += t.getTotalAssetCreatedVolume();

				}

				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<TotalAssetCreatedVolume> categoryList = new ArrayList<TotalAssetCreatedVolume>();

				//filtered by category

				for(String c : category){
					for(TotalAssetCreatedVolume cat : totalAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(TotalAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalAssetCreatedVolume();

				}
				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<TotalAssetCreatedVolume> accountList = new ArrayList<TotalAssetCreatedVolume>();

				for(String accnt : account){
					for(TotalAssetCreatedVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(TotalAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalAssetCreatedVolume();

				}
				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<TotalAssetCreatedVolume> accountList = new ArrayList<TotalAssetCreatedVolume>();
				List<TotalAssetCreatedVolume> filteredAccountCategoryList = new ArrayList<TotalAssetCreatedVolume>();


				//filterd by account
				for(String accnt : account){
					for(TotalAssetCreatedVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(TotalAssetCreatedVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(TotalAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalAssetCreatedVolume();
				}
				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<TotalAssetCreatedVolume> regionList = new ArrayList<TotalAssetCreatedVolume>();

				//filter by region
				for(String regon : region){
					for(TotalAssetCreatedVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(TotalAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalAssetCreatedVolume();
				}

				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<TotalAssetCreatedVolume> regionList = new ArrayList<TotalAssetCreatedVolume>();
				List<TotalAssetCreatedVolume> filteredRegionAccountList = new ArrayList<TotalAssetCreatedVolume>();

				//filter by region
				for(String regon : region){
					for(TotalAssetCreatedVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(TotalAssetCreatedVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(TotalAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalAssetCreatedVolume();

				}
				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<TotalAssetCreatedVolume> regionList = new ArrayList<TotalAssetCreatedVolume>();
				List<TotalAssetCreatedVolume> filteredRegionCategoryList = new ArrayList<TotalAssetCreatedVolume>();

				//filterd by region

				for(String regon : region){
					for(TotalAssetCreatedVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(TotalAssetCreatedVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAssetCreatedVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(TotalAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalAssetCreatedVolume();
				}
				totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<TotalAssetCreatedVolume> regionList = new ArrayList<TotalAssetCreatedVolume>();
				List<TotalAssetCreatedVolume> accountList = new ArrayList<TotalAssetCreatedVolume>();
				List<TotalAssetCreatedVolume> filteredRegionCategoryList = new ArrayList<TotalAssetCreatedVolume>();

				if(totalAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(TotalAssetCreatedVolume reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(TotalAssetCreatedVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(TotalAssetCreatedVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(TotalAssetCreatedVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(TotalAssetCreatedVolume t : totalAssetVolumes){
						totalAssetVolume += t.getTotalAssetCreatedVolume();
					}

					totalAssetVolumeSum.setTotalAssetCreatedVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//=======================Start Depot connected Asset Value===========================================//


	public DepotConnectedAssetValue getAllDepotConnectedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		DepotConnectedAssetValue totalAssetAmountSum = new DepotConnectedAssetValue();


		try{

			List<DepotConnectedAssetValue> totalAssetValues = new ArrayList<DepotConnectedAssetValue>();
			List<DepotConnectedAssetValue> totalDepotAssetValuesByUsername = new ArrayList<DepotConnectedAssetValue>();
			List<DepotConnectedAssetValue> mocList = new ArrayList<DepotConnectedAssetValue>();

			totalDepotAssetValuesByUsername = depotConnetedAssetValueRepository.findAllDepotConnectdAssetValue(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValue mocc : totalDepotAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(DepotConnectedAssetValue t : mocList){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}

				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<DepotConnectedAssetValue> categoryList = new ArrayList<DepotConnectedAssetValue>();

				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetValue cat : totalDepotAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(DepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<DepotConnectedAssetValue> accountList = new ArrayList<DepotConnectedAssetValue>();

				for(String accnt : account){
					for(DepotConnectedAssetValue acc : totalDepotAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(DepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<DepotConnectedAssetValue> accountList = new ArrayList<DepotConnectedAssetValue>();
				List<DepotConnectedAssetValue> filteredAccountCategoryList = new ArrayList<DepotConnectedAssetValue>();



				//filterd by account
				for(String accnt : account){
					for(DepotConnectedAssetValue acc : totalDepotAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(DepotConnectedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(DepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<DepotConnectedAssetValue> regionList = new ArrayList<DepotConnectedAssetValue>();

				//filter by region
				for(String regon : region){
					for(DepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(DepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}

				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<DepotConnectedAssetValue> regionList = new ArrayList<DepotConnectedAssetValue>();
				List<DepotConnectedAssetValue> filteredRegionAccountList = new ArrayList<DepotConnectedAssetValue>();

				//filter by region
				for(String regon : region){
					for(DepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(DepotConnectedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(DepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<DepotConnectedAssetValue> regionList = new ArrayList<DepotConnectedAssetValue>();
				List<DepotConnectedAssetValue> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetValue>();

				//filterd by region

				for(String regon : region){
					for(DepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(DepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}	
			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<DepotConnectedAssetValue> regionList = new ArrayList<DepotConnectedAssetValue>();
				List<DepotConnectedAssetValue> accountList = new ArrayList<DepotConnectedAssetValue>();
				List<DepotConnectedAssetValue> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetValue>();

				if(totalDepotAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(DepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(DepotConnectedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(DepotConnectedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(DepotConnectedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(DepotConnectedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getDepotConnectedAssetValue();
					}

					totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	//=======================Start Depot connected Asset Volume===========================================//

	public DepotConnectedAssetVolume getAllDepotConnectedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Integer totalAssetVolume = 0;
		DepotConnectedAssetVolume totalAssetVolumeSum= new DepotConnectedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<DepotConnectedAssetVolume> totalAssetVolumes = new ArrayList<DepotConnectedAssetVolume>();
			List<DepotConnectedAssetVolume> totalDepotAssetVolumeByUsername = new ArrayList<DepotConnectedAssetVolume>();
			List<DepotConnectedAssetVolume> mocList = new ArrayList<DepotConnectedAssetVolume>();

			totalDepotAssetVolumeByUsername = depotConnetedAssetVolumeRepository.findAllDepotConnectdAssetVolume(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolume mocc : totalDepotAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				for(DepotConnectedAssetVolume t : mocList){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}

				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<DepotConnectedAssetVolume> categoryList = new ArrayList<DepotConnectedAssetVolume>();


				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetVolume cat : totalDepotAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(DepotConnectedAssetVolume t : mocList){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}

				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);




			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<DepotConnectedAssetVolume> accountList = new ArrayList<DepotConnectedAssetVolume>();

				for(String accnt : account){
					for(DepotConnectedAssetVolume acc : totalDepotAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}



				totalAssetVolumes.addAll(mocList);

				for(DepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<DepotConnectedAssetVolume> accountList = new ArrayList<DepotConnectedAssetVolume>();
				List<DepotConnectedAssetVolume> filteredAccountCategoryList = new ArrayList<DepotConnectedAssetVolume>();


				//filterd by account
				for(String accnt : account){
					for(DepotConnectedAssetVolume acc : totalDepotAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(DepotConnectedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(DepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();
				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<DepotConnectedAssetVolume> regionList = new ArrayList<DepotConnectedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(DepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(DepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();
				}

				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<DepotConnectedAssetVolume> regionList = new ArrayList<DepotConnectedAssetVolume>();
				List<DepotConnectedAssetVolume> filteredRegionAccountList = new ArrayList<DepotConnectedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(DepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(DepotConnectedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(DepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<DepotConnectedAssetVolume> regionList = new ArrayList<DepotConnectedAssetVolume>();
				List<DepotConnectedAssetVolume> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetVolume>();

				//filterd by region

				for(String regon : region){
					for(DepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(DepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();
				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<DepotConnectedAssetVolume> regionList = new ArrayList<DepotConnectedAssetVolume>();
				List<DepotConnectedAssetVolume> accountList = new ArrayList<DepotConnectedAssetVolume>();
				List<DepotConnectedAssetVolume> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetVolume>();

				if(totalDepotAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(DepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(DepotConnectedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(DepotConnectedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(DepotConnectedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(DepotConnectedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnectedAssetVolume();
					}

					totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if
		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}

	//=================================================== Start Deployed Asset=====================================

	public DeployedAssetValue getDeployedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00 ;
		//Integer totalAssetAmountSum = 0;
		DeployedAssetValue totalAssetAmountSum = new DeployedAssetValue();


		try{

			List<DeployedAssetValue> totalAssetValues = new ArrayList<DeployedAssetValue>();
			List<DeployedAssetValue> totalDeployedAssetValuesByUsername = new ArrayList<DeployedAssetValue>();
			List<DeployedAssetValue> mocList = new ArrayList<DeployedAssetValue>();

			totalDeployedAssetValuesByUsername = deployedAssetValueRepository.findAllDeployedAssetValue(username);



			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(DeployedAssetValue mocc : totalDeployedAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(DeployedAssetValue t : mocList){
					totalAssetAmount += t.getDeployedAssetValue();

				}

				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<DeployedAssetValue> categoryList = new ArrayList<DeployedAssetValue>();

				//filtered by category

				for(String c : category){
					for(DeployedAssetValue cat : totalDeployedAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DeployedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(DeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();

				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<DeployedAssetValue> accountList = new ArrayList<DeployedAssetValue>();

				for(String accnt : account){
					for(DeployedAssetValue acc : totalDeployedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DeployedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(DeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();

				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<DeployedAssetValue> accountList = new ArrayList<DeployedAssetValue>();
				List<DeployedAssetValue> filteredAccountCategoryList = new ArrayList<DeployedAssetValue>();


				//filterd by account
				for(String accnt : account){
					for(DeployedAssetValue acc : totalDeployedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(DeployedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(DeployedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(DeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();
				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}



			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<DeployedAssetValue> regionList = new ArrayList<DeployedAssetValue>();

				//filter by region
				for(String regon : region){
					for(DeployedAssetValue reg : totalDeployedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DeployedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(DeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();
				}

				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<DeployedAssetValue> regionList = new ArrayList<DeployedAssetValue>();
				List<DeployedAssetValue> filteredRegionAccountList = new ArrayList<DeployedAssetValue>();

				//filter by region
				for(String regon : region){
					for(DeployedAssetValue reg : totalDeployedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(DeployedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DeployedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(DeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();

				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<DeployedAssetValue> regionList = new ArrayList<DeployedAssetValue>();
				List<DeployedAssetValue> filteredRegionCategoryList = new ArrayList<DeployedAssetValue>();

				//filterd by region

				for(String regon : region){
					for(DeployedAssetValue reg : totalDeployedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(DeployedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DeployedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(DeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();
				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<DeployedAssetValue> regionList = new ArrayList<DeployedAssetValue>();
				List<DeployedAssetValue> accountList = new ArrayList<DeployedAssetValue>();
				List<DeployedAssetValue> filteredRegionCategoryList = new ArrayList<DeployedAssetValue>();

				if(totalDeployedAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(DeployedAssetValue reg : totalDeployedAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(DeployedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(DeployedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(DeployedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(DeployedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getDeployedAssetValue();
					}

					totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	public DepolyedAssetVolume getAllDeployedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Integer totalAssetVolume = 0;
		DepolyedAssetVolume totalAssetVolumeSum= new DepolyedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<DepolyedAssetVolume> totalAssetVolumes = new ArrayList<DepolyedAssetVolume>();
			List<DepolyedAssetVolume> totalDeployedAssetVolumeByUsername = new ArrayList<DepolyedAssetVolume>();
			List<DepolyedAssetVolume> mocList = new ArrayList<DepolyedAssetVolume>();

			totalDeployedAssetVolumeByUsername = deployedAssetVolumeRepository.findAllDeployedAssetVolume(username);



			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(DepolyedAssetVolume mocc : totalDeployedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}



				for(DepolyedAssetVolume t : mocList){
					totalAssetVolume += t.getDeployedAssetVolume();

				}

				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<DepolyedAssetVolume> categoryList = new ArrayList<DepolyedAssetVolume>();


				//filtered by category

				for(String c : category){
					for(DepolyedAssetVolume cat : totalDeployedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepolyedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(DepolyedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();

				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);


			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<DepolyedAssetVolume> accountList = new ArrayList<DepolyedAssetVolume>();

				for(String accnt : account){
					for(DepolyedAssetVolume acc : totalDeployedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepolyedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(DepolyedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();

				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}



			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<DepolyedAssetVolume> accountList = new ArrayList<DepolyedAssetVolume>();
				List<DepolyedAssetVolume> filteredAccountCategoryList = new ArrayList<DepolyedAssetVolume>();



				//filterd by account
				for(String accnt : account){
					for(DepolyedAssetVolume acc : totalDeployedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(DepolyedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepolyedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				totalAssetVolumes.addAll(mocList);

				for(DepolyedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();
				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<DepolyedAssetVolume> regionList = new ArrayList<DepolyedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(DepolyedAssetVolume reg : totalDeployedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepolyedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(DepolyedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();
				}

				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<DepolyedAssetVolume> regionList = new ArrayList<DepolyedAssetVolume>();
				List<DepolyedAssetVolume> filteredRegionAccountList = new ArrayList<DepolyedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(DepolyedAssetVolume reg : totalDeployedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(DepolyedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}


				//filtered by MOC
				for(String m : moc){
					for(DepolyedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(DepolyedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();

				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<DepolyedAssetVolume> regionList = new ArrayList<DepolyedAssetVolume>();
				List<DepolyedAssetVolume> filteredRegionCategoryList = new ArrayList<DepolyedAssetVolume>();

				//filterd by region

				for(String regon : region){
					for(DepolyedAssetVolume reg : totalDeployedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(DepolyedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(DepolyedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(DepolyedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();
				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}	



			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<DepolyedAssetVolume> regionList = new ArrayList<DepolyedAssetVolume>();
				List<DepolyedAssetVolume> accountList = new ArrayList<DepolyedAssetVolume>();
				List<DepolyedAssetVolume> filteredRegionCategoryList = new ArrayList<DepolyedAssetVolume>();

				if(totalDeployedAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(DepolyedAssetVolume reg : totalDeployedAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(DepolyedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(DepolyedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(DepolyedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(DepolyedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getDeployedAssetVolume();
					}

					totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//==========================================Start Complied Asset========================================================

	public CompliedAssetValue getCompliedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00 ;
		//Integer totalAssetAmountSum = 0;
		CompliedAssetValue totalAssetAmountSum = new CompliedAssetValue();


		try{

			List<CompliedAssetValue> totalAssetValues = new ArrayList<CompliedAssetValue>();
			List<CompliedAssetValue> totalCompliedAssetValuesByUsername = new ArrayList<CompliedAssetValue>();
			List<CompliedAssetValue> mocList = new ArrayList<CompliedAssetValue>();

			totalCompliedAssetValuesByUsername = compliedAssetValueRepository.findAllCompliedAssetValue(username);



			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetValue mocc : totalCompliedAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				for(CompliedAssetValue t : mocList){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}

				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CompliedAssetValue> categoryList = new ArrayList<CompliedAssetValue>();

				//filtered by category

				for(String c : category){
					for(CompliedAssetValue cat : totalCompliedAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CompliedAssetValue> accountList = new ArrayList<CompliedAssetValue>();


				for(String accnt : account){
					for(CompliedAssetValue acc : totalCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CompliedAssetValue> accountList = new ArrayList<CompliedAssetValue>();
				List<CompliedAssetValue> filteredAccountCategoryList = new ArrayList<CompliedAssetValue>();


				//filterd by account
				for(String accnt : account){
					for(CompliedAssetValue acc : totalCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CompliedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();
				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}




			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CompliedAssetValue> regionList = new ArrayList<CompliedAssetValue>();

				//filter by region
				for(String regon : region){
					for(CompliedAssetValue reg : totalCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();
				}

				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CompliedAssetValue> regionList = new ArrayList<CompliedAssetValue>();
				List<CompliedAssetValue> filteredRegionAccountList = new ArrayList<CompliedAssetValue>();

				//filter by region
				for(String regon : region){
					for(CompliedAssetValue reg : totalCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CompliedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}


				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CompliedAssetValue> regionList = new ArrayList<CompliedAssetValue>();
				List<CompliedAssetValue> filteredRegionCategoryList = new ArrayList<CompliedAssetValue>();

				//filterd by region

				for(String regon : region){
					for(CompliedAssetValue reg : totalCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CompliedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();
				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}	





			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CompliedAssetValue> regionList = new ArrayList<CompliedAssetValue>();
				List<CompliedAssetValue> accountList = new ArrayList<CompliedAssetValue>();
				List<CompliedAssetValue> filteredRegionCategoryList = new ArrayList<CompliedAssetValue>();


				if(totalCompliedAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CompliedAssetValue reg : totalCompliedAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CompliedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CompliedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(CompliedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CompliedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getTotalCompliedAssetValue();
					}

					totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	public CompliedAssetVolume getAllCompliedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Integer totalAssetVolume = 0;
		CompliedAssetVolume totalAssetVolumeSum= new CompliedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CompliedAssetVolume> totalAssetVolumes = new ArrayList<CompliedAssetVolume>();
			List<CompliedAssetVolume> totalCompliedAssetVolumeByUsername = new ArrayList<CompliedAssetVolume>();
			List<CompliedAssetVolume> mocList = new ArrayList<CompliedAssetVolume>();

			totalCompliedAssetVolumeByUsername = compliedAssetVolumeRepository.findAllCompliedAssetVolume(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetVolume mocc : totalCompliedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				for(CompliedAssetVolume t : mocList){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}

				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);

			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CompliedAssetVolume> categoryList = new ArrayList<CompliedAssetVolume>();


				//filtered by category

				for(String c : category){
					for(CompliedAssetVolume cat : totalCompliedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(CompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CompliedAssetVolume> accountList = new ArrayList<CompliedAssetVolume>();

				for(String accnt : account){
					for(CompliedAssetVolume acc : totalCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CompliedAssetVolume> accountList = new ArrayList<CompliedAssetVolume>();
				List<CompliedAssetVolume> filteredAccountCategoryList = new ArrayList<CompliedAssetVolume>();


				//filterd by account
				for(String accnt : account){
					for(CompliedAssetVolume acc : totalCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CompliedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(CompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CompliedAssetVolume> regionList = new ArrayList<CompliedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(CompliedAssetVolume reg : totalCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}

				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CompliedAssetVolume> regionList = new ArrayList<CompliedAssetVolume>();
				List<CompliedAssetVolume> filteredRegionAccountList = new ArrayList<CompliedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(CompliedAssetVolume reg : totalCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CompliedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				totalAssetVolumes.addAll(mocList);

				for(CompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CompliedAssetVolume> regionList = new ArrayList<CompliedAssetVolume>();
				List<CompliedAssetVolume> filteredRegionCategoryList = new ArrayList<CompliedAssetVolume>();

				//filterd by region

				for(String regon : region){
					for(CompliedAssetVolume reg : totalCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CompliedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CompliedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}	
			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CompliedAssetVolume> regionList = new ArrayList<CompliedAssetVolume>();
				List<CompliedAssetVolume> accountList = new ArrayList<CompliedAssetVolume>();
				List<CompliedAssetVolume> filteredRegionCategoryList = new ArrayList<CompliedAssetVolume>();

				if(totalCompliedAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CompliedAssetVolume reg : totalCompliedAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CompliedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CompliedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(CompliedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(CompliedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getTotalCompliedAssetVolume();
					}

					totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}

	//===============================================Start Not Complied Asset=============================================


	public NotCompliedAssetValue getNotCompliedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		NotCompliedAssetValue totalAssetAmountSum = new NotCompliedAssetValue();


		try{

			List<NotCompliedAssetValue> totalAssetValues = new ArrayList<NotCompliedAssetValue>();
			List<NotCompliedAssetValue> totalNotCompliedAssetValuesByUsername = new ArrayList<NotCompliedAssetValue>();
			List<NotCompliedAssetValue> mocList = new ArrayList<NotCompliedAssetValue>();

			totalNotCompliedAssetValuesByUsername = notCompliedAssetValueRepository.findAllNotCompliedAssetValue(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetValue mocc : totalNotCompliedAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(NotCompliedAssetValue t : mocList){
					totalAssetAmount += t.getTotalNotCompliedAssetValue();

				}

				totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);

			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<NotCompliedAssetValue> categoryList = new ArrayList<NotCompliedAssetValue>();

				//filtered by category

				for(String c : category){
					for(NotCompliedAssetValue cat : totalNotCompliedAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(NotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalNotCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<NotCompliedAssetValue> accountList = new ArrayList<NotCompliedAssetValue>();


				for(String accnt : account){
					for(NotCompliedAssetValue acc : totalNotCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(NotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalNotCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<NotCompliedAssetValue> accountList = new ArrayList<NotCompliedAssetValue>();
				List<NotCompliedAssetValue> filteredAccountCategoryList = new ArrayList<NotCompliedAssetValue>();


				//filterd by account
				for(String accnt : account){
					for(NotCompliedAssetValue acc : totalNotCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(NotCompliedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(NotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalNotCompliedAssetValue();
				}
				totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);
			}



			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<NotCompliedAssetValue> regionList = new ArrayList<NotCompliedAssetValue>();

				//filter by region
				for(String regon : region){
					for(NotCompliedAssetValue reg : totalNotCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(NotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalNotCompliedAssetValue();
				}

				totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<NotCompliedAssetValue> regionList = new ArrayList<NotCompliedAssetValue>();
				List<NotCompliedAssetValue> filteredRegionAccountList = new ArrayList<NotCompliedAssetValue>();

				//filter by region
				for(String regon : region){
					for(NotCompliedAssetValue reg : totalNotCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(NotCompliedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(NotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalNotCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<NotCompliedAssetValue> regionList = new ArrayList<NotCompliedAssetValue>();
				List<NotCompliedAssetValue> filteredRegionCategoryList = new ArrayList<NotCompliedAssetValue>();

				//filterd by region

				for(String regon : region){
					for(NotCompliedAssetValue reg : totalNotCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(NotCompliedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(NotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalNotCompliedAssetValue();
				}
				totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);
			}	





			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<NotCompliedAssetValue> regionList = new ArrayList<NotCompliedAssetValue>();
				List<NotCompliedAssetValue> accountList = new ArrayList<NotCompliedAssetValue>();
				List<NotCompliedAssetValue> filteredRegionCategoryList = new ArrayList<NotCompliedAssetValue>();

				if(totalNotCompliedAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(NotCompliedAssetValue reg : totalNotCompliedAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(NotCompliedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(NotCompliedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(NotCompliedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(NotCompliedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getTotalNotCompliedAssetValue();
					}

					totalAssetAmountSum.setTotalNotCompliedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	public NotCompliedAssetVolume getNotCompliedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		Integer totalAssetVolume = 0;
		//Integer totalAssetAmountSum = 0;
		NotCompliedAssetVolume totalAssetVolumeSum = new NotCompliedAssetVolume();


		try{

			List<NotCompliedAssetVolume> totalAssetVolumes = new ArrayList<NotCompliedAssetVolume>();
			List<NotCompliedAssetVolume> totalNotCompliedAssetVolumeByUsername = new ArrayList<NotCompliedAssetVolume>();
			List<NotCompliedAssetVolume> mocList = new ArrayList<NotCompliedAssetVolume>();

			totalNotCompliedAssetVolumeByUsername = notCompliedAssetVolumeRepository.findAllNotCompliedAssetVolume(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetVolume mocc : totalNotCompliedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				for(NotCompliedAssetVolume t : mocList){
					totalAssetVolume += t.getTotalNotCompliedAssetVolume();

				}

				totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);

			}
			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<NotCompliedAssetVolume> categoryList = new ArrayList<NotCompliedAssetVolume>();

				//filtered by category

				for(String c : category){
					for(NotCompliedAssetVolume cat : totalNotCompliedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				totalAssetVolumes.addAll(mocList);

				for(NotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalNotCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);


			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<NotCompliedAssetVolume> accountList = new ArrayList<NotCompliedAssetVolume>();

				for(String accnt : account){
					for(NotCompliedAssetVolume acc : totalNotCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(NotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalNotCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<NotCompliedAssetVolume> accountList = new ArrayList<NotCompliedAssetVolume>();
				List<NotCompliedAssetVolume> filteredAccountCategoryList = new ArrayList<NotCompliedAssetVolume>();


				//filterd by account
				for(String accnt : account){
					for(NotCompliedAssetVolume acc : totalNotCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(NotCompliedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(NotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalNotCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<NotCompliedAssetVolume> regionList = new ArrayList<NotCompliedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(NotCompliedAssetVolume reg : totalNotCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(NotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalNotCompliedAssetVolume();
				}

				totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<NotCompliedAssetVolume> regionList = new ArrayList<NotCompliedAssetVolume>();
				List<NotCompliedAssetVolume> filteredRegionAccountList = new ArrayList<NotCompliedAssetVolume>();

				//filter by region
				for(String regon : region){
					for(NotCompliedAssetVolume reg : totalNotCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(NotCompliedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(NotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalNotCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<NotCompliedAssetVolume> regionList = new ArrayList<NotCompliedAssetVolume>();
				List<NotCompliedAssetVolume> filteredRegionCategoryList = new ArrayList<NotCompliedAssetVolume>();

				//filterd by region

				for(String regon : region){
					for(NotCompliedAssetVolume reg : totalNotCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(NotCompliedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(NotCompliedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(NotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalNotCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<NotCompliedAssetVolume> regionList = new ArrayList<NotCompliedAssetVolume>();
				List<NotCompliedAssetVolume> accountList = new ArrayList<NotCompliedAssetVolume>();
				List<NotCompliedAssetVolume> filteredRegionCategoryList = new ArrayList<NotCompliedAssetVolume>();

				if(totalNotCompliedAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(NotCompliedAssetVolume reg : totalNotCompliedAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(NotCompliedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(NotCompliedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(NotCompliedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(NotCompliedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getTotalNotCompliedAssetVolume();
					}

					totalAssetVolumeSum.setTotalNotCompliedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}
	//=====================================================================View Start =============================================================================

	public List<CurrentMocViewDto> getCurrentMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
		//		List<CurrentMocView> currentMocViewDetails = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> regionList = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> mocList = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> categoryList = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> filteredViewList = new ArrayList<CurrentMocView>();
		//		
		//		try{
		//			currentMocViewDetails=currentMocViewRepository.findAllCurrentMocViewByAccount(account);
		//			//Pageable paging = PageRequest.of(pageNo, pageSize);
		//			
		//			//Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewDetails(paging);
		//			
		//			
		//			//filtered by MOC
		//			for(String m : moc){
		//				for(CurrentMocView mocc : currentMocViewDetails){
		//					if(m.equals(mocc.getMoc())){
		//						mocList.add(mocc);
		//					}
		//
		//				}
		//
		//			}
		//			
		//			//filtered by region
		//			for(String r :region){
		//				for(CurrentMocView reg : mocList){
		//					if(r.equals(reg.getRegion())){
		//						regionList.add(reg);
		//					}
		//
		//				}
		//
		//			}
		//			
		//			//-----filter by category------//
		//
		//			for(String c : category){
		//				for(CurrentMocView cat : regionList){
		//					if(c.equals(cat.getCategory())){
		//						categoryList.add(cat);
		//					}
		//
		//				}
		//
		//			}
		//			
		//			filteredViewList.addAll(categoryList);
		//		}catch(Exception e){
		//			e.printStackTrace();
		//		}
		//		return filteredViewList;
		List<CurrentMocViewDto> filteredViewList = new ArrayList<CurrentMocViewDto>();
		List<CurrentMocView> totalRecords = new ArrayList<CurrentMocView>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMoc(moc, paging);
				totalRecords = currentMocViewRepository.findCountByMoc(moc);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}
			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocCategory(moc,category, paging);
				totalRecords = currentMocViewRepository.findCountByMocCategory(moc,category);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3


				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocAccount(moc,account, paging);
				totalRecords = currentMocViewRepository.findCountByAccount(moc,account);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4

				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocAccountCategory(moc, account, category, paging);
				totalRecords = currentMocViewRepository.findCountByAccountMocCategory(moc, account, category);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}

			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocRegion(moc, region, paging);
				totalRecords = currentMocViewRepository.findCountByMocRegion(moc, region);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}



			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocAccountRegion(moc, account, region, paging);
				totalRecords = currentMocViewRepository.findCountByAccountMocRegion(moc, account, region);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}




			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocRegionCategory(moc, region, category, paging);
				totalRecords = currentMocViewRepository.findAllCountCurrentMocViewByMocRegionCategory(moc, region, category);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}


			}

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
				totalRecords = currentMocViewRepository.findAllCountCurrentMocViewByMocRegionAccountCategory(moc, account, region, category);

				for(CurrentMocView c : currentMocViewDetails.getContent()){
					CurrentMocViewDto currentMocViewDto = new CurrentMocViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}
			}


		}catch(Exception e){
			e.printStackTrace();
		}
		return filteredViewList;
	}

	//=========================Previous Moc View==========================================================================

	public List<PreviousMocViewDto> getPreviousMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){

		List<PreviousMocViewDto> filteredViewList = new ArrayList<PreviousMocViewDto>();
		List<PreviousMocView> totalRecords = new ArrayList<PreviousMocView>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMoc(moc, paging);
				totalRecords = previousMocViewRepository.findCountByMoc(moc);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}
			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocCategory(moc,category, paging);
				totalRecords = previousMocViewRepository.findCountByMocCategory(moc,category);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3


				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocAccount(moc,account, paging);
				totalRecords = previousMocViewRepository.findCountByAccount(moc,account);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4

				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocAccountCategory(moc, account, category, paging);
				totalRecords = previousMocViewRepository.findCountByAccountMocCategory(moc, account, category);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}	

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocRegion(moc, region, paging);
				totalRecords = previousMocViewRepository.findCountByMocRegion(moc, region);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}


			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocAccountRegion(moc, account, region, paging);
				totalRecords = previousMocViewRepository.findCountByAccountMocRegion(moc, account, region);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}
			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocRegionCategory(moc, region, category, paging);
				totalRecords = previousMocViewRepository.findAllCountPreviousMocViewByMocRegionCategory(moc, region, category);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}


			}

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				Page<PreviousMocView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
				totalRecords = previousMocViewRepository.findAllCountPreviousMocViewByMocRegionAccountCategory(moc, account, region, category);

				for(PreviousMocView c : previousMocViewDetails.getContent()){
					PreviousMocViewDto previousMocViewDto = new PreviousMocViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return filteredViewList;
	}

	//=========================Next Moc View==========================================================================

	public List<NextMocViewDto> getNextMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){

		List<NextMocView> regionList = new ArrayList<NextMocView>();
		List<NextMocView> categoryList = new ArrayList<NextMocView>();
		List<NextMocView> filteredViewList = new ArrayList<NextMocView>();
		List<NextMocView> totalRecords = new ArrayList<>();
		NextMocViewDto nextMocViewDto = new NextMocViewDto();
		List<NextMocView> mocList = new ArrayList<NextMocView>();
		List<NextMocViewDto> nextMocViewList = new ArrayList<>();
		List<NextMocView> finalRecords = new ArrayList<>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);
			Page<NextMocView>nextMocViewDetails=nextMocViewRepository.findAllNextMocViewByAccounts(moc,account,paging);
			totalRecords = 	nextMocViewRepository.findAllCountNextMocViewByMocRegionAccountCategory(moc, account, category);

			for(String r :region){
				for(NextMocView reg : totalRecords){
					Pattern pattern = Pattern.compile("(^|,)"+r+"(,|$)");
					Matcher matcher = pattern.matcher(reg.getRegion());
					if(matcher.find()){
						finalRecords.add(reg);
					}

				}

			}

			//-----filter by region------//

			for(String r :region){
				for(NextMocView reg : nextMocViewDetails){
					Pattern pattern = Pattern.compile("(^|,)"+r+"(,|$)");
					Matcher matcher = pattern.matcher(reg.getRegion());
					if(matcher.find()){
						regionList.add(reg);
					}

				}

			}


			//-----filter by category------//

			for(String c : category){
				for(NextMocView cat : regionList){
					if(c.equals(cat.getCategory().trim())){
						categoryList.add(cat);
					}

				}

			}

			filteredViewList.addAll(categoryList);


			for(NextMocView c : filteredViewList){
				NextMocViewDto nextMocViewDtoDetails = new NextMocViewDto();

				nextMocViewDtoDetails.setRefNo(c.getVisiRefNo());
				nextMocViewDtoDetails.setMoc(c.getMoc());
				nextMocViewDtoDetails.setCategory(c.getCategory());
				nextMocViewDtoDetails.setRegion(c.getRegion());
				nextMocViewDtoDetails.setCity(c.getCity());
				nextMocViewDtoDetails.setAssetDescription(c.getAssetDescription());
				nextMocViewDtoDetails.setAssetType(c.getAssetType());
				nextMocViewDtoDetails.setNoOfStores(c.getNoOfStores());
				nextMocViewDtoDetails.setAccount(c.getAccount());
				nextMocViewDtoDetails.setTotalRecords(finalRecords.size());
				

				nextMocViewList.add(nextMocViewDtoDetails);
			}



		}catch(Exception e){
			e.printStackTrace();
		}
		return nextMocViewList;
	}






}
