package com.unilever.asset.commercialB2C.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CommB2CTotalaAssetCreatedVolume;
import com.unilever.global.GlobalVariables;

@Repository
public interface CommB2CTotalAssetCreatedVolumeRepository  extends JpaRepository<CommB2CTotalaAssetCreatedVolume, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_TOTAL_ASSETS_CREATED_VOLUME", nativeQuery = true)
	List<CommB2CTotalaAssetCreatedVolume> findAllTotalAssetCreatedVolumeDetails();
}
