package com.unilever.sales.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface B2CSalesRepository {

}
