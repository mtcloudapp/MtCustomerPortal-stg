package com.unilever.asset.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.unilever.global.GlobalVariables;
@Entity
@Table(name="vw_EXT_CURR_MOC", schema=GlobalVariables.schemaName)
public class ExternalCurentView implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3454173072971836397L;
	
	@Id
	private String id;

	@Column(name="REGION")	
	private String region;

	@Column(name="BRANCH")
	private String branch;

	@Column(name="ACCOUNT")
	private String account;

	@Column(name="MOC")
	private String moc;

	@Column(name="CATEGORY")
	private String category;

	@Column(name="STORE ID")
	private String storeID;

	@Column(name="CITY")
	private String city;

	@Column(name="BRAND")
	private String brand;

	@Column(name="ASSET TYPE")
	private String assetType;

	@Column(name="ASSET DESCRIPTION")
	private String assetDescription;

	@Column(name="COMPLIANCE")
	private String compliance;

	@Column(name="LOSS TREE")
	private String lossTree;

	public ExternalCurentView() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExternalCurentView(String id, String region, String branch, String account, String moc, String category,
			String storeID, String city, String brand, String assetType, String assetDescription, String compliance,
			String lossTree) {
		super();
		this.id = id;
		this.region = region;
		this.branch = branch;
		this.account = account;
		this.moc = moc;
		this.category = category;
		this.storeID = storeID;
		this.city = city;
		this.brand = brand;
		this.assetType = assetType;
		this.assetDescription = assetDescription;
		this.compliance = compliance;
		this.lossTree = lossTree;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStoreID() {
		return storeID;
	}

	public void setStoreID(String storeID) {
		this.storeID = storeID;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getAssetDescription() {
		return assetDescription;
	}

	public void setAssetDescription(String assetDescription) {
		this.assetDescription = assetDescription;
	}

	
	public String getCompliance() {
		return compliance;
	}

	public void setCompliance(String compliance) {
		this.compliance = compliance;
	}

	public String getLossTree() {
		return lossTree;
	}

	public void setLossTree(String lossTree) {
		this.lossTree = lossTree;
	}
	
	

}
