package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.ExternalCurentView;
import com.unilever.global.GlobalVariables;

@Repository
public interface CurrentNextMocViewRepository extends PagingAndSortingRepository<ExternalCurentView, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC=:moc and ecn.ACCOUNT=:account", nativeQuery = true)
	List<ExternalCurentView> findExtrnalCurrentNextMocView(@Param("moc") String moc,@Param("account") String account);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.ACCOUNT=:account", nativeQuery = true)
	List<ExternalCurentView> findExtrnalCurrentNextMocViewByAccount(@Param("account") String account);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account", nativeQuery = true)
	Page<ExternalCurentView> findExtrnalCurrentMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account,Pageable pageable);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account", nativeQuery = true)
	List<ExternalCurentView> findCountExtrnalCurrentMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.CATEGORY in :category", nativeQuery = true)
	Page<ExternalCurentView> findExtrnalCurrentMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.CATEGORY in :category", nativeQuery = true)
	List<ExternalCurentView> findCountExtrnalCurrentMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.REGION in :region", nativeQuery = true)
	Page<ExternalCurentView> findExtrnalCurrentMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.REGION in :region", nativeQuery = true)
	List<ExternalCurentView> findCountExtrnalCurrentMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
	Page<ExternalCurentView> findExtrnalCurrentMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
	List<ExternalCurentView> findCountExtrnalCurrentMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region);
}
