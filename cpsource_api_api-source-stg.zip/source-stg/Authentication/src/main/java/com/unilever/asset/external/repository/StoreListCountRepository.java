package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.StoreListCount;
import com.unilever.global.GlobalVariables;

@Repository
public interface StoreListCountRepository extends JpaRepository<StoreListCount, Integer>{
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_STORE_LIST_TOTAL_COUNT etas where etas.USERNAME=:username", nativeQuery = true)
	List<StoreListCount> findAllStoreListCountExternalDetails(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_STORE_LIST_TOTAL_COUNT etas where etas.USERNAME=:username and etas.MOC=:moc", nativeQuery = true)
	List<StoreListCount> findAllStoreListCountExternalDetailsByMoc(@Param("username") String username,@Param("moc") String moc);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_STORE_LIST_TOTAL_COUNT etas where etas.USERNAME=:username and etas.MOC=:moc and etas.CATEGORY_NAME=:category", nativeQuery = true)
	List<StoreListCount> findAllStoreListCountExternalDetailsByMocAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_STORE_LIST_TOTAL_COUNT etas where etas.USERNAME=:username and  etas.REGION_NAME=:region and etas.MOC=:moc", nativeQuery = true)
	List<StoreListCount> findAllStoreListCountExternalDetailsByRegionAndMoc(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);

	
}
