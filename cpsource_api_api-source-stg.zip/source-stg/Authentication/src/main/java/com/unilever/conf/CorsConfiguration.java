package com.unilever.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


public class CorsConfiguration
	{
	    @Bean
	    public WebMvcConfigurer corsConfigurer() {
	        return new WebMvcConfigurer() {
	            @Override
	            public void addCorsMappings(CorsRegistry registry) {
	                registry.addMapping("/rest/v2//**")
	                .allowedOrigins("*")
	                .allowedMethods("GET", "POST", "PUT", "DELETE");
	            }
	        };
	    }
	}

