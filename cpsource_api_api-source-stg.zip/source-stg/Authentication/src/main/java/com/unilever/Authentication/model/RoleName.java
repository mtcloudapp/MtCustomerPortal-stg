package com.unilever.Authentication.model;

public enum  RoleName {
    ROLE_KAM,
    ROLE_COMMERCIAL,
    ROLE_EXTERNAL,
    ROLE_B2C,
    ROLE_B2CUSER, //Added By Sarin - 21Mar2022
    ROLE_NAM,
    ROLE_NFM,
    ROLE_GM,
    ROLE_VP,
    ROLE_SUPPORT,
    ROLE_CDM,
    ROLE_CMM,
    ROLE_DP,
    ROLE_GMFIN,
    ROLE_KAE,
    ROLE_MTAS,
    ROLE_NCDM,
    ROLE_NCMM,
    ROLE_SCM,
    ROLE_TME,
    ROLE_TSO
}