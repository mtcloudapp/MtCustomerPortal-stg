package com.unilever.Authentication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ACCOUNT")
public class Account {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "ACCOUNT_ID")
	    private int accountId;
	    
	    @Column(name = "ACCOUNT_NAME")
	    private String accountName;

		public Account() {
			super();
					}

		public Account(int accountId, String accountName) {
			super();
			this.accountId = accountId;
			this.accountName = accountName;
		}

		public int getAccountId() {
			return accountId;
		}

		public void setAccountId(int accountId) {
			this.accountId = accountId;
		}

		public String getAccountName() {
			return accountName;
		}

		public void setAccountName(String accountName) {
			this.accountName = accountName;
		}
		
		

	    
}
