package com.unilever.claims.extenal.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.unilever.global.GlobalVariables;

@Entity
@Table(name="vw_CPS_MT_FINANCE", schema=GlobalVariables.schemaName)
public class CpsMtFinaceView implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1363728359469399969L;

	@Id
	private String ID;

	@Column(name="REGION")
	private String branch;

	@Column(name="ACCOUNT")
	private String account;

	@Column(name="MOC")
	private String moc;

	@Column(name="CATEGORY")
	private String category;

	@Column(name="STORECODE")
	private String storeCode;

	@Column(name="STATE")
	private String stateCode;

	@Column(name="SOL_CODE")
	private String solCode;

	@Column(name="CHANNELS")
	private String channels;

	@Column(name="PAY_OR_NOT_PAY")
	private String payOrNotPay;

	@Column(name="BUDGET_PER_STORE")
	private Double budgetPerStore;

	public CpsMtFinaceView() {
		super();
		// TODO Auto-generated constructor stub
	}

	


	public CpsMtFinaceView(String iD, String branch, String account, String moc, String category, String storeCode,
			String stateCode, String solCode, String channels, String payOrNotPay, Double budgetPerStore) {
		super();
		ID = iD;
		this.branch = branch;
		this.account = account;
		this.moc = moc;
		this.category = category;
		this.storeCode = storeCode;
		this.stateCode = stateCode;
		this.solCode = solCode;
		this.channels = channels;
		this.payOrNotPay = payOrNotPay;
		this.budgetPerStore = budgetPerStore;
	}

	
	public String getID() {
		return ID;
	}




	public void setID(String iD) {
		ID = iD;
	}




	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStoreCode() {
		return storeCode;
	}

	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getSolCode() {
		return solCode;
	}

	public void setSolCode(String solCode) {
		this.solCode = solCode;
	}

	public String getChannels() {
		return channels;
	}

	public void setChannels(String channels) {
		this.channels = channels;
	}

	public String getPayOrNotPay() {
		return payOrNotPay;
	}

	public void setPayOrNotPay(String payOrNotPay) {
		this.payOrNotPay = payOrNotPay;
	}

	public Double getBudgetPerStore() {
		return budgetPerStore;
	}

	public void setBudgetPerStore(Double budgetPerStore) {
		this.budgetPerStore = budgetPerStore;
	}

	
	
}
