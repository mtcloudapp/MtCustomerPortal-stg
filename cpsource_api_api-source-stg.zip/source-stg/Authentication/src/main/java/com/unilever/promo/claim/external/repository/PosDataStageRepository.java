package com.unilever.promo.claim.external.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PosDataStage;

@Repository
public interface PosDataStageRepository extends JpaRepository<PosDataStage, Integer>{

	@Transactional
    @Query(value ="select count(*) from "+GlobalVariables.schemaName+".POS_DATA_STAGE", nativeQuery = true)
	Integer findCountPosDataStage();
	
	@Transactional
    @Query(value ="select pcs.FILE_NO from "+GlobalVariables.schemaName+".POS_DATA_STAGE pcs", nativeQuery = true)
	Integer findFileNo();
	
	@Transactional
    @Query(value ="select count(*) from "+GlobalVariables.schemaName+".POS_DATA_STAGE pcs where pcs.ACCOUNT_NAME=:accountName and pcs.MOC=:moc", nativeQuery = true)
	Integer findCountPosDataStageDataByAccountAndMoc(@Param("accountName") String accountName, @Param("moc") String moc);
	
	@Modifying
	@Transactional
    @Query(value ="truncate table "+GlobalVariables.schemaName+".POS_DATA_STAGE", nativeQuery = true)
    void truncatePosDataStage();
	
	//Added By Sarin Jul2021 - Claim File B2C Approval - Starts
	@Modifying
	@Transactional
    @Query(value ="delete from "+GlobalVariables.schemaName+".POS_DATA_STAGE pcs where pcs.ACCOUNT_NAME=:accountName and pcs.MOC=:moc", nativeQuery = true)
    void deletePosDataStageByAccountAndMoc(@Param("accountName") String accountName, @Param("moc") String moc);
	
	@Transactional
    @Query(value ="select pcs.FILE_NO from "+GlobalVariables.schemaName+".POS_DATA_STAGE pcs where pcs.ACCOUNT_NAME=:accountName and pcs.MOC=:moc LIMIT 1", nativeQuery = true)
	Integer findFileNoByAccountMoc(@Param("accountName") String accountName, @Param("moc") String moc);
	
	@Transactional
    //@Query(value ="select count(1) from "+GlobalVariables.schemaName+".POS_DATA_STAGE pcs where pcs.ACCOUNT_NAME=:accountName and pcs.MOC=:moc LIMIT 1", nativeQuery = true)  //Commented By Sarin Mar2022 - POS File KAM Approval
	@Query(value ="select count(1) from "+GlobalVariables.schemaName+".POS_DATA_STAGE PCS inner join POS_FILE_UPLOAD_MASTER PCFM ON PCFM.FILE_NO = PCS.FILE_NO AND PCFM.ACCOUNT_NAME = PCS.ACCOUNT_NAME AND PCFM.MOC = PCS.MOC AND PCFM.KAM_USERNAME_APPROVER IS NOT NULL where PCS.ACCOUNT_NAME=:accountName and PCS.MOC=:moc LIMIT 1", nativeQuery = true)  //Added By Sarin Mar2022 - POS File KAM Approval
	Integer findRowByAccountMoc(@Param("accountName") String accountName, @Param("moc") String moc);
	//Added By Sarin Jul2021 - Claim File B2C Approval - Ends
	
	//Added By Sarin Mar2022 - POS File KAM Approval
	@Transactional
    @Query(value ="select count(1) from "+GlobalVariables.schemaName+".POS_DATA_STAGE PCS inner join ACCOUNT A ON A.ACCOUNT_NAME = PCS.ACCOUNT_NAME inner join USER_ACCOUNT UA ON UA.ACCOUNT_ID = A.ACCOUNT_ID inner join USER_MASTER UM ON UM.USER_ID = UA.USER_ID inner join ROLE_MASTER RM ON RM.ROLE_ID = UM.ROLE_ID AND RM.ROLE_NAME = 'ROLE_KAM' inner join POS_FILE_UPLOAD_MASTER PCFM ON PCFM.FILE_NO = PCS.FILE_NO AND PCFM.ACCOUNT_NAME = PCS.ACCOUNT_NAME AND PCFM.MOC = PCS.MOC AND PCFM.KAM_USERNAME_APPROVER IS NULL WHERE PCS.ACCOUNT_NAME = :accountName AND PCS.MOC = :moc AND UM.USERNAME = :kamusername", nativeQuery = true)
	Integer findKamRowCountByAccountMoc(@Param("accountName") String accountName, @Param("moc") String moc, @Param("kamusername") String kamusername);
}
