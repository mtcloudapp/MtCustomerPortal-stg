package com.unilever.claims.external.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.extenal.model.ExternalServiceNoteDetails;
import com.unilever.global.GlobalVariables;

@Repository
public interface ExternalServiceNoteDetailsRepository extends JpaRepository<ExternalServiceNoteDetails, String>{


	@Transactional 
    @Query(value ="select cmf.FILE_NAME  from "+GlobalVariables.schemaName+".EXT_SERVICE_NOTE_DETAILS cmf where cmf.SOL_CODE=:solCode and cmf.STATE=:state", nativeQuery = true)
	Set<String> findFilesBySoleCodeAndState(@Param("solCode") String solCode,@Param("state") String state);
	
   @Transactional 
   @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_SERVICE_NOTE_DETAILS cmf where cmf.SOL_CODE=:solCode and cmf.STATE=:state order by cmf.ID desc limit 1", nativeQuery = true)
   ExternalServiceNoteDetails findLastUplodedFile(@Param("solCode") String solCode,@Param("state") String state);
	
}
