package com.unilever.asset.kam.model;

import java.util.List;

public class NextMocViewDto {
	private String refNo;
	private String moc;
	private String category;
	private String region;
	private String city;
	private String assetDescription;
	private String assetType;
	private String noOfStores;
	private String account;
	private Integer totalRecords;
	
	
	public NextMocViewDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NextMocViewDto(String refNo, String moc, String category, String region, String city,
			String assetDescription, String assetType, String noOfStores, String account, Integer totalRecords) {
		super();
		this.refNo = refNo;
		this.moc = moc;
		this.category = category;
		this.region = region;
		this.city = city;
		this.assetDescription = assetDescription;
		this.assetType = assetType;
		this.noOfStores = noOfStores;
		this.account = account;
		this.totalRecords = totalRecords;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getMoc() {
		return moc;
	}
	public void setMoc(String moc) {
		this.moc = moc;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAssetDescription() {
		return assetDescription;
	}
	public void setAssetDescription(String assetDescription) {
		this.assetDescription = assetDescription;
	}
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getNoOfStores() {
		return noOfStores;
	}
	public void setNoOfStores(String noOfStores) {
		this.noOfStores = noOfStores;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public Integer getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	
	
	
	
	
	

}
