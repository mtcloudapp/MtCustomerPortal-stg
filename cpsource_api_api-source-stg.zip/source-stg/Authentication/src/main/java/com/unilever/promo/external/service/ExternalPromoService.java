package com.unilever.promo.external.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.unilever.asset.external.model.ExternalCurentView;
import com.unilever.asset.external.model.ExternalCurrentMocViewDto;
import com.unilever.asset.external.model.ExternalPreviousMocView;
import com.unilever.asset.external.model.ExternalPreviousMocViewDto;
import com.unilever.promo.external.model.CurrentMocExternalPromoView;
import com.unilever.promo.external.model.CurrentMocExternalPromoViewDto;
import com.unilever.promo.external.model.ExtenalTotalUtilizeVolume;
import com.unilever.promo.external.model.ExternalNoOfPromotion;
import com.unilever.promo.external.model.ExternalTotalPlannedBudget;
import com.unilever.promo.external.model.ExternalTotalPlannedPromoVolume;
import com.unilever.promo.external.model.NextMocExternalPromoView;
import com.unilever.promo.external.model.NextMocExternalPromoViewDto;
import com.unilever.promo.external.model.PreviousMocExternalPromoView;
import com.unilever.promo.external.model.PreviousMocExternalPromoViewDto;
import com.unilever.promo.external.repository.ExternalCurrentMocPromoViewRepository;
import com.unilever.promo.external.repository.ExternalNextMocPromoViewRepository;
import com.unilever.promo.external.repository.ExternalNoOfPromotionRepository;
import com.unilever.promo.external.repository.ExternalPreviousMocPromoViewRepository;
import com.unilever.promo.external.repository.ExternalTotalPlannedBudgetRepository;
import com.unilever.promo.external.repository.ExternalTotalPlannedPromoVolumeRepository;
import com.unilever.promo.external.repository.ExternalTotalUtilizedVolumeRepository;

@Service
public class ExternalPromoService {
	
	@Autowired
	ExternalNoOfPromotionRepository externalNoOfPromotionRepository;

	@Autowired
	ExternalTotalPlannedBudgetRepository externalTotalPlannedBudgetRepository;

	@Autowired
	ExternalTotalPlannedPromoVolumeRepository externalTotalPlannedPromoVolumeRepository;

	@Autowired
	ExternalTotalUtilizedVolumeRepository externalTotalUtilizedVolumeRepository;
	
	@Autowired
	ExternalCurrentMocPromoViewRepository externalCurrentMocPromoViewRepository;
	
	@Autowired
	ExternalNextMocPromoViewRepository externalNextMocPromoViewRepository;
	
	@Autowired
	ExternalPreviousMocPromoViewRepository externalPreviousMocPromoViewRepository;
	
	
	
	
	//==========================================No Of Promotion Start ====================================================

		public Integer getExternalNoOfPromotionValue(String username,List<String> region,List<String> moc,List<String> category){


			Integer totalAssetAmount = 0;
			
			try{

				if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

					totalAssetAmount = externalNoOfPromotionRepository.findNoOfPromotionByMoc(moc, username);
				}

				else if(region.get(0).equals("All") && moc !=null && category !=null  ){   //2

					totalAssetAmount = externalNoOfPromotionRepository.findNoOfPromotionByMocCategory(moc, category, username);

				}
				else if(region !=null && moc !=null && category.get(0).equals("All")){    //3
					
					totalAssetAmount = externalNoOfPromotionRepository.findNoOfPromotionByMocRegion(moc, region, username);
					
				}

				else if(region != null && moc !=null && category !=null  ){  //4

					totalAssetAmount = externalNoOfPromotionRepository.findNoOfPromotionByMocRegionCategory(moc, region, category, username);

				}//end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetAmount;

		}

		//==========================================Total Planned Budget Start ====================================================

		public ExternalTotalPlannedBudget getExternalTotalPlannedBudget(String username,List<String> region,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			ExternalTotalPlannedBudget totalAssetAmountSum = new ExternalTotalPlannedBudget();


			try{

				List<ExternalTotalPlannedBudget> totalExternalData = new ArrayList<ExternalTotalPlannedBudget>();
				List<ExternalTotalPlannedBudget> mocList = new ArrayList<ExternalTotalPlannedBudget>();
				List<ExternalTotalPlannedBudget> filteredList = new ArrayList<ExternalTotalPlannedBudget>();

				totalExternalData = externalTotalPlannedBudgetRepository.findAllTotalPlannedBudget(username);

				if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

					//filtered by MOC
					for(String m : moc){
						for(ExternalTotalPlannedBudget mocc : totalExternalData){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);
					for(ExternalTotalPlannedBudget t : filteredList){
						totalAssetAmount += t.getTotalPlannedBudget();
					}

					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && moc !=null && category !=null  ){   //2

					List<ExternalTotalPlannedBudget> categoryList = new ArrayList<ExternalTotalPlannedBudget>();

					//filtered by category

					for(String c : category){
						for(ExternalTotalPlannedBudget cat : totalExternalData){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalTotalPlannedBudget mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					filteredList.addAll(mocList);

					for(ExternalTotalPlannedBudget t : filteredList){
						totalAssetAmount += t.getTotalPlannedBudget();
					}

					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);

				}
				else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

					List<ExternalTotalPlannedBudget> regionList = new ArrayList<ExternalTotalPlannedBudget>();

					//filter by region
					for(String regon : region){
						for(ExternalTotalPlannedBudget reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalTotalPlannedBudget mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(ExternalTotalPlannedBudget t : filteredList){
						totalAssetAmount += t.getTotalPlannedBudget();
					}

					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);

				}

				else if(region != null && moc !=null && category !=null  ){  //4

					if(totalExternalData !=null)	{
						List<ExternalTotalPlannedBudget> regionList = new ArrayList<ExternalTotalPlannedBudget>();
						List<ExternalTotalPlannedBudget> filteredRegionCategoryList = new ArrayList<ExternalTotalPlannedBudget>();

						//filterd by region

						for(String regon : region){
							for(ExternalTotalPlannedBudget reg : totalExternalData){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}

						//filtered by category

						for(String c : category){
							for(ExternalTotalPlannedBudget cat : regionList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}

						//filtered by MOC
						for(String m : moc){
							for(ExternalTotalPlannedBudget mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						filteredList.addAll(mocList);
						for(ExternalTotalPlannedBudget t : filteredList){
							totalAssetAmount += t.getTotalPlannedBudget();
						}

						totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);

					}//end of if

				}//end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetAmountSum;

		}

		
		//==========================================Total Planned promo volume Start ====================================================

		public ExternalTotalPlannedPromoVolume getExternalTotalPlannedPromoVolume(String username,List<String> region,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			ExternalTotalPlannedPromoVolume totalAssetAmountSum = new ExternalTotalPlannedPromoVolume();


			try{

				List<ExternalTotalPlannedPromoVolume> totalExternalData = new ArrayList<ExternalTotalPlannedPromoVolume>();
				List<ExternalTotalPlannedPromoVolume> mocList = new ArrayList<ExternalTotalPlannedPromoVolume>();
				List<ExternalTotalPlannedPromoVolume> filteredList = new ArrayList<ExternalTotalPlannedPromoVolume>();

				totalExternalData = externalTotalPlannedPromoVolumeRepository.findAllTotalPlannedPromoVolume(username);

				if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

					//filtered by MOC
					for(String m : moc){
						for(ExternalTotalPlannedPromoVolume mocc : totalExternalData){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);
					for(ExternalTotalPlannedPromoVolume t : filteredList){
						totalAssetAmount += t.getTotalPlannedPromoVolume();
					}

					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && moc !=null && category !=null  ){   //2

					List<ExternalTotalPlannedPromoVolume> categoryList = new ArrayList<ExternalTotalPlannedPromoVolume>();

					//filtered by category

					for(String c : category){
						for(ExternalTotalPlannedPromoVolume cat : totalExternalData){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalTotalPlannedPromoVolume mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					filteredList.addAll(mocList);

					for(ExternalTotalPlannedPromoVolume t : filteredList){
						totalAssetAmount += t.getTotalPlannedPromoVolume();
					}

					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);

				}
				else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

					List<ExternalTotalPlannedPromoVolume> regionList = new ArrayList<ExternalTotalPlannedPromoVolume>();

					//filter by region
					for(String regon : region){
						for(ExternalTotalPlannedPromoVolume reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExternalTotalPlannedPromoVolume mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(ExternalTotalPlannedPromoVolume t : filteredList){
						totalAssetAmount += t.getTotalPlannedPromoVolume();
					}

					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);

				}

				else if(region != null && moc !=null && category !=null  ){  //4

					if(totalExternalData !=null)	{
						List<ExternalTotalPlannedPromoVolume> regionList = new ArrayList<ExternalTotalPlannedPromoVolume>();
						List<ExternalTotalPlannedPromoVolume> filteredRegionCategoryList = new ArrayList<ExternalTotalPlannedPromoVolume>();

						//filterd by region

						for(String regon : region){
							for(ExternalTotalPlannedPromoVolume reg : totalExternalData){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}

						//filtered by category

						for(String c : category){
							for(ExternalTotalPlannedPromoVolume cat : regionList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}

						//filtered by MOC
						for(String m : moc){
							for(ExternalTotalPlannedPromoVolume mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						filteredList.addAll(mocList);
						for(ExternalTotalPlannedPromoVolume t : filteredList){
							totalAssetAmount += t.getTotalPlannedPromoVolume();
						}

						totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);

					}//end of if

				}//end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetAmountSum;

		}

		
		//==========================================Total Utilized Volume Start ====================================================

		public ExtenalTotalUtilizeVolume getExternalTotalUtilizedVolume(String username,List<String> region,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			ExtenalTotalUtilizeVolume totalAssetAmountSum = new ExtenalTotalUtilizeVolume();


			try{

				List<ExtenalTotalUtilizeVolume> totalExternalData = new ArrayList<ExtenalTotalUtilizeVolume>();
				List<ExtenalTotalUtilizeVolume> mocList = new ArrayList<ExtenalTotalUtilizeVolume>();
				List<ExtenalTotalUtilizeVolume> filteredList = new ArrayList<ExtenalTotalUtilizeVolume>();

				totalExternalData = externalTotalUtilizedVolumeRepository.findAllTotalUtilizedVolume(username);

				if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

					//filtered by MOC
					for(String m : moc){
						for(ExtenalTotalUtilizeVolume mocc : totalExternalData){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);
					for(ExtenalTotalUtilizeVolume t : filteredList){
						totalAssetAmount += t.getTotalUtilizedVolume();
					}

					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && moc !=null && category !=null  ){   //2

					List<ExtenalTotalUtilizeVolume> categoryList = new ArrayList<ExtenalTotalUtilizeVolume>();

					//filtered by category

					for(String c : category){
						for(ExtenalTotalUtilizeVolume cat : totalExternalData){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExtenalTotalUtilizeVolume mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					filteredList.addAll(mocList);

					for(ExtenalTotalUtilizeVolume t : filteredList){
						totalAssetAmount += t.getTotalUtilizedVolume();
					}

					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);

				}
				else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

					List<ExtenalTotalUtilizeVolume> regionList = new ArrayList<ExtenalTotalUtilizeVolume>();

					//filter by region
					for(String regon : region){
						for(ExtenalTotalUtilizeVolume reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ExtenalTotalUtilizeVolume mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);

					for(ExtenalTotalUtilizeVolume t : filteredList){
						totalAssetAmount += t.getTotalUtilizedVolume();
					}

					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);

				}

				else if(region != null && moc !=null && category !=null  ){  //4

					if(totalExternalData !=null)	{
						List<ExtenalTotalUtilizeVolume> regionList = new ArrayList<ExtenalTotalUtilizeVolume>();
						List<ExtenalTotalUtilizeVolume> filteredRegionCategoryList = new ArrayList<ExtenalTotalUtilizeVolume>();

						//filterd by region

						for(String regon : region){
							for(ExtenalTotalUtilizeVolume reg : totalExternalData){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}

						//filtered by category

						for(String c : category){
							for(ExtenalTotalUtilizeVolume cat : regionList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}

						//filtered by MOC
						for(String m : moc){
							for(ExtenalTotalUtilizeVolume mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						filteredList.addAll(mocList);
						for(ExtenalTotalUtilizeVolume t : filteredList){
							totalAssetAmount += t.getTotalUtilizedVolume();
						}

						totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);

					}//end of if

				}//end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}

			return totalAssetAmountSum;

		}
		
		//======================================================MOC Views==================================

		//=============================================Current Moc View ====================================
		
		public List<CurrentMocExternalPromoViewDto> getPromoExternalCurrentMocView(List<String> region,List<String> moc,String account,List<String> category,Integer pageNo, Integer pageSize){
			List<CurrentMocExternalPromoViewDto> filteredViewList = new ArrayList<>();
			List<CurrentMocExternalPromoView> totalRecords = new ArrayList<>();
			try{
				
				Pageable paging = PageRequest.of(pageNo, pageSize);
				
				Page<CurrentMocExternalPromoView> externalCurrentMocViewDetails = externalCurrentMocPromoViewRepository.findExternalCurrentMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
				totalRecords = externalCurrentMocPromoViewRepository.findCountExternalCurrentMocViewByMocCategoryRegionAccount(moc, account, category, region);
				
				for(CurrentMocExternalPromoView c : externalCurrentMocViewDetails.getContent()){
					CurrentMocExternalPromoViewDto currentMocExternalPromoViewDto = new CurrentMocExternalPromoViewDto();

					currentMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
					currentMocExternalPromoViewDto.setBrand(c.getBrand());
					currentMocExternalPromoViewDto.setCategory(c.getCategory());
					currentMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
					currentMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
					currentMocExternalPromoViewDto.setMoc(c.getMoc());
					currentMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
					currentMocExternalPromoViewDto.setRegion(c.getRegion());
					currentMocExternalPromoViewDto.setSol_code(c.getSol_code());
					currentMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
					currentMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
					currentMocExternalPromoViewDto.setBasepack(c.getBasepack());
					currentMocExternalPromoViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocExternalPromoViewDto);
				}
				
				
//			if(region.get(0).equals("All")  && category.get(0).equals("All") && moc !=null){//1
//					
//					Page<CurrentMocExternalPromoView> externalCurrentMocViewDetails = externalCurrentMocPromoViewRepository.findExternalCurrentMocViewByMocAccount(moc, account, paging);
//					totalRecords = externalCurrentMocPromoViewRepository.findCountExternalCurrentMocViewByMocAccount(moc, account);
//					
//					for(CurrentMocExternalPromoView c : externalCurrentMocViewDetails.getContent()){
//						CurrentMocExternalPromoViewDto currentMocExternalPromoViewDto = new CurrentMocExternalPromoViewDto();
//
//						currentMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						currentMocExternalPromoViewDto.setBrand(c.getBrand());
//						currentMocExternalPromoViewDto.setCategory(c.getCategory());
//						currentMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocExternalPromoViewDto.setMoc(c.getMoc());
//						currentMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocExternalPromoViewDto.setRegion(c.getRegion());
//						currentMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						currentMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						currentMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocExternalPromoViewDto.setBasepack(c.getBasepack());
//						currentMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//
//						filteredViewList.add(currentMocExternalPromoViewDto);
//					}
//					
//					
//				}
//				else if(region.get(0).equals("All")  && category !=null && moc !=null){//2
//					
//					Page<CurrentMocExternalPromoView> externalCurrentMocViewDetails = externalCurrentMocPromoViewRepository.findExternalCurrentMocViewByMocCategoryAccount(moc, account, category, paging);
//					totalRecords = externalCurrentMocPromoViewRepository.findCountExternalCurrentMocViewByMocCategoryAccount(moc, account, category);
//					
//					for(CurrentMocExternalPromoView c : externalCurrentMocViewDetails.getContent()){
//						CurrentMocExternalPromoViewDto currentMocExternalPromoViewDto = new CurrentMocExternalPromoViewDto();
//
//						currentMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						currentMocExternalPromoViewDto.setBrand(c.getBrand());
//						currentMocExternalPromoViewDto.setCategory(c.getCategory());
//						currentMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocExternalPromoViewDto.setMoc(c.getMoc());
//						currentMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocExternalPromoViewDto.setRegion(c.getRegion());
//						currentMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						currentMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						currentMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocExternalPromoViewDto.setBasepack(c.getBasepack());
//						currentMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocExternalPromoViewDto);
//					}
//				}
//				else if(region !=null  && category.get(0).equals("All") && moc !=null){//3
//					
//					Page<CurrentMocExternalPromoView> externalCurrentMocViewDetails = externalCurrentMocPromoViewRepository.findExternalCurrentMocViewByMocRegionAccount(moc, account, region, paging);
//					totalRecords = externalCurrentMocPromoViewRepository.findCountExternalCurrentMocViewByMocRegionAccount(moc, account, region);
//					
//					for(CurrentMocExternalPromoView c : externalCurrentMocViewDetails.getContent()){
//						CurrentMocExternalPromoViewDto currentMocExternalPromoViewDto = new CurrentMocExternalPromoViewDto();
//
//						currentMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						currentMocExternalPromoViewDto.setBrand(c.getBrand());
//						currentMocExternalPromoViewDto.setCategory(c.getCategory());
//						currentMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocExternalPromoViewDto.setMoc(c.getMoc());
//						currentMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocExternalPromoViewDto.setRegion(c.getRegion());
//						currentMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						currentMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						currentMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocExternalPromoViewDto.setBasepack(c.getBasepack());
//						currentMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocExternalPromoViewDto);
//					}
//					
//				}
//					
//				else if(region !=null  && category != null && moc !=null){//4
//					
//					Page<CurrentMocExternalPromoView> externalCurrentMocViewDetails = externalCurrentMocPromoViewRepository.findExternalCurrentMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
//					totalRecords = externalCurrentMocPromoViewRepository.findCountExternalCurrentMocViewByMocCategoryRegionAccount(moc, account, category, region);
//					
//					for(CurrentMocExternalPromoView c : externalCurrentMocViewDetails.getContent()){
//						CurrentMocExternalPromoViewDto currentMocExternalPromoViewDto = new CurrentMocExternalPromoViewDto();
//
//						currentMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						currentMocExternalPromoViewDto.setBrand(c.getBrand());
//						currentMocExternalPromoViewDto.setCategory(c.getCategory());
//						currentMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocExternalPromoViewDto.setMoc(c.getMoc());
//						currentMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocExternalPromoViewDto.setRegion(c.getRegion());
//						currentMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						currentMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						currentMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocExternalPromoViewDto.setBasepack(c.getBasepack());
//						currentMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocExternalPromoViewDto);
//					}
//				
//				
//				}
				

			}catch(Exception e){
				e.printStackTrace();
			}
			return filteredViewList;
		}


		//=============================================Previous Moc View ====================================
		
		public List<PreviousMocExternalPromoViewDto> getPromoExternalPreviousMocView(List<String> region,List<String> moc,String account,List<String> category,Integer pageNo, Integer pageSize){
			
			List<PreviousMocExternalPromoViewDto> filteredViewList = new ArrayList<>();
			List<PreviousMocExternalPromoView> totalRecords = new ArrayList<>();
			
			try{
				Pageable paging = PageRequest.of(pageNo, pageSize);
				
				Page<PreviousMocExternalPromoView> externalPreviousMocViewDetails = externalPreviousMocPromoViewRepository.findExternalPreviousMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
				totalRecords = externalPreviousMocPromoViewRepository.findCountExternalPreviousMocViewByMocRegionAccount(moc, account, region);
				
				for(PreviousMocExternalPromoView c : externalPreviousMocViewDetails.getContent()){
					PreviousMocExternalPromoViewDto previousMocExternalPromoViewDto = new PreviousMocExternalPromoViewDto();

					previousMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
					previousMocExternalPromoViewDto.setBrand(c.getBrand());
					previousMocExternalPromoViewDto.setCategory(c.getCategory());
					previousMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
					previousMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
					previousMocExternalPromoViewDto.setMoc(c.getMoc());
					previousMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
					previousMocExternalPromoViewDto.setRegion(c.getRegion());
					previousMocExternalPromoViewDto.setSol_code(c.getSol_code());
					previousMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
					previousMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
					previousMocExternalPromoViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocExternalPromoViewDto);
				}
				
//				if(region.get(0).equals("All")  && category.get(0).equals("All") && moc !=null){//1
//					
//					Page<PreviousMocExternalPromoView> externalPreviousMocViewDetails = externalPreviousMocPromoViewRepository.findExternalPreviousMocViewByMocAccount(moc, account, paging);
//					totalRecords = externalPreviousMocPromoViewRepository.findCountExternalPreviousMocViewByMocAccount(moc, account);
//					
//					for(PreviousMocExternalPromoView c : externalPreviousMocViewDetails.getContent()){
//						PreviousMocExternalPromoViewDto previousMocExternalPromoViewDto = new PreviousMocExternalPromoViewDto();
//
//						previousMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						previousMocExternalPromoViewDto.setBrand(c.getBrand());
//						previousMocExternalPromoViewDto.setCategory(c.getCategory());
//						previousMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocExternalPromoViewDto.setMoc(c.getMoc());
//						previousMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocExternalPromoViewDto.setRegion(c.getRegion());
//						previousMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						previousMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						previousMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocExternalPromoViewDto);
//					}
//					
//				}
//				
//				else if(region.get(0).equals("All")  && category !=null && moc !=null){//2
//					
//					Page<PreviousMocExternalPromoView> externalPreviousMocViewDetails = externalPreviousMocPromoViewRepository.findExternalPreviousMocViewByMocCategoryAccount(moc, account, category, paging);
//					totalRecords = externalPreviousMocPromoViewRepository.findCountExternalPreviousMocViewByMocCategoryAccount(moc, account, category);
//					
//					for(PreviousMocExternalPromoView c : externalPreviousMocViewDetails.getContent()){
//						PreviousMocExternalPromoViewDto previousMocExternalPromoViewDto = new PreviousMocExternalPromoViewDto();
//
//						previousMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						previousMocExternalPromoViewDto.setBrand(c.getBrand());
//						previousMocExternalPromoViewDto.setCategory(c.getCategory());
//						previousMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocExternalPromoViewDto.setMoc(c.getMoc());
//						previousMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocExternalPromoViewDto.setRegion(c.getRegion());
//						previousMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						previousMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						previousMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocExternalPromoViewDto);
//					}
//					
//					
//				}
//				
//				else if(region !=null  && category.get(0).equals("All") && moc !=null){//3
//					
//					Page<PreviousMocExternalPromoView> externalPreviousMocViewDetails = externalPreviousMocPromoViewRepository.findExternalPreviousMocViewByMocRegionAccount(moc, account, region, paging);
//					totalRecords = externalPreviousMocPromoViewRepository.findCountExternalPreviousMocViewByMocRegionAccount(moc, account, region);
//					
//					for(PreviousMocExternalPromoView c : externalPreviousMocViewDetails.getContent()){
//						PreviousMocExternalPromoViewDto previousMocExternalPromoViewDto = new PreviousMocExternalPromoViewDto();
//
//						previousMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						previousMocExternalPromoViewDto.setBrand(c.getBrand());
//						previousMocExternalPromoViewDto.setCategory(c.getCategory());
//						previousMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocExternalPromoViewDto.setMoc(c.getMoc());
//						previousMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocExternalPromoViewDto.setRegion(c.getRegion());
//						previousMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						previousMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						previousMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocExternalPromoViewDto);
//					}
//					
//				}
//				
//				else if(region !=null  && category != null && moc !=null){//4
//					
//					Page<PreviousMocExternalPromoView> externalPreviousMocViewDetails = externalPreviousMocPromoViewRepository.findExternalPreviousMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
//					totalRecords = externalPreviousMocPromoViewRepository.findCountExternalPreviousMocViewByMocRegionAccount(moc, account, region);
//					
//					for(PreviousMocExternalPromoView c : externalPreviousMocViewDetails.getContent()){
//						PreviousMocExternalPromoViewDto previousMocExternalPromoViewDto = new PreviousMocExternalPromoViewDto();
//
//						previousMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//						previousMocExternalPromoViewDto.setBrand(c.getBrand());
//						previousMocExternalPromoViewDto.setCategory(c.getCategory());
//						previousMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocExternalPromoViewDto.setMoc(c.getMoc());
//						previousMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocExternalPromoViewDto.setRegion(c.getRegion());
//						previousMocExternalPromoViewDto.setSol_code(c.getSol_code());
//						previousMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//						previousMocExternalPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocExternalPromoViewDto);
//					}
//					
//				}
			
			}catch(Exception e){
				e.printStackTrace();
			}
			return filteredViewList;
		}

		//=============================================Next Moc View ====================================
		
				public List<NextMocExternalPromoViewDto> getPromoExternalNextMocView(List<String> region,List<String> moc,String account,List<String> category,Integer pageNo, Integer pageSize){
					
					List<NextMocExternalPromoViewDto> filteredViewList = new ArrayList<>();
					List<NextMocExternalPromoView> totalRecords = new ArrayList<>();
					
					try{
						Pageable paging = PageRequest.of(pageNo, pageSize);
						Page<NextMocExternalPromoView> externalNextMocViewDetails = externalNextMocPromoViewRepository.findExternalNextMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
						totalRecords = externalNextMocPromoViewRepository.findCountExternalNextMocViewByMocRegionAccount(moc, account, region);
						
						for(NextMocExternalPromoView c : externalNextMocViewDetails.getContent()){
							NextMocExternalPromoViewDto nextMocExternalPromoViewDto = new NextMocExternalPromoViewDto();

							nextMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
							nextMocExternalPromoViewDto.setBrand(c.getBrand());
							nextMocExternalPromoViewDto.setCategory(c.getCategory());
							nextMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
							nextMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
							nextMocExternalPromoViewDto.setMoc(c.getMoc());
							nextMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
							nextMocExternalPromoViewDto.setRegion(c.getRegion());
							nextMocExternalPromoViewDto.setSol_code(c.getSol_code());
							nextMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
							nextMocExternalPromoViewDto.setTotalRecords(totalRecords.size());

							filteredViewList.add(nextMocExternalPromoViewDto);
						}
						
//						if(region.get(0).equals("All")  && category.get(0).equals("All") && moc !=null){//1
//							
//							Page<NextMocExternalPromoView> externalNextMocViewDetails = externalNextMocPromoViewRepository.findExternalNextMocViewByMocAccount(moc, account, paging);
//							totalRecords = externalNextMocPromoViewRepository.findCountExternalNextMocViewByMocAccount(moc, account);
//							
//							for(NextMocExternalPromoView c : externalNextMocViewDetails.getContent()){
//								NextMocExternalPromoViewDto nextMocExternalPromoViewDto = new NextMocExternalPromoViewDto();
//
//								nextMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//								nextMocExternalPromoViewDto.setBrand(c.getBrand());
//								nextMocExternalPromoViewDto.setCategory(c.getCategory());
//								nextMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocExternalPromoViewDto.setMoc(c.getMoc());
//								nextMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocExternalPromoViewDto.setRegion(c.getRegion());
//								nextMocExternalPromoViewDto.setSol_code(c.getSol_code());
//								nextMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//								nextMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocExternalPromoViewDto);
//							}
//							
//						}
//						
//						else if(region.get(0).equals("All")  && category !=null && moc !=null){//2
//							
//							Page<NextMocExternalPromoView> externalNextMocViewDetails = externalNextMocPromoViewRepository.findExternalNextMocViewByMocCategoryAccount(moc, account, category, paging);
//							totalRecords = externalNextMocPromoViewRepository.findCountExternalNextMocViewByMocCategoryAccount(moc, account, category);
//							
//							for(NextMocExternalPromoView c : externalNextMocViewDetails.getContent()){
//								NextMocExternalPromoViewDto nextMocExternalPromoViewDto = new NextMocExternalPromoViewDto();
//
//								nextMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//								nextMocExternalPromoViewDto.setBrand(c.getBrand());
//								nextMocExternalPromoViewDto.setCategory(c.getCategory());
//								nextMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocExternalPromoViewDto.setMoc(c.getMoc());
//								nextMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocExternalPromoViewDto.setRegion(c.getRegion());
//								nextMocExternalPromoViewDto.setSol_code(c.getSol_code());
//								nextMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//								nextMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocExternalPromoViewDto);
//							}
//							
//							
//						}
//						
//						else if(region !=null  && category.get(0).equals("All") && moc !=null){//3
//							
//							Page<NextMocExternalPromoView> externalNextMocViewDetails = externalNextMocPromoViewRepository.findExternalNextMocViewByMocRegionAccount(moc, account, region, paging);
//							totalRecords = externalNextMocPromoViewRepository.findCountExternalNextMocViewByMocRegionAccount(moc, account, region);
//							
//							for(NextMocExternalPromoView c : externalNextMocViewDetails.getContent()){
//								NextMocExternalPromoViewDto nextMocExternalPromoViewDto = new NextMocExternalPromoViewDto();
//
//								nextMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//								nextMocExternalPromoViewDto.setBrand(c.getBrand());
//								nextMocExternalPromoViewDto.setCategory(c.getCategory());
//								nextMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocExternalPromoViewDto.setMoc(c.getMoc());
//								nextMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocExternalPromoViewDto.setRegion(c.getRegion());
//								nextMocExternalPromoViewDto.setSol_code(c.getSol_code());
//								nextMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//								nextMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocExternalPromoViewDto);
//							}
//							
//						}
//						
//						else if(region !=null  && category != null && moc !=null){//4
//							
//							Page<NextMocExternalPromoView> externalNextMocViewDetails = externalNextMocPromoViewRepository.findExternalNextMocViewByMocCategoryRegionAccount(moc, account, category, region, paging);
//							totalRecords = externalNextMocPromoViewRepository.findCountExternalNextMocViewByMocRegionAccount(moc, account, region);
//							
//							for(NextMocExternalPromoView c : externalNextMocViewDetails.getContent()){
//								NextMocExternalPromoViewDto nextMocExternalPromoViewDto = new NextMocExternalPromoViewDto();
//
//								nextMocExternalPromoViewDto.setArticle_code(c.getArticle_code());
//								nextMocExternalPromoViewDto.setBrand(c.getBrand());
//								nextMocExternalPromoViewDto.setCategory(c.getCategory());
//								nextMocExternalPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocExternalPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocExternalPromoViewDto.setMoc(c.getMoc());
//								nextMocExternalPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocExternalPromoViewDto.setRegion(c.getRegion());
//								nextMocExternalPromoViewDto.setSol_code(c.getSol_code());
//								nextMocExternalPromoViewDto.setTotal_planned_volume(c.getTotal_planned_volume());
//								nextMocExternalPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocExternalPromoViewDto);
//							}
//							
//							
//						}
					
					}catch(Exception e){
						e.printStackTrace();
					}
					return filteredViewList;
				}


}
