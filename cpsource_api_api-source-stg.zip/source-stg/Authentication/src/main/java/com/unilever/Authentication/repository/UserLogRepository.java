package com.unilever.Authentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.Authentication.model.UserLog;
import com.unilever.global.GlobalVariables;
import com.unilever.upload.model.StoreListCurrentDetails;

public interface UserLogRepository extends JpaRepository<UserLog, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".USER_LOG", nativeQuery = true)
	List<UserLog> findUserDetails();
	
}
