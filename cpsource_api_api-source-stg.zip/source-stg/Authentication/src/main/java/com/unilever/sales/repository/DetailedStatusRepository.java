package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.DetailedStatus;

@Repository
public interface DetailedStatusRepository extends JpaRepository<DetailedStatus, Integer>{
	
	/*@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status", nativeQuery = true)
	Page<DetailedStatus> findDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,Pageable pageable);
	*/
	
	/*@Transactional
	//@Procedure(procedureName = "sp_detailed_status_cal")
	@Query(value = "CALL sp_detailed_status_cal(:p_Branch,:p_Category,:p_AccountName,:p_MOC,:p_PoNumber);",nativeQuery = true)
	List<DetailedStatus> findDetailStatusList(@Param("p_Branch") List<String> p_Branch,@Param("p_Category") List<String> p_Category,
					@Param("p_AccountName") List<String> p_AccountName,@Param("p_MOC") List<String> p_MOC,@Param("p_PoNumber") String p_PoNumber);
	*/
	
	@Transactional
	//@Procedure(procedureName = "sp_detailed_status_cal")
	@Query(value = "CALL sp_detailed_status_cal(:p_Branch,:p_Category,:p_AccountName,:p_MOC,:p_PoNumber);",nativeQuery = true)
	List<DetailedStatus> findDetailStatusList(@Param("p_Branch") String p_Branch,@Param("p_Category") String p_Category,
					@Param("p_AccountName") String p_AccountName,@Param("p_MOC") String p_MOC,@Param("p_PoNumber") String p_PoNumber);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS ORDER BY tac.PO_NUMBER ASC", nativeQuery = true)
	Page<DetailedStatus> findDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS ORDER BY tac.PO_NUMBER ASC", nativeQuery = true)
	Page<DetailedStatus> findDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select SUM(tac.PO_VALUE) from "+GlobalVariables.schemaName+".DETAILED_STATUS tac GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfPoValue();
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATED_SUM) from "+GlobalVariables.schemaName+".DETAILED_STATUS tac GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfAllocatedValue();
	
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_SUM) from "+GlobalVariables.schemaName+".DETAILED_STATUS tac GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfInvoiced();
	
	
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<DetailedStatus> findCountDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<DetailedStatus> findCountDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status);
	

	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NO) from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Integer> findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NO) from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER=:poNumber and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Integer> findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") String poNumber,@Param("status") List<String> status);
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NO) from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Integer> findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status);
	

	@Transactional
    @Query(value ="select DISTINCT tac.PO_NUMBER  from "+GlobalVariables.schemaName+".DETAILED_STATUS tac", nativeQuery = true)
	List<String> findAllPoNumber();
	
	/*@Transactional
    @Query(value ="select count(*) from "+GlobalVariables.schemaName+".DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.STATUS in :status", nativeQuery = true)
	List<Integer> findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") String poNumber,@Param("status") List<String> status);*/
}
