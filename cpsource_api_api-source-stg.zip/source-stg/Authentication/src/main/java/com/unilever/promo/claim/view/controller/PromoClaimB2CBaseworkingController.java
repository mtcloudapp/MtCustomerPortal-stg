package com.unilever.promo.claim.view.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.view.service.PromoClaimB2CBaseworkingService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimB2CBaseworkingController {
	
	@Autowired
	PromoClaimB2CBaseworkingService promoClaimB2CBaseworkingService;
	
	
	@PutMapping("/updateBaseWorkingByB2C")
	public ResponseEntity<ResponseMessage> updateBaseWorkingByB2C(@RequestParam("solcode") Integer solcode, @RequestParam("basepack") Integer basepack, 
			@RequestParam("articleCode") Integer articleCode, @RequestParam("netClaimValueRevised") Double netClaimValueRevised,@RequestParam("netClaimQtyRevised") Double netClaimQtyRevised,
			@RequestParam("promotionAmtRevised") Double promotionAmtRevised, @RequestParam("claimAmtPerUnitRevised") Double claimAmtPerUnitRevised,@RequestParam("claimPosPrimaryQtyRevised") Double claimPosPrimaryQtyRevised,
			@RequestParam("custClaimMinQtyRevised") Double custClaimMinQtyRevised, @RequestParam("diffInCustomerClaimRevised") Double diffInCustomerClaimRevised,@RequestParam("hulClaimRevised") Double hulClaimRevised,
			@RequestParam("netClaimRevised")Double netClaimRevised,@RequestParam("diffClaimsRevised")Double diffClaimsRevised) {
	
		String message = "";
		ResponseMessage response = new ResponseMessage();
			try {
			     response = promoClaimB2CBaseworkingService.updateBaseWorkingByB2C(solcode, basepack, articleCode, netClaimValueRevised, netClaimQtyRevised, 
			    		 															promotionAmtRevised, claimAmtPerUnitRevised, claimPosPrimaryQtyRevised, 
			    		 															custClaimMinQtyRevised, diffInCustomerClaimRevised, hulClaimRevised, netClaimRevised, diffClaimsRevised);
				

				if(response.getMessage().equals("Success")){
					message = "Updated Successfully!!";

				}
				return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Sorry!! Could not Updated...";
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
			}
		
	}
	
	@PutMapping("/updateOverrunClaimByB2C")
	public ResponseEntity<ResponseMessage> updateOverrunClaimByB2C(@RequestParam("solcode") Integer solcode, @RequestParam("account") String account, 
			@RequestParam("moc") String moc, @RequestParam("approvedOverrunPercentage") Double approvedOverrunPercentage){

		String message = "";
		ResponseMessage response = new ResponseMessage();
		try{
			response = promoClaimB2CBaseworkingService.updateOverrunclaimByB2C(solcode, account, moc, approvedOverrunPercentage);
			if(response.getMessage().equals("Success")){
				message = "Updated Successfully!!";

			}
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));

		}catch(Exception e){
			e.printStackTrace();
			message = "Sorry!! Could not Updated...";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
		}



	}
	
	@PutMapping(value= "/approveOverrunByB2C")
	public ResponseEntity<ResponseMessage> approveOverrunByB2C(@RequestParam("account") String account,@RequestParam("moc") String moc,@RequestParam("username") String username,@RequestParam("overrun") String overrun){
		String message = "";
		ResponseMessage response = new ResponseMessage();

		try {
			response = promoClaimB2CBaseworkingService.approveOverrunClaim(account, moc, username,overrun);

			if(response.getMessage().equals("Success")){
				message = "Approved Successfully";

			}else{
				message = response.getMessage();
			}

			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Sorry!! Not Approved";
		}

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	}
	
	@GetMapping("/downloadBaseWorkingSheetByB2C")
	public ResponseEntity<Resource> downloadBaseWorkingSheetByB2C(@RequestParam("accountName") String accountName,@RequestParam("moc") String moc) {
	String filename = "C:\\Users\\subhasishdatvst\\Desktop\\store_list.xlsx";

	Integer count = 0;

	InputStreamResource file = new InputStreamResource(promoClaimB2CBaseworkingService.getBaseWorkingDetails(accountName, moc));

	return ResponseEntity.ok()
	.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
	.body(file);


	}
	
	@GetMapping("/downloadBaseWorkingRevisedSheetByB2C")
	public ResponseEntity<Resource> downloadBaseWorkingRevisedSheetByB2C(@RequestParam("accountName") String accountName,@RequestParam("moc") String moc) {
	String filename = "C:\\Users\\subhasishdatvst\\Desktop\\store_list.xlsx";

	Integer count = 0;

	InputStreamResource file = new InputStreamResource(promoClaimB2CBaseworkingService.getRevisedBaseWorkingDetails(accountName, moc));

	return ResponseEntity.ok()
	.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
	.body(file);


	}
	
	

	

}
