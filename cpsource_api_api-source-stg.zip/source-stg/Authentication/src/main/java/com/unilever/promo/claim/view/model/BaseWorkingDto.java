package com.unilever.promo.claim.view.model;

import java.io.Serializable;

public class BaseWorkingDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4459139681299925155L;
	
	//private Integer solCode;
	private String solCode;  //Added By Sarin Jun2021

	private Integer basepack;

	private Integer articleCode;

	private String solCodeDescription;

	private Double hulMRP;
	
	private Double customerMRP;
	
	private Double netClaimValue;
	
	private Double netClaimQty;
	
	private Double promotionAmt;
	
	private Double claimAmtPerUnit;
	
	private Double claimPOSPrimaryQty;
	
	private Double customerClaimMinQty;
	
	private Double diffInCustomerClaims;
	
	private Double hulClaim;
	
	private Double netClaim;
	
	private Double diffClaim;
	
	private String promotionUnit;
	
	private String deductionBucket;
	
	private Double deductionAmount;
	
	private Integer totalRecords;
	
	public BaseWorkingDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSolCode() {
		return solCode;
	}

	public void setSolCode(String solCode) {
		this.solCode = solCode;
	}

	public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public String getSolCodeDescription() {
		return solCodeDescription;
	}

	public void setSolCodeDescription(String solCodeDescription) {
		this.solCodeDescription = solCodeDescription;
	}

	public Double getHulMRP() {
		return hulMRP;
	}

	public void setHulMRP(Double hulMRP) {
		this.hulMRP = hulMRP;
	}

	public Double getCustomerMRP() {
		return customerMRP;
	}

	public void setCustomerMRP(Double customerMRP) {
		this.customerMRP = customerMRP;
	}

	public Double getNetClaimValue() {
		return netClaimValue;
	}

	public void setNetClaimValue(Double netClaimValue) {
		this.netClaimValue = netClaimValue;
	}

	public Double getPromotionAmt() {
		return promotionAmt;
	}

	public void setPromotionAmt(Double promotionAmt) {
		this.promotionAmt = promotionAmt;
	}

	public Double getClaimAmtPerUnit() {
		return claimAmtPerUnit;
	}

	public void setClaimAmtPerUnit(Double claimAmtPerUnit) {
		this.claimAmtPerUnit = claimAmtPerUnit;
	}

	public Double getClaimPOSPrimaryQty() {
		return claimPOSPrimaryQty;
	}

	public void setClaimPOSPrimaryQty(Double claimPOSPrimaryQty) {
		this.claimPOSPrimaryQty = claimPOSPrimaryQty;
	}

	public Double getCustomerClaimMinQty() {
		return customerClaimMinQty;
	}

	public void setCustomerClaimMinQty(Double customerClaimMinQty) {
		this.customerClaimMinQty = customerClaimMinQty;
	}

	public Double getDiffInCustomerClaims() {
		return diffInCustomerClaims;
	}

	public void setDiffInCustomerClaims(Double diffInCustomerClaims) {
		this.diffInCustomerClaims = diffInCustomerClaims;
	}

	public Double getHulClaim() {
		return hulClaim;
	}

	public void setHulClaim(Double hulClaim) {
		this.hulClaim = hulClaim;
	}

	public Double getNetClaim() {
		return netClaim;
	}

	public void setNetClaim(Double netClaim) {
		this.netClaim = netClaim;
	}

	public Double getDiffClaim() {
		return diffClaim;
	}

	public void setDiffClaim(Double diffClaim) {
		this.diffClaim = diffClaim;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	public Double getNetClaimQty() {
		return netClaimQty;
	}

	public void setNetClaimQty(Double netClaimQty) {
		this.netClaimQty = netClaimQty;
	}

	public String getPromotionUnit() {
		return promotionUnit;
	}

	public void setPromotionUnit(String promotionUnit) {
		this.promotionUnit = promotionUnit;
	}

	public String getDeductionBucket() {
		return deductionBucket;
	}

	public void setDeductionBucket(String deductionBucket) {
		this.deductionBucket = deductionBucket;
	}

	public Double getDeductionAmount() {
		return deductionAmount;
	}

	public void setDeductionAmount(Double deductionAmount) {
		this.deductionAmount = deductionAmount;
	}
	
	
	
	

}
