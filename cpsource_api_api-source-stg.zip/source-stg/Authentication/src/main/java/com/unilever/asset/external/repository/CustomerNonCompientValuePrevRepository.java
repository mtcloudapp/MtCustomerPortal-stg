package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.ExternalCustomerNonCompliedAssetValuePrev;
import com.unilever.global.GlobalVariables;

@Repository
public interface CustomerNonCompientValuePrevRepository extends JpaRepository<ExternalCustomerNonCompliedAssetValuePrev, Integer>{
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_NOT_COMPLIED_ASSETS_VALUE_PREV etas where etas.USERNAME=:username", nativeQuery = true)
	List<ExternalCustomerNonCompliedAssetValuePrev> findAllCustomerNonCompliantValueExternalDetails(@Param("username") String username);
	
}
