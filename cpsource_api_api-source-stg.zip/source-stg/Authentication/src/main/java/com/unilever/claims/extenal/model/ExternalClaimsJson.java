package com.unilever.claims.extenal.model;

public class ExternalClaimsJson {
	
	private Double totalAmountPlanned;
	private Double rejectedClaimValue;
	private Double rejectedClaimVolume;
	private Double approvedExceptnClaimValue;
	private Double approvedExceptnClaimVolume;
	private Double claimsRaised;
	private Double paidClaimValue;
	private Double unpaidClaimValue;
	
	public ExternalClaimsJson() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Double getTotalAmountPlanned() {
		return totalAmountPlanned;
	}

	public void setTotalAmountPlanned(Double totalAmountPlanned) {
		this.totalAmountPlanned = totalAmountPlanned;
	}

	public Double getRejectedClaimValue() {
		return rejectedClaimValue;
	}

	public void setRejectedClaimValue(Double rejectedClaimValue) {
		this.rejectedClaimValue = rejectedClaimValue;
	}

	public Double getRejectedClaimVolume() {
		return rejectedClaimVolume;
	}

	public void setRejectedClaimVolume(Double rejectedClaimVolume) {
		this.rejectedClaimVolume = rejectedClaimVolume;
	}

	public Double getApprovedExceptnClaimValue() {
		return approvedExceptnClaimValue;
	}

	public void setApprovedExceptnClaimValue(Double approvedExceptnClaimValue) {
		this.approvedExceptnClaimValue = approvedExceptnClaimValue;
	}

	public Double getApprovedExceptnClaimVolume() {
		return approvedExceptnClaimVolume;
	}

	public void setApprovedExceptnClaimVolume(Double approvedExceptnClaimVolume) {
		this.approvedExceptnClaimVolume = approvedExceptnClaimVolume;
	}

	public Double getClaimsRaised() {
		return claimsRaised;
	}

	public void setClaimsRaised(Double claimsRaised) {
		this.claimsRaised = claimsRaised;
	}

	public Double getPaidClaimValue() {
		return paidClaimValue;
	}

	public void setPaidClaimValue(Double paidClaimValue) {
		this.paidClaimValue = paidClaimValue;
	}

	public Double getUnpaidClaimValue() {
		return unpaidClaimValue;
	}

	public void setUnpaidClaimValue(Double unpaidClaimValue) {
		this.unpaidClaimValue = unpaidClaimValue;
	}
	
	

}
