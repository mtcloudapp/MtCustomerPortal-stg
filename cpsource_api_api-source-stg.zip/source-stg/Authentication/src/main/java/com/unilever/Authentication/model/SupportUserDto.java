package com.unilever.Authentication.model;

import java.io.Serializable;

import javax.persistence.Column;

public class SupportUserDto implements Serializable{
	
	private static final long serialVersionUID = -6075397445936250818L;
	
	private Integer solCode;
  	
    private Integer articleCode;
  	
    private Integer basepack;
  	
    private String accountName;
  	
    private String moc;
	
    private String solCodeDescription;
	
    private String entryFieldForUpdatingSolCodeDescription;
    
    private Integer totalRecords;

	public SupportUserDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	

	public String getSolCodeDescription() {
		return solCodeDescription;
	}

	public void setSolCodeDescription(String solCodeDescription) {
		this.solCodeDescription = solCodeDescription;
	}

	public String getEntryFieldForUpdatingSolCodeDescription() {
		return entryFieldForUpdatingSolCodeDescription;
	}

	public void setEntryFieldForUpdatingSolCodeDescription(String entryFieldForUpdatingSolCodeDescription) {
		this.entryFieldForUpdatingSolCodeDescription = entryFieldForUpdatingSolCodeDescription;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}
    
	
    

}
