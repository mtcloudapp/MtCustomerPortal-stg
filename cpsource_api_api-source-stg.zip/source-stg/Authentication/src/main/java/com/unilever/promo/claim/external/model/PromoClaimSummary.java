package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROMO_CLAIMS_SUMMARY")
public class PromoClaimSummary implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2247710298984537491L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="FILE_NO")
	private Integer fileNo;

	@Column(name="WORKFLOW_STAGE_ID")
	private Integer workflowStageID;

	@Column(name="ACCOUNT")
	private String accountName;

	@Column(name="MOC")
	private String moc;

	@Column(name="CUSTOMER_CLAIMED")
	private Double customerClaimed;

	@Column(name="LESS_DEDUCTION")
	private Double lesssDeduction;

	@Column(name="BASEPACK_NOT_APPLICABLE")
	private Double basepackNotApplicable;

	@Column(name="INVALID_CLAIMS")
	private Double invalidsClaims;

	@Column(name="NO_SOL_CODE")
	private Double noSolCode;

	@Column(name="HIGHER_MRP")
	private Double higherMRP;

	@Column(name="POS_VS_CLAIM_QUANTITY")
	private Double posVsClaimQty;

	@Column(name="PRIMARY_VS_CLAIM_QUANTITY")
	private Double primaryVsClaimQty;

	@Column(name="NET_CLAIMS")
	private Double netClaims;

	@Column(name="LESS_OVERRUNS")
	private Double lessOverrun;

	@Column(name="OVERRUN_APPROVED")
	private Double overrunApproved;

	@Column(name="PAYABLES")
	private Double payables;

	@Column(name="AUDIT_CREATE_DATE")
	private String auditCreateDate;

	@Column(name="AUDIT_MODIFIED_DATE")
	private String auditModifiedDate;

	public PromoClaimSummary() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PromoClaimSummary(Integer rECORD_ID, Integer fileNo, Integer workflowStageID, String accountName, String moc,
			Double customerClaimed, Double lesssDeduction, Double basepackNotApplicable, Double invalidsClaims,
			Double noSolCode, Double higherMRP, Double posVsClaimQty, Double primaryVsClaimQty, Double netClaims,
			Double lessOverrun, Double overrunApproved, Double payables, String auditCreateDate,
			String auditModifiedDate) {
		super();
		RECORD_ID = rECORD_ID;
		this.fileNo = fileNo;
		this.workflowStageID = workflowStageID;
		this.accountName = accountName;
		this.moc = moc;
		this.customerClaimed = customerClaimed;
		this.lesssDeduction = lesssDeduction;
		this.basepackNotApplicable = basepackNotApplicable;
		this.invalidsClaims = invalidsClaims;
		this.noSolCode = noSolCode;
		this.higherMRP = higherMRP;
		this.posVsClaimQty = posVsClaimQty;
		this.primaryVsClaimQty = primaryVsClaimQty;
		this.netClaims = netClaims;
		this.lessOverrun = lessOverrun;
		this.overrunApproved = overrunApproved;
		this.payables = payables;
		this.auditCreateDate = auditCreateDate;
		this.auditModifiedDate = auditModifiedDate;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	public Integer getWorkflowStageID() {
		return workflowStageID;
	}

	public void setWorkflowStageID(Integer workflowStageID) {
		this.workflowStageID = workflowStageID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getCustomerClaimed() {
		return customerClaimed;
	}

	public void setCustomerClaimed(Double customerClaimed) {
		this.customerClaimed = customerClaimed;
	}

	public Double getLesssDeduction() {
		return lesssDeduction;
	}

	public void setLesssDeduction(Double lesssDeduction) {
		this.lesssDeduction = lesssDeduction;
	}

	public Double getBasepackNotApplicable() {
		return basepackNotApplicable;
	}

	public void setBasepackNotApplicable(Double basepackNotApplicable) {
		this.basepackNotApplicable = basepackNotApplicable;
	}

	public Double getInvalidsClaims() {
		return invalidsClaims;
	}

	public void setInvalidsClaims(Double invalidsClaims) {
		this.invalidsClaims = invalidsClaims;
	}

	public Double getNoSolCode() {
		return noSolCode;
	}

	public void setNoSolCode(Double noSolCode) {
		this.noSolCode = noSolCode;
	}

	public Double getHigherMRP() {
		return higherMRP;
	}

	public void setHigherMRP(Double higherMRP) {
		this.higherMRP = higherMRP;
	}

	public Double getPosVsClaimQty() {
		return posVsClaimQty;
	}

	public void setPosVsClaimQty(Double posVsClaimQty) {
		this.posVsClaimQty = posVsClaimQty;
	}

	public Double getPrimaryVsClaimQty() {
		return primaryVsClaimQty;
	}

	public void setPrimaryVsClaimQty(Double primaryVsClaimQty) {
		this.primaryVsClaimQty = primaryVsClaimQty;
	}

	public Double getNetClaims() {
		return netClaims;
	}

	public void setNetClaims(Double netClaims) {
		this.netClaims = netClaims;
	}

	public Double getLessOverrun() {
		return lessOverrun;
	}

	public void setLessOverrun(Double lessOverrun) {
		this.lessOverrun = lessOverrun;
	}

	public Double getOverrunApproved() {
		return overrunApproved;
	}

	public void setOverrunApproved(Double overrunApproved) {
		this.overrunApproved = overrunApproved;
	}

	public Double getPayables() {
		return payables;
	}

	public void setPayables(Double payables) {
		this.payables = payables;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}

	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}

	

}
