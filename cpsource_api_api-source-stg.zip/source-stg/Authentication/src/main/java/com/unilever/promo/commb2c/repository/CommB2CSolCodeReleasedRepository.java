package com.unilever.promo.commb2c.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.commb2c.model.CommB2CSolCodeReleased;

@Repository
public interface CommB2CSolCodeReleasedRepository extends JpaRepository<CommB2CSolCodeReleased, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_SOL_CODE_RELEASED", nativeQuery = true)
	List<CommB2CSolCodeReleased> findAllSolcodeReleased();
	
	@Transactional
    @Query(value ="select cnf.SOL_CODE_RELEASED from "+GlobalVariables.schemaName+".COMMB2C_SOL_CODE_RELEASED cnf where cnf.ACCOUNT_NAME in :account "
    		+ "and cnf.MOC in :moc and cnf.REGION_NAME in :region and cnf.CATEGORY_NAME in :category", nativeQuery = true)
	List<String> findDistinctSolCodeReleased(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);


}
