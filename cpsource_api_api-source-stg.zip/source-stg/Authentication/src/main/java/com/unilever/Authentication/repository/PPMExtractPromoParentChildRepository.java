package com.unilever.Authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.Authentication.model.PPMExtractPromoParentChild;

@Repository
public interface PPMExtractPromoParentChildRepository  extends JpaRepository<PPMExtractPromoParentChild, Integer>{
	
	@Transactional
	@Procedure(procedureName = "sp_LoadPromoParentChild")
	void insertIntoPromoParentChild();

}
