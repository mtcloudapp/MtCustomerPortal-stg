package com.unilever.promo.claim.external.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.POS_VS_Primary;

@Repository
public interface POS_VS_PrimaryrRepository extends JpaRepository<POS_VS_Primary, Integer>{
	
	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".POS_VS_PRIMARY pcfm where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNoOfPOS_VS_Primary(@Param("accountName") String accountName, @Param("moc") String moc);


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".POS_VS_PRIMARY  pcfm set pcfm.WORKFLOW_STAGE_ID=:stageID  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updatePOS_VS_PrimaryByAccountMocFileNo(@Param("stageID") Integer stageID,@Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);

//	@Transactional
//	@Query(value = "CALL sp_promo_claims_Pos_vs_primary();", nativeQuery = true)
//	void insertIntoPOS_VS_Primary();

	@Transactional
	@Procedure(procedureName = "sp_promo_claims_Pos_vs_primary")
	void insertIntoPOS_VS_Primary(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
}
