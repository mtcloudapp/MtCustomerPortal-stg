package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.DetailStatusView;

@Repository
public interface DetailStatusViewRepository extends JpaRepository<DetailStatusView, Integer>{
	
	
    @Query(value ="select min(RECORD_ID) ,PO_NUMBER,PO_DATE ,DEPOT,DELIVERY_DATE ,STATUS,count(DISTINCT PO_NUMBER, CIC_NO),sum(ALLOCATED_SUM),sum(INVOICED_SUM),sum(PO_VALUE)  from EXT_DETAILED_STATUS  where USERNAME in :account and MOC in :moc and"
    		+ " BRANCH in :branch and CATEGORY in :category and STATUS in :status GROUP BY PO_NUMBER,PO_DATE,DEPOT,DELIVERY_DATE,STATUS", nativeQuery = true)
	Page<DetailStatusView> findExternalDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status,Pageable pageable);
	
     
    @Query(value ="select min(RECORD_ID) ,PO_NUMBER,PO_DATE ,DEPOT,DELIVERY_DATE ,STATUS,count(DISTINCT PO_NUMBER, CIC_NO),sum(ALLOCATED_SUM),sum(INVOICED_SUM),sum(PO_VALUE)  from EXT_DETAILED_STATUS  where USERNAME in :account and MOC in :moc and"
    		+ " BRANCH in :branch and CATEGORY in :category and PO_NUMBER in :poNumber and STATUS in :status GROUP BY PO_NUMBER,PO_DATE,DEPOT,DELIVERY_DATE,STATUS", nativeQuery = true)
	Page<DetailStatusView> findExternalDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,Pageable pageable);
	
    @Query(value ="select min(RECORD_ID) ,PO_NUMBER,PO_DATE ,DEPOT,DELIVERY_DATE ,STATUS,count(DISTINCT PO_NUMBER, CIC_NO),sum(ALLOCATED_SUM),sum(INVOICED_SUM),sum(PO_VALUE)  from DETAILED_STATUS  where ACCOUNT in :account and MOC in :moc and"
    		+ " BRANCH in :branch and CATEGORY in :category and STATUS in :status GROUP BY PO_NUMBER,PO_DATE,DEPOT,DELIVERY_DATE,STATUS", nativeQuery = true)
	Page<DetailStatusView> findB2ClDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status,Pageable pageable);
    
    @Query(value ="select min(RECORD_ID) ,PO_NUMBER,PO_DATE ,DEPOT,DELIVERY_DATE ,STATUS,count(DISTINCT PO_NUMBER, CIC_NO),sum(ALLOCATED_SUM),sum(INVOICED_SUM),sum(PO_VALUE)  from DETAILED_STATUS  where ACCOUNT in :account and MOC in :moc and"
    		+ " BRANCH in :branch and CATEGORY in :category and PO_NUMBER in :poNumber and STATUS in :status GROUP BY PO_NUMBER,PO_DATE,DEPOT,DELIVERY_DATE,STATUS", nativeQuery = true)
	Page<DetailStatusView> findB2ClDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,Pageable pageable);
	
    @Query(value ="select min(RECORD_ID) ,PO_NUMBER,PO_DATE ,DEPOT,DELIVERY_DATE ,STATUS,count(DISTINCT PO_NUMBER, CIC_NO),sum(ALLOCATED_SUM),sum(INVOICED_SUM),sum(PO_VALUE)  from INT_DETAILED_STATUS  where ACCOUNT in :account and MOC in :moc and"
    		+ " BRANCH in :branch and CATEGORY in :category and STATUS in :status and USERNAME=:username GROUP BY PO_NUMBER,PO_DATE,DEPOT,DELIVERY_DATE,STATUS", nativeQuery = true)
	Page<DetailStatusView> findKamDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status,@Param("username") String username,Pageable pageable);
	
     
    @Query(value ="select min(RECORD_ID) ,PO_NUMBER,PO_DATE ,DEPOT,DELIVERY_DATE ,STATUS,count(DISTINCT PO_NUMBER, CIC_NO),sum(ALLOCATED_SUM),sum(INVOICED_SUM),sum(PO_VALUE)  from INT_DETAILED_STATUS  where ACCOUNT in :account and MOC in :moc and"
    		+ " BRANCH in :branch and CATEGORY in :category and PO_NUMBER in :poNumber and STATUS in :status and USERNAME=:username  GROUP BY PO_NUMBER,PO_DATE,DEPOT,DELIVERY_DATE,STATUS", nativeQuery = true)
	Page<DetailStatusView> findKamDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,@Param("username") String username,Pageable pageable);
	
    
}
