package com.unilever.Authentication.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.Authentication.message.request.LoginForm;
import com.unilever.Authentication.message.request.SignUpForm;
import com.unilever.Authentication.message.response.JwtResponse;
import com.unilever.Authentication.message.response.ResponseMessage;
import com.unilever.Authentication.model.Account;
import com.unilever.Authentication.model.AccountDto;
import com.unilever.Authentication.model.Role;
import com.unilever.Authentication.model.RoleName;
import com.unilever.Authentication.model.SupportUserDto;
import com.unilever.Authentication.model.User;
import com.unilever.Authentication.model.UserLog;
import com.unilever.Authentication.repository.AccountRepository;
import com.unilever.Authentication.repository.RoleRepository;
import com.unilever.Authentication.repository.UserLogRepository;
import com.unilever.Authentication.repository.UserRepository;
import com.unilever.Authentication.security.jwt.JwtProvider;
import com.unilever.Authentication.service.AutenticationService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController

@RequestMapping("/api/auth")
public class AuthRestAPIs {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	AutenticationService autenticationService;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtProvider jwtProvider;


	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	UserLogRepository userLogRepository;

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginForm loginRequest) {

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = jwtProvider.generateJwtToken(authentication);
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		List<Account> accountNames = new ArrayList<Account>();
		List<String>accountDetails = new ArrayList<String>();
		List<String>accountDetailsList = new ArrayList<String>();
		List<String> accessDetails = new ArrayList<String>();
		Set<String> accessDetailsList = new HashSet<String>();
		List<String> accessList = new ArrayList<String>();
		
		
		Integer userID = accountRepository.findUserIdByUsername(userDetails.getUsername());
		accountNames = accountRepository.findAccountByUserId(userID);

		for(Account acccount : accountNames){
			accountDetails.add(acccount.getAccountName());
			accessDetails = accountRepository.findCategoryAccountByAccountId(userID);
			accessDetailsList.addAll(accessDetails);
		}

		accountDetailsList.addAll(accountDetails);
		accessList.addAll(accessDetailsList);
		String accessListStr =  accessList.stream().map(Object::toString)
				.collect(Collectors.joining("||"));


		AccountDto acnt = new AccountDto();
		acnt.setAccountNames(accountDetailsList);
		acnt.setAccountCategoryMapping(accessListStr);
		
	 if(authentication.isAuthenticated()){
		UserLog userLog = new UserLog();
		userLog.setUsername(userDetails.getUsername());
		userLog.setIsLogggedIn("T");
		String currentLogTime = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").format(new Date());
		userLog.setLogTime(currentLogTime);
		userLog.setRoleType(userDetails.getAuthorities().toString());
		userLogRepository.save(userLog);
		}
		return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getUsername(),acnt, userDetails.getAuthorities()));
	}


	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpForm signUpRequest) {
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Username is already taken!"),
					HttpStatus.BAD_REQUEST);
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Email is already in use!"),
					HttpStatus.BAD_REQUEST);
		}

		// Creating user's account
		User user = new User(signUpRequest.getName(), signUpRequest.getUsername(), signUpRequest.getEmail(),
				encoder.encode(signUpRequest.getPassword()));

		//Set<String> strRoles = signUpRequest.getRole();
		String role = signUpRequest.getRole();
		//Set<Role> roles = new HashSet<>();
		Role userRole = null;

		//strRoles.forEach(role -> {
		switch (role) {
		case "KAM":
			userRole = roleRepository.findByName(RoleName.ROLE_KAM)
			.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
			//roles.add(adminRole);

			break;
		case "COMMERCIAL":
			userRole = roleRepository.findByName(RoleName.ROLE_COMMERCIAL)
			.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
			//roles.add(pmRole);

			break;

		case "B2C":
			userRole = roleRepository.findByName(RoleName.ROLE_B2C)
			.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
			//roles.add(pmRole);

			break;
			
		default:
			userRole = roleRepository.findByName(RoleName.ROLE_EXTERNAL)
			.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
			//roles.add(userRole);
		}
		//});

		user.setROLES(userRole);
		userRepository.save(user);

		return new ResponseEntity<>(new ResponseMessage("User registered successfully!"), HttpStatus.OK);
	}
	
	/*@PutMapping("/changePassword")
	public ResponseMessage changePassword(String username, String oldPassword, String newPassword){
		ResponseMessage message = new ResponseMessage();

		try{
			message = autenticationService.chanegePassword(username, oldPassword, newPassword);

		}catch(Exception e){
			e.getStackTrace();
		}
		return message;

	}
*/
	@PutMapping("/changePassword")
	public ResponseMessage changePassword(String username, String recoveryPasswd, String newPassword){
		ResponseMessage message = new ResponseMessage();

		try{
			message = autenticationService.changePassword(username, recoveryPasswd, newPassword);

		}catch(Exception e){
			e.getStackTrace();
		}
		return message;

	}
	
	@PutMapping("/changePasswordByEmail")
	public ResponseMessage changePasswordByEmail(String username, String recoveryPasswd, String newPassword){
	ResponseMessage message = new ResponseMessage();

	try{
	message = autenticationService.chanegePasswordByEmail(username, recoveryPasswd, newPassword);

	}catch(Exception e){
	e.getStackTrace();
	}
	return message;

	}
	@GetMapping("/sendEmail")
	public ResponseMessage sendEmail(@RequestParam("email") String email){
		
		ResponseMessage message = new ResponseMessage();

		try{
			message = autenticationService.validateEmail(email);

		}catch(Exception e){
			e.getStackTrace();
		}
		return message;
	}
	
	@GetMapping("/downloadUserLog")
	public ResponseEntity<Resource> downloadUserLog() {
		String filename = "C:\\Users\\subhasishdatvst\\Desktop\\store_list.xlsx";
		InputStreamResource file = new InputStreamResource(autenticationService.getUserLogData());

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
				.body(file);
	}

	@PutMapping("/updateBySupportUser")
	public ResponseMessage updateBySupportUser(Integer solcode,String solcodeDescpNew){
		ResponseMessage message = new ResponseMessage();

		try{
			message = autenticationService.updateBySupportUserBySolcode(solcode,solcodeDescpNew);

		}catch(Exception e){
			e.getStackTrace();
		}
		return message;

	}

	/*@GetMapping("/getSupportUserDetails")
	public List<SupportUserDto> getSupportUserDetials(String account,String moc,@RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "10") Integer pageSize ){
		List<SupportUserDto> supportUserDetails = new ArrayList<>();
	try{
		supportUserDetails = autenticationService.getSupportUserView(account,moc,pageNo, pageSize);
	
	}catch(Exception e){
	e.getStackTrace();
	}
	return supportUserDetails;

	}*/
	
	@GetMapping("/saveBySupportUser")
	public ResponseMessage saveBySupportUser(String accountName,String moc){
	ResponseMessage message = new ResponseMessage();

	try{
	   message = autenticationService.saveBySupportUser(accountName, moc);

	}catch(Exception e){
	e.getStackTrace();
	}
	return message;

	}

	@PutMapping("/updateSolCodeBySupportUser")
	public ResponseMessage updateSolCodeBySupportUser(@RequestParam("solcode") List<Integer> solcode,@RequestParam("solcodeDescpOld") List<String> solcodeDescpOld,
			@RequestParam("solcodeDescpNew")List<String> solcodeDescpNew,@RequestParam("account") String account,@RequestParam("moc") String moc){
		ResponseMessage message = new ResponseMessage();

		try{
			message = autenticationService.updateSupportUserBySolcode(solcode, solcodeDescpOld, solcodeDescpNew,account,moc);

		}catch(Exception e){
			e.getStackTrace();
		}
		return message;

	}

}