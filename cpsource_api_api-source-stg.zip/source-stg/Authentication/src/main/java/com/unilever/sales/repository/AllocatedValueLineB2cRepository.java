package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.PoAllocatedValue;
import com.unilever.sales.model.PoAllocatedValueB2c;

@Repository
public interface AllocatedValueLineB2cRepository extends JpaRepository<PoAllocatedValueB2c, Integer>  {

	@Transactional
    @Query(value ="select sum(etas.ALLOCATED_VALUE) from "+GlobalVariables.schemaName+".ALLOCATED_TOTAL_VALUE etas  where etas.BRANCH in :region and etas.ACCOUNT in :account and etas.MOC in :moc and etas.CATEGORY in :category", nativeQuery = true)
	Double findAllocatedValueOfPo(@Param("region") List<String> region,@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("category") List<String> category);

}
