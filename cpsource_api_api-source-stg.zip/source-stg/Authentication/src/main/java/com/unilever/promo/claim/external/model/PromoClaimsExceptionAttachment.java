package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROMO_CLAIMS_EXCEPTION_ATTACHMENT")
public class PromoClaimsExceptionAttachment implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1012541417225545999L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="RECORD_ID")
	private String id;

	@Column(name="ATTACHMENT_FILE_NO")
	private Integer attachmentFileNo;

	@Column(name="ACCOUNT_NAME")
	private String accountName;

	@Column(name="MOC")
	private String moc;

	@Column(name="UPLOAD_DATE")
	private String uploadDate;

	@Column(name="UPLOADED_FILE_NAME")
	private String uploadedFileName;

	@Column(name="AUDIT_CREATE_DATE")
	private String auditCreateDate;

	@Column(name="AUDIT_MODIFIED_DATE")
	private String auditModifiedDate;

	public PromoClaimsExceptionAttachment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PromoClaimsExceptionAttachment(String id, Integer attachmentFileNo, String accountName, String moc,
			String uploadDate, String uploadedFileName, String auditCreateDate, String auditModifiedDate) {
		super();
		this.id = id;
		this.attachmentFileNo = attachmentFileNo;
		this.accountName = accountName;
		this.moc = moc;
		this.uploadDate = uploadDate;
		this.uploadedFileName = uploadedFileName;
		this.auditCreateDate = auditCreateDate;
		this.auditModifiedDate = auditModifiedDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getAttachmentFileNo() {
		return attachmentFileNo;
	}

	public void setAttachmentFileNo(Integer attachmentFileNo) {
		this.attachmentFileNo = attachmentFileNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getUploadedFileName() {
		return uploadedFileName;
	}

	public void setUploadedFileName(String uploadedFileName) {
		this.uploadedFileName = uploadedFileName;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}

	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}
	


}
