package com.unilever.promo.claim.external.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaimFileUploadMaster;

@Repository
public interface PrompClaimsFileUploadMasterRepository  extends JpaRepository<PromoClaimFileUploadMaster, Integer>{
  
	@Transactional
    @Query(value ="select count(*) from "+GlobalVariables.schemaName+".PROMO_CLAIMS_FILE_UPLOAD_MASTER pcfm where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findCountPromoClaimFileUploadMaster(@Param("accountName") String accountName, @Param("moc") String moc);
	
	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".PROMO_CLAIMS_FILE_UPLOAD_MASTER pcfm where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNoOfPromoClaimFileUploadMst(@Param("accountName") String accountName, @Param("moc") String moc);


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".PROMO_CLAIMS_FILE_UPLOAD_MASTER  pcfm set pcfm.WORKFLOW_STAGE_ID=:stageID  where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updatePromoClaimFileUploadMstByAccountMocFileNo(@Param("stageID") Integer stageID,@Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);

	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".PROMO_CLAIMS_FILE_UPLOAD_MASTER pcfm where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNo(@Param("accountName") String accountName, @Param("moc") String moc);
	
	//Added By Sarin Jul2021 - Claim File B2C Approval
	@Transactional
	@Query(value ="select S3_PATH from "+GlobalVariables.schemaName+".PROMO_CLAIMS_FILE_UPLOAD_MASTER pcfm where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc and FILE_NO = :fileNo LIMIT 1", nativeQuery = true)
	String findS3PathByAccountMocFileno(@Param("accountName") String accountName, @Param("moc") String moc, @Param("fileNo") Integer fileNo);
	
	//Added By Sarin Nov2021 - Claim File KAM Approval
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".PROMO_CLAIMS_FILE_UPLOAD_MASTER pcfm set pcfm.KAM_USERNAME_APPROVER=:kamUserName, pcfm.KAM_ACTION=:kamAction, pcfm.KAM_APPROVED_DATE=current_timestamp() where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updatePromoClaimFileUploadKAMDetailsByAccountMocFileNo(@Param("kamUserName") String kamUserName, @Param("kamAction") String kamAction, @Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);
}
