package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BASE_WORKING")
public class BaseWorking implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -2178509718685692842L;



	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="FILE_NO")
	private Integer fileNo;

	@Column(name="WORKFLOW_STAGE_ID")
	private Integer workflowStageID;

	@Column(name="ACCOUNT")
	private String accountName;

	@Column(name="MOC")
	private String moc;
	
	@Column(name="SOL_CODE")
	private Integer solCode;
	
	@Column(name="SOL_CODE_REVISED")
	//private Integer solCodeRevised;
	private String solCodeRevised;  //Added By Sarin Jun2021
	
	@Column(name="BASEPACK_REVISED")
	private Integer basepackRevised;

	
	@Column(name="BASEPACK")
	private Integer basepack;

	
	@Column(name="ARTICLE_CODE")
	private Integer articleCode;

	
	@Column(name="SOL_CODE_DESCRIPTION")
	private String soleCodeDesc;

	
	@Column(name="BASEPACK_APPLICABILITY")
	private String basepackAvaibility;

	
	@Column(name="HUL_MRP")
	private Double hulMRP;

	
	@Column(name="CUSTOMER_MRP")
	private Double customerMRP;

	
	@Column(name="PROMOTION_UNIT")
	private String promotionUnit;

	
	@Column(name="NET_CLAIM_VALUE")
	private Double netClaimValue;

	
	@Column(name="NET_CLAIM_QUANTITY")
	private Double netClaimQty;

	
	@Column(name="PROMOTION_AMOUNT")
	private Double promotionAmt;

	
	@Column(name="CLAIM_AMOUNT_PER_UNIT")
	private Double claimAmtPerUnit;

	
	@Column(name="CLAIM_POS_PRIMARY_QUANTITY")
	private Double claimPosPrimaryQty;

	
	@Column(name="CUSTOMER_CLAIM_MIN_QUANTITY")
	private Double customerClaimMinQty;

	
	@Column(name="DEDUCTION_AMOUNT")
	private Double deductionAmt;

	
	@Column(name="DEDUCTION_BUCKET")
	private String deductionBucket;

	
	@Column(name="DIFFERENCE_IN_CUSTOMER_CLAIMS")
	private Double diffInCustomerClaims;
	
	@Column(name="HUL_CLAIM")
	private Double hulClaim;
	
	@Column(name="NET_CLAIMS")
	private Double netClaims;
	
	@Column(name="DIFFERENCE_CLAIMS")
	private Double diffClaims;
	
	@Column(name="NET_CLAIM_VALUE_REVISED")
	private Double netClaimValueRevised;
	
	@Column(name="NET_CLAIM_QUANTITY_REVISED")
	private Double netClaimQtyRevised;
	
	@Column(name="PROMOTION_AMOUNT_REVISED")
	private Double promotionAmtRevised;
	
	@Column(name="CLAIM_AMOUNT_PER_UNIT_REVISED")
	private Double claimAmtPerUnitRevised;
	
	@Column(name="CLAIM_POS_PRIMARY_QUANTITY_REVISED")
	private Double claimPosPrimaryQtyRevised;
	
	@Column(name="CUSTOMER_CLAIM_MIN_QUANTITY_REVISED")
	private Double custClaimMinQtyRevised;
	
	@Column(name="DIFFERENCE_IN_CUSTOMER_CLAIMS_REVISED")
	private Double diffInCustomerClaimRevised;
	
	@Column(name="HUL_CLAIM_REVISED")
	private Double hulClaimRevised;
	
	@Column(name="NET_CLAIMS_REVISED")
	private Double netClaimRevised;
	
	@Column(name="DIFFERENCE_CLAIMS_REVISED")
	private Double diffClaimsRevised;
	
	@Column(name="AUDIT_CREATE_DATE")
	private String auditCreateDate;

		public BaseWorking() {
		super();
		// TODO Auto-generated constructor stub
	}

	
public BaseWorking(Integer rECORD_ID, Integer fileNo, Integer workflowStageID, String accountName, String moc,
				Integer solCode, String solCodeRevised, Integer basepackRevised, Integer basepack, Integer articleCode,
				String soleCodeDesc, String basepackAvaibility, Double hulMRP, Double customerMRP, String promotionUnit,
				Double netClaimValue, Double netClaimQty, Double promotionAmt, Double claimAmtPerUnit,
				Double claimPosPrimaryQty, Double customerClaimMinQty, Double deductionAmt, String deductionBucket,
				Double diffInCustomerClaims, Double hulClaim, Double netClaims, Double diffClaims,
				Double netClaimValueRevised, Double netClaimQtyRevised, Double promotionAmtRevised,
				Double claimAmtPerUnitRevised, Double claimPosPrimaryQtyRevised, Double custClaimMinQtyRevised,
				Double diffInCustomerClaimRevised, Double hulClaimRevised, Double netClaimRevised,
				Double diffClaimsRevised, String auditCreateDate) {
			super();
			RECORD_ID = rECORD_ID;
			this.fileNo = fileNo;
			this.workflowStageID = workflowStageID;
			this.accountName = accountName;
			this.moc = moc;
			this.solCode = solCode;
			this.solCodeRevised = solCodeRevised;
			this.basepackRevised = basepackRevised;
			this.basepack = basepack;
			this.articleCode = articleCode;
			this.soleCodeDesc = soleCodeDesc;
			this.basepackAvaibility = basepackAvaibility;
			this.hulMRP = hulMRP;
			this.customerMRP = customerMRP;
			this.promotionUnit = promotionUnit;
			this.netClaimValue = netClaimValue;
			this.netClaimQty = netClaimQty;
			this.promotionAmt = promotionAmt;
			this.claimAmtPerUnit = claimAmtPerUnit;
			this.claimPosPrimaryQty = claimPosPrimaryQty;
			this.customerClaimMinQty = customerClaimMinQty;
			this.deductionAmt = deductionAmt;
			this.deductionBucket = deductionBucket;
			this.diffInCustomerClaims = diffInCustomerClaims;
			this.hulClaim = hulClaim;
			this.netClaims = netClaims;
			this.diffClaims = diffClaims;
			this.netClaimValueRevised = netClaimValueRevised;
			this.netClaimQtyRevised = netClaimQtyRevised;
			this.promotionAmtRevised = promotionAmtRevised;
			this.claimAmtPerUnitRevised = claimAmtPerUnitRevised;
			this.claimPosPrimaryQtyRevised = claimPosPrimaryQtyRevised;
			this.custClaimMinQtyRevised = custClaimMinQtyRevised;
			this.diffInCustomerClaimRevised = diffInCustomerClaimRevised;
			this.hulClaimRevised = hulClaimRevised;
			this.netClaimRevised = netClaimRevised;
			this.diffClaimsRevised = diffClaimsRevised;
			this.auditCreateDate = auditCreateDate;
		}






	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	public Integer getWorkflowStageID() {
		return workflowStageID;
	}

	public void setWorkflowStageID(Integer workflowStageID) {
		this.workflowStageID = workflowStageID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}

	public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public String getSoleCodeDesc() {
		return soleCodeDesc;
	}

	public void setSoleCodeDesc(String soleCodeDesc) {
		this.soleCodeDesc = soleCodeDesc;
	}

	public String getBasepackAvaibility() {
		return basepackAvaibility;
	}

	public void setBasepackAvaibility(String basepackAvaibility) {
		this.basepackAvaibility = basepackAvaibility;
	}

	public Double getHulMRP() {
		return hulMRP;
	}

	public void setHulMRP(Double hulMRP) {
		this.hulMRP = hulMRP;
	}

	public Double getCustomerMRP() {
		return customerMRP;
	}

	public void setCustomerMRP(Double customerMRP) {
		this.customerMRP = customerMRP;
	}

	public String getPromotionUnit() {
		return promotionUnit;
	}

	public void setPromotionUnit(String promotionUnit) {
		this.promotionUnit = promotionUnit;
	}

	public Double getNetClaimValue() {
		return netClaimValue;
	}

	public void setNetClaimValue(Double netClaimValue) {
		this.netClaimValue = netClaimValue;
	}

	public Double getNetClaimQty() {
		return netClaimQty;
	}

	public void setNetClaimQty(Double netClaimQty) {
		this.netClaimQty = netClaimQty;
	}

	public Double getPromotionAmt() {
		return promotionAmt;
	}

	public void setPromotionAmt(Double promotionAmt) {
		this.promotionAmt = promotionAmt;
	}

	public Double getClaimAmtPerUnit() {
		return claimAmtPerUnit;
	}

	public void setClaimAmtPerUnit(Double claimAmtPerUnit) {
		this.claimAmtPerUnit = claimAmtPerUnit;
	}

	public Double getClaimPosPrimaryQty() {
		return claimPosPrimaryQty;
	}

	public void setClaimPosPrimaryQty(Double claimPosPrimaryQty) {
		this.claimPosPrimaryQty = claimPosPrimaryQty;
	}

	public Double getCustomerClaimMinQty() {
		return customerClaimMinQty;
	}

	public void setCustomerClaimMinQty(Double customerClaimMinQty) {
		this.customerClaimMinQty = customerClaimMinQty;
	}

	public Double getDeductionAmt() {
		return deductionAmt;
	}

	public void setDeductionAmt(Double deductionAmt) {
		this.deductionAmt = deductionAmt;
	}

	public String getDeductionBucket() {
		return deductionBucket;
	}

	public void setDeductionBucket(String deductionBucket) {
		this.deductionBucket = deductionBucket;
	}

	public Double getDiffInCustomerClaims() {
		return diffInCustomerClaims;
	}

	public void setDiffInCustomerClaims(Double diffInCustomerClaims) {
		this.diffInCustomerClaims = diffInCustomerClaims;
	}

	public Double getHulClaim() {
		return hulClaim;
	}

	public void setHulClaim(Double hulClaim) {
		this.hulClaim = hulClaim;
	}

	public Double getNetClaims() {
		return netClaims;
	}

	public void setNetClaims(Double netClaims) {
		this.netClaims = netClaims;
	}

	public Double getDiffClaims() {
		return diffClaims;
	}

	public void setDiffClaims(Double diffClaims) {
		this.diffClaims = diffClaims;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public Double getNetClaimValueRevised() {
		return netClaimValueRevised;
	}

	public void setNetClaimValueRevised(Double netClaimValueRevised) {
		this.netClaimValueRevised = netClaimValueRevised;
	}

	public Double getNetClaimQtyRevised() {
		return netClaimQtyRevised;
	}

	public void setNetClaimQtyRevised(Double netClaimQtyRevised) {
		this.netClaimQtyRevised = netClaimQtyRevised;
	}

	public Double getPromotionAmtRevised() {
		return promotionAmtRevised;
	}

	public void setPromotionAmtRevised(Double promotionAmtRevised) {
		this.promotionAmtRevised = promotionAmtRevised;
	}

	public Double getClaimAmtPerUnitRevised() {
		return claimAmtPerUnitRevised;
	}

	public void setClaimAmtPerUnitRevised(Double claimAmtPerUnitRevised) {
		this.claimAmtPerUnitRevised = claimAmtPerUnitRevised;
	}

	public Double getClaimPosPrimaryQtyRevised() {
		return claimPosPrimaryQtyRevised;
	}

	public void setClaimPosPrimaryQtyRevised(Double claimPosPrimaryQtyRevised) {
		this.claimPosPrimaryQtyRevised = claimPosPrimaryQtyRevised;
	}

	public Double getCustClaimMinQtyRevised() {
		return custClaimMinQtyRevised;
	}

	public void setCustClaimMinQtyRevised(Double custClaimMinQtyRevised) {
		this.custClaimMinQtyRevised = custClaimMinQtyRevised;
	}

	public Double getDiffInCustomerClaimRevised() {
		return diffInCustomerClaimRevised;
	}

	public void setDiffInCustomerClaimRevised(Double diffInCustomerClaimRevised) {
		this.diffInCustomerClaimRevised = diffInCustomerClaimRevised;
	}

	public Double getHulClaimRevised() {
		return hulClaimRevised;
	}

	public void setHulClaimRevised(Double hulClaimRevised) {
		this.hulClaimRevised = hulClaimRevised;
	}

	public Double getNetClaimRevised() {
		return netClaimRevised;
	}

	public void setNetClaimRevised(Double netClaimRevised) {
		this.netClaimRevised = netClaimRevised;
	}

	public Double getDiffClaimsRevised() {
		return diffClaimsRevised;
	}

	public void setDiffClaimsRevised(Double diffClaimsRevised) {
		this.diffClaimsRevised = diffClaimsRevised;
	}

	public String getSolCodeRevised() {
		return solCodeRevised;
	}

	public void setSolCodeRevised(String solCodeRevised) {
		this.solCodeRevised = solCodeRevised;
	}

	public Integer getBasepackRevised() {
		return basepackRevised;
	}

	public void setBasepackRevised(Integer basepackRevised) {
		this.basepackRevised = basepackRevised;
	}
	
	

}
