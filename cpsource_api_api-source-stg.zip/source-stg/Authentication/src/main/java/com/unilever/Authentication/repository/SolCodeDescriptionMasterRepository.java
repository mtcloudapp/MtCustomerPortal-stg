package com.unilever.Authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.Authentication.model.SOLCodeDescriptionMaster;

@Repository
public interface SolCodeDescriptionMasterRepository extends JpaRepository<SOLCodeDescriptionMaster, Integer>{
	
	@Transactional
	@Procedure(procedureName = "sp_promo_load_description_master")
	void insertIntoSolCodeDescriptionMaster();
	

}
