package com.unilever.asset.commercialB2C.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetValue;
import com.unilever.global.GlobalVariables;

@Repository
public interface CommB2CPlannedAssetValueReposiory extends JpaRepository<CommB2CPlannedAssetValue, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_PLANNED_ASSETS_VALUE", nativeQuery = true)
	List<CommB2CPlannedAssetValue> findAllPlannedAssetValueDetails();
}
