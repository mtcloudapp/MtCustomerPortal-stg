package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.global.GlobalVariables;

public interface NextMocViewRepository extends PagingAndSortingRepository<NextMocView, String>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :accounts", nativeQuery = true)
	Page<NextMocView> findAllNextMocViewByAccounts(@Param("moc") List<String> moc,@Param("accounts") List<String> accounts,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm where icm.MOC in :moc", nativeQuery = true)
	List<NextMocView> findCountByMoc(@Param("moc") List<String> moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocView> findCountByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	List<NextMocView> findCountByAccount(@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocView> findCountByAccountMocCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	List<NextMocView> findCountByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	List<NextMocView> findCountByAccountMocRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocView> findAllCountNextMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	
//	@Transactional
//    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
//	List<NextMocView> findAllCountNextMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :account  and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocView> findAllCountNextMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
		
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC icm", nativeQuery = true)
	List<NextMocView> findAllNextMocViewDetails();
	
}
