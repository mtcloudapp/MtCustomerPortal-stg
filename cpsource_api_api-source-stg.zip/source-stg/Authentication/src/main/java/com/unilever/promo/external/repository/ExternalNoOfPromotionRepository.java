package com.unilever.promo.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.external.model.ExternalNoOfPromotion;
import com.unilever.promo.kam.model.NextMocPromoView;

@Repository
public interface ExternalNoOfPromotionRepository extends JpaRepository<ExternalNoOfPromotion, Integer>{

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_NO_OF_PROMOTIONS etas where etas.USERNAME=:username", nativeQuery = true)
	List<ExternalNoOfPromotion> findAllNoOfPromotinDetails(@Param("username") String username);
	
	@Transactional
    @Query(value ="select count(distinct etas.SOL_CODE) from "+GlobalVariables.schemaName+".EXT_NO_OF_PROMOTIONS etas  where etas.MOC in :moc and etas.USERNAME=:username", nativeQuery = true)
	Integer findNoOfPromotionByMoc(@Param("moc") List<String> moc,@Param("username") String username);
	
	@Transactional
    @Query(value ="select count(distinct etas.SOL_CODE) from "+GlobalVariables.schemaName+".EXT_NO_OF_PROMOTIONS etas  where etas.MOC in :moc and etas.CATEGORY_NAME in :category and etas.USERNAME=:username", nativeQuery = true)
	Integer findNoOfPromotionByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,@Param("username") String username);
	
	@Transactional
    @Query(value ="select count(distinct etas.SOL_CODE) from "+GlobalVariables.schemaName+".EXT_NO_OF_PROMOTIONS etas  where etas.MOC in :moc and etas.REGION_NAME in :region and etas.USERNAME=:username", nativeQuery = true)
	Integer findNoOfPromotionByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("username") String username);
	
	@Transactional
    @Query(value ="select count(distinct etas.SOL_CODE) from "+GlobalVariables.schemaName+".EXT_NO_OF_PROMOTIONS etas  where etas.MOC in :moc and etas.REGION_NAME in :region and etas.CATEGORY_NAME in :category and etas.USERNAME=:username", nativeQuery = true)
	Integer findNoOfPromotionByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,@Param("username") String username);
	
}
