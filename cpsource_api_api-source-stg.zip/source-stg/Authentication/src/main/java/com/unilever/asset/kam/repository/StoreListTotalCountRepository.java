package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.global.GlobalVariables;

public interface StoreListTotalCountRepository extends JpaRepository<StoreListTotalCount, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCount(@Param("username") String username);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.REGION_NAME like %:region%", nativeQuery = true)
	List<StoreListTotalCount> findByRegionName(@Param("region") String region);
	
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCountByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCountByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCountByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCountByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCountByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCountByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<StoreListTotalCount> findAllStoreListTotalCountByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);

	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountDetails();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where  tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_COUNT tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<StoreListTotalCount> findAllStoreListTotalCountByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		









}
