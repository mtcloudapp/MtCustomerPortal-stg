package com.unilever.promo.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.external.model.CurrentMocExternalPromoView;


@Repository
public interface ExternalCurrentMocPromoViewRepository extends PagingAndSortingRepository<CurrentMocExternalPromoView, String>  {

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account", nativeQuery = true)
	Page<CurrentMocExternalPromoView> findExternalCurrentMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account,Pageable pageable);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account", nativeQuery = true)
	List<CurrentMocExternalPromoView> findCountExternalCurrentMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocExternalPromoView> findExternalCurrentMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocExternalPromoView> findCountExternalCurrentMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.REGION in :region", nativeQuery = true)
	Page<CurrentMocExternalPromoView> findExternalCurrentMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.REGION in :region", nativeQuery = true)
	List<CurrentMocExternalPromoView> findCountExternalCurrentMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L2_CUSTOMER=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
	Page<CurrentMocExternalPromoView> findExternalCurrentMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_CURR_PROMO ecn  where ecn.MOC in :moc and ecn.L2_CUSTOMER=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
	List<CurrentMocExternalPromoView> findCountExternalCurrentMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region);

}
