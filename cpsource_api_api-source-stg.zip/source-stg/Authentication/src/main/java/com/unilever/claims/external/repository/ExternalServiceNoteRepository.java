package com.unilever.claims.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.NextMocView;
import com.unilever.claims.extenal.model.CpsMtFinaceView;
import com.unilever.global.GlobalVariables;

@Repository
public interface ExternalServiceNoteRepository extends PagingAndSortingRepository<CpsMtFinaceView, String>{
	
	@Transactional 
    @Query(value ="select distinct cmf.SOL_CODE from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.ACCOUNT=:account "
    		+ "and cmf.MOC=:moc and cmf.BRANCH=:branch and cmf.CATEGORY=:category and cmf.CHANNELS=:channels", nativeQuery = true)
	List<String> findSoleCode(@Param("account") String account,@Param("moc") String moc,@Param("branch") String branch,@Param("category") String category,@Param("channels") String channels);
	
	@Transactional 
    @Query(value ="select distinct cmf.STATE_CODE from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.ACCOUNT=:account "
    		+ "and cmf.MOC=:moc and cmf.BRANCH=:branch and cmf.CATEGORY=:category and cmf.CHANNELS=:channels and cmf.SOL_CODE=:solCode", nativeQuery = true)
	String findStateCode(@Param("account") String account,@Param("moc") String moc,@Param("branch") String branch,@Param("category") String category,@Param("channels") String channels,@Param("solCode") String solCode);
	
	
	@Transactional 
    @Query(value ="select sum(cmf.BUDGET_PER_STORE)  from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.ACCOUNT=:account and "
    		+ "cmf.MOC=:moc and cmf.BRANCH=:branch and cmf.CATEGORY=:category and cmf.CHANNELS=:channels and cmf.SOL_CODE=:solCode", nativeQuery = true)
	 Double findTotalAmountPayableBySoleCode(@Param("account") String account,@Param("moc") String moc,@Param("branch") String branch,
													@Param("category") String category,@Param("channels") String channels,@Param("solCode") String solCode);
	
//====================================================B2C view===============================================================================
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc  and cmf.CHANNELS=:channels  group by cmf.ACCOUNT , cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByMocAndChannel(@Param("moc") List<String> moc,@Param("channels") String channels, Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region  and cmf.CHANNELS=:channels  group by cmf.ACCOUNT , cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByMocRegionAndChannel(@Param("moc") List<String> moc,@Param("channels") String channels,@Param("region") List<String> region, Pageable pageable);
	

	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.CATEGORY in :category  and cmf.CHANNELS=:channels  group by cmf.ACCOUNT , cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByMocCategoryAndChannel(@Param("moc") List<String> moc,@Param("channels") String channels,@Param("category") List<String> category, Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.CATEGORY in :category  and cmf.CHANNELS=:channels  group by cmf.ACCOUNT , cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByMocRegionCategoryChannel(@Param("moc") List<String> moc,@Param("channels") String channels,@Param("region") List<String> region,@Param("category") List<String> category, Pageable pageable);
	
	//================================================Start Count row b2c View====================================================
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc  and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByMocAndChannel(@Param("moc") List<String> moc,@Param("channels") String channels);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region  and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByMocRegionAndChannel(@Param("moc") List<String> moc,@Param("channels") String channels,@Param("region") List<String> region);
	

	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.CATEGORY in :category  and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByMocCategoryAndChannel(@Param("moc") List<String> moc,@Param("channels") String channels,@Param("category") List<String> category);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.CATEGORY in :category  and cmf.CHANNELS=:channels group by  ACCOUNT, MOC, CATEGORY, REGION , SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByMocRegionCategoryChannel(@Param("moc") List<String> moc,@Param("channels") String channels,@Param("region") List<String> region,@Param("category") List<String> category);
	
	
	
	
	//================================================Start External View====================================================
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByExternalMocAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("channels") String channels, Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByExternalMocRegionAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,@Param("channels") String channels, Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.CATEGORY in :category  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByExternalMocCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("channels") String channels, Pageable pageable);
	
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.CATEGORY in :category  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByExternalMocRegionCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,@Param("category") List<String> category,@Param("channels") String channels, Pageable pageable);
	
	
	//============================================Count row external view===============================================
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByExternalMocAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("channels") String channels);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByExternalMocRegionAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,@Param("channels") String channels);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.CATEGORY in :category  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByExternalMocCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("channels") String channels);
	
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.CATEGORY in :category  and cmf.ACCOUNT=:account and cmf.CHANNELS=:channels group by  ACCOUNT, MOC, CATEGORY, REGION , SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByExternalMocRegionCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,@Param("category") List<String> category,@Param("channels") String channels);
	
	
	//=======================================================Kam View===============================================================
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.ACCOUNT in :account and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByKamMocAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("channels") String channels, Pageable pageable);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.ACCOUNT in :account and cmf.CATEGORY in :category  and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByKamMocCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,@Param("channels") String channels, Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.ACCOUNT in :account  and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByKamMocRegionAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("channels") String channels, Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.CATEGORY in :category  and cmf.ACCOUNT in :account and cmf.CHANNELS=:channels  group by cmf.ACCOUNT, cmf.MOC , cmf.CATEGORY , cmf.REGION , cmf.SOL_CODE ,cmf.STATE,cmf.CHANNELS", nativeQuery = true)
	Page<CpsMtFinaceView> findByKamMocRegionCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,@Param("channels") String channels, Pageable pageable);
	
//=============================================Count row kam view===============================================	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.ACCOUNT in :account and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByKamMocAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("channels") String channels);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.ACCOUNT in :account and cmf.CATEGORY in :category  and cmf.CHANNELS=:channels  group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByKamMocCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,@Param("channels") String channels);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.ACCOUNT in :account  and cmf.CHANNELS=:channels group by  SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByKamMocRegionAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("channels") String channels);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf where "
    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.CATEGORY in :category  and cmf.ACCOUNT in :account and cmf.CHANNELS=:channels group by  ACCOUNT, MOC, CATEGORY, REGION , SOL_CODE ,STATE, CHANNELS", nativeQuery = true)
	List<CpsMtFinaceView> findCountByKamMocRegionCategoryAccountChannel(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,@Param("channels") String channels);
	
	
	
	
	
//==================================================================================================================	
	@Transactional 
    @Query(value ="select sum(cmf.BUDGET_PER_STORE)  from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.SOL_CODE=:solCode and cmf.STATE=:state and cmf.CHANNELS=:channels", nativeQuery = true)
	Double findB2CTotalAmountPayableBySoleCodeAndState(@Param("solCode") String solCode,@Param("state") String state,@Param("channels") String channels);
	

	@Transactional 
    @Query(value ="select distinct cmf.STATE_CODE from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.SOL_CODE=:solCode", nativeQuery = true)
	String findB2CStateCode(@Param("solCode") String solCode);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.MOC in :moc and cmf.BRANCH in :branch and cmf.CHANNELS=:channels", nativeQuery = true)
	List<CpsMtFinaceView> findByMocAndRegion(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("channels") String channels);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.MOC in :moc and cmf.CATEGORY in :category and cmf.CHANNELS=:channels", nativeQuery = true)
	List<CpsMtFinaceView> findByMocAndCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,@Param("channels") String channels);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.MOC in :moc and cmf.BRANCH in :branch and cmf.CATEGORY in :category and cmf.CHANNELS=:channels", nativeQuery = true)
	List<CpsMtFinaceView> findByMocRegionCategory(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,@Param("channels") String channels);
	

	@Transactional
    @Query(value ="select *  from "+GlobalVariables.schemaName+".vw_CPS_MT_FINANCE cmf  where cmf.STATE=:state and cmf.SOL_CODE=:solcode and cmf.CHANNELS=:channels group by SOL_CODE,STATE", nativeQuery = true)
	CpsMtFinaceView findRegionCategoryBySolcodeAndState(@Param("state") String state,@Param("solcode") String solcode,@Param("channels") String channels);
	





}
