package com.unilever.asset.kam.model;

public class NextMocJson {
	
	private Double storeListTotalCount;
	private Double storeListTotalValue;
	private Double plannedAssetValue;
	private Integer plannedAssetVolume;
	private Double depotConnetedAssetValue;
	private Integer depotConnetedAssetVolume;
	
	
	public NextMocJson() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Double getStoreListTotalCount() {
		return storeListTotalCount;
	}
	public void setStoreListTotalCount(Double storeListTotalCount) {
		this.storeListTotalCount = storeListTotalCount;
	}
	public Double getStoreListTotalValue() {
		return storeListTotalValue;
	}
	public void setStoreListTotalValue(Double storeListTotalValue) {
		this.storeListTotalValue = storeListTotalValue;
	}
	public Double getPlannedAssetValue() {
		return plannedAssetValue;
	}
	public void setPlannedAssetValue(Double plannedAssetValue) {
		this.plannedAssetValue = plannedAssetValue;
	}

	public Double getDepotConnetedAssetValue() {
		return depotConnetedAssetValue;
	}
	public void setDepotConnetedAssetValue(Double depotConnetedAssetValue) {
		this.depotConnetedAssetValue = depotConnetedAssetValue;
	}
	public Integer getPlannedAssetVolume() {
		return plannedAssetVolume;
	}
	public void setPlannedAssetVolume(Integer plannedAssetVolume) {
		this.plannedAssetVolume = plannedAssetVolume;
	}
	public Integer getDepotConnetedAssetVolume() {
		return depotConnetedAssetVolume;
	}
	public void setDepotConnetedAssetVolume(Integer depotConnetedAssetVolume) {
		this.depotConnetedAssetVolume = depotConnetedAssetVolume;
	}
	
}
