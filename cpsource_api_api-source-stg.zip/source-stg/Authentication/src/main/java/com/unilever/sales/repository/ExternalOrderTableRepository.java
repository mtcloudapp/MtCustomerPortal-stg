package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.ExternalOrderTable;

@Repository
public interface ExternalOrderTableRepository extends JpaRepository<ExternalOrderTable, Integer>{
	
	@Transactional
    @Query(value ="select distinct tac.PO_NUMBER from "+GlobalVariables.schemaName+".EXT_ORDER_TABLE tac where tac.USERNAME=:username "
    		+ "and tac.MOC in :moc and tac.BRANCH in :branch and tac.CATEGORY in :category", nativeQuery = true)
	List<String> findPONumByExternal(@Param("username") String username,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category);
    
	@Transactional
    @Query(value ="select distinct tac.STATUS from "+GlobalVariables.schemaName+".EXT_ORDER_TABLE tac where tac.PO_NUMBER in :poNumber", nativeQuery = true)
	List<String> findExternalStatusByPONumber(@Param("poNumber") List<String> poNumber);
	
	@Transactional
    @Query(value ="select distinct tac.STATUS from "+GlobalVariables.schemaName+".EXT_ORDER_TABLE tac", nativeQuery = true)
	List<String> findExternalStatusByPONumber();

}
