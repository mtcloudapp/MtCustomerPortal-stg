package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.global.GlobalVariables;

public interface NotCompliedAssetVolumeRepository extends JpaRepository<NotCompliedAssetVolume, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolume(@Param("username") String username);

	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);


	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeDetails();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where  tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VOLUME tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<NotCompliedAssetVolume> findAllNotCompliedAssetVolumeByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		







}
