package com.unilever.promo.async.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.unilever.asset.external.service.ExternalAssetService;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.promo.kam.model.KamNoOfPromotion;
import com.unilever.promo.kam.model.KamSolCodeReleased;
import com.unilever.promo.kam.model.KamTotalPlannedBudget;
import com.unilever.promo.kam.model.KamTotalPlannedPromVolume;
import com.unilever.promo.kam.model.KamTotalPlannedPromoValue;
import com.unilever.promo.kam.model.KamTotalUtilizedValue;
import com.unilever.promo.kam.model.KamTotalUtilizedVolume;
import com.unilever.promo.kam.model.KamUtilizedBudget;
import com.unilever.promo.kam.service.KamPromoService;

@Service
public class KamPromoAsyncService {
	
	private static Logger log = LoggerFactory.getLogger(KamPromoAsyncService.class);
	
	@Autowired
	KamPromoService kamPromoService;
	

	@Async("asyncExecutor")
	public CompletableFuture<Integer> getNoOfPromotion(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Integer noOfPromotions = 0;	      

		try{

			noOfPromotions = kamPromoService.getNoOfPromotion(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(noOfPromotions);
	}

	@Async("asyncExecutor")
	public CompletableFuture<Integer> getSolCodeRealeased(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

//		KamSolCodeReleased totalAssetValueData = new KamSolCodeReleased();	
		Integer solCodeReleased = 0;

		try{
			solCodeReleased = kamPromoService.getSolCodeReleased(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(solCodeReleased);
	}

	@Async("asyncExecutor")
	public CompletableFuture<KamTotalPlannedBudget> getTotalPlannedBudget(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		KamTotalPlannedBudget totalAssetValueData = new KamTotalPlannedBudget();	      

		try{
			
			totalAssetValueData = kamPromoService.getTotalPlannedBudget(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	@Async("asyncExecutor")
	public CompletableFuture<KamTotalPlannedPromoValue> getTotalPlannedPromoValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		KamTotalPlannedPromoValue totalAssetValueData = new KamTotalPlannedPromoValue();	      

		try{
			totalAssetValueData = kamPromoService.getTotalPlannedPromoValue(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	
	@Async("asyncExecutor")
	public CompletableFuture<KamTotalPlannedPromVolume> getTotalPlannedPromoVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		KamTotalPlannedPromVolume totalAssetValueData = new KamTotalPlannedPromVolume();	      

		try{
			totalAssetValueData = kamPromoService.getTotalPlannedPromoVolume(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<KamTotalUtilizedValue> getTotalUtilizedValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		KamTotalUtilizedValue totalAssetValueData = new KamTotalUtilizedValue();	      

		try{

			totalAssetValueData = kamPromoService.getTotalUtilizedValue(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	
	@Async("asyncExecutor")
	public CompletableFuture<KamTotalUtilizedVolume> getTotalUtilizedVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		KamTotalUtilizedVolume totalAssetValueData = new KamTotalUtilizedVolume();	      

		try{
			
			totalAssetValueData = kamPromoService.getTotalUtilizedVolume(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<KamUtilizedBudget> getUtilizedBudget(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		KamUtilizedBudget totalAssetValueData = new KamUtilizedBudget();	      

		try{
			totalAssetValueData = kamPromoService.getUtilizedBudget(username, region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	
	
	

}
