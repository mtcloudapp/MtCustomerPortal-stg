package com.unilever.claims.kam.model;

public class AssetClaimsJsonObj {
	
	private Double totalAmountPlanned;
	private Double greenClaimValue;
	private Double greenClaimVolume;
	private Double approvedExceptnClaimValue;
	private Double approvedExceptnClaimVolume;
	private Double redClaimValue;
	private Double redClaimVolume;
	private Double totalAmountPayable;
	private Double totalAmountPaid;
	private Double totalAmountPending;
	private Double totalClaimsRaised;
	
	public AssetClaimsJsonObj() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Double getTotalAmountPlanned() {
		return totalAmountPlanned;
	}

	public void setTotalAmountPlanned(Double totalAmountPlanned) {
		this.totalAmountPlanned = totalAmountPlanned;
	}

	public Double getGreenClaimValue() {
		return greenClaimValue;
	}

	public void setGreenClaimValue(Double greenClaimValue) {
		this.greenClaimValue = greenClaimValue;
	}

	public Double getGreenClaimVolume() {
		return greenClaimVolume;
	}

	public void setGreenClaimVolume(Double greenClaimVolume) {
		this.greenClaimVolume = greenClaimVolume;
	}

	public Double getApprovedExceptnClaimValue() {
		return approvedExceptnClaimValue;
	}

	public void setApprovedExceptnClaimValue(Double approvedExceptnClaimValue) {
		this.approvedExceptnClaimValue = approvedExceptnClaimValue;
	}

	public Double getApprovedExceptnClaimVolume() {
		return approvedExceptnClaimVolume;
	}

	public void setApprovedExceptnClaimVolume(Double approvedExceptnClaimVolume) {
		this.approvedExceptnClaimVolume = approvedExceptnClaimVolume;
	}

	public Double getRedClaimValue() {
		return redClaimValue;
	}

	public void setRedClaimValue(Double redClaimValue) {
		this.redClaimValue = redClaimValue;
	}

	public Double getRedClaimVolume() {
		return redClaimVolume;
	}

	public void setRedClaimVolume(Double redClaimVolume) {
		this.redClaimVolume = redClaimVolume;
	}

	public Double getTotalAmountPayable() {
		return totalAmountPayable;
	}

	public void setTotalAmountPayable(Double totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}

	public Double getTotalAmountPaid() {
		return totalAmountPaid;
	}

	public void setTotalAmountPaid(Double totalAmountPaid) {
		this.totalAmountPaid = totalAmountPaid;
	}

	public Double getTotalAmountPending() {
		return totalAmountPending;
	}

	public void setTotalAmountPending(Double totalAmountPending) {
		this.totalAmountPending = totalAmountPending;
	}

	public Double getTotalClaimsRaised() {
		return totalClaimsRaised;
	}

	public void setTotalClaimsRaised(Double totalClaimsRaised) {
		this.totalClaimsRaised = totalClaimsRaised;
	}
	
	

}
