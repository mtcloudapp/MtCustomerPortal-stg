package com.unilever.asset.commercialB2C.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CurrentMocCommB2CView;
import com.unilever.asset.commercialB2C.model.NextMocCommB2CView;
import com.unilever.global.GlobalVariables;

public interface NextMocCommB2CViewRepository extends PagingAndSortingRepository<NextMocCommB2CView, String>{
	
//	@Transactional
//    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
//	Page<NextMocCommB2CView> findAllNextMocViewByAccounts(@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	List<NextMocCommB2CView> findAllNextMocViewByAccounts(@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm  where icm.REGION like '%:region%' and icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	Page<NextMocCommB2CView> findByRegionContaining(@Param("region") List<String> region,@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm where icm.MOC in :moc", nativeQuery = true)
	List<NextMocCommB2CView> findCountByMoc(@Param("moc") List<String> moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocCommB2CView> findCountByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	List<NextMocCommB2CView> findCountByAccount(@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocCommB2CView> findCountByAccountMocCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	List<NextMocCommB2CView> findCountByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	List<NextMocCommB2CView> findCountByAccountMocRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocCommB2CView> findAllCountNextMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	
//	@Transactional
//    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
//	List<NextMocView> findAllCountNextMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account  and icm.CATEGORY in :category", nativeQuery = true)
	List<NextMocCommB2CView> findAllCountNextMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
		
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_MOC_B2C icm", nativeQuery = true)
	List<NextMocCommB2CView> findAllNextMocViewDetails();
	
}
