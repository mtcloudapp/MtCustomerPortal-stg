package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DROPPED_PO")
public class PoDroppedB2c implements Serializable {
	
private static final long serialVersionUID = 3064910868034743996L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="BRANCH")
	private String Branch;
	
	@Column(name="CATEGORY")
	private String Category;
	
	@Column(name="ACCOUNT")
	private String Account;
	
	@Column(name="MOC")
	private String Moc;

	@Column(name="PO_NUMBER")
	private String PoNumber;
	
	@Column(name="CIC_NUMBER")
	private String Cic;

	public PoDroppedB2c() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PoDroppedB2c(Integer rECORD_ID, String branch, String category, String account, String moc, String poNumber,
			String cic) {
		super();
		RECORD_ID = rECORD_ID;
		Branch = branch;
		Category = category;
		Account = account;
		Moc = moc;
		PoNumber = poNumber;
		Cic = cic;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getBranch() {
		return Branch;
	}

	public void setBranch(String branch) {
		Branch = branch;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getAccount() {
		return Account;
	}

	public void setAccount(String account) {
		Account = account;
	}

	public String getMoc() {
		return Moc;
	}

	public void setMoc(String moc) {
		Moc = moc;
	}

	public String getPoNumber() {
		return PoNumber;
	}

	public void setPoNumber(String poNumber) {
		PoNumber = poNumber;
	}

	public String getCic() {
		return Cic;
	}

	public void setCic(String cic) {
		Cic = cic;
	}

	
}
