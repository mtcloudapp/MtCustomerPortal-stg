package com.unilever.promo.claim.view.model;

import java.io.Serializable;

public class DeductionBucketDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -3760783080823657676L;
	
	private Integer solCode;

	private Integer basepack;

	private Integer articleCode;
	
	//private Integer solCodeRevised;
	private String solCodeRevised;  //Commented above line and Added By Sarin Jun2021
	
	private Integer basepackRevised;

	private Double hulMRP;
	
	private Double customerMRP;
	
    private Double customerClaimMinQty;
	
	private Double netClaimValue;
	
	private Double deductionAmt;
	
	private Integer totalRecords;

	public DeductionBucketDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}

	public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public Double getHulMRP() {
		return hulMRP;
	}

	public void setHulMRP(Double hulMRP) {
		this.hulMRP = hulMRP;
	}

	public Double getCustomerMRP() {
		return customerMRP;
	}

	public void setCustomerMRP(Double customerMRP) {
		this.customerMRP = customerMRP;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	public String getSolCodeRevised() {
		return solCodeRevised;
	}

	public void setSolCodeRevised(String solCodeRevised) {
		this.solCodeRevised = solCodeRevised;
	}

	public Integer getBasepackRevised() {
		return basepackRevised;
	}

	public void setBasepackRevised(Integer basepackRevised) {
		this.basepackRevised = basepackRevised;
	}

	public Double getCustomerClaimMinQty() {
		return customerClaimMinQty;
	}

	public void setCustomerClaimMinQty(Double customerClaimMinQty) {
		this.customerClaimMinQty = customerClaimMinQty;
	}

	public Double getNetClaimValue() {
		return netClaimValue;
	}

	public void setNetClaimValue(Double netClaimValue) {
		this.netClaimValue = netClaimValue;
	}

	public Double getDeductionAmt() {
		return deductionAmt;
	}

	public void setDeductionAmt(Double deductionAmt) {
		this.deductionAmt = deductionAmt;
	}
	
	
	
	
	

}
