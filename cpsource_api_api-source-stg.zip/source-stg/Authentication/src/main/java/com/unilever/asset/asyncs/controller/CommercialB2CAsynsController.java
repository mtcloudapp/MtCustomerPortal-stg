package com.unilever.asset.asyncs.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.asset.asyncs.service.AsyncService;
import com.unilever.asset.commercialB2C.model.CommB2CCompliedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CCompliedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDeployedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CDeployedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValueNext;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetVolumeNext;
import com.unilever.asset.commercialB2C.model.CommB2CNotCompliedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CNotCompliedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalCount;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalValue;
import com.unilever.asset.commercialB2C.model.CommB2CTotalaAssetCreatedValue;
import com.unilever.asset.commercialB2C.model.CommB2CTotalaAssetCreatedVolume;
import com.unilever.asset.commercialB2C.model.JsonObjCommB2C;
import com.unilever.asset.commercialB2C.model.NextMocJsonCommB2C;
import com.unilever.asset.kam.model.CompliedAssetValue;
import com.unilever.asset.kam.model.CompliedAssetVolume;
import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.JsonObject;
import com.unilever.asset.kam.model.NextMocJson;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetVolume;
import com.unilever.asset.kam.model.PreviousMocView;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.service.KamAssetService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CommercialB2CAsynsController {
	
	private static Logger log = LoggerFactory.getLogger(KamAsyncController.class);

	@Autowired
	private AsyncService service;
	
	@Autowired
	KamAssetService kamAssetService;
	

	@GetMapping("/getCurrentMOCCommercialAssetsData")
	public String getCurrentMOCCommercialAssetsData(@RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		
       try{
    	   
    	CompletableFuture<CommB2CTotalaAssetCreatedValue> totalAssetValues = service.getCommercialAndB2cTotalAssetValue(region, account, moc, category);
   		CompletableFuture<CommB2CTotalaAssetCreatedVolume> totalAssetVolumes = service.getCommercialB2CTotalAssetCreatedVolume(region, account, moc, category);
   		CompletableFuture<CommB2CDepotConnectedAssetValue> totalDepotAssetValues = service.getAllCommercialB2CDepotConnectedAssetValue(region, account, moc, category);
   		CompletableFuture<CommB2CDepotConnectedAssetVolume> totalDepotAssetVolumes = service.getAllCommercialB2CDepotConnectedAssetVolume(region, account, moc, category);
   		CompletableFuture<CommB2CDeployedAssetValue> totalDeployedAssetValues = service.getAllCommercialB2CDeployedAssetValue(region, account, moc, category);
   		CompletableFuture<CommB2CDeployedAssetVolume> totalDeployedAssetVolumes = service.getAllCommercialB2CDeployedAssetVolume(region, account, moc, category);
   		CompletableFuture<CommB2CCompliedAssetValue> totalCompliedAssetValues = service.getAllCommercialB2CCompliedAssetValue(region, account, moc, category);
   		CompletableFuture<CommB2CCompliedAssetVolume> totalCompliedAssetVolumes = service.getAllCommercialB2CCompliedAssetVolume(region, account, moc, category);
   		CompletableFuture<CommB2CNotCompliedAssetValue> totalNotCompliedAssetValues = service.getAllCommercialB2CNotCompliedAssetValue(region, account, moc, category);
   		CompletableFuture<CommB2CNotCompliedAssetVolume> totalNotCompliedAssetVolumes = service.getAllCommercialB2CNotCompliedAssetVolume(region, account, moc, category);

		// Wait until they are all done
		CompletableFuture.allOf(totalAssetValues, totalAssetVolumes, totalDepotAssetValues, totalDepotAssetVolumes,totalDeployedAssetValues,totalDeployedAssetVolumes,totalCompliedAssetValues,totalCompliedAssetVolumes,totalNotCompliedAssetValues,totalNotCompliedAssetVolumes).join();

		log.info("TotalAssetValues--> " + totalAssetValues.get());
		log.info("totalAssetVolumes--> " + totalAssetVolumes.get());
		log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
		log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
		log.info("totalDeployedAssetValues--> " + totalDeployedAssetValues.get());
		log.info("totalDeployedAssetVolumes--> " + totalDeployedAssetVolumes.get());
		log.info("totalCompliedAssetValues--> " + totalCompliedAssetValues.get());
		log.info("totalCompliedAssetVolumes--> " + totalCompliedAssetVolumes.get());
		log.info("totalNotCompliedAssetValues--> " + totalNotCompliedAssetValues.get());
		log.info("totalNotCompliedAssetVolumes--> " + totalNotCompliedAssetVolumes.get());

		JsonObjCommB2C obj = new JsonObjCommB2C();
		Gson gson = new Gson();

		obj.setTotalAssetValue(totalAssetValues.get().getTotalAssetCreatedValue());
		obj.setTotalAssetVolume(totalAssetVolumes.get().getTotalCompliedAssetVolume());
		obj.setDepotConnectedAssetValue(totalDepotAssetValues.get().getDepotConnectedAssetValue());
		obj.setDepotConnectedAssetVolume(totalDepotAssetVolumes.get().getDepotConnectedAssetsVolume());
		obj.setDeployedAssetValue(totalDeployedAssetValues.get().getDeployedAssetValue());
		obj.setDeployedAssetVolume(totalDeployedAssetVolumes.get().getDeployedAssetVolume());
		obj.setComplieddAssetValue(totalCompliedAssetValues.get().getTotalCompliedAssetValue());
		obj.setCompliedAssetVolume(totalCompliedAssetVolumes.get().getTotalCompliedAssetVolume());
		obj.setNotComplieddAssetValue(totalNotCompliedAssetValues.get().getNotCompliedAssetValue());
		obj.setNotCompliedAssetVolume(totalNotCompliedAssetVolumes.get().getNotCompliedAssetVolume());
		
		json = gson.toJson(obj); 
       }
       catch(Exception e){
    	   e.printStackTrace();
       }

		return json;
	}
	
	@GetMapping("/getPreviousMOCCommercialAssetsData")
	public String getPreviousMOCCommercialAssetsData( @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		
       try{
    	   
    	    CompletableFuture<CommB2CTotalaAssetCreatedValue> totalAssetValues = service.getCommercialAndB2cTotalAssetValue(region, account, moc, category);
      		CompletableFuture<CommB2CTotalaAssetCreatedVolume> totalAssetVolumes = service.getCommercialB2CTotalAssetCreatedVolume(region, account, moc, category);
      		CompletableFuture<CommB2CDepotConnectedAssetValue> totalDepotAssetValues = service.getAllCommercialB2CDepotConnectedAssetValue(region, account, moc, category);
      		CompletableFuture<CommB2CDepotConnectedAssetVolume> totalDepotAssetVolumes = service.getAllCommercialB2CDepotConnectedAssetVolume(region, account, moc, category);
      		CompletableFuture<CommB2CDeployedAssetValue> totalDeployedAssetValues = service.getAllCommercialB2CDeployedAssetValue(region, account, moc, category);
      		CompletableFuture<CommB2CDeployedAssetVolume> totalDeployedAssetVolumes = service.getAllCommercialB2CDeployedAssetVolume(region, account, moc, category);
      		CompletableFuture<CommB2CCompliedAssetValue> totalCompliedAssetValues = service.getAllCommercialB2CCompliedAssetValue(region, account, moc, category);
      		CompletableFuture<CommB2CCompliedAssetVolume> totalCompliedAssetVolumes = service.getAllCommercialB2CCompliedAssetVolume(region, account, moc, category);
      		CompletableFuture<CommB2CNotCompliedAssetValue> totalNotCompliedAssetValues = service.getAllCommercialB2CNotCompliedAssetValue(region, account, moc, category);
      		CompletableFuture<CommB2CNotCompliedAssetVolume> totalNotCompliedAssetVolumes = service.getAllCommercialB2CNotCompliedAssetVolume(region, account, moc, category);
 
		// Wait until they are all done
		CompletableFuture.allOf(totalAssetValues, totalAssetVolumes, totalDepotAssetValues, totalDepotAssetVolumes,totalDeployedAssetValues,totalDeployedAssetVolumes,totalCompliedAssetValues,totalCompliedAssetVolumes,totalNotCompliedAssetValues,totalNotCompliedAssetVolumes).join();

		log.info("TotalAssetValues--> " + totalAssetValues.get());
		log.info("totalAssetVolumes--> " + totalAssetVolumes.get());
		log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
		log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
		log.info("totalDeployedAssetValues--> " + totalDeployedAssetValues.get());
		log.info("totalDeployedAssetVolumes--> " + totalDeployedAssetVolumes.get());
		log.info("totalCompliedAssetValues--> " + totalCompliedAssetValues.get());
		log.info("totalCompliedAssetVolumes--> " + totalCompliedAssetVolumes.get());
		log.info("totalNotCompliedAssetValues--> " + totalNotCompliedAssetValues.get());
		log.info("totalNotCompliedAssetVolumes--> " + totalNotCompliedAssetVolumes.get());

		JsonObjCommB2C obj = new JsonObjCommB2C();
		Gson gson = new Gson();

		obj.setTotalAssetValue(totalAssetValues.get().getTotalAssetCreatedValue());
		obj.setTotalAssetVolume(totalAssetVolumes.get().getTotalCompliedAssetVolume());
		obj.setDepotConnectedAssetValue(totalDepotAssetValues.get().getDepotConnectedAssetValue());
		obj.setDepotConnectedAssetVolume(totalDepotAssetVolumes.get().getDepotConnectedAssetsVolume());
		obj.setDeployedAssetValue(totalDeployedAssetValues.get().getDeployedAssetValue());
		obj.setDeployedAssetVolume(totalDeployedAssetVolumes.get().getDeployedAssetVolume());
		obj.setComplieddAssetValue(totalCompliedAssetValues.get().getTotalCompliedAssetValue());
		obj.setCompliedAssetVolume(totalCompliedAssetVolumes.get().getTotalCompliedAssetVolume());
		obj.setNotComplieddAssetValue(totalNotCompliedAssetValues.get().getNotCompliedAssetValue());
		obj.setNotCompliedAssetVolume(totalNotCompliedAssetVolumes.get().getNotCompliedAssetVolume());
		
		json = gson.toJson(obj); 
       }
       catch(Exception e){
    	   e.printStackTrace();
       }

		return json;
	}
	
	@GetMapping("/getNextMOCCommercialAssetsData")
	public String getNextMOCCommercialAssetsData(@RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		
       try{
    	 
    	CompletableFuture<CommB2CStoreListTotalCount> storeListTotalCount = service.getAllCommercialB2CStoreListTotalCount(region, account, moc, category);
   		CompletableFuture<CommB2CStoreListTotalValue> storeListTotalValue = service.getAllCommercialB2CStoreListTotalValue(region, account, moc, category);
   		CompletableFuture<CommB2CPlannedAssetValue> plannedAssetValue = service.getAllCommercialB2CPlannedAssetValue(region, account, moc, category);
   		CompletableFuture<CommB2CPlannedAssetVolume> plannedAssetVolume = service.getAllCommercialB2CPlannedAssetVolume(region, account, moc, category);
   		CompletableFuture<CommB2CDepotConnectedAssetValueNext> totalDepotAssetValues = service.getAllCommercilB2CDepotConnectedAssetValue(region, account, moc, category);
   		CompletableFuture<CommB2CDepotConnectedAssetVolumeNext> totalDepotAssetVolumes = service.getAllCCommercialB2CDepotConnectedAssetVolume(region, account, moc, category);
   		
		
		// Wait until they are all done
		CompletableFuture.allOf(storeListTotalCount, storeListTotalValue,plannedAssetValue,plannedAssetVolume,totalDepotAssetValues,totalDepotAssetVolumes).join();

		log.info("storeListTotalCount--> " + storeListTotalCount.get());
		log.info("storeListTotalValue--> " + storeListTotalValue.get());
		log.info("plannedAssetValue--> " + plannedAssetValue.get());
		log.info("plannedAssetVolume--> " + plannedAssetVolume.get());
		log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
		log.info("totalDepotAssetVolumes--> " + totalDepotAssetVolumes.get());
		
		NextMocJsonCommB2C obj = new NextMocJsonCommB2C();
		Gson gson = new Gson();

		obj.setStoreListTotalCount(storeListTotalCount.get().getStoreListTotalCount());
		obj.setStoreListTotalValue(storeListTotalValue.get().getStoreListTotalValue());
		obj.setPlannedAssetValue(plannedAssetValue.get().getPlannedAssetValue());
		obj.setPlannedAssetVolume(plannedAssetVolume.get().getPlannedAssetVolume());
		obj.setDepotConnetedAssetValue(totalDepotAssetValues.get().getDepotConnetedAssetValue());
		obj.setDepotConnetedAssetVolume(totalDepotAssetVolumes.get().getDepotConnetedAssetVolume());
		json = gson.toJson(obj); 
       }
       catch(Exception e){
    	   e.printStackTrace();
       }

		return json;
	}
	
	//////=======================================View for commercial==================================================
	
	//======================================= Current MOC View==================================================
	
		@GetMapping("/getCurrentMocCommercialView")
		public List<CurrentMocView> getCurrentMocCommercialView(@RequestParam("accounts")List<String> accounts, @RequestParam("moc") String moc){
			
			
			List<CurrentMocView> listcurrentMocViewDetails = new ArrayList<CurrentMocView>();
			try{
			  List<CurrentMocView> currentMocViewDetails = new ArrayList<CurrentMocView>();
			  List<CurrentMocView> mocviewList = new ArrayList<CurrentMocView>();
			  for(String accunt : accounts)	{
			   // currentMocViewDetails = kamAssetService.getCurrentMocView(accunt,moc);
			    mocviewList.addAll(currentMocViewDetails);
			
			  }
			
			  listcurrentMocViewDetails.addAll(mocviewList);
			
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return listcurrentMocViewDetails;
		
		}
		
		//======================================= Previous MOC View==================================================
		@GetMapping("/getPreviousMocCommercialView")
		public List<PreviousMocView> getPreviousMocCommercialView(@RequestParam("accounts")List<String> accounts,@RequestParam("moc") String moc){
			
			List<PreviousMocView> previousMocViewDetails = new ArrayList<PreviousMocView>();
			try{
				 List<PreviousMocView> previousMocDetails = new ArrayList<PreviousMocView>();
				 List<PreviousMocView> mocviewList = new ArrayList<PreviousMocView>();
				 for(String accunt : accounts)	{
			//		 previousMocDetails = kamAssetService.getPreviousMocView(accunt,moc);
				     mocviewList.addAll(previousMocDetails);
				 }
				 
				 previousMocViewDetails.addAll(mocviewList);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return previousMocViewDetails;
		
		}
		
		//======================================= Next MOC View==================================================
			@GetMapping("/getNextMocCommercialView")
			public List<NextMocView> getNextMocCommercialView(@RequestParam("accounts")List<String> accounts,@RequestParam("moc") String moc){
				
				List<NextMocView> nextMocViewDetails = new ArrayList<NextMocView>();
				try{
				     List<NextMocView> nextMocDetails = new ArrayList<NextMocView>();
					List<NextMocView> mocviewList = new ArrayList<NextMocView>();
					 for(String accunt : accounts)	{
		//				 nextMocDetails = kamAssetService.getNextMocView(accunt,moc);
						 mocviewList.addAll(nextMocDetails);
					 }
					 nextMocViewDetails.addAll(mocviewList);
				}
				catch(Exception e){
					e.printStackTrace();
				}
				return nextMocViewDetails;
			
			}


}
