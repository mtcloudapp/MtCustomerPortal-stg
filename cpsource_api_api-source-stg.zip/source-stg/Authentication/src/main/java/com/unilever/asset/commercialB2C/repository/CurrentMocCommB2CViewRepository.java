package com.unilever.asset.commercialB2C.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CurrentMocCommB2CView;
import com.unilever.asset.commercialB2C.model.PreviousMocCommB2CView;
import com.unilever.global.GlobalVariables;

@Repository
public interface CurrentMocCommB2CViewRepository extends PagingAndSortingRepository<CurrentMocCommB2CView, String> {

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.ACCOUNT in :accounts", nativeQuery = true)
	List<CurrentMocCommB2CView> findAllCurrentMocViewByAccount(@Param("accounts") List<String> accounts);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm", nativeQuery = true)
	List<CurrentMocCommB2CView> findAllCurrentMocViewDetails();
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMoc(@Param("moc") List<String> moc,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm where icm.MOC in :moc", nativeQuery = true)
	List<CurrentMocCommB2CView> findCountByMoc(@Param("moc") List<String> moc);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocCommB2CView> findCountByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	List<CurrentMocCommB2CView> findCountByAccount(@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMocAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocCommB2CView> findCountByAccountMocCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	List<CurrentMocCommB2CView> findCountByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMocAccountRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	List<CurrentMocCommB2CView> findCountByAccountMocRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocCommB2CView> findAllCountCurrentMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocCommB2CView> findAllCurrentMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC_B2C icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocCommB2CView> findAllCountCurrentMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);
}
