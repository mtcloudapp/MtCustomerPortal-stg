package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.ExtPoInvoicedValue;
import com.unilever.sales.model.PoInvoicedValue;

@Repository
public interface InvoicedValueLinesExternalRepository extends JpaRepository<ExtPoInvoicedValue, Integer> {
	
	@Transactional
    @Query(value ="select sum(etas.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_INVOICED_TOTAL_VALUE etas  where etas.USERNAME=:username and etas.BRANCH in :region and etas.MOC in :moc and etas.CATEGORY in :category", nativeQuery = true)
	Double findInvoicedValueOfPo(@Param("username") String username,@Param("region") List<String> region,@Param("moc") List<String> moc,@Param("category") List<String> category);


}
