package com.unilever.promo.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.external.model.NextMocExternalPromoView;
import com.unilever.promo.external.model.NextMocExternalPromoView;

@Repository
public interface ExternalNextMocPromoViewRepository extends PagingAndSortingRepository<NextMocExternalPromoView, String>  {
	
	//==================================================================================================================================
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account", nativeQuery = true)
	Page<NextMocExternalPromoView> findExternalNextMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account,Pageable pageable);
    
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account", nativeQuery = true)
	List<NextMocExternalPromoView> findCountExternalNextMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account);

//=======================================================================	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.CATEGORY in :category", nativeQuery = true)
	Page<NextMocExternalPromoView> findExternalNextMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.CATEGORY in :category", nativeQuery = true)
	List<NextMocExternalPromoView> findCountExternalNextMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category);

//=======================================
	
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.REGION in :region", nativeQuery = true)
	Page<NextMocExternalPromoView> findExternalNextMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L1_CUSTOMER=:account and ecn.REGION in :region", nativeQuery = true)
	List<NextMocExternalPromoView> findCountExternalNextMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region);

	
//======================================================	
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L2_CUSTOMER=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
	Page<NextMocExternalPromoView> findExternalNextMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region,Pageable pageable);


	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_PROMO ecn  where ecn.MOC in :moc and ecn.L2_CUSTOMER=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
	List<NextMocExternalPromoView> findCountExternalNextMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region);


}
