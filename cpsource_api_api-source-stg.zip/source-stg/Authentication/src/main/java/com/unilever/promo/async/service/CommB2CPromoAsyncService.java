package com.unilever.promo.async.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.unilever.promo.commb2c.model.CommB2CNoOfPromotion;
import com.unilever.promo.commb2c.model.CommB2CSolCodeReleased;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedBudget;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedPromoValue;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedPromoVolume;
import com.unilever.promo.commb2c.model.CommB2CTotalUtilizedValue;
import com.unilever.promo.commb2c.model.CommB2CTotalUtilizedVolume;
import com.unilever.promo.commb2c.model.CommB2CUtilizedBudget;
import com.unilever.promo.commb2c.service.CommB2CPromoService;


@Service
public class CommB2CPromoAsyncService {

	private static Logger log = LoggerFactory.getLogger(CommB2CPromoAsyncService.class);
	
	@Autowired
	CommB2CPromoService commB2CPromoService;
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getNoOfPromotion(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		Integer noOfPromotions = 0;
		try{
			noOfPromotions = commB2CPromoService.getNoOfPromotion(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(noOfPromotions);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Integer> getSolCodeReleased(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		Integer solCodeReleased =0;
		try{
			solCodeReleased = commB2CPromoService.getSolCodeReleased(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(solCodeReleased);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<CommB2CTotalPlannedBudget> getTotalPlannedBudget(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CTotalPlannedBudget totalAssetValueData = new CommB2CTotalPlannedBudget();
		try{
			totalAssetValueData = commB2CPromoService.getTotalPlannedBudget(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<CommB2CTotalPlannedPromoValue> getTotalPlannedPromoValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CTotalPlannedPromoValue totalAssetValueData = new CommB2CTotalPlannedPromoValue();
		try{
			totalAssetValueData = commB2CPromoService.getTotalPlannedPromoValue(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<CommB2CTotalPlannedPromoVolume> getTotalPlannedPromovolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CTotalPlannedPromoVolume totalAssetValueData = new CommB2CTotalPlannedPromoVolume();
		try{
			totalAssetValueData = commB2CPromoService.getTotalPlannedPromovolume(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<CommB2CTotalUtilizedValue> getTotalUtilizedValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CTotalUtilizedValue totalAssetValueData = new CommB2CTotalUtilizedValue();
		try{
			totalAssetValueData = commB2CPromoService.getTotalUtilizedValue(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}


	@Async("asyncExecutor")
	public CompletableFuture<CommB2CTotalUtilizedVolume> getTotalUtilizeddVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CTotalUtilizedVolume totalAssetValueData = new CommB2CTotalUtilizedVolume();
		try{
			totalAssetValueData = commB2CPromoService.getTotalUtilizeddVolume(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}


	@Async("asyncExecutor")
	public CompletableFuture<CommB2CUtilizedBudget> getUtilizedBudget(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CUtilizedBudget totalAssetValueData = new CommB2CUtilizedBudget();
		try{
			totalAssetValueData = commB2CPromoService.getUtilizedBudget(region, account, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}






}
