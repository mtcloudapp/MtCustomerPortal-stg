package com.unilever.claims.upload.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.unilever.claims.extenal.model.CpsMtFinanceDto;
import com.unilever.claims.extenal.model.ExternalServiceNoteDetails;
import com.unilever.claims.external.repository.ExternalServiceNoteDetailsRepository;
import com.unilever.claims.upload.service.ExernalServiceNoteUploadService;
import com.unilever.message.ResponseMessage;
import com.unilever.upload.service.ExcelHelper;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class ExternalServiceNoteUploadController {
	
	
	
	@Autowired
	ExernalServiceNoteUploadService serviceNoteUploadService;
	
	@Autowired
	private AmazonS3 amazonS3;
	
	@Value("${aws.s3.bucket}")
	private String bucketName;

	@Autowired
	ExternalServiceNoteDetailsRepository externalServiceNoteDetailsRepository;
	
	
	//==================================Kam View========================================================================
	
	@GetMapping("/getKamAssetClaimsView")
	public List<CpsMtFinanceDto> getExternalAssetClaimsView(@RequestParam("account") List<String> account,
			@RequestParam("moc") List<String> moc,@RequestParam("region") List<String> region,
			@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize){
		
		List<CpsMtFinanceDto> externalAssetClaimsView = new ArrayList<CpsMtFinanceDto>();
		try{
			externalAssetClaimsView = serviceNoteUploadService.getKamAssetClaimView(account, region, moc, category, pageNo, pageSize);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalAssetClaimsView;
	
	}
	
	
	
	
	//==================================Customer View========================================================================
	
	@GetMapping("/getExternalAssetClaimsView")
	public List<CpsMtFinanceDto> getExternalAssetClaimsView(@RequestParam("account") String account,
			@RequestParam("moc") List<String> moc,@RequestParam("region") List<String> region,
			@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize){
		
		List<CpsMtFinanceDto> externalAssetClaimsView = new ArrayList<CpsMtFinanceDto>();
		try{
			externalAssetClaimsView = serviceNoteUploadService.getExternalAssetClaimView(account, region, moc, category, pageNo, pageSize);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalAssetClaimsView;
	
	}
	
	@GetMapping("/getB2CAssetClaimsView")
	public List<CpsMtFinanceDto> getB2CAssetClaimsView(
			@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,
			@RequestParam("category") List<String> category,@RequestParam("account") List<String> account,
			@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize ){
		
		List<CpsMtFinanceDto> externalAssetClaimsView = new ArrayList<CpsMtFinanceDto>();
		try{
			externalAssetClaimsView = serviceNoteUploadService.getB2CAssetClaimView(region, account, moc, category, pageNo, pageSize);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalAssetClaimsView;
	
	}
	
	
	
	@GetMapping("/getCommercialView")
	public List<CpsMtFinanceDto> getCommercialView(
			@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,
			@RequestParam("category") List<String> category,@RequestParam("account") List<String> account,
			@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize ){
		
		List<CpsMtFinanceDto> externalAssetClaimsView = new ArrayList<CpsMtFinanceDto>();
		try{
			externalAssetClaimsView = serviceNoteUploadService.getB2CAssetClaimView(region, account, moc, category, pageNo, pageSize);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalAssetClaimsView;
	
	}

	
	
	@PostMapping(value= "/uploadByExternal")
	public ResponseEntity<ResponseMessage> uploadByExternal(@RequestParam("file") final MultipartFile [] multipartFiles,
			@RequestParam("invoiceNo") String invoiceNo,
			@RequestParam("baseAmt") Double baseAmt,@RequestParam("taxAmt") Double taxAmt,
			@RequestParam("solCode") String solCode,@RequestParam("state") String state,@RequestParam("moc") String moc,
			@RequestParam("payableAmt") Double payableAmt,@RequestParam("account") String account
			) throws IOException {
	   
		 ResponseMessage response = new ResponseMessage();
		
		try{
			 List<String> fileNames = new ArrayList<String>();
			 Integer count = 1;
			
			/* Arrays.asList(multipartFiles).stream().forEach(file -> {
				
				 serviceNoteUploadService.save(file, invoiceNo, baseAmt, taxAmt, solCode, payableAmt);
				 
			     fileNames.add(file.getOriginalFilename());
			    
			      });*/
			 for(MultipartFile file : multipartFiles){
				 String resp="";
				 if(count == 1){
				 if(file.getContentType().equals("image/jpeg") || file.getContentType().equals("image/png") || file.getContentType().equals("application/pdf")){
				     response =  serviceNoteUploadService.save(file, invoiceNo, baseAmt, taxAmt, solCode,state, payableAmt,account,moc,count,resp);
				 }else{
					 response.setMessage("Sorry! You can upload only jpeg,png and pdf");
					 return new ResponseEntity<ResponseMessage>(response, HttpStatus.OK);
				  }
				 }
				 		
				 if(count>1 && response.getMessage().equals("Success")){
				    if(file.getContentType().equals("image/jpeg") || file.getContentType().equals("image/png") || file.getContentType().equals("application/pdf")){
					 response =  serviceNoteUploadService.save(file, invoiceNo, baseAmt, taxAmt, solCode,state, payableAmt,account,moc,count,response.getMessage());
				    }else{
				    	response.setMessage("Sorry! You can upload only jpeg,png and pdf");
						 return new ResponseEntity<ResponseMessage>(response, HttpStatus.OK);
				    }
				   }
				
				
				 fileNames.add(file.getOriginalFilename());
				 count++;
			 }
			 
			 
			 if(response.getMessage().equals("Success")){
			    response.setMessage("[" + fileNames + "] uploaded successfully.");
			 }
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	
	@GetMapping("/getLastUplodadedFileDetails")
	public ResponseEntity<ResponseMessage> getLastUplodadedFileDetails(@RequestParam("solcode") String solcode,@RequestParam("state") String state){
		ResponseMessage responseMessage = new ResponseMessage();
		
		try{
			ExternalServiceNoteDetails externalServiceNoteDetails = new ExternalServiceNoteDetails();
			externalServiceNoteDetails = serviceNoteUploadService.getLastFileDetails(solcode,state);
		   
			if(externalServiceNoteDetails != null){
				responseMessage.setMessage("Invoice No: "+externalServiceNoteDetails.getInvoiceNo()+", " +"File Name: "+externalServiceNoteDetails.getFileName()+" ,"+"Last Uploded Time: "+externalServiceNoteDetails.getUploadTime());
			}else{
				responseMessage.setMessage("Sorry!! There is no file");
			}
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseMessage, HttpStatus.OK);
	}
	
	
	
	
	@PostMapping("/uploadByB2C")
	public ResponseEntity<ResponseMessage> uploadByB2C(@RequestParam("file") MultipartFile file) {
		String message = "";
		//  int userID = userId;
		
		ResponseMessage response = new ResponseMessage();
		if (ExcelHelper.hasExcelFormat(file)) {
			try {
			     response = serviceNoteUploadService.uploadByB2C(file);
				

				if(response.getMessage().equals("Success")){
					message = "Uploaded the file successfully: " + file.getOriginalFilename();

				}else{
					message = response.getMessage();
				}

				return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not upload the file: " + file.getOriginalFilename() + "!";
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
			}
		}

		message = "Please upload an excel file!";
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));
	}

	
	 @GetMapping(value = "/downloadByB2C", produces="application/zip")
	 public void downloadByB2C(@RequestParam String solCode,@RequestParam String state, HttpServletResponse response) throws IOException {
	  try{ 
	   Set<String> fileNames = new HashSet<String>();
	   Set<String> fileNameList = new HashSet<String>();
	 
	   fileNames = externalServiceNoteDetailsRepository.findFilesBySoleCodeAndState(solCode,state);
	   
	   for(String fileName : fileNames){
		   String file = null;
		   file = solCode+"_"+fileName;
		   fileNameList.add(file);
	   }
	   zipDownload(fileNameList,response);
	  }
	  catch(Exception e){
		  e.printStackTrace();
	  }
	 }
	
	
	
	 public void zipDownload(@RequestParam Set<String> name, HttpServletResponse response) throws IOException {
	 	ZipOutputStream zipOut = new ZipOutputStream(response.getOutputStream());
	 	String zipFileName ="abc.zip";
	 	 byte bytes[] = new byte[4096];
	    
	 try{
	 	 
	    for (String fileName : name) {
	 		// S3Object s3object = amazonS3.getObject(bucketName, fileName);
	 		ZipEntry zipEntry = new ZipEntry(fileName);
	 		zipOut.putNextEntry(zipEntry);
	 		 InputStream in = serviceNoteUploadService.downloadFileAsStream(bucketName, fileName);
	            int bytesRead = -1;

	            while ((bytesRead = in.read(bytes)) != -1) {
	            	zipOut.write(bytes, 0, bytesRead);
	            }
	           
	 	}
	 }catch(Exception e){
		 e.printStackTrace();
	 }finally{
		 zipOut.closeEntry();
         zipOut.finish();
         zipOut.close();
	 }
	 	
	 	response.setStatus(HttpServletResponse.SC_OK);
	 	response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + zipFileName + "\"");
	 }
 

	 @GetMapping("/downloadClaimHistoryByB2C")
		public ResponseEntity<Resource> downloadClaimHistoryByB2C(@RequestParam("solcode") String solcode,@RequestParam("state") String state) {
			String filename = "claim_history";
			InputStreamResource file = new InputStreamResource(serviceNoteUploadService.getClaimHistory(solcode,state));

			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
					.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
					.body(file);
		}


}
