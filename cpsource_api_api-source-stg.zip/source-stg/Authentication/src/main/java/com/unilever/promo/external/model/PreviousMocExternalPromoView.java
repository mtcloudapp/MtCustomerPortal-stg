package com.unilever.promo.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.unilever.global.GlobalVariables;

@Entity
@Table(name="vw_EXT_NEXT_PROMO", schema=GlobalVariables.schemaName)
public class PreviousMocExternalPromoView implements Serializable {
	
	private static final long serialVersionUID = -5922087877145840252L;
	
	@Id
	private String id;
	
	@Column(name="SOL_CODE")
	private Integer sol_code;
	
	@Column(name="PROMO_DESCRIPTION")
	private String promo_description;
	
	@Column(name="L1_CUSTOMER")
	private String l1_customer;
	
	@Column(name="L2_CUSTOMER")
	private String l2_customer;
	
	@Column(name="ARTICLE_CODE")
	private String article_code;
	
	@Column(name="CATEGORY")
	private String category;
	
	@Column(name="BRAND")
	private String brand;
	
	@Column(name="REGION")
	private String region;
	
	@Column(name="TOTAL_PLANNED_VOLUME")
	private Integer total_planned_volume;
	
	@Column(name="UTILIZED_VOLUME")
	private Double utilized_volume;
	
	@Column(name="MOC")
	private String moc;

	public PreviousMocExternalPromoView() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public PreviousMocExternalPromoView(String id, Integer sol_code, String promo_description, String l1_customer,
			String l2_customer, String article_code, String category, String brand, String region,
			Integer total_planned_volume, Double utilized_volume, String moc) {
		super();
		this.id = id;
		this.sol_code = sol_code;
		this.promo_description = promo_description;
		this.l1_customer = l1_customer;
		this.l2_customer = l2_customer;
		this.article_code = article_code;
		this.category = category;
		this.brand = brand;
		this.region = region;
		this.total_planned_volume = total_planned_volume;
		this.utilized_volume = utilized_volume;
		this.moc = moc;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public Integer getSol_code() {
		return sol_code;
	}



	public void setSol_code(Integer sol_code) {
		this.sol_code = sol_code;
	}



	public String getPromo_description() {
		return promo_description;
	}



	public void setPromo_description(String promo_description) {
		this.promo_description = promo_description;
	}



	public String getL1_customer() {
		return l1_customer;
	}



	public void setL1_customer(String l1_customer) {
		this.l1_customer = l1_customer;
	}



	public String getL2_customer() {
		return l2_customer;
	}



	public void setL2_customer(String l2_customer) {
		this.l2_customer = l2_customer;
	}



	



	public String getArticle_code() {
		return article_code;
	}



	public void setArticle_code(String article_code) {
		this.article_code = article_code;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public String getBrand() {
		return brand;
	}



	public void setBrand(String brand) {
		this.brand = brand;
	}



	public String getRegion() {
		return region;
	}



	public void setRegion(String region) {
		this.region = region;
	}



	public Integer getTotal_planned_volume() {
		return total_planned_volume;
	}



	public void setTotal_planned_volume(Integer total_planned_volume) {
		this.total_planned_volume = total_planned_volume;
	}



	public Double getUtilized_volume() {
		return utilized_volume;
	}



	public void setUtilized_volume(Double utilized_volume) {
		this.utilized_volume = utilized_volume;
	}



	public String getMoc() {
		return moc;
	}



	public void setMoc(String moc) {
		this.moc = moc;
	}



	
	
	
	

}
