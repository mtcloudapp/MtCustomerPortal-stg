package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.global.GlobalVariables;

public interface DeployedAssetVolumeRepository extends JpaRepository<DepolyedAssetVolume, Integer> {
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDeployedAssetVolume(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);


	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeDetails();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where  tac.MOC=:moc", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VOLUME tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<DepolyedAssetVolume> findAllDepolyedAssetVolumeByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		











}
