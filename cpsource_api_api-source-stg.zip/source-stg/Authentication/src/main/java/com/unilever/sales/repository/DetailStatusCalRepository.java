package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.sales.model.DetailStatusCal;

public interface DetailStatusCalRepository extends JpaRepository<DetailStatusCal, Integer>{

	@Transactional
	//@Procedure(procedureName = "sp_detailed_status_cal")
	@Query(value = "CALL sp_detailed_status_cal(:p_Branch,:p_Category,:p_AccountName,:p_MOC,:p_PoNumber);",nativeQuery = true)
	List<DetailStatusCal> findDetailStatusListForAllPo(@Param("p_Branch") List<String> p_Branch,@Param("p_Category") List<String> p_Category,
					@Param("p_AccountName") List<String> p_AccountName,@Param("p_MOC") List<String> p_MOC,@Param("p_PoNumber") String p_PoNumber);
	

	@Transactional
	@Procedure(procedureName = "sp_detailed_status_cal")
	List<DetailStatusCal> findDetailStatusList(@Param("p_Branch") List<String> p_Branch,@Param("p_Category") List<String> p_Category,
					@Param("p_AccountName") List<String> p_AccountName,@Param("p_MOC") List<String> p_MOC,@Param("p_PoNumber") List<String> p_PoNumber);
	
}
