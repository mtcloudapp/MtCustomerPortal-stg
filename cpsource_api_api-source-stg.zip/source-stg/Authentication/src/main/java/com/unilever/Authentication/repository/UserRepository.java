package com.unilever.Authentication.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.unilever.Authentication.model.User;
import com.unilever.global.GlobalVariables;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
    
    @Transactional 
    @Query(value ="select um.PASSWORD  from "+GlobalVariables.schemaName+".USER_MASTER um where um.USERNAME=:username", nativeQuery = true)
	String findPasswordByUsername(@Param("username") String username);
    
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value ="update "+GlobalVariables.schemaName+".USER_MASTER  um set um.PASSWORD=:newPassword  where um.USERNAME=:username", nativeQuery = true)
    void updatePassword(@Param("newPassword") String newPassword,@Param("username") String username);

    @Transactional 
    @Query(value ="select um.EMAILID  from "+GlobalVariables.schemaName+".USER_MASTER um", nativeQuery = true)
	List<String> findEmails();
    
    @Transactional 
    @Query(value ="select um.USERNAME  from "+GlobalVariables.schemaName+".USER_MASTER um where um.EMAILID=:email", nativeQuery = true)
	String findUsernameByEmailId(@Param("email") String email);
    
    
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value ="update "+GlobalVariables.schemaName+".USER_MASTER  um set um.ACCESS_CODE=:accessCode  where um.EMAILID=:email", nativeQuery = true)
    void updateAccessCodeByEmail(@Param("accessCode") String accessCode,@Param("email") String email);

    
    @Transactional 
    @Query(value ="select um.ACCESS_CODE  from "+GlobalVariables.schemaName+".USER_MASTER um where um.USERNAME=:username", nativeQuery = true)
	String findAccessCodeByUsername(@Param("username") String username);
    
    
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value ="update "+GlobalVariables.schemaName+".USER_MASTER  um set um.ACCESS_CODE=:accessCode  where um.USERNAME=:username", nativeQuery = true)
    void updateAccessCodeByUserName(@Param("accessCode") String accessCode,@Param("username") String username);

    
    
    @Transactional 
    @Query(value ="select um.USERNAME  from "+GlobalVariables.schemaName+".USER_MASTER um", nativeQuery = true)
	List<String> findUserNames();
    
}