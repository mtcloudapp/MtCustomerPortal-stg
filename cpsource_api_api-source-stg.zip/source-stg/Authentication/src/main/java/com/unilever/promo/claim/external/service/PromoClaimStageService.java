package com.unilever.promo.claim.external.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.cloudfront.model.Paths;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.external.model.PosDataFieldMapping;
import com.unilever.promo.claim.external.model.PosDataStage;
import com.unilever.promo.claim.external.model.PosFileUploadMaster;
import com.unilever.promo.claim.external.model.PromoClaimFieldMapping;
import com.unilever.promo.claim.external.model.PromoClaimFileUploadMaster;
import com.unilever.promo.claim.external.model.PromoClaimStage;
import com.unilever.promo.claim.external.model.PromoClaimStageFileValidate;
import com.unilever.promo.claim.external.repository.BaseWorkingRepository;
import com.unilever.promo.claim.external.repository.OverrunClaimRepository;
import com.unilever.promo.claim.external.repository.POSDataRepository;
import com.unilever.promo.claim.external.repository.POS_VS_PrimaryrRepository;
import com.unilever.promo.claim.external.repository.PosDataFieldMappingRepository;
import com.unilever.promo.claim.external.repository.PosDataMasterRepository;
import com.unilever.promo.claim.external.repository.PosDataStageRepository;
import com.unilever.promo.claim.external.repository.PosFileUploadMasterRepository;
import com.unilever.promo.claim.external.repository.PromoClaimFieldMappingRepository;
import com.unilever.promo.claim.external.repository.PromoClaimMasterRepository;
import com.unilever.promo.claim.external.repository.PromoClaimStageExternalRepository;
import com.unilever.promo.claim.external.repository.PromoClaimStageFileValidateRepository;
import com.unilever.promo.claim.external.repository.PromoClaimSummaryRepository;
import com.unilever.promo.claim.external.repository.PromoClaimsRepository;
import com.unilever.promo.claim.external.repository.PrompClaimsFileUploadMasterRepository;

@Service
public class PromoClaimStageService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PromoClaimStageService.class);

	//Added By Sarin Jul2021 - Claim File B2C Approval
	static String ORIG_POS_CLAIM_FILE = "ORIG";
	static String NEW_POS_CLAIM_FILE = "NEW";
	static String CLAIM_TYPE_POS = "POS";
	static String CLAIM_TYPE_CLAIM = "CLAIM";
	static String CLAIM_KAM_APPROVAL = "KAM";

	@Autowired
	private AmazonS3 amazonS3;

	@Value("${aws.s3.bucket_promo_claims}")
	private String bucketName;

	@Value("${aws.s3.bucket_pos_data}")
	private String posBucketName;
	
	@Value("${gcp.storage.bucket_promo_claims}")
	private String gcpBucketName;

	@Autowired
	private Storage gcpStorage;

	//Added By Harsha Aug2021 - Excel file upload based on size
	@Value("${file.processing.limit}")
	private int fileSizeDecider ;
	
	@Autowired
	PromoClaimStageExternalRepository promoClaimStageExternalRepository;

	@Autowired
	PrompClaimsFileUploadMasterRepository prompClaimsFileUploadMasterRepository;

	@Autowired
	PromoClaimMasterRepository promoClaimMasterRepository;

	@Autowired
	PosDataStageRepository posDataStageRepository;

	@Autowired
	PosFileUploadMasterRepository posFileUploadMasterRepository;

	@Autowired
	PosDataMasterRepository posDataMasterRepository;

	@Autowired
	BaseWorkingRepository baseWorkingRepository;

	@Autowired
	OverrunClaimRepository overrunClaimRepository;

	@Autowired
	POS_VS_PrimaryrRepository pos_vs_PrimaryrRepository;

	@Autowired
	PromoClaimsRepository promoClaimsRepository;

	@Autowired
	POSDataRepository posDataRepository;

	@Autowired
	PromoClaimSummaryRepository promoClaimSummaryRepository;
	
	//Added By Sarin Jun2022 - Excel file validation for POS file
	@Autowired
	PosDataFieldMappingRepository posDataFieldMappingRepository;
	
	//Added By Sarin Jun2021 - Excel file validation for Claim file - begins
	@Autowired
	PromoClaimFieldMappingRepository promoClaimFieldMappingRepository;
	
	@Autowired
	PromoClaimStageFileValidateRepository promoClaimStageFileValidateRepository;

	public boolean validateUploadedClaimFile(List<PromoClaimStage> promoClaimStageDetail, String accountName) {
		
		String sSOLCodeColumn = "", sArticleCodeColumn = "", sClaimValueColumn = "", sClaimQtyColumn = "", sClaimPerUnitColumn = "", sMRPColumn = "";
		List<PromoClaimFieldMapping> lstFieldMapping = promoClaimFieldMappingRepository.getClaimFileColumnValuesByAccount(accountName);
		
		for(PromoClaimFieldMapping promoClaimFieldMapping : lstFieldMapping){
			System.out.println(promoClaimFieldMapping.getAccountName() + " " + promoClaimFieldMapping.getFieldName() + " " + promoClaimFieldMapping.getFieldValue());
			
			if (promoClaimFieldMapping.getFieldName().equalsIgnoreCase("SOL_CODE")) {
				sSOLCodeColumn = promoClaimFieldMapping.getFieldValue().trim();
			} else if (promoClaimFieldMapping.getFieldName().equalsIgnoreCase("ARTICLE_CODE")) {
				sArticleCodeColumn = promoClaimFieldMapping.getFieldValue().trim();
			} else if (promoClaimFieldMapping.getFieldName().equalsIgnoreCase("CLAIM_VALUE")) {
				sClaimValueColumn = promoClaimFieldMapping.getFieldValue().trim();
			} else if (promoClaimFieldMapping.getFieldName().equalsIgnoreCase("CLAIM_QTY")) {
				sClaimQtyColumn = promoClaimFieldMapping.getFieldValue().trim();
			} else if (promoClaimFieldMapping.getFieldName().equalsIgnoreCase("CLAIM_PER_UNIT")) {
				sClaimPerUnitColumn = promoClaimFieldMapping.getFieldValue().trim();
			} else if (promoClaimFieldMapping.getFieldName().equalsIgnoreCase("MRP")) {
				sMRPColumn = promoClaimFieldMapping.getFieldValue().trim();
			}
		}
		
		boolean errorFound = false; int iFirstRow = 0;
		String sSOLError = "", sArticleCodeError = "", sClaimValueError = "", sClaimQtyError = "", sClaimPerUnitError = "", sMRPError = "";
		List<PromoClaimStageFileValidate> lstPromoClaimStageFileDetails = new ArrayList<PromoClaimStageFileValidate>();
		
		for(PromoClaimStage promoClaimStage: promoClaimStageDetail){
			//System.out.println(promoClaimStage.getRecordID() + " " + promoClaimStage.getColumnA() + " " + promoClaimStage.getColumnC());
			
			sSOLError = ""; sArticleCodeError = ""; sClaimValueError = ""; 
			sClaimQtyError = ""; sClaimPerUnitError = ""; sMRPError = "";
			PromoClaimStageFileValidate promoClaimStageFileValidate = new PromoClaimStageFileValidate(null,
					promoClaimStage.getColumnA(), promoClaimStage.getColumnB(), promoClaimStage.getColumnC(),
					promoClaimStage.getColumnD(), promoClaimStage.getColumnE(), promoClaimStage.getColumnF(),
					promoClaimStage.getColumnG(), promoClaimStage.getColumnH(), promoClaimStage.getColumnI(),
					promoClaimStage.getColumnJ(), promoClaimStage.getColumnK(), promoClaimStage.getColumnL(),
					promoClaimStage.getColumnM(), promoClaimStage.getColumnN(), promoClaimStage.getColumnO(),
					promoClaimStage.getColumnP(), promoClaimStage.getColumnQ(), promoClaimStage.getColumnR(),
					promoClaimStage.getColumnS(), promoClaimStage.getColumnT(), promoClaimStage.getColumnU(),
					promoClaimStage.getColumnV(), promoClaimStage.getColumnW(), promoClaimStage.getColumnX(),
					promoClaimStage.getColumnY(), promoClaimStage.getColumnZ(), promoClaimStage.getColumnAA(),
					promoClaimStage.getColumnAB(), promoClaimStage.getColumnAC(), promoClaimStage.getColumnAD(),
					promoClaimStage.getColumnAE(), promoClaimStage.getColumnAF(), promoClaimStage.getColumnAG(),
					promoClaimStage.getColumnAH(), promoClaimStage.getColumnAI(), promoClaimStage.getColumnAJ(),
					promoClaimStage.getColumnAK(), promoClaimStage.getColumnAL(), promoClaimStage.getColumnAM(),
					promoClaimStage.getColumnAN(), promoClaimStage.getColumnAO(), promoClaimStage.getColumnAP(),
					promoClaimStage.getColumnAQ(), promoClaimStage.getColumnAR(), promoClaimStage.getColumnAS(),
					promoClaimStage.getColumnAT(), promoClaimStage.getColumnAU(), promoClaimStage.getColumnAV(),
					promoClaimStage.getColumnAW(), promoClaimStage.getColumnAX(), promoClaimStage.getColumnAY(),
					promoClaimStage.getColumnAZ(), promoClaimStage.getNoOfColumns(), null, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
					accountName, "CLAIM");  //Added By Sarin Jun2022 - Excel file validation for POS file
			
			if (iFirstRow > 0) {
				//SOL Code error check
				switch (sSOLCodeColumn) {
				case "COLUMN_A":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnA(), true);
					break;
				case "COLUMN_B":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnB(), true);
					break;
				case "COLUMN_C":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnC(), true);
					break;
				case "COLUMN_D":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnD(), true);
					break;
				case "COLUMN_E":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnE(), true);
					break;
				case "COLUMN_F":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnF(), true);
					break;
				case "COLUMN_G":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnG(), true);
					break;
				case "COLUMN_H":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnH(), true);
					break;
				case "COLUMN_I":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnI(), true);
					break;
				case "COLUMN_J":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnJ(), true);
					break;
				case "COLUMN_K":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnK(), true);
					break;
				case "COLUMN_L":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnL(), true);
					break;
				case "COLUMN_M":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnM(), true);
					break;
				case "COLUMN_N":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnN(), true);
					break;
				case "COLUMN_O":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnO(), true);
					break;
				case "COLUMN_P":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnP(), true);
					break;
				case "COLUMN_Q":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnQ(), true);
					break;
				case "COLUMN_R":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnR(), true);
					break;
				case "COLUMN_S":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnS(), true);
					break;
				case "COLUMN_T":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnT(), true);
					break;
				case "COLUMN_U":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnU(), true);
					break;
				case "COLUMN_V":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnV(), true);
					break;
				case "COLUMN_W":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnW(), true);
					break;
				case "COLUMN_X":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnX(), true);
					break;
				case "COLUMN_Y":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnY(), true);
					break;
				case "COLUMN_Z":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnZ(), true);
					break;
				case "COLUMN_AA":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAA(), true);
					break;
				case "COLUMN_AB":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAB(), true);
					break;
				case "COLUMN_AC":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAC(), true);
					break;
				case "COLUMN_AD":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAD(), true);
					break;
				case "COLUMN_AE":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAE(), true);
					break;
				case "COLUMN_AF":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAF(), true);
					break;
				case "COLUMN_AG":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAG(), true);
					break;
				case "COLUMN_AH":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAH(), true);
					break;
				case "COLUMN_AI":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAI(), true);
					break;
				case "COLUMN_AJ":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAJ(), true);
					break;
				case "COLUMN_AK":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAK(), true);
					break;
				case "COLUMN_AL":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAL(), true);
					break;
				case "COLUMN_AM":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAM(), true);
					break;
				case "COLUMN_AN":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAN(), true);
					break;
				case "COLUMN_AO":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAO(), true);
					break;
				case "COLUMN_AP":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAP(), true);
					break;
				case "COLUMN_AQ":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAQ(), true);
					break;
				case "COLUMN_AR":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAR(), true);
					break;
				case "COLUMN_AS":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAS(), true);
					break;
				case "COLUMN_AT":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAT(), true);
					break;
				case "COLUMN_AU":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAU(), true);
					break;
				case "COLUMN_AV":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAV(), true);
					break;
				case "COLUMN_AW":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAW(), true);
					break;
				case "COLUMN_AX":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAX(), true);
					break;
				case "COLUMN_AY":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAY(), true);
					break;
				case "COLUMN_AZ":
					sSOLError = validateExcelColumns(promoClaimStage.getColumnAZ(), true);
					break;
				}
				if (sSOLError.length() > 0) {
					sSOLError = "SOL Code " + sSOLError + " ";
					errorFound = true;
				}

				//Article Code error check
				switch (sArticleCodeColumn) {
				case "COLUMN_A":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnA(), false);
					break;
				case "COLUMN_B":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnB(), false);
					break;
				case "COLUMN_C":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnC(), false);
					break;
				case "COLUMN_D":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnD(), false);
					break;
				case "COLUMN_E":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnE(), false);
					break;
				case "COLUMN_F":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnF(), false);
					break;
				case "COLUMN_G":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnG(), false);
					break;
				case "COLUMN_H":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnH(), false);
					break;
				case "COLUMN_I":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnI(), false);
					break;
				case "COLUMN_J":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnJ(), false);
					break;
				case "COLUMN_K":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnK(), false);
					break;
				case "COLUMN_L":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnL(), false);
					break;
				case "COLUMN_M":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnM(), false);
					break;
				case "COLUMN_N":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnN(), false);
					break;
				case "COLUMN_O":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnO(), false);
					break;
				case "COLUMN_P":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnP(), false);
					break;
				case "COLUMN_Q":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnQ(), false);
					break;
				case "COLUMN_R":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnR(), false);
					break;
				case "COLUMN_S":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnS(), false);
					break;
				case "COLUMN_T":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnT(), false);
					break;
				case "COLUMN_U":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnU(), false);
					break;
				case "COLUMN_V":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnV(), false);
					break;
				case "COLUMN_W":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnW(), false);
					break;
				case "COLUMN_X":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnX(), false);
					break;
				case "COLUMN_Y":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnY(), false);
					break;
				case "COLUMN_Z":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnZ(), false);
					break;
				case "COLUMN_AA":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAA(), false);
					break;
				case "COLUMN_AB":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAB(), false);
					break;
				case "COLUMN_AC":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAC(), false);
					break;
				case "COLUMN_AD":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAD(), false);
					break;
				case "COLUMN_AE":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAE(), false);
					break;
				case "COLUMN_AF":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAF(), false);
					break;
				case "COLUMN_AG":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAG(), false);
					break;
				case "COLUMN_AH":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAH(), false);
					break;
				case "COLUMN_AI":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAI(), false);
					break;
				case "COLUMN_AJ":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAJ(), false);
					break;
				case "COLUMN_AK":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAK(), false);
					break;
				case "COLUMN_AL":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAL(), false);
					break;
				case "COLUMN_AM":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAM(), false);
					break;
				case "COLUMN_AN":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAN(), false);
					break;
				case "COLUMN_AO":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAO(), false);
					break;
				case "COLUMN_AP":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAP(), false);
					break;
				case "COLUMN_AQ":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAQ(), false);
					break;
				case "COLUMN_AR":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAR(), false);
					break;
				case "COLUMN_AS":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAS(), false);
					break;
				case "COLUMN_AT":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAT(), false);
					break;
				case "COLUMN_AU":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAU(), false);
					break;
				case "COLUMN_AV":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAV(), false);
					break;
				case "COLUMN_AW":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAW(), false);
					break;
				case "COLUMN_AX":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAX(), false);
					break;
				case "COLUMN_AY":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAY(), false);
					break;
				case "COLUMN_AZ":
					sArticleCodeError = validateExcelColumns(promoClaimStage.getColumnAZ(), false);
					break;
				}
				if (sArticleCodeError.length() > 0) {
					sArticleCodeError = "Article Code " + sArticleCodeError + " ";
					errorFound = true;
				}

				//Claim Value error check
				switch (sClaimValueColumn) {
				case "COLUMN_A":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnA(), false);
					break;
				case "COLUMN_B":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnB(), false);
					break;
				case "COLUMN_C":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnC(), false);
					break;
				case "COLUMN_D":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnD(), false);
					break;
				case "COLUMN_E":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnE(), false);
					break;
				case "COLUMN_F":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnF(), false);
					break;
				case "COLUMN_G":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnG(), false);
					break;
				case "COLUMN_H":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnH(), false);
					break;
				case "COLUMN_I":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnI(), false);
					break;
				case "COLUMN_J":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnJ(), false);
					break;
				case "COLUMN_K":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnK(), false);
					break;
				case "COLUMN_L":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnL(), false);
					break;
				case "COLUMN_M":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnM(), false);
					break;
				case "COLUMN_N":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnN(), false);
					break;
				case "COLUMN_O":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnO(), false);
					break;
				case "COLUMN_P":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnP(), false);
					break;
				case "COLUMN_Q":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnQ(), false);
					break;
				case "COLUMN_R":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnR(), false);
					break;
				case "COLUMN_S":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnS(), false);
					break;
				case "COLUMN_T":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnT(), false);
					break;
				case "COLUMN_U":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnU(), false);
					break;
				case "COLUMN_V":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnV(), false);
					break;
				case "COLUMN_W":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnW(), false);
					break;
				case "COLUMN_X":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnX(), false);
					break;
				case "COLUMN_Y":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnY(), false);
					break;
				case "COLUMN_Z":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnZ(), false);
					break;
				case "COLUMN_AA":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAA(), false);
					break;
				case "COLUMN_AB":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAB(), false);
					break;
				case "COLUMN_AC":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAC(), false);
					break;
				case "COLUMN_AD":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAD(), false);
					break;
				case "COLUMN_AE":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAE(), false);
					break;
				case "COLUMN_AF":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAF(), false);
					break;
				case "COLUMN_AG":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAG(), false);
					break;
				case "COLUMN_AH":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAH(), false);
					break;
				case "COLUMN_AI":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAI(), false);
					break;
				case "COLUMN_AJ":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAJ(), false);
					break;
				case "COLUMN_AK":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAK(), false);
					break;
				case "COLUMN_AL":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAL(), false);
					break;
				case "COLUMN_AM":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAM(), false);
					break;
				case "COLUMN_AN":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAN(), false);
					break;
				case "COLUMN_AO":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAO(), false);
					break;
				case "COLUMN_AP":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAP(), false);
					break;
				case "COLUMN_AQ":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAQ(), false);
					break;
				case "COLUMN_AR":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAR(), false);
					break;
				case "COLUMN_AS":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAS(), false);
					break;
				case "COLUMN_AT":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAT(), false);
					break;
				case "COLUMN_AU":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAU(), false);
					break;
				case "COLUMN_AV":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAV(), false);
					break;
				case "COLUMN_AW":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAW(), false);
					break;
				case "COLUMN_AX":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAX(), false);
					break;
				case "COLUMN_AY":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAY(), false);
					break;
				case "COLUMN_AZ":
					sClaimValueError = validateExcelColumns(promoClaimStage.getColumnAZ(), false);
					break;
				}
				if (sClaimValueError.length() > 0) {
					sClaimValueError = "Claim Value " + sClaimValueError + " ";
					errorFound = true;
				}

				//Claim Qty error check
				switch (sClaimQtyColumn) {
				case "COLUMN_A":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnA(), false);
					break;
				case "COLUMN_B":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnB(), false);
					break;
				case "COLUMN_C":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnC(), false);
					break;
				case "COLUMN_D":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnD(), false);
					break;
				case "COLUMN_E":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnE(), false);
					break;
				case "COLUMN_F":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnF(), false);
					break;
				case "COLUMN_G":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnG(), false);
					break;
				case "COLUMN_H":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnH(), false);
					break;
				case "COLUMN_I":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnI(), false);
					break;
				case "COLUMN_J":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnJ(), false);
					break;
				case "COLUMN_K":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnK(), false);
					break;
				case "COLUMN_L":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnL(), false);
					break;
				case "COLUMN_M":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnM(), false);
					break;
				case "COLUMN_N":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnN(), false);
					break;
				case "COLUMN_O":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnO(), false);
					break;
				case "COLUMN_P":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnP(), false);
					break;
				case "COLUMN_Q":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnQ(), false);
					break;
				case "COLUMN_R":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnR(), false);
					break;
				case "COLUMN_S":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnS(), false);
					break;
				case "COLUMN_T":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnT(), false);
					break;
				case "COLUMN_U":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnU(), false);
					break;
				case "COLUMN_V":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnV(), false);
					break;
				case "COLUMN_W":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnW(), false);
					break;
				case "COLUMN_X":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnX(), false);
					break;
				case "COLUMN_Y":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnY(), false);
					break;
				case "COLUMN_Z":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnZ(), false);
					break;
				case "COLUMN_AA":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAA(), false);
					break;
				case "COLUMN_AB":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAB(), false);
					break;
				case "COLUMN_AC":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAC(), false);
					break;
				case "COLUMN_AD":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAD(), false);
					break;
				case "COLUMN_AE":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAE(), false);
					break;
				case "COLUMN_AF":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAF(), false);
					break;
				case "COLUMN_AG":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAG(), false);
					break;
				case "COLUMN_AH":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAH(), false);
					break;
				case "COLUMN_AI":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAI(), false);
					break;
				case "COLUMN_AJ":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAJ(), false);
					break;
				case "COLUMN_AK":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAK(), false);
					break;
				case "COLUMN_AL":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAL(), false);
					break;
				case "COLUMN_AM":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAM(), false);
					break;
				case "COLUMN_AN":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAN(), false);
					break;
				case "COLUMN_AO":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAO(), false);
					break;
				case "COLUMN_AP":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAP(), false);
					break;
				case "COLUMN_AQ":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAQ(), false);
					break;
				case "COLUMN_AR":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAR(), false);
					break;
				case "COLUMN_AS":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAS(), false);
					break;
				case "COLUMN_AT":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAT(), false);
					break;
				case "COLUMN_AU":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAU(), false);
					break;
				case "COLUMN_AV":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAV(), false);
					break;
				case "COLUMN_AW":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAW(), false);
					break;
				case "COLUMN_AX":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAX(), false);
					break;
				case "COLUMN_AY":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAY(), false);
					break;
				case "COLUMN_AZ":
					sClaimQtyError = validateExcelColumns(promoClaimStage.getColumnAZ(), false);
					break;
				}
				if (sClaimQtyError.length() > 0) {
					sClaimQtyError = "Claim Qty " + sClaimQtyError + " ";
					errorFound = true;
				}

				//Claim per Unit error check
				switch (sClaimPerUnitColumn) {
				case "COLUMN_A":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnA(), false);
					break;
				case "COLUMN_B":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnB(), false);
					break;
				case "COLUMN_C":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnC(), false);
					break;
				case "COLUMN_D":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnD(), false);
					break;
				case "COLUMN_E":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnE(), false);
					break;
				case "COLUMN_F":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnF(), false);
					break;
				case "COLUMN_G":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnG(), false);
					break;
				case "COLUMN_H":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnH(), false);
					break;
				case "COLUMN_I":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnI(), false);
					break;
				case "COLUMN_J":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnJ(), false);
					break;
				case "COLUMN_K":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnK(), false);
					break;
				case "COLUMN_L":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnL(), false);
					break;
				case "COLUMN_M":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnM(), false);
					break;
				case "COLUMN_N":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnN(), false);
					break;
				case "COLUMN_O":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnO(), false);
					break;
				case "COLUMN_P":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnP(), false);
					break;
				case "COLUMN_Q":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnQ(), false);
					break;
				case "COLUMN_R":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnR(), false);
					break;
				case "COLUMN_S":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnS(), false);
					break;
				case "COLUMN_T":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnT(), false);
					break;
				case "COLUMN_U":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnU(), false);
					break;
				case "COLUMN_V":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnV(), false);
					break;
				case "COLUMN_W":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnW(), false);
					break;
				case "COLUMN_X":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnX(), false);
					break;
				case "COLUMN_Y":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnY(), false);
					break;
				case "COLUMN_Z":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnZ(), false);
					break;
				case "COLUMN_AA":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAA(), false);
					break;
				case "COLUMN_AB":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAB(), false);
					break;
				case "COLUMN_AC":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAC(), false);
					break;
				case "COLUMN_AD":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAD(), false);
					break;
				case "COLUMN_AE":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAE(), false);
					break;
				case "COLUMN_AF":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAF(), false);
					break;
				case "COLUMN_AG":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAG(), false);
					break;
				case "COLUMN_AH":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAH(), false);
					break;
				case "COLUMN_AI":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAI(), false);
					break;
				case "COLUMN_AJ":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAJ(), false);
					break;
				case "COLUMN_AK":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAK(), false);
					break;
				case "COLUMN_AL":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAL(), false);
					break;
				case "COLUMN_AM":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAM(), false);
					break;
				case "COLUMN_AN":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAN(), false);
					break;
				case "COLUMN_AO":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAO(), false);
					break;
				case "COLUMN_AP":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAP(), false);
					break;
				case "COLUMN_AQ":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAQ(), false);
					break;
				case "COLUMN_AR":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAR(), false);
					break;
				case "COLUMN_AS":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAS(), false);
					break;
				case "COLUMN_AT":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAT(), false);
					break;
				case "COLUMN_AU":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAU(), false);
					break;
				case "COLUMN_AV":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAV(), false);
					break;
				case "COLUMN_AW":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAW(), false);
					break;
				case "COLUMN_AX":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAX(), false);
					break;
				case "COLUMN_AY":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAY(), false);
					break;
				case "COLUMN_AZ":
					sClaimPerUnitError = validateExcelColumns(promoClaimStage.getColumnAZ(), false);
					break;
				}
				if (sClaimPerUnitError.length() > 0) {
					sClaimPerUnitError = "Claim per Unit " + sClaimPerUnitError + " ";
					errorFound = true;
				}

				//MRP error check
				switch (sMRPColumn) {
				case "COLUMN_A":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnA(), false);
					break;
				case "COLUMN_B":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnB(), false);
					break;
				case "COLUMN_C":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnC(), false);
					break;
				case "COLUMN_D":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnD(), false);
					break;
				case "COLUMN_E":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnE(), false);
					break;
				case "COLUMN_F":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnF(), false);
					break;
				case "COLUMN_G":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnG(), false);
					break;
				case "COLUMN_H":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnH(), false);
					break;
				case "COLUMN_I":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnI(), false);
					break;
				case "COLUMN_J":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnJ(), false);
					break;
				case "COLUMN_K":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnK(), false);
					break;
				case "COLUMN_L":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnL(), false);
					break;
				case "COLUMN_M":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnM(), false);
					break;
				case "COLUMN_N":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnN(), false);
					break;
				case "COLUMN_O":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnO(), false);
					break;
				case "COLUMN_P":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnP(), false);
					break;
				case "COLUMN_Q":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnQ(), false);
					break;
				case "COLUMN_R":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnR(), false);
					break;
				case "COLUMN_S":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnS(), false);
					break;
				case "COLUMN_T":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnT(), false);
					break;
				case "COLUMN_U":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnU(), false);
					break;
				case "COLUMN_V":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnV(), false);
					break;
				case "COLUMN_W":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnW(), false);
					break;
				case "COLUMN_X":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnX(), false);
					break;
				case "COLUMN_Y":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnY(), false);
					break;
				case "COLUMN_Z":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnZ(), false);
					break;
				case "COLUMN_AA":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAA(), false);
					break;
				case "COLUMN_AB":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAB(), false);
					break;
				case "COLUMN_AC":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAC(), false);
					break;
				case "COLUMN_AD":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAD(), false);
					break;
				case "COLUMN_AE":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAE(), false);
					break;
				case "COLUMN_AF":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAF(), false);
					break;
				case "COLUMN_AG":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAG(), false);
					break;
				case "COLUMN_AH":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAH(), false);
					break;
				case "COLUMN_AI":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAI(), false);
					break;
				case "COLUMN_AJ":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAJ(), false);
					break;
				case "COLUMN_AK":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAK(), false);
					break;
				case "COLUMN_AL":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAL(), false);
					break;
				case "COLUMN_AM":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAM(), false);
					break;
				case "COLUMN_AN":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAN(), false);
					break;
				case "COLUMN_AO":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAO(), false);
					break;
				case "COLUMN_AP":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAP(), false);
					break;
				case "COLUMN_AQ":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAQ(), false);
					break;
				case "COLUMN_AR":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAR(), false);
					break;
				case "COLUMN_AS":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAS(), false);
					break;
				case "COLUMN_AT":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAT(), false);
					break;
				case "COLUMN_AU":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAU(), false);
					break;
				case "COLUMN_AV":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAV(), false);
					break;
				case "COLUMN_AW":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAW(), false);
					break;
				case "COLUMN_AX":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAX(), false);
					break;
				case "COLUMN_AY":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAY(), false);
					break;
				case "COLUMN_AZ":
					sMRPError = validateExcelColumns(promoClaimStage.getColumnAZ(), false);
					break;
				}
				if (sMRPError.length() > 0) {
					sMRPError = "MRP " + sMRPError + " ";
					errorFound = true;
				}
			}
			iFirstRow++;
			
			promoClaimStageFileValidate.setErrorMsg(sSOLError + sArticleCodeError + sClaimValueError 
					+ sClaimQtyError + sClaimPerUnitError + sMRPError);
			
			lstPromoClaimStageFileDetails.add(promoClaimStageFileValidate);
		}
		
		if (errorFound) {
			//promoClaimStageFileValidateRepository.deletePromoClaimStageFileValidate();
			promoClaimStageFileValidateRepository.saveAll(lstPromoClaimStageFileDetails);
		}
		
		return errorFound;
	}
	
	private String validateExcelColumns(String sColumnValue, boolean isSOLCode) {
		String sResult = "";
		if (sColumnValue == null) {
			sColumnValue = "";
		}
		Pattern specialCh; //= Pattern.compile("!@#$%^*&-");
		//Pattern whitespaceCh = Pattern.compile("(?=\\S+$)");
		
		if (isSOLCode) {
			specialCh = Pattern.compile("[!@#$%^*]");
		} else {
			specialCh = Pattern.compile("[!@#$%^*&-]");
		}
		
		if (sColumnValue.equalsIgnoreCase("NA")) {
			sResult = "value is NA,";
		}
		if ((sColumnValue.trim().isEmpty()) && (isSOLCode)) {
			sResult = "should not be blank,";
		}
		if ((sColumnValue.contains(" ")) && (!isSOLCode)) {
			sResult = sResult + "contains whitespace,";
		}
		if (specialCh.matcher(sColumnValue).find()) {
			sResult = sResult + "should not contain special characters";
		}
		
		return sResult;
	}
	
	//public ByteArrayInputStream getPromoClaimErrorDetails() {  //Commented By Sarin Jun2022 - Excel file validation for POS file
	public ByteArrayInputStream getPromoClaimErrorDetails(String accountName, String fileType) {  //Added By Sarin Jun2022 - Excel file validation for POS file
		//List<PromoClaimStageFileValidate> promoClaimErrorDataList = promoClaimStageFileValidateRepository.getPromoClaimFileErrorList();  //Commented By Sarin Jun2022 - Excel file validation for POS file
		List<PromoClaimStageFileValidate> promoClaimErrorDataList = promoClaimStageFileValidateRepository.getPromoClaimFileErrorList(accountName, fileType);  //Added By Sarin Jun2022 - Excel file validation for POS file
		ByteArrayInputStream in = PromoClaimExcelHelper.generatePromoClaimErrorDataToExcel(promoClaimErrorDataList);
		return in;
	}
	
	public ResponseMessage calcPromoClaims(String accountName,String moc, String claimType) {
		
		ResponseMessage resps = new ResponseMessage();
		try {
			Integer promoClaimStageCount = promoClaimStageExternalRepository.findCountPromoClaimStageDataByAccountAndMoc(accountName, moc);
			Integer posStageCount = posDataStageRepository.findCountPosDataStageDataByAccountAndMoc(accountName, moc);
			
			//if ((posStageCount > 0) && (claimType.equalsIgnoreCase(CLAIM_TYPE_POS))) {                                                        //Commented By Sarin Nov2021 - Claim File KAM Approval
			if ((posStageCount > 0) && ( (claimType.equalsIgnoreCase(CLAIM_TYPE_POS))) || (claimType.equalsIgnoreCase(CLAIM_KAM_APPROVAL)) ) {  //Added By Sarin Nov2021 - Claim File KAM Approval
				LOGGER.info("INSERT INTO POS MASTER STARTS");
				//posDataMasterRepository.insertPosDataByAccountName(accountName);
				posDataMasterRepository.insertPosDataByAccountName(accountName, moc);
				LOGGER.info("INSERT INTO POS MASTER ENDS");
			}
			
			//if ((promoClaimStageCount > 0) && (claimType.equalsIgnoreCase(CLAIM_TYPE_CLAIM))) {                                                        //Commented By Sarin Nov2021 - Claim File KAM Approval
			if ((promoClaimStageCount > 0) && ( (claimType.equalsIgnoreCase(CLAIM_TYPE_CLAIM))) || (claimType.equalsIgnoreCase(CLAIM_KAM_APPROVAL)) ) {  //Added By Sarin Nov2021 - Claim File KAM Approval
				LOGGER.info("INSERT INTO PROMO CLAIM MASTER TABLE STARTS HERE");
				//promoClaimMasterRepository.insertDataByAccountName(accountName);
				promoClaimMasterRepository.insertDataByAccountName(accountName, moc);
				LOGGER.info("INSERT INTO PROMO CLAIM MASTER TABLE STARTS HERE");
			}
			
			if ((promoClaimStageCount > 0) || (posStageCount > 0)) {
				LOGGER.info("store procs starts");
				promoClaimsRepository.insertIntoPromoClaim(accountName,moc);
				posDataRepository.insertIntoPOSData(accountName,moc);
				pos_vs_PrimaryrRepository.insertIntoPOS_VS_Primary(accountName, moc);
				baseWorkingRepository.insertIntoBaseworking(accountName,moc);
				overrunClaimRepository.insertIntoOverrunClaim(accountName,moc);
				promoClaimSummaryRepository.insertIntoPromoClaimSummary(accountName,moc);
				LOGGER.info("store procs end");
			}
			
			Integer claimSummaryData = promoClaimSummaryRepository.findPromoClaimSummaryByAccountMOC(accountName, moc);
			Integer overrunClaimData = overrunClaimRepository.findOverrunClaimByAccountMOC(accountName, moc);
			Integer baseworkingData = baseWorkingRepository.findBaseworkingByAccountMOC(accountName, moc);

			if(claimSummaryData > 0 && overrunClaimData > 0 && baseworkingData > 0) {
				resps.setMessage("Calculation Completed For " + accountName + " " + moc);
			} else {
				resps.setMessage("Pos and Claim files not available For " + accountName + " " + moc);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			resps.setMessage("Error while doing calculation For " + accountName + " " + moc);
		}
		
		return resps;
		
	}
	
	public String getPromoClaimFile(String accountName, String moc, String fileType) {
		Integer fileNo = 0;
		String claimFileName = "";
		if (fileType.equalsIgnoreCase(ORIG_POS_CLAIM_FILE)) {
			fileNo = promoClaimMasterRepository.findFileNoOfPromoClaimMst(accountName, moc);
		} else if (fileType.equalsIgnoreCase(NEW_POS_CLAIM_FILE)) {
			fileNo = promoClaimStageExternalRepository.findFileNoByAccountMoc(accountName, moc);
		}
		claimFileName = prompClaimsFileUploadMasterRepository.findS3PathByAccountMocFileno(accountName, moc, fileNo);
		return "promo_claims/" + claimFileName;
	}
	
	public String getPromoPosFile(String accountName, String moc, String fileType) {
		Integer fileNo = 0;
		String posFileName = "";
		if (fileType.equalsIgnoreCase(ORIG_POS_CLAIM_FILE)) {
			fileNo = posDataMasterRepository.findFileNoOfPOSDataMst(accountName, moc);
		} else if (fileType.equalsIgnoreCase(NEW_POS_CLAIM_FILE)) {
			fileNo = posDataStageRepository.findFileNoByAccountMoc(accountName, moc);
		}
		posFileName = posFileUploadMasterRepository.findS3PathByAccountMocFileno(accountName, moc, fileNo);
		return "promo_claims/pos/" + posFileName;
	}
	
	public String getb2cClaimNotificationCount(String accountName, String moc) {
		Integer claimCount = promoClaimStageExternalRepository.findRowByAccountMoc(accountName, moc);
		if (claimCount > 0) {
			return "1";
		} else {
			return "0";
		}
		
	}
	
	public String getb2cPosNotificationCount(String accountName, String moc) {
		Integer posCount = posDataStageRepository.findRowByAccountMoc(accountName, moc);
		if (posCount > 0) {
			return "1";
		} else {
			return "0";
		}
		
	}
	//Added By Sarin Jun2021 - Excel file validation for Claim file - ends
	
	//Added By Harsha Aug2021 - Excel file upload based on size for Claim file - starts
	private static final long  MEGABYTE = 1024L * 1024L;

	public static long bytesToMeg(long bytes) {
		return bytes / MEGABYTE ;
	}
	//Added By Harsha Aug2021 - Excel file validation for Claim file - ends

	public ResponseMessage save(MultipartFile file,String accountName,String moc) {

		ResponseMessage resps = new ResponseMessage();
		String currentLoadTime = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").format(new Date());
		boolean isUploadOnly = true; //Added By Sarin Nov2021 - Claim File KAM Approval

		try{
			LOGGER.info("LOGIC FOR CLAIM UPLOAD STARTS HERE");
			//List<PromoClaimStage> promoClaimStageDetails = PromoClaimExcelHelper.excelToPromoClaimStage(file.getInputStream()); //Commented By Harsha Aug2021
			//Added By Harsha Aug2021 - Excel file validation for Claim file - starts
			List<PromoClaimStage> promoClaimStageDetails = null;
			System.out.println("Promo claim file size: " + bytesToMeg(file.getSize()));
			if(bytesToMeg(file.getSize())>= fileSizeDecider) {
				promoClaimStageDetails = PromoClaimExcelHelper.excelTopromoClaimStageLargeFile(file.getInputStream());
			} else {
				promoClaimStageDetails = PromoClaimExcelHelper.excelToPromoClaimStage(file.getInputStream());
			}
			System.out.println("Promo claim stage list size: " + bytesToMeg(promoClaimStageDetails.size()));
			//Added By Harsha Aug2021 - Excel file validation for Claim file - ends
			
			//Added By Sarin Jun2021 - Excel file validation for Claim file - starts
			//promoClaimStageFileValidateRepository.deletePromoClaimStageFileValidate();  //Commented By Sarin Jun2022 - Excel file validation for POS file
			promoClaimStageFileValidateRepository.deletePromoClaimStageFileValidate(accountName, "CLAIM");  //Added By Sarin Jun2022 - Excel file validation for POS file
			if (validateUploadedClaimFile(promoClaimStageDetails, accountName)) {
				resps.setMessage("Incorrect file format upload For "+accountName+" "+moc);
				return resps;
			}
			//Remove header row
			promoClaimStageDetails.remove(0);
			//Added By Sarin Jun2021 - Excel file validation for Claim file - ends
			Integer promoClaimCount = promoClaimStageExternalRepository.findCountPromoClaimStage();
			Integer fileNo = prompClaimsFileUploadMasterRepository.findFileNo(accountName, moc);
			Integer fileUploadMasterNo = prompClaimsFileUploadMasterRepository.findCountPromoClaimFileUploadMaster(accountName, moc);
			Integer promoClaimStageData = promoClaimStageExternalRepository.findCountPromoClaimStageDataByAccountAndMoc(accountName, moc);

			PromoClaimFileUploadMaster promoClaimFileUploadMaster = new PromoClaimFileUploadMaster();
			promoClaimFileUploadMaster.setAccountName(accountName);
			promoClaimFileUploadMaster.setMoc(moc);

			if(fileUploadMasterNo>0){
				promoClaimFileUploadMaster.setWorkflowStageId(2);
			}else{
				promoClaimFileUploadMaster.setWorkflowStageId(1);
			}

			promoClaimFileUploadMaster.setUploadBy(accountName);
			promoClaimFileUploadMaster.setUploadDate(currentLoadTime);

			

			for(PromoClaimStage promoClaimStage : promoClaimStageDetails){
				promoClaimStage.setAccountName(accountName);
				promoClaimStage.setMoc(moc);
				promoClaimStage.setLoadDate(currentLoadTime);
				promoClaimStage.setUploadBy(accountName);
				if(fileNo == null){
					promoClaimStage.setFileNo(1);

				}else{
					promoClaimStage.setFileNo(fileNo+1);

				}

				if(fileUploadMasterNo == null){
					promoClaimFileUploadMaster.setFileNo(1);
					promoClaimFileUploadMaster.setS3Path("1_" + moc+"_"+accountName+"_"+file.getOriginalFilename());  //Added By Sarin Jul2021 - Claim File B2C Approval
				}else{
					promoClaimFileUploadMaster.setFileNo(fileUploadMasterNo+1);
					promoClaimFileUploadMaster.setS3Path((fileUploadMasterNo+1) + "_" + moc+"_"+accountName+"_"+file.getOriginalFilename());  //Added By Sarin Jul2021 - Claim File B2C Approval
				}


				if(promoClaimStageData>0){
					promoClaimStage.setWorkflowStageID(2);
				}else{
					promoClaimStage.setWorkflowStageID(1);
				}

			}
			
			//Added By Sarin Jul2021 - Claim File B2C Approval - Starts
			Integer fileNum = 0;
			if (fileNo == null) {
				fileNum = 1;
			} else {
				fileNum = fileNo + 1;
			}
			
			promoClaimStageExternalRepository.deletePromoClaimStageByAccountAndMoc(accountName, moc);
			//Added By Sarin Jul2021 - Claim File B2C Approval - Ends

			if(promoClaimCount>0){
				
				LOGGER.info("INSERT INTO PROMO CLAIM FILE UPLOAD MASTER TABLE STARTS HERE");
				prompClaimsFileUploadMasterRepository.save(promoClaimFileUploadMaster);
				LOGGER.info("INSERT INTO PROMO CLAIM FILE UPLOAD MASTER TABLE ENDS HERE");
				LOGGER.info("INSERT INTO PROMO CLAIM STAGE TABLE STARTS HERE");
				promoClaimStageExternalRepository.saveAll(promoClaimStageDetails);
				LOGGER.info("INSERT INTO PROMO CLAIM STAGE TABLE ENDS HERE");
				LOGGER.info("UPLOAD PROMO CLAIM FILE TO S3 STARTS");
				//uploadFile(file,accountName,moc);
				uploadFile(file,accountName,moc, fileNum);  //Added By Sarin Jul2021 - Claim File B2C Approval
				LOGGER.info("UPLOAD PROMO CLAIM FILE TO S3 ENDS");
			}else{
				
				LOGGER.info("INSERT INTO PROMO CLAIM FILE UPLOAD MASTER TABLE STARTS HERE");
				prompClaimsFileUploadMasterRepository.save(promoClaimFileUploadMaster);
				LOGGER.info("INSERT INTO PROMO CLAIM FILE UPLOAD MASTER TABLE ENDS HERE");
				LOGGER.info("INSERT INTO PROMO CLAIM STAGE TABLE STARTS HERE");
				promoClaimStageExternalRepository.saveAll(promoClaimStageDetails);
				LOGGER.info("INSERT INTO PROMO CLAIM STAGE TABLE ENDS HERE");
				LOGGER.info("UPLOAD PROMO CLAIM FILE TO S3 STARTS");
				//uploadFile(file,accountName,moc);
				uploadFile(file,accountName,moc, fileNum);  //Added By Sarin Jul2021 - Claim File B2C Approval
				LOGGER.info("UPLOAD PROMO CLAIM FILE TO S3 ENDS");
			
			}
			
			//Added By Sarin Nov2021 - Claim File KAM Approval - Starts
			if (isUploadOnly) {
				resps.setMessage("Claim Uploaded, Calculation will initiate post KAM approval for "+accountName+" "+moc);
				return resps;	
			}
			//Added By Sarin Nov2021 - Claim File KAM Approval - Ends
			
			//Added By Sarin Jul2021 - Claim File B2C Approval - Starts
			Integer promoClaimFileCnt = prompClaimsFileUploadMasterRepository.findCountPromoClaimFileUploadMaster(accountName, moc);
			if (promoClaimFileCnt > 1) {
				resps.setMessage("Calculation will initiate post B2C approval For "+accountName+" "+moc);
				return resps;
			}
			//Added By Sarin Jul2021 - Claim File B2C Approval - Ends
			
			LOGGER.info("INSERT INTO PROMO CLAIM MASTER TABLE STARTS HERE");
			//promoClaimMasterRepository.insertDataByAccountName(accountName);     //Commented By Sarin Jul2021 - Claim File B2C Approval
			promoClaimMasterRepository.insertDataByAccountName(accountName, moc);  //Added By Sarin Jul2021 - Claim File B2C Approval
			LOGGER.info("INSERT INTO PROMO CLAIM MASTER TABLE STARTS HERE");


		}catch(Exception e){
			e.printStackTrace();
		}
		
		Integer posFileUploadMstCount = posFileUploadMasterRepository.findCountPosFileUploadMaster(accountName, moc);
		if(posFileUploadMstCount > 0){
			LOGGER.info("store procs starts");
			promoClaimsRepository.insertIntoPromoClaim(accountName,moc);
			posDataRepository.insertIntoPOSData(accountName,moc);
			pos_vs_PrimaryrRepository.insertIntoPOS_VS_Primary(accountName, moc);
			baseWorkingRepository.insertIntoBaseworking(accountName,moc);
			overrunClaimRepository.insertIntoOverrunClaim(accountName,moc);
			promoClaimSummaryRepository.insertIntoPromoClaimSummary(accountName,moc);
			LOGGER.info("store procs end");
		}	


		Integer claimSummaryData = promoClaimSummaryRepository.findPromoClaimSummaryByAccountMOC(accountName, moc);
		Integer overrunClaimData = overrunClaimRepository.findOverrunClaimByAccountMOC(accountName, moc);
		Integer baseworkingData = baseWorkingRepository.findBaseworkingByAccountMOC(accountName, moc);

		if(claimSummaryData > 0 && overrunClaimData > 0 && baseworkingData > 0){
			resps.setMessage("Calculation Completed For "+accountName+" "+moc);
		}else{
			resps.setMessage("Incorrect file upload For "+accountName+" "+moc);
		}
		
		return resps;


	}

	//Added By Sarin Jun2022 - Excel file validation for POS file - begins
	public boolean validateUploadedPosFile(List<PosDataStage> posStageDetail, String accountName) {
		String sArticleCodeColumn = "", sBillQtyColumn = "";
		List<PosDataFieldMapping> lstFieldMapping = posDataFieldMappingRepository.getPosFileColumnValuesByAccount(accountName); 
		
		for(PosDataFieldMapping posDataFieldMapping : lstFieldMapping){
			System.out.println(posDataFieldMapping.getAccountName() + " " + posDataFieldMapping.getFieldName() + " " + posDataFieldMapping.getFieldValue());
			
			if (posDataFieldMapping.getFieldName().equalsIgnoreCase("ARTICLE_CODE")) {
				sArticleCodeColumn = posDataFieldMapping.getFieldValue().trim();
			} else if (posDataFieldMapping.getFieldName().equalsIgnoreCase("BILL_QTY")) {
				sBillQtyColumn = posDataFieldMapping.getFieldValue().trim();
			} 
		}
		
		boolean errorFound = false; int iFirstRow = 0;
		String sArticleCodeError = "", sBillQtyError = "";
		List<PromoClaimStageFileValidate> lstPosDataStageFileDetails = new ArrayList<PromoClaimStageFileValidate>();
		
		for(PosDataStage posDataStage: posStageDetail){
			//System.out.println(promoClaimStage.getRecordID() + " " + promoClaimStage.getColumnA() + " " + promoClaimStage.getColumnC());
			
			sArticleCodeError = ""; sBillQtyError = "";
			PromoClaimStageFileValidate posDataStageFileValidate = new PromoClaimStageFileValidate(null,
					posDataStage.getColumnA(), posDataStage.getColumnB(), posDataStage.getColumnC(),
					posDataStage.getColumnD(), posDataStage.getColumnE(), posDataStage.getColumnF(),
					posDataStage.getColumnG(), posDataStage.getColumnH(), posDataStage.getColumnI(),
					posDataStage.getColumnJ(), posDataStage.getColumnK(), posDataStage.getColumnL(),
					posDataStage.getColumnM(), posDataStage.getColumnN(), posDataStage.getColumnO(),
					posDataStage.getColumnP(), posDataStage.getColumnQ(), posDataStage.getColumnR(),
					posDataStage.getColumnS(), posDataStage.getColumnT(), posDataStage.getColumnU(),
					posDataStage.getColumnV(), posDataStage.getColumnW(), posDataStage.getColumnX(),
					posDataStage.getColumnY(), posDataStage.getColumnZ(), posDataStage.getColumnAA(),
					posDataStage.getColumnAB(), posDataStage.getColumnAC(), posDataStage.getColumnAD(),
					posDataStage.getColumnAE(), posDataStage.getColumnAF(), posDataStage.getColumnAG(),
					posDataStage.getColumnAH(), posDataStage.getColumnAI(), posDataStage.getColumnAJ(),
					posDataStage.getColumnAK(), posDataStage.getColumnAL(), posDataStage.getColumnAM(),
					posDataStage.getColumnAN(), posDataStage.getColumnAO(), posDataStage.getColumnAP(),
					posDataStage.getColumnAQ(), posDataStage.getColumnAR(), posDataStage.getColumnAS(),
					posDataStage.getColumnAT(), posDataStage.getColumnAU(), posDataStage.getColumnAV(),
					posDataStage.getColumnAW(), posDataStage.getColumnAX(), posDataStage.getColumnAY(),
					posDataStage.getColumnAZ(), posDataStage.getNoOfColumns(), null, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
					accountName, "POS");
			
			if (iFirstRow > 0) {
				
				//Article Code error check
				switch (sArticleCodeColumn) {
				case "COLUMN_A":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnA(), false);
					break;
				case "COLUMN_B":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnB(), false);
					break;
				case "COLUMN_C":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnC(), false);
					break;
				case "COLUMN_D":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnD(), false);
					break;
				case "COLUMN_E":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnE(), false);
					break;
				case "COLUMN_F":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnF(), false);
					break;
				case "COLUMN_G":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnG(), false);
					break;
				case "COLUMN_H":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnH(), false);
					break;
				case "COLUMN_I":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnI(), false);
					break;
				case "COLUMN_J":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnJ(), false);
					break;
				case "COLUMN_K":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnK(), false);
					break;
				case "COLUMN_L":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnL(), false);
					break;
				case "COLUMN_M":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnM(), false);
					break;
				case "COLUMN_N":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnN(), false);
					break;
				case "COLUMN_O":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnO(), false);
					break;
				case "COLUMN_P":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnP(), false);
					break;
				case "COLUMN_Q":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnQ(), false);
					break;
				case "COLUMN_R":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnR(), false);
					break;
				case "COLUMN_S":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnS(), false);
					break;
				case "COLUMN_T":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnT(), false);
					break;
				case "COLUMN_U":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnU(), false);
					break;
				case "COLUMN_V":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnV(), false);
					break;
				case "COLUMN_W":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnW(), false);
					break;
				case "COLUMN_X":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnX(), false);
					break;
				case "COLUMN_Y":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnY(), false);
					break;
				case "COLUMN_Z":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnZ(), false);
					break;
				case "COLUMN_AA":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAA(), false);
					break;
				case "COLUMN_AB":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAB(), false);
					break;
				case "COLUMN_AC":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAC(), false);
					break;
				case "COLUMN_AD":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAD(), false);
					break;
				case "COLUMN_AE":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAE(), false);
					break;
				case "COLUMN_AF":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAF(), false);
					break;
				case "COLUMN_AG":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAG(), false);
					break;
				case "COLUMN_AH":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAH(), false);
					break;
				case "COLUMN_AI":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAI(), false);
					break;
				case "COLUMN_AJ":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAJ(), false);
					break;
				case "COLUMN_AK":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAK(), false);
					break;
				case "COLUMN_AL":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAL(), false);
					break;
				case "COLUMN_AM":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAM(), false);
					break;
				case "COLUMN_AN":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAN(), false);
					break;
				case "COLUMN_AO":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAO(), false);
					break;
				case "COLUMN_AP":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAP(), false);
					break;
				case "COLUMN_AQ":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAQ(), false);
					break;
				case "COLUMN_AR":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAR(), false);
					break;
				case "COLUMN_AS":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAS(), false);
					break;
				case "COLUMN_AT":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAT(), false);
					break;
				case "COLUMN_AU":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAU(), false);
					break;
				case "COLUMN_AV":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAV(), false);
					break;
				case "COLUMN_AW":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAW(), false);
					break;
				case "COLUMN_AX":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAX(), false);
					break;
				case "COLUMN_AY":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAY(), false);
					break;
				case "COLUMN_AZ":
					sArticleCodeError = validateExcelColumns(posDataStage.getColumnAZ(), false);
					break;
				}
				if (sArticleCodeError.length() > 0) {
					sArticleCodeError = "Article Code " + sArticleCodeError + " ";
					errorFound = true;
				}

				//Bill Qty error check
				switch (sBillQtyColumn) {
				case "COLUMN_A":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnA(), true);
					break;
				case "COLUMN_B":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnB(), true);
					break;
				case "COLUMN_C":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnC(), true);
					break;
				case "COLUMN_D":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnD(), true);
					break;
				case "COLUMN_E":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnE(), true);
					break;
				case "COLUMN_F":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnF(), true);
					break;
				case "COLUMN_G":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnG(), true);
					break;
				case "COLUMN_H":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnH(), true);
					break;
				case "COLUMN_I":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnI(), true);
					break;
				case "COLUMN_J":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnJ(), true);
					break;
				case "COLUMN_K":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnK(), true);
					break;
				case "COLUMN_L":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnL(), true);
					break;
				case "COLUMN_M":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnM(), true);
					break;
				case "COLUMN_N":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnN(), true);
					break;
				case "COLUMN_O":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnO(), true);
					break;
				case "COLUMN_P":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnP(), true);
					break;
				case "COLUMN_Q":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnQ(), true);
					break;
				case "COLUMN_R":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnR(), true);
					break;
				case "COLUMN_S":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnS(), true);
					break;
				case "COLUMN_T":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnT(), true);
					break;
				case "COLUMN_U":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnU(), true);
					break;
				case "COLUMN_V":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnV(), true);
					break;
				case "COLUMN_W":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnW(), true);
					break;
				case "COLUMN_X":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnX(), true);
					break;
				case "COLUMN_Y":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnY(), true);
					break;
				case "COLUMN_Z":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnZ(), true);
					break;
				case "COLUMN_AA":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAA(), true);
					break;
				case "COLUMN_AB":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAB(), true);
					break;
				case "COLUMN_AC":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAC(), true);
					break;
				case "COLUMN_AD":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAD(), true);
					break;
				case "COLUMN_AE":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAE(), true);
					break;
				case "COLUMN_AF":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAF(), true);
					break;
				case "COLUMN_AG":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAG(), true);
					break;
				case "COLUMN_AH":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAH(), true);
					break;
				case "COLUMN_AI":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAI(), true);
					break;
				case "COLUMN_AJ":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAJ(), true);
					break;
				case "COLUMN_AK":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAK(), true);
					break;
				case "COLUMN_AL":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAL(), true);
					break;
				case "COLUMN_AM":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAM(), true);
					break;
				case "COLUMN_AN":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAN(), true);
					break;
				case "COLUMN_AO":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAO(), true);
					break;
				case "COLUMN_AP":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAP(), true);
					break;
				case "COLUMN_AQ":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAQ(), true);
					break;
				case "COLUMN_AR":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAR(), true);
					break;
				case "COLUMN_AS":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAS(), true);
					break;
				case "COLUMN_AT":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAT(), true);
					break;
				case "COLUMN_AU":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAU(), true);
					break;
				case "COLUMN_AV":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAV(), true);
					break;
				case "COLUMN_AW":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAW(), true);
					break;
				case "COLUMN_AX":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAX(), true);
					break;
				case "COLUMN_AY":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAY(), true);
					break;
				case "COLUMN_AZ":
					sBillQtyError = validateExcelColumns(posDataStage.getColumnAZ(), true);
					break;
				}
				if (sBillQtyError.length() > 0) {
					sBillQtyError = "Bill Qty " + sBillQtyError + " ";
					errorFound = true;
				}

			}
			iFirstRow++;
			
			posDataStageFileValidate.setErrorMsg(sArticleCodeError + sBillQtyError);
			
			lstPosDataStageFileDetails.add(posDataStageFileValidate);
		}
		
		if (errorFound) {
			//promoClaimStageFileValidateRepository.deletePromoClaimStageFileValidate();
			promoClaimStageFileValidateRepository.saveAll(lstPosDataStageFileDetails);
		}
		
		return errorFound;
	}
	//Added By Sarin Jun2021 - Excel file validation for Claim file - ends
	
	public ResponseMessage savePosData(MultipartFile file,String accountName,String moc) {

		ResponseMessage resps = new ResponseMessage();
		String currentLoadTime = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss").format(new Date());
		boolean isUploadOnly = true; //Added By Sarin Mar2022 - POS File KAM Approval - variable used to restrict calculation from customer login

		try{
			LOGGER.info("LOGIC FOR POS UPLOAD STARTS HERE");
			//List<PosDataStage> posDataStageDetails = PromoClaimExcelHelper.excelToPosDataStage(file.getInputStream());
			//Added By Harsha Aug2021 - Excel file validation for Claim file - starts
			List<PosDataStage> posDataStageDetails = null;
			System.out.println("Promo claim file size: " + bytesToMeg(file.getSize()));
			if(bytesToMeg(file.getSize())>= fileSizeDecider) {
				posDataStageDetails = PromoClaimExcelHelper.excelToPosDataStageLargeFile(file.getInputStream());
			} else {
				posDataStageDetails = PromoClaimExcelHelper.excelToPosDataStage(file.getInputStream());
			}
			System.out.println("Promo claim stage list size: " + bytesToMeg(posDataStageDetails.size()));
			//Added By Harsha Aug2021 - Excel file validation for Claim file - ends
			
			//Added By Sarin Jun2022 - Excel file validation for POS file - starts
			promoClaimStageFileValidateRepository.deletePromoClaimStageFileValidate(accountName, "POS");  //Added By Sarin Jun2022 - Excel file validation for POS file
			if (validateUploadedPosFile(posDataStageDetails, accountName)) {
				resps.setMessage("Incorrect file format upload For "+accountName+" "+moc);
				return resps;
			}
			//Remove header row
			posDataStageDetails.remove(0);
			//Added By Sarin Jun2022 - Excel file validation for POS file - ends
			
			Integer posDataCount = posDataStageRepository.findCountPosDataStage();
			Integer fileNo = posFileUploadMasterRepository.findFileNo(accountName, moc);
			Integer posStageData = posDataStageRepository.findCountPosDataStageDataByAccountAndMoc(accountName, moc);
			Integer posfileUploadMasterNo = posFileUploadMasterRepository.findCountPosFileUploadMaster(accountName, moc);


			PosFileUploadMaster posFileUploadMaster = new PosFileUploadMaster();
			posFileUploadMaster.setAccountName(accountName);
			posFileUploadMaster.setMoc(moc);

			if(posfileUploadMasterNo>0){
				posFileUploadMaster.setWorkflowStageId(2);
			}else{
				posFileUploadMaster.setWorkflowStageId(1);
			}

			posFileUploadMaster.setUploadBy(accountName);
			posFileUploadMaster.setUploadDate(currentLoadTime);

			for(PosDataStage posDataStage : posDataStageDetails){
				posDataStage.setAccountName(accountName);
				posDataStage.setMoc(moc);
				posDataStage.setLoadDate(currentLoadTime);
				posDataStage.setUploadBy(accountName);
				if(fileNo == null){
					posDataStage.setFileNo(1);

				}else{
					posDataStage.setFileNo(fileNo+1);

				}

				if(posfileUploadMasterNo == null){
					posFileUploadMaster.setFileNo(1);
					posFileUploadMaster.setS3Path("1_" + moc+"_"+accountName+"_"+file.getOriginalFilename());  //Added By Sarin Jul2021 - Claim File B2C Approval
				}else{
					posFileUploadMaster.setFileNo(posfileUploadMasterNo+1);
					posFileUploadMaster.setS3Path((posfileUploadMasterNo+1) + "_" + moc+"_"+accountName+"_"+file.getOriginalFilename());  //Added By Sarin Jul2021 - Claim File B2C Approval
				}


				if(posStageData>0){
					posDataStage.setWorkflowStageID(2);
				}else{
					posDataStage.setWorkflowStageID(1);
				}

			}

			//Added By Sarin Jul2021 - Claim File B2C Approval - Starts
			Integer fileNum = 0;
			if (fileNo == null) {
				fileNum = 1;
			} else {
				fileNum = fileNo + 1;
			}
			
			posDataStageRepository.deletePosDataStageByAccountAndMoc(accountName, moc);
			//Added By Sarin Jul2021 - Claim File B2C Approval - Ends

			if(posDataCount>0){
				LOGGER.info("INSERT INTO POS FILE UPLOAD MASTER TABLE STARTS HERE");
				posFileUploadMasterRepository.save(posFileUploadMaster);
				LOGGER.info("INSERT INTO POS FILE UPLOAD MASTER TABLE ENDS HERE");
				LOGGER.info("INSERT INTO POS DATA STAGE TABLE STARTS HERE");
				posDataStageRepository.saveAll(posDataStageDetails);
				LOGGER.info("INSERT INTO POS DATA STAGE TABLE ENDS HERE");
				LOGGER.info("UPLOAD PROMO POS FILE TO S3 STARTS");
				//uploadPosFile(file,accountName,moc);
				uploadPosFile(file,accountName,moc, fileNum);  //Added By Sarin Jul2021 - Claim File B2C Approval
				//executeRemoteShellScript();
				LOGGER.info("UPLOAD PROMO POS FILE TO S3 ENDS");
			}else{
				LOGGER.info("INSERT INTO POS FILE UPLOAD MASTER TABLE STARTS HERE");
				posFileUploadMasterRepository.save(posFileUploadMaster);
				LOGGER.info("INSERT INTO POS FILE UPLOAD MASTER TABLE ENDS HERE");
				LOGGER.info("INSERT INTO PROMO POS STAGE TABLE STARTS HERE");
				posDataStageRepository.saveAll(posDataStageDetails);
				LOGGER.info("INSERT INTO PROMO POS STAGE TABLE ENDS HERE");
				LOGGER.info("UPLOAD PROMO POS FILE TO S3 STARTS");
				//uploadPosFile(file,accountName,moc);
				uploadPosFile(file,accountName,moc, fileNum);  //Added By Sarin Jul2021 - Claim File B2C Approval
				//executeRemoteShellScript();
				LOGGER.info("UPLOAD PROMO POS FILE TO S3 ENDS");
			}
			
			//Added By Sarin Mar2022 - POS File KAM Approval - Starts
			if (isUploadOnly) {
				resps.setMessage("Pos File Uploaded, Calculation will initiate post KAM approval for "+accountName+" "+moc);
				return resps;	
			}
			//Added By Sarin Mar2022 - POS File KAM Approval - Ends
			
			//Added By Sarin Jul2021 - Claim File B2C Approval - Starts
			//Integer promoClaimFileCnt = prompClaimsFileUploadMasterRepository.findCountPromoClaimFileUploadMaster(accountName, moc);
			Integer posFileCnt = posFileUploadMasterRepository.findCountPosFileUploadMaster(accountName, moc);
			if (posFileCnt > 1) {
				resps.setMessage("Calculation will initiate post B2C approval For "+accountName+" "+moc);
				return resps;
			}
			//Added By Sarin Jul2021 - Claim File B2C Approval - Ends

			LOGGER.info("INSERT INTO POS MASTER STARTS");
			//posDataMasterRepository.insertPosDataByAccountName(accountName);     //Commented By Sarin Jul2021 - Claim File B2C Approval
			posDataMasterRepository.insertPosDataByAccountName(accountName, moc);  //Added By Sarin Jul2021 - Claim File B2C Approval
			LOGGER.info("INSERT INTO POS MASTER ENDS");


		}
		catch(Exception e){
			e.printStackTrace();
		}
		Integer promoClaimFileCount = prompClaimsFileUploadMasterRepository.findCountPromoClaimFileUploadMaster(accountName, moc);
		if(promoClaimFileCount > 0){
			promoClaimsRepository.insertIntoPromoClaim(accountName,moc);
			posDataRepository.insertIntoPOSData(accountName,moc);
			pos_vs_PrimaryrRepository.insertIntoPOS_VS_Primary(accountName, moc);
			baseWorkingRepository.insertIntoBaseworking(accountName,moc);
			overrunClaimRepository.insertIntoOverrunClaim(accountName,moc);
			promoClaimSummaryRepository.insertIntoPromoClaimSummary(accountName,moc);

		}
		
		Integer claimSummaryData = promoClaimSummaryRepository.findPromoClaimSummaryByAccountMOC(accountName, moc);
		Integer overrunClaimData = overrunClaimRepository.findOverrunClaimByAccountMOC(accountName, moc);
		Integer baseworkingData = baseWorkingRepository.findBaseworkingByAccountMOC(accountName, moc);
		
		if(claimSummaryData > 0 && overrunClaimData > 0 && baseworkingData > 0){
			resps.setMessage("Calculation Completed For "+accountName+" "+moc);
		}else{
			resps.setMessage("Incorrect file upload For "+accountName+" "+moc);
		}
		return resps;

	}
	
	public ResponseMessage validateFilesData(String accountName,String moc) {

		ResponseMessage resps = new ResponseMessage();
		
		try{
			Integer claimData = prompClaimsFileUploadMasterRepository.findCountPromoClaimFileUploadMaster(accountName, moc);
			Integer posData = posFileUploadMasterRepository.findCountPosFileUploadMaster(accountName, moc);
			
			//Added By Sarin Jul2021 - Claim File B2C Approval
			if (claimData > 1 || posData > 1) {
				//resps.setMessage("Calculation will initiate post B2C approval For "+accountName+" "+moc);  //Commented By Sarin Nov2021 - Claim File KAM Approval
				resps.setMessage("Calculation will initiate post KAM approval For "+accountName+" "+moc);    //Added By Sarin Nov2021 - Claim File KAM Approval
				return resps;
			}
			
			//if(accountName.equals("RELI")) {  //Commented & Added below By Sarin Jun2021 - Excel file validation for Claim file
			//if(accountName.equals("RELI") && (promoClaimStageFileValidateRepository.findCountPromoClaimStageFileValidate() == 0)) {  //Commented By Sarin Jun2022 - Excel file validation for POS file
			if(accountName.equals("RELI") && (promoClaimStageFileValidateRepository.findCountPromoClaimStageFileValidate(accountName, "CLAIM") == 0)) {  //Added By Sarin Jun2022 - Excel file validation for POS file
				resps.setMessage("Calculation Initiated..");				
			}
			if(!accountName.equals("RELI")) {
				//if(claimData > 0 && posData > 0){  //Commented & Added below By Sarin Jun2021 - Excel file validation for Claim file
				//if((claimData > 0 && posData > 0) && (promoClaimStageFileValidateRepository.findCountPromoClaimStageFileValidate() == 0)){  //Commented By Sarin Jun2022 - Excel file validation for POS file
				if((claimData > 0 && posData > 0) && (promoClaimStageFileValidateRepository.findCountPromoClaimStageFileValidate(accountName, "CLAIM") == 0)){  //Added By Sarin Jun2022 - Excel file validation for POS file
					resps.setMessage("Calculation Initiated..");
				}else{
					resps.setMessage("Sorry !! Calculation Not Initiated..");
				}								
			}
		
		}catch(Exception e){
			
		}
		return resps;
		
	}


	@Async
	//public void uploadFile(final MultipartFile multipartFile,String accountName,String moc) {
	public void uploadFile(final MultipartFile multipartFile,String accountName,String moc, Integer fileNo) {  //Added By Sarin Jul2021 - Claim File B2C Approval
		LOGGER.info("File upload in progress.");

		try {
			final File file = convertMultiPartFileToFile(multipartFile);
			//uploadFileToS3Bucket(bucketName, file,accountName,moc);
			//uploadFileToS3Bucket(bucketName, file,accountName,moc, fileNo);  //Added By Sarin Jul2021 - Claim File B2C Approval
			uploadFileToGcpBucket(bucketName, file,accountName,moc, fileNo);
			LOGGER.info("File upload is completed.");
			file.delete();	// To remove the file locally created in the project folder.
		} catch (IOException e) {
			LOGGER.info("File upload is failed.");
			LOGGER.error("Error= {} while uploading file.", e.getMessage());
		}

	}

	@Async
	//public void uploadPosFile(final MultipartFile multipartFile,String accountName,String moc) {
	public void uploadPosFile(final MultipartFile multipartFile,String accountName,String moc, Integer fileNo) {  //Added By Sarin Jul2021 - Claim File B2C Approval
		LOGGER.info("File upload in progress.");

		try {
			final File file = convertMultiPartFileToFile(multipartFile);
			//uploadFileToS3Bucket(posBucketName, file,accountName,moc);
			//uploadFileToS3Bucket(posBucketName, file,accountName,moc, fileNo);  //Added By Sarin Jul2021 - Claim File B2C Approval
			uploadPosFileToGcpBucket(bucketName, file,accountName,moc, fileNo);
			LOGGER.info("File upload is completed.");
			file.delete();	// To remove the file locally created in the project folder.
		} catch (IOException e) {
			LOGGER.info("File upload is failed.");
			LOGGER.error("Error= {} while uploading file.", e.getMessage());
		}

	}

	public void executeRemoteShellScript() {

		String REMOTE_HOST = "10.51.3.235";
		String USERNAME = "mtuser";
		String PASSWORD = "qG!qOBvD";
		int REMOTE_PORT = 22;
		int SESSION_TIMEOUT = 10000;
		int CHANNEL_TIMEOUT = 5000;
		String remoteShellScriptDir = "/root/hello.sh";

		Session jschSession = null;

		try {

			JSch jsch = new JSch();
			//jsch.setKnownHosts("/home/.ssh/known_hosts");
			jschSession = jsch.getSession(USERNAME, REMOTE_HOST, REMOTE_PORT);

			// not recommend, uses jsch.setKnownHosts
			jschSession.setConfig("StrictHostKeyChecking", "no");

			// authenticate using password
			jschSession.setPassword(PASSWORD);

			// 10 seconds timeout session
			jschSession.connect(SESSION_TIMEOUT);

			ChannelExec channelExec = (ChannelExec) jschSession.openChannel("exec");

			// run a shell script
			channelExec.setCommand("sh " + remoteShellScriptDir + " Hanna");

			// display errors to System.err
			channelExec.setErrStream(System.err);

			InputStream in = channelExec.getInputStream();

			// 5 seconds timeout channel
			channelExec.connect(CHANNEL_TIMEOUT);

			// read the result from remote server
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0) break;
					System.out.print(new String(tmp, 0, i));
				}
				if (channelExec.isClosed()) {
					if (in.available() > 0) continue;
					System.out.println("exit-status: "
							+ channelExec.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {
				}
			}

			channelExec.disconnect();

		} catch (JSchException | IOException e) {

			e.printStackTrace();

		} finally {
			if (jschSession != null) {
				jschSession.disconnect();
			}
		}

	}

	private File convertMultiPartFileToFile(final MultipartFile multipartFile) {
		final File file = new File(multipartFile.getOriginalFilename());
		try (final FileOutputStream outputStream = new FileOutputStream(file)) {
			outputStream.write(multipartFile.getBytes());
		} catch (final IOException ex) {
			LOGGER.error("Error converting the multi-part file to file= ", ex.getMessage());
		}
		return file;
	}

	//private void uploadFileToS3Bucket(final String bucketName, final File file,String accountName,String moc) {
	private void uploadFileToS3Bucket(final String bucketName, final File file,String accountName,String moc, Integer fileNo) {  //Added By Sarin Jul2021 - Claim File B2C Approval
		final String uniqueFileName = file.getName();
		LOGGER.info("Uploading file with name= " + uniqueFileName);
		//String filename= moc+"_"+accountName+"_"+uniqueFileName;
		String filename= fileNo + "_" + moc+"_"+accountName+"_"+uniqueFileName;  //Added By Sarin Jul2021 - Claim File B2C Approval
		final PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, filename,file);
		amazonS3.putObject(putObjectRequest);
	}

	private void uploadFileToGcpBucket(final String bucketName, final File file,String accountName,String moc, Integer fileNo) throws IOException {
		final String uniqueFileName = file.getName();
		LOGGER.info("Uploading file with name= " + uniqueFileName);
		String filename= "promo_claims/" + fileNo + "_" + moc+"_"+accountName+"_"+uniqueFileName;
		
		BlobId blobId = BlobId.of(gcpBucketName, filename);
		BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
		byte[] fileArr = Files.readAllBytes(java.nio.file.Paths.get(file.toURI()));
		gcpStorage.create(blobInfo, fileArr);
	}
	
	private void uploadPosFileToGcpBucket(final String bucketName, final File file,String accountName,String moc, Integer fileNo) throws IOException {
		final String uniqueFileName = file.getName();
		LOGGER.info("Uploading file with name= " + uniqueFileName);
		String filename= "promo_claims/pos/" + fileNo + "_" + moc+"_"+accountName+"_"+uniqueFileName;
		
		BlobId blobId = BlobId.of(gcpBucketName, filename);
		BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
		byte[] fileArr = Files.readAllBytes(java.nio.file.Paths.get(file.toURI()));
		gcpStorage.create(blobInfo, fileArr);
	}

	//====================================download from S3==================================================


	public byte[] downloadFile(String bucketName,String keyName) {
		/*
		S3Object obj = amazonS3.getObject(bucketName, keyName);
		S3ObjectInputStream stream = obj.getObjectContent();
		try {
			byte[] content = IOUtils.toByteArray(stream);
			obj.close();
			return content;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;
		*/ //Commented for GCP Migration
		
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		gcpStorage.get(bucketName, keyName).downloadTo(outputStream);
		return outputStream.toByteArray();
		
	}
	

}
