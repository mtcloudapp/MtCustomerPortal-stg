package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.AvailablePO;
import com.unilever.sales.model.PoInvoicedValue;

@Repository
public interface InvoicedValueLinesRepository extends JpaRepository<PoInvoicedValue, Integer>{

	@Transactional
    //@Query(value ="select sum(etas.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_INVOICED_TOTAL_VALUE etas  where etas.BRANCH in :region and etas.ACCOUNT in :account and etas.MOC in :moc and etas.CATEGORY in :category and etas.USERNAME=:username", nativeQuery = true)
	@Query(value ="select sum(etas.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_INVOICED_TOTAL_VALUE etas inner join USER_ACCOUNT_CATEGORY_MAPPING uac on etas.CATEGORY = uac.CATEGORY_NAME and etas.ACCOUNT = uac.ACCOUNT_NAME where etas.BRANCH in :region and etas.ACCOUNT in :account and etas.MOC in :moc and etas.CATEGORY in :category and uac.USERNAME=:username", nativeQuery = true)
	Double findInvoicedValueOfPo(@Param("region") List<String> region,@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("category") List<String> category,@Param("username") String username);

}
