package com.unilever.claims.upload.service;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.unilever.claims.b2c.repository.B2CClaimsRepository;
import com.unilever.claims.extenal.model.CpsMtFinaceView;
import com.unilever.claims.extenal.model.CpsMtFinanceDto;
import com.unilever.claims.extenal.model.ExternalPaymentStatus;
import com.unilever.claims.extenal.model.ExternalServiceNoteDetails;
import com.unilever.claims.extenal.model.ExternalServiceNoteMaster;
import com.unilever.claims.external.repository.ExternalServiceNoteDetailsRepository;
import com.unilever.claims.external.repository.ExternalServiceNoteMasterRepository;
import com.unilever.claims.external.repository.ExternalServiceNoteRepository;
import com.unilever.claims.external.service.ExternalClaimsExcelHelper;
import com.unilever.message.ResponseMessage;
import com.unilever.upload.model.StoreListCurrentDetails;
import com.unilever.upload.model.StoreListDetails;
import com.unilever.upload.service.ExcelHelper;


@Service
public class ExernalServiceNoteUploadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExernalServiceNoteUploadService.class);

	@Autowired
	private AmazonS3 amazonS3;

	@Value("${aws.s3.bucket}")
	private String bucketName;

	@Autowired
	private ExternalServiceNoteRepository externalServiceNoteRepository;

	@Autowired
	private ExternalServiceNoteMasterRepository externalServiceNoteMasterRepository;

	@Autowired
	private B2CClaimsRepository b2CClaimsRepository;

	@Autowired
	private ExternalServiceNoteDetailsRepository externalServiceNoteDetailsRepository;




	//==================================KAM /Internal  Views================================================

	public List<CpsMtFinanceDto> getKamAssetClaimView(List<String> account,List<String> region,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){

		List<CpsMtFinanceDto> cpsMtFinanceDtoList = new ArrayList<CpsMtFinanceDto>();
		String channels = "Green Channel";
		List<CpsMtFinaceView> totalRecords = new ArrayList<CpsMtFinaceView>();
		try{

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocAndChannel(moc, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocAndChannel(moc, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}

			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocCategoryAndChannel(moc, channels, category, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocCategoryAndChannel(moc, channels, category);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}


			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocAccountChannel(moc, account, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocAccountChannel(moc, account, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocCategoryAccountChannel(moc, account, category, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocCategoryAccountChannel(moc, account, category, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}


			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocRegionAndChannel(moc, channels, region, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocRegionAndChannel(moc, channels, region);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocRegionAccountChannel(moc, account, region, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocRegionAccountChannel(moc, account, region, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocRegionCategoryChannel(moc, channels, region, category, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocRegionCategoryChannel(moc, channels, region, category);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}

			}


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocRegionCategoryAccountChannel(moc, account, region, category, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocRegionCategoryAccountChannel(moc, account, region, category, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}

		}catch(Exception e){
			e.printStackTrace();
		}

		return cpsMtFinanceDtoList;


	}



	//==================================Customer/External Views================================================

	public List<CpsMtFinanceDto> getExternalAssetClaimView(String account,List<String> region,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){

		List<CpsMtFinanceDto> cpsMtFinanceDtoList = new ArrayList<CpsMtFinanceDto>();
		String channels = "Green Channel";
		List<CpsMtFinaceView> totalRecords = new ArrayList<CpsMtFinaceView>();

		try{

			if(account !=null && region.get(0).equals("All")  && category.get(0).equals("All") && moc !=null){//1

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByExternalMocAccountChannel(moc, account, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByExternalMocAccountChannel(moc, account, channels);
				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}//end of if

			if(account !=null && region !=null  && moc !=null && category.get(0).equals("All") ){//2

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByExternalMocRegionAccountChannel(moc, account, region, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByExternalMocRegionAccountChannel(moc, account, region, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}


			}//end of if

			if(account !=null && region.get(0).equals("All")  && moc !=null && category != null){//3

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByExternalMocCategoryAccountChannel(moc, account, category, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByExternalMocCategoryAccountChannel(moc, account, category, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}


			}//end of if

			if(account !=null && region !=null  && moc !=null && category != null){//4

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByExternalMocRegionCategoryAccountChannel(moc, account, region, category, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByExternalMocRegionCategoryAccountChannel(moc, account, region, category, channels);
				
				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}


			}//end of if


		}catch(Exception e){
			e.printStackTrace();
		}

		return cpsMtFinanceDtoList;
	}




	//==================================B2C Views================================================

	public List<CpsMtFinanceDto> getB2CAssetClaimView(List<String>region,List<String>account, List<String> moc,List<String> category, Integer pageNo, Integer pageSize){

		List<CpsMtFinanceDto> cpsMtFinanceDtoList = new ArrayList<CpsMtFinanceDto>();
		String channels = "Green Channel";
		List<CpsMtFinaceView> totalRecords = new ArrayList<CpsMtFinaceView>();
		try{


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocAndChannel(moc, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocAndChannel(moc, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}

			}//end of if

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocCategoryAndChannel(moc, channels, category, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocCategoryAndChannel(moc, channels, category);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}//end of if

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocAccountChannel(moc, account, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocAccountChannel(moc, account, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}//end of if


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocCategoryAccountChannel(moc, account, category, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocCategoryAccountChannel(moc, account, category, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}


			}//end of if

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocRegionAndChannel(moc, channels, region, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocRegionAndChannel(moc, channels, region);


				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}
			}//end of if

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocRegionAccountChannel(moc, account, region, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocRegionAccountChannel(moc, account, region, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}//end of if

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByMocRegionCategoryChannel(moc, channels, region, category, paging);
				totalRecords = externalServiceNoteRepository.findCountByMocRegionCategoryChannel(moc, channels, region, category);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}

				}

			}//end of if


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<CpsMtFinaceView> cpsMtFinanceViewList = externalServiceNoteRepository.findByKamMocRegionCategoryAccountChannel(moc, account, region, category, channels, paging);
				totalRecords = externalServiceNoteRepository.findCountByKamMocRegionCategoryAccountChannel(moc, account, region, category, channels);

				if(cpsMtFinanceViewList.hasContent()){ 
					Double totalPaybleAmt = 0.00;
					Double claimRaised = 0.00;
					Double paidAmt = 0.00;
					Double pendingAmt = 0.00;
					for(CpsMtFinaceView cmf : cpsMtFinanceViewList){
						CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
						totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode(),cmf.getChannels());
						claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(cmf.getSolCode(),cmf.getStateCode());
						paidAmt = b2CClaimsRepository.findPaidAmtBySolcodeAndState(cmf.getSolCode(),cmf.getStateCode());

						if(paidAmt == null){
							cpsMtFinanceDto.setPaidAmt(0.00);
							cpsMtFinanceDto.setPendingAmt(totalPaybleAmt);
						}else{
							cpsMtFinanceDto.setPaidAmt(paidAmt);
							pendingAmt = totalPaybleAmt-paidAmt;
							cpsMtFinanceDto.setPendingAmt(pendingAmt);
						}

						if(claimRaised == null){
							claimRaised=0.0;
						}
						cpsMtFinanceDto.setAccountName(cmf.getAccount());
						cpsMtFinanceDto.setSolCode(cmf.getSolCode());
						cpsMtFinanceDto.setState(cmf.getStateCode());
						cpsMtFinanceDto.setMoc(cmf.getMoc());
						cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
						cpsMtFinanceDto.setClaimRaised(claimRaised);
						cpsMtFinanceDto.setTotalRecords(totalRecords.size());
						cpsMtFinanceDtoList.add(cpsMtFinanceDto);

					}



				}

			}//end of if




		}catch(Exception e){
			e.getStackTrace();
		}


		return cpsMtFinanceDtoList;

	}



	public ExternalServiceNoteDetails getLastFileDetails(String solcode,String state){

		ExternalServiceNoteDetails	externalServiceNoteDetails = new ExternalServiceNoteDetails();
		try{
			ExternalServiceNoteDetails fileDetails = externalServiceNoteDetailsRepository.findLastUplodedFile(solcode,state);
			externalServiceNoteDetails.setInvoiceNo(fileDetails.getInvoiceNo());
			externalServiceNoteDetails.setFileName(fileDetails.getFileName());
			externalServiceNoteDetails.setUploadTime(fileDetails.getUploadTime());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return externalServiceNoteDetails;

	}





	public ResponseMessage save(final MultipartFile multipartFile,String invoiceNo,Double baseAmt,
			Double taxAmt,String solCode,String state,Double payableAmt,String account, String moc,
			Integer count,String response){

		ResponseMessage resps = new ResponseMessage();

		try {
			Double claimRaised = 0.00;
			Double claimRaisedAmt = 0.00;
			String channels = "Green Channel";
			ExternalServiceNoteMaster externalServiceNoteMaster = new ExternalServiceNoteMaster();
			ExternalServiceNoteDetails externalServiceNoteDetails = new ExternalServiceNoteDetails();
			CpsMtFinaceView cpsMtFinaceView = new CpsMtFinaceView();
			
			String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			LinkedList<String> invoiceNos = new LinkedList<String>();
			if(externalServiceNoteMasterRepository.findStoreMasterDetails(solCode).size()>0){
				invoiceNos = externalServiceNoteMasterRepository.findInvoiceNos();
			}

			claimRaised = externalServiceNoteMasterRepository.findClaimRaisedBySoleCodeAndState(solCode,state);
			cpsMtFinaceView = externalServiceNoteRepository.findRegionCategoryBySolcodeAndState(state, solCode, channels);
			
					
			if(count == 1){

				if(invoiceNos.contains(invoiceNo)) {
					resps.setMessage("Sorry! Invoice No has already taken");
					return resps;
				}	
				
				if(claimRaised != null){
					claimRaisedAmt = claimRaised+baseAmt+taxAmt;
					
				}else{
					claimRaisedAmt = baseAmt+taxAmt;
				}
				
			  	if(payableAmt>=claimRaisedAmt){
					externalServiceNoteMaster.setSolCOde(solCode);
					externalServiceNoteMaster.setStateCode(state);
					externalServiceNoteMaster.setClaimsRaised(claimRaisedAmt);
					externalServiceNoteMaster.setInvoiceNo(invoiceNo);
					externalServiceNoteMaster.setBaseAmt(baseAmt);
					externalServiceNoteMaster.setTaxAmt(taxAmt);
					externalServiceNoteMaster.setAccount(account);
					externalServiceNoteMaster.setMoc(moc);
					externalServiceNoteMaster.setRegion(cpsMtFinaceView.getBranch());
					externalServiceNoteMaster.setCategory(cpsMtFinaceView.getCategory());
					externalServiceNoteDetails.setFileName(multipartFile.getOriginalFilename());
					externalServiceNoteDetails.setSolCOde(solCode);
					externalServiceNoteDetails.setState(state);
					externalServiceNoteDetails.setUploadTime(timeStamp);
					externalServiceNoteDetails.setInvoiceNo(invoiceNo);
					externalServiceNoteMasterRepository.save(externalServiceNoteMaster);
					externalServiceNoteDetailsRepository.save(externalServiceNoteDetails);
					uploadFile(multipartFile,solCode,state);
					resps.setMessage("Success");

				}

				else{
					resps.setMessage("Claim Raised Should not  exceed Total Payable Amount");
				}
			  
			 
			
			}

			if(count>1 && response.equals("Success")){
				externalServiceNoteDetails.setFileName(multipartFile.getOriginalFilename());
				externalServiceNoteDetails.setSolCOde(solCode);
				externalServiceNoteDetails.setState(state);
				externalServiceNoteDetails.setUploadTime(timeStamp);
				externalServiceNoteDetails.setInvoiceNo(invoiceNo);
				externalServiceNoteDetailsRepository.save(externalServiceNoteDetails);
				uploadFile(multipartFile,solCode,state);

				resps.setMessage("Success");
			}

		} catch (final AmazonServiceException ex) {
			LOGGER.info("File upload is failed.");
			LOGGER.error("Error= {} while uploading file.", ex.getMessage());
		}
		return resps;

	}



	@Async
	public void uploadFile(final MultipartFile multipartFile,String solCode,String state) {
		LOGGER.info("File upload in progress.");


		try {
			final File file = convertMultiPartFileToFile(multipartFile);
			uploadFileToS3Bucket(bucketName, file,solCode,state);
			LOGGER.info("File upload is completed.");
			file.delete();	// To remove the file locally created in the project folder.
		} catch (final AmazonServiceException ex) {
			LOGGER.info("File upload is failed.");
			LOGGER.error("Error= {} while uploading file.", ex.getMessage());
		}

	}


	private File convertMultiPartFileToFile(final MultipartFile multipartFile) {
		final File file = new File(multipartFile.getOriginalFilename());
		try (final FileOutputStream outputStream = new FileOutputStream(file)) {
			outputStream.write(multipartFile.getBytes());
		} catch (final IOException ex) {
			LOGGER.error("Error converting the multi-part file to file= ", ex.getMessage());
		}
		return file;
	}

	private void uploadFileToS3Bucket(final String bucketName, final File file,String solCode,String state) {
		final String uniqueFileName = solCode+"_"+file.getName();
		LOGGER.info("Uploading file with name= " + uniqueFileName);
		final PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, uniqueFileName, file);
		amazonS3.putObject(putObjectRequest);
	}

	//=======================================Excel upload by b2c===============================================

	public ResponseMessage uploadByB2C(MultipartFile file){

		ResponseMessage resps = new ResponseMessage();
		try{
		Double paidAmount = 0.00;
		Double paidAmnt=0.00;
		Double actualPaidAmnt=0.00;
		List<String> invoiceList = new ArrayList<String>();
		List<ExternalPaymentStatus> externalPaymentStatus = ExternalClaimsExcelHelper.excelToExternalPaymentStatus(file.getInputStream());
		invoiceList = externalServiceNoteMasterRepository.findInvoiceNos();
		for(ExternalPaymentStatus e : externalPaymentStatus){
		Double sumOfBaseAmtTaxAmt = externalServiceNoteMasterRepository.findBaseAmtTaxAmtByInvoiceNo(e.getInvoiceNo());
		ExternalServiceNoteMaster externalServiceNoteMaster = externalServiceNoteMasterRepository.findSolCodeAndStateByInvoiceNo(e.getInvoiceNo());
		if(!invoiceList.contains(e.getInvoiceNo())){
		resps.setMessage("Sorry! Invoice No does not exist");
		return resps;
		}else{
		e.setSoleCode(externalServiceNoteMaster.getSolCOde());
		e.setState(externalServiceNoteMaster.getStateCode());
		e.setAccount(externalServiceNoteMaster.getAccount());
		e.setMoc(externalServiceNoteMaster.getMoc());
		e.setRegion(externalServiceNoteMaster.getRegion());
		e.setCategory(externalServiceNoteMaster.getCategory());
		e.setActualPaidAmt(e.getPaidAmt());

		}

		if(e.getPaidAmt()>sumOfBaseAmtTaxAmt){
		resps.setMessage("Paid amt should be lesser than or equals to sum of base amt and tax Amt");
		return resps;
		}
		paidAmount = b2CClaimsRepository.findPaidAmtByInvoiceNo(e.getInvoiceNo());
		if(paidAmount != null){
		actualPaidAmnt = b2CClaimsRepository.findActualPaidAmtByInvoiceNo(e.getInvoiceNo());
		paidAmnt = paidAmount+e.getPaidAmt();
		if(paidAmnt<=sumOfBaseAmtTaxAmt){
		  if(!e.getPaidAmt().equals(actualPaidAmnt)){
		b2CClaimsRepository.updatePaidAmt(e.getInvoiceNo(),paidAmnt,e.getPaidAmt());
		resps.setMessage("Success");
		  }else if(e.getPaidAmt().equals(actualPaidAmnt)){
		  b2CClaimsRepository.updatePaidAmt(e.getInvoiceNo(),paidAmnt,e.getPaidAmt());
		  resps.setMessage("Success");
		}
		}else{
		resps.setMessage("Paid amt should be lesser than or equals to sum of base amt and tax Amt");
		return resps;
		}
		}else{
		List<ExternalPaymentStatus> paymentStatus = new ArrayList<ExternalPaymentStatus>();
		List<ExternalPaymentStatus> paymentStatusList = new ArrayList<ExternalPaymentStatus>();
		ExternalPaymentStatus extPaymentStatus = new ExternalPaymentStatus();
		paymentStatus = b2CClaimsRepository.findExternalPymentDetails();
		extPaymentStatus.setInvoiceNo(e.getInvoiceNo());
		extPaymentStatus.setSoleCode(externalServiceNoteMaster.getSolCOde());
		extPaymentStatus.setState(externalServiceNoteMaster.getStateCode());
		extPaymentStatus.setAccount(externalServiceNoteMaster.getAccount());
		extPaymentStatus.setMoc(externalServiceNoteMaster.getMoc());
		extPaymentStatus.setRegion(externalServiceNoteMaster.getRegion());
		extPaymentStatus.setCategory(externalServiceNoteMaster.getCategory());
		extPaymentStatus.setActualPaidAmt(e.getPaidAmt());
		extPaymentStatus.setPaidAmt(e.getPaidAmt());
		paymentStatusList.add(extPaymentStatus);
		paymentStatusList.addAll(paymentStatus);
		b2CClaimsRepository.saveAll(paymentStatusList);
		resps.setMessage("Success");
		}
		}//end of for
		/*if(paidAmount == null){
		b2CClaimsRepository.saveAll(externalPaymentStatus);
		   resps.setMessage("Success");
		}*/
		}
		catch(Exception e){
		e.getStackTrace();
		}

		return resps;

		}

	//====================================download by b2c==================================================

	public InputStream downloadFileAsStream(String bucketName, String objectKey) {


		try {
			GetObjectRequest s3ObjectReq = new GetObjectRequest(bucketName, objectKey);
			long startTime=System.currentTimeMillis();
			S3Object downlodedObjectMD = amazonS3.getObject(s3ObjectReq);
			LOGGER.info("Time to load Stream is "+(System.currentTimeMillis()-startTime)+" ms");
			return downlodedObjectMD.getObjectContent();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//====================================download claim history by b2c==================================================

	public ByteArrayInputStream getClaimHistory(String solCode, String state) {
		String channels = "Green Channel";
		List<CpsMtFinanceDto> cpsMtFinanceDtoList = new ArrayList<CpsMtFinanceDto>();
		List<ExternalServiceNoteMaster> externalServiceNoteMaster = new ArrayList<ExternalServiceNoteMaster>();
		externalServiceNoteMaster = externalServiceNoteMasterRepository.findBySoleCodeAndState(solCode, state);
		Double totalPaybleAmt = externalServiceNoteRepository.findB2CTotalAmountPayableBySoleCodeAndState(solCode,state,channels);

		for(ExternalServiceNoteMaster e : externalServiceNoteMaster){
			CpsMtFinanceDto cpsMtFinanceDto = new CpsMtFinanceDto();
			cpsMtFinanceDto.setAccountName(e.getAccount());
			cpsMtFinanceDto.setSolCode(e.getSolCOde());
			cpsMtFinanceDto.setMoc(e.getMoc());
			cpsMtFinanceDto.setState(e.getStateCode());
			cpsMtFinanceDto.setInvoiceNo(e.getInvoiceNo());
			cpsMtFinanceDto.setTotalPayableAmt(totalPaybleAmt);
			cpsMtFinanceDto.setBaseAmt(e.getBaseAmt());
			cpsMtFinanceDto.setTaxAmt(e.getTaxAmt());
			cpsMtFinanceDto.setClaimRaised(e.getClaimsRaised());

			cpsMtFinanceDtoList.add(cpsMtFinanceDto);
		}


		ByteArrayInputStream in = ExternalClaimsExcelHelper.claimHistoryToExcelByB2C(cpsMtFinanceDtoList);
		return in;
	}


}
