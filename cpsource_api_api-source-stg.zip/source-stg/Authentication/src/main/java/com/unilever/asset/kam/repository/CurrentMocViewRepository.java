package com.unilever.asset.kam.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.PreviousMocView;
import com.unilever.global.GlobalVariables;

@Repository
public interface CurrentMocViewRepository extends PagingAndSortingRepository<CurrentMocView, String> {

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.ACCOUNT in :accounts", nativeQuery = true)
	List<CurrentMocView> findAllCurrentMocViewByAccount(@Param("accounts") List<String> accounts);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm", nativeQuery = true)
	List<CurrentMocView> findAllCurrentMocViewDetails();
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMoc(@Param("moc") List<String> moc,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm where icm.MOC in :moc", nativeQuery = true)
	List<CurrentMocView> findCountByMoc(@Param("moc") List<String> moc);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocView> findCountByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm where icm.MOC in :moc and icm.ACCOUNT in :account", nativeQuery = true)
	List<CurrentMocView> findCountByAccount(@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMocAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocView> findCountByAccountMocCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm where icm.MOC in :moc and icm.REGION in :region", nativeQuery = true)
	List<CurrentMocView> findCountByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMocAccountRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region", nativeQuery = true)
	List<CurrentMocView> findCountByAccountMocRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocView> findAllCountCurrentMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocView> findAllCurrentMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_MOC icm  where icm.MOC in :moc and icm.ACCOUNT in :account and icm.REGION in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocView> findAllCountCurrentMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);
}
