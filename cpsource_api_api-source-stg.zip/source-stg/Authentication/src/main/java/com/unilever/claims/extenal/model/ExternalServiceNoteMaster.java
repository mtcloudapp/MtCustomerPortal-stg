package com.unilever.claims.extenal.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_SERVICE_NOTE_MASTER")
public class ExternalServiceNoteMaster implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8650020024381902562L;
	
	
	@Id
	@Column(name="INVOICE_NO")
    private String invoiceNo;
	
	@Column(name="SOL_CODE")
    private String solCOde;
	
	@Column(name="STATE")
    private String stateCode;
	
	@Column(name="MOC")
    private String moc;

	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="BASE_AMOUNT")
    private Double baseAmt;
	
	@Column(name="TAX_AMOUNT")
    private Double taxAmt;

	@Column(name="CLAIMS_RAISED")
    private Double claimsRaised;
	
	@Column(name="REGION")
    private String region;
	
	@Column(name="CATEGORY")
    private String category;
	
	
	public ExternalServiceNoteMaster() {
		super();
		// TODO Auto-generated constructor stub
	}



	public ExternalServiceNoteMaster(String invoiceNo, String solCOde, String stateCode, String moc, String account,
			Double baseAmt, Double taxAmt, Double claimsRaised, String region, String category) {
		super();
		this.invoiceNo = invoiceNo;
		this.solCOde = solCOde;
		this.stateCode = stateCode;
		this.moc = moc;
		this.account = account;
		this.baseAmt = baseAmt;
		this.taxAmt = taxAmt;
		this.claimsRaised = claimsRaised;
		this.region = region;
		this.category = category;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}


	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getSolCOde() {
		return solCOde;
	}

	public void setSolCOde(String solCOde) {
		this.solCOde = solCOde;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Double getBaseAmt() {
		return baseAmt;
	}

	public void setBaseAmt(Double baseAmt) {
		this.baseAmt = baseAmt;
	}

	public Double getTaxAmt() {
		return taxAmt;
	}

	public void setTaxAmt(Double taxAmt) {
		this.taxAmt = taxAmt;
	}


	public Double getClaimsRaised() {
		return claimsRaised;
	}


	public void setClaimsRaised(Double claimsRaised) {
		this.claimsRaised = claimsRaised;
	}



	public String getRegion() {
		return region;
	}



	public void setRegion(String region) {
		this.region = region;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}
	
	

	
}
