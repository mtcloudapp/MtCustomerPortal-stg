package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.global.GlobalVariables;

@Repository
public interface TotalAssetCreatedVolumeRepository extends JpaRepository<TotalAssetCreatedVolume, Integer>{
  
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tav where tav.USERNAME=:username", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeDetails(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
	
	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolume();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where  tac.MOC=:moc", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_ASSETS_CREATED_VOLUME tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<TotalAssetCreatedVolume> findAllTotalAssetCreatedVolumeByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		



}
