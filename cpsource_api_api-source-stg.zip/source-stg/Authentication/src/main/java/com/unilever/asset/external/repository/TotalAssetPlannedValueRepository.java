package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.TotalAssetPlannedValue;
import com.unilever.asset.external.model.TotalAssetPlannedValue;
import com.unilever.global.GlobalVariables;

@Repository
public interface TotalAssetPlannedValueRepository extends JpaRepository<TotalAssetPlannedValue, Integer>{
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_PLANNED_ASSETS_VALUE etas where etas.USERNAME=:username", nativeQuery = true)
	List<TotalAssetPlannedValue> findAllTotalAssetPlannedValueExternalDetails(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_PLANNED_ASSETS_VALUE etas where etas.USERNAME=:username and etas.MOC=:moc", nativeQuery = true)
	List<TotalAssetPlannedValue> findAllTotalAssetPlannedValueExternalDetailsByMoc(@Param("username") String username,@Param("moc") String moc);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_PLANNED_ASSETS_VALUE etas where etas.USERNAME=:username and etas.MOC=:moc and etas.CATEGORY_NAME=:category", nativeQuery = true)
	List<TotalAssetPlannedValue> findAllTotalAssetPlannedValueExternalDetailsByMocAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_PLANNED_ASSETS_VALUE etas where etas.USERNAME=:username and  etas.REGION_NAME=:region and etas.MOC=:moc", nativeQuery = true)
	List<TotalAssetPlannedValue> findAllTotalAssetPlannedValueExternalDetailsByRegionAndMoc(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);




}
