package com.unilever.promo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.asset.external.model.ExternalCurrentMocViewDto;
import com.unilever.asset.external.model.ExternalNextMocViewDto;
import com.unilever.asset.external.model.ExternalPreviousMocViewDto;
import com.unilever.promo.external.model.CurrentMocExternalPromoViewDto;
import com.unilever.promo.external.model.NextMocExternalPromoViewDto;
import com.unilever.promo.external.model.PreviousMocExternalPromoViewDto;
import com.unilever.promo.external.service.ExternalPromoService;
import com.unilever.promo.kam.service.KamPromoService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class ExternalPromoController {

	@Autowired
	ExternalPromoService externalPromoService;
	
	//==================================================MOC Views==================================================
		@GetMapping("/getPromoExternalCurrentMocView")
		public List<CurrentMocExternalPromoViewDto> getPromoExternalCurrentNextMocView(@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,@RequestParam("account") String account,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			    @RequestParam(defaultValue = "10") Integer pageSize){
			
			List<CurrentMocExternalPromoViewDto> externalPromoCurrentMocView = new ArrayList<>();
			try{
				externalPromoCurrentMocView = externalPromoService.getPromoExternalCurrentMocView(region,moc, account, category,pageNo,pageSize);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return externalPromoCurrentMocView;
		
		}


		@GetMapping("/getPromoExternalPreviousMocView")
		public List<PreviousMocExternalPromoViewDto> getPromoExternalPreviousMocView(@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,@RequestParam("account") String account,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			    @RequestParam(defaultValue = "10") Integer pageSize){
			
			List<PreviousMocExternalPromoViewDto> externalPromoPreviousMocView = new ArrayList<>();
			try{
				externalPromoPreviousMocView = externalPromoService.getPromoExternalPreviousMocView(region,moc, account, category,pageNo,pageSize);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return externalPromoPreviousMocView;
		
		}

		@GetMapping("/getPromoExternalNextMocView")
		public List<NextMocExternalPromoViewDto> getPromoExternalNextMocView(@RequestParam("region") List<String> region,@RequestParam("moc") List<String> moc,@RequestParam("account") String account,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			    @RequestParam(defaultValue = "10") Integer pageSize){
			
			List<NextMocExternalPromoViewDto> externalPromoNextMocView = new ArrayList<>();
			try{
				externalPromoNextMocView = externalPromoService.getPromoExternalNextMocView(region, moc, account, category,pageNo,pageSize);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return externalPromoNextMocView;
		
		}
}
