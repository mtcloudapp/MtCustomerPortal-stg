package com.unilever.claims.commb2c.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "COMMB2C_RED_CLAIMS_VALUE")
public class RedClaimsValueCommb2c {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4630226183535609462L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="ACCOUNT_NAME")
    private String accountName;
	
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="RED_CLAIMS_VALUE")
    private Double redClaimValue;

	public RedClaimsValueCommb2c() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RedClaimsValueCommb2c(Integer rECORD_ID, String regionName, String accountName,
			String categoryNaame, String moc, Double redClaimValue) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.accountName = accountName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.redClaimValue = redClaimValue;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getRedClaimValue() {
		return redClaimValue;
	}

	public void setRedClaimValue(Double redClaimValue) {
		this.redClaimValue = redClaimValue;
	}
}
