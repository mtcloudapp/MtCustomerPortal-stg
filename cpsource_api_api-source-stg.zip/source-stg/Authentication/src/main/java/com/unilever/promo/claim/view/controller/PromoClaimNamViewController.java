package com.unilever.promo.claim.view.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.promo.claim.view.model.BaseWorkingDto;
import com.unilever.promo.claim.view.model.DeductionBucketDto;
import com.unilever.promo.claim.view.model.OverrunClaimDto;
import com.unilever.promo.claim.view.model.PromoClaimFileDto;
import com.unilever.promo.claim.view.model.PromoClaimsSummaryDto;
import com.unilever.promo.claim.view.service.PromoClaimNamViewService;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimNamViewController {

		@Autowired
		PromoClaimNamViewService promoClaimNamViewService;

		//======================================= Promo Claim Summary View==================================================
		
		@GetMapping("/getPromoClaimSummaryViewByNAM")
		public List<PromoClaimsSummaryDto> getPromoClaimSummaryViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<PromoClaimsSummaryDto> promoClaimsSummaryDetails = new ArrayList<PromoClaimsSummaryDto>();
			try{

				promoClaimsSummaryDetails = promoClaimNamViewService.getPromoClaimSummaryView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return promoClaimsSummaryDetails;

		}
		
		
		//======================================= Promo Claim Customer Claim File==================================================
		
		@GetMapping("/getPromoClaimFileViewByNAM")
		public List<PromoClaimFileDto> getPromoClaimFileViewByGM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<PromoClaimFileDto> promoClaimFileDetails = new ArrayList<>();
			try{

				promoClaimFileDetails = promoClaimNamViewService.getPromoClaimFileView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return promoClaimFileDetails;

		}


		//======================================= Baseworking View==================================================
		
		@GetMapping("/getBaseworkingViewByNAM")
		public List<BaseWorkingDto> getBaseworkingViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<BaseWorkingDto> baseworkingDetails = new ArrayList<BaseWorkingDto>();
			try{

				baseworkingDetails = promoClaimNamViewService.getBaseWorkingView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return baseworkingDetails;

		}

		//======================================= Overrun Report View==================================================
		
			@GetMapping("/getOverrunViewByNAM")
			public List<OverrunClaimDto> getOverrunViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
					@RequestParam(defaultValue = "10") Integer pageSize){

				List<OverrunClaimDto> overrunDetails = new ArrayList<OverrunClaimDto>();
				try{

					overrunDetails = promoClaimNamViewService.getOverrunView(account, moc, pageNo, pageSize);

				}
				catch(Exception e){
					e.printStackTrace();
				}
				return overrunDetails;

			}

			
			//======================================= Deduction Bucket For No SolCode==================================================
			
			@GetMapping("/getNoSoleCodeViewByNAM")
			public List<DeductionBucketDto> getNoSoleCodeViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
					@RequestParam("bucket") String bucket,
					@RequestParam(defaultValue = "0") Integer pageNo, 
					@RequestParam(defaultValue = "10") Integer pageSize){

				List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
				try{

					deductionBucketDetails = promoClaimNamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

				}
				catch(Exception e){
					e.printStackTrace();
				}
				return deductionBucketDetails;

			}
			
			
			
			//======================================= Deduction Bucket For No Basepack==================================================
			
					@GetMapping("/getNoBasepackViewByNAM")
					public List<DeductionBucketDto> getNoBasepackViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimNamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}
					
			
					
					//======================================= Deduction Bucket For POS Deduction==================================================
					
					@GetMapping("/getPOSDeductionViewByNAM")
					public List<DeductionBucketDto> getPOSDeductionViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimNamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}
					
			
		//======================================= Deduction Bucket For Primary Deduction==================================================
					
					@GetMapping("/getPrimaryDeductionViewByNAM")
					public List<DeductionBucketDto> getPrimaryDeductionViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimNamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}

					
	//======================================= Deduction Bucket For Invalid Claims==================================================
					
					@GetMapping("/getInvalidClaimsViewByNAM")
					public List<DeductionBucketDto> getInvalidClaimsViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimNamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}

					
	//======================================= Deduction Bucket For Higher MRP==================================================
					
					@GetMapping("/getHigherMRPViewByNAM")
					public List<DeductionBucketDto> getHigherMRPViewByNAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimNamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}

}
