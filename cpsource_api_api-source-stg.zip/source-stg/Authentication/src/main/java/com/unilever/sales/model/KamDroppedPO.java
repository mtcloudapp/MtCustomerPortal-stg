package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INT_DROPPED_PO")
public class KamDroppedPO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6041633713462122331L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="BRANCH")
    private String branch;
	
	@Column(name="CATEGORY")
    private String category;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="PO_NUMBER")
    private String poNumber;
	
	@Column(name="USERNAME")
    private String username;
	
	@Column(name="CIC_NUMBER")
    private String cicNumber;

	public KamDroppedPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KamDroppedPO(Integer rECORD_ID, String branch, String category, String account, String moc, String poNumber,
			String username, String cicNumber) {
		super();
		RECORD_ID = rECORD_ID;
		this.branch = branch;
		this.category = category;
		this.account = account;
		this.moc = moc;
		this.poNumber = poNumber;
		this.username = username;
		this.cicNumber = cicNumber;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCicNumber() {
		return cicNumber;
	}

	public void setCicNumber(String cicNumber) {
		this.cicNumber = cicNumber;
	}
	
	
	

}
