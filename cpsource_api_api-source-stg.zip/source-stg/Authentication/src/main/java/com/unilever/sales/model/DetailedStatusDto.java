package com.unilever.sales.model;

import java.io.Serializable;
import java.util.List;


public class DetailedStatusDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7601115268177784061L;
   
	private String poNumber;
	
	private String status;
	
	private Double poValue;
	
	private Integer noOfLines;
	
	private List<Integer> noOfLinesCount;
	
	private String poDate;
	
	private String depot;
	
    private Double allocatedSum;
	
    private Double invoicedSum;
	
    private String delivaryDate;
    
    private Integer totalRecords;

	public DetailedStatusDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getPoValue() {
		return poValue;
	}

	public void setPoValue(Double poValue) {
		this.poValue = poValue;
	}

	
	public Integer getNoOfLines() {
		return noOfLines;
	}

	public void setNoOfLines(Integer noOfLines) {
		this.noOfLines = noOfLines;
	}

	public String getPoDate() {
		return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public String getDepot() {
		return depot;
	}

	public void setDepot(String depot) {
		this.depot = depot;
	}

	public Double getAllocatedSum() {
		return allocatedSum;
	}

	public void setAllocatedSum(Double allocatedSum) {
		this.allocatedSum = allocatedSum;
	}

	public Double getInvoicedSum() {
		return invoicedSum;
	}

	public void setInvoicedSum(Double invoicedSum) {
		this.invoicedSum = invoicedSum;
	}

	public String getDelivaryDate() {
		return delivaryDate;
	}

	public void setDelivaryDate(String delivaryDate) {
		this.delivaryDate = delivaryDate;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	public List<Integer> getNoOfLinesCount() {
		return noOfLinesCount;
	}

	public void setNoOfLinesCount(List<Integer> noOfLinesCount) {
		this.noOfLinesCount = noOfLinesCount;
	}

	
}
