package com.unilever.global;

public class GlobalVariables {
  
//	public static final String schemaName="test";
	//public static final String MAIL_URL=" https://mt-customer-portal-dev-app-alb-877675614.ap-south-1.elb.amazonaws.com/user/recovery-password"; //Commented By Sarin 14Ma42022 - Configure stg url
//	public static final String MAIL_URL="https://onemt.hulcd.com/user/recovery-password";
	public static final String schemaName="mtcustomerportal";
	// public static final String URL="https://onemt-prod-api.hulcd.com/";
	//public static final String URL="https://onemt-stg-api.hulcd.com/";  //Added By Sarin 14Ma42022 - Configure stg url
	//public static final String MAIL_URL=" https://onemt-stg.hulcd.com/user/recovery-password";  //Added By Sarin 14Ma42022 - Configure stg url
	public static final String URL="http://34.149.179.116/";  //Added By Sarin 14Ma42022 - Configure stg url
	public static final String MAIL_URL=" http://34.149.179.116/user/recovery-password";  //Added By Sarin 14Ma42022 - Configure stg url

}
