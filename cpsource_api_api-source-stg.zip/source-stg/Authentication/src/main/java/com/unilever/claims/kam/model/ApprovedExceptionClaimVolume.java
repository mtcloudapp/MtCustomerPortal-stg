package com.unilever.claims.kam.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INT_APPROVED_EXCEPTION_CLAIMS_VOLUME")
public class ApprovedExceptionClaimVolume implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7881375127880439593L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="USERNAME")
    private String userName;
	
	@Column(name="ACCOUNT_NAME")
    private String accountName;
	
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="APPROVED_EXCEPTION_CLAIMS_VOLUME")
    private Double approvedExceptionClaimVolume;

	public ApprovedExceptionClaimVolume() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApprovedExceptionClaimVolume(Integer rECORD_ID, String regionName, String userName, String accountName,
			String categoryNaame, String moc, Double approvedExceptionClaimVolume) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.userName = userName;
		this.accountName = accountName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.approvedExceptionClaimVolume = approvedExceptionClaimVolume;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getApprovedExceptionClaimVolume() {
		return approvedExceptionClaimVolume;
	}

	public void setApprovedExceptionClaimVolume(Double approvedExceptionClaimVolume) {
		this.approvedExceptionClaimVolume = approvedExceptionClaimVolume;
	}
	
	
}
