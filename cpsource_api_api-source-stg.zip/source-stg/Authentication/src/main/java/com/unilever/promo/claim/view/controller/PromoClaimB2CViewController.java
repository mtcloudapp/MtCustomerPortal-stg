package com.unilever.promo.claim.view.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.promo.claim.view.model.BaseWorkingDto;
import com.unilever.promo.claim.view.model.DeductionBucketDto;
import com.unilever.promo.claim.view.model.FinalPublishDto;
import com.unilever.promo.claim.view.model.OverrunClaimDto;
import com.unilever.promo.claim.view.model.PromoClaimFileDto;
import com.unilever.promo.claim.view.model.PromoClaimsSummaryDto;
import com.unilever.promo.claim.view.service.PromoClaimB2CViewService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimB2CViewController {

	@Autowired
	PromoClaimB2CViewService promoClaimB2CViewService;
	
	
	//=======================================publish tab view==========================================================//

	@GetMapping("/getFinalPublishDetails")
	public List<FinalPublishDto> getFinalPublishDetails(@RequestParam("account") String account, @RequestParam("moc") String moc){

		List<FinalPublishDto> finalPublishDetails = new ArrayList<FinalPublishDto>();
		try{

			finalPublishDetails = promoClaimB2CViewService.getPromoClaimFinalPublishView(account, moc);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return finalPublishDetails;

	}
	   
	
	
	
	
	//======================================= Promo Claim Summary View==================================================//
	
	@GetMapping("/getPromoClaimSummaryViewByB2C")
	public List<PromoClaimsSummaryDto> getPromoClaimSummaryViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize){

		List<PromoClaimsSummaryDto> promoClaimsSummaryDetails = new ArrayList<PromoClaimsSummaryDto>();
		try{

			promoClaimsSummaryDetails = promoClaimB2CViewService.getPromoClaimSummaryView(account, moc, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return promoClaimsSummaryDetails;

	}
	
	//======================================= Promo Claim Customer Claim File==================================================
	
		@GetMapping("/getPromoClaimFileViewByB2C")
		public List<PromoClaimFileDto> getPromoClaimFileViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<PromoClaimFileDto> promoClaimFileDetails = new ArrayList<>();
			try{

				promoClaimFileDetails = promoClaimB2CViewService.getPromoClaimFileView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return promoClaimFileDetails;

		}

	//======================================= Baseworking View==================================================
	
	@GetMapping("/getBaseworkingViewByB2C")
	public List<BaseWorkingDto> getBaseworkingViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize){

		List<BaseWorkingDto> baseworkingDetails = new ArrayList<BaseWorkingDto>();
		try{

			baseworkingDetails = promoClaimB2CViewService.getBaseWorkingView(account, moc, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return baseworkingDetails;

	}

	//======================================= Overrun Report View==================================================
	
		@GetMapping("/getOverrunViewByB2C")
		public List<OverrunClaimDto> getOverrunViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<OverrunClaimDto> overrunDetails = new ArrayList<OverrunClaimDto>();
			try{

				overrunDetails = promoClaimB2CViewService.getOverrunView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return overrunDetails;

		}

		
		//======================================= Deduction Bucket For No SolCode==================================================
		
		@GetMapping("/getNoSoleCodeViewByB2C")
		public List<DeductionBucketDto> getNoSoleCodeViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,
				@RequestParam("bucket") String bucket,
				@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
			try{

				deductionBucketDetails = promoClaimB2CViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return deductionBucketDetails;

		}
		
		
		
		//======================================= Deduction Bucket For No Basepack==================================================
		
				@GetMapping("/getNoBasepackViewByB2C")
				public List<DeductionBucketDto> getNoBasepackViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimB2CViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}
				
		
				
				//======================================= Deduction Bucket For POS Deduction==================================================
				
				@GetMapping("/getPOSDeductionViewByB2C")
				public List<DeductionBucketDto> getPOSDeductionViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimB2CViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}
				
		
	//======================================= Deduction Bucket For Primary Deduction==================================================
				
				@GetMapping("/getPrimaryDeductionViewByB2C")
				public List<DeductionBucketDto> getPrimaryDeductionViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimB2CViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

				
//======================================= Deduction Bucket For Invalid Claims==================================================
				
				@GetMapping("/getInvalidClaimsViewByB2C")
				public List<DeductionBucketDto> getInvalidClaimsViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimB2CViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

				
//======================================= Deduction Bucket For Higher MRP==================================================
				
				@GetMapping("/getHigherMRPViewByB2C")
				public List<DeductionBucketDto> getHigherMRPViewByB2C(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimB2CViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

	
}
