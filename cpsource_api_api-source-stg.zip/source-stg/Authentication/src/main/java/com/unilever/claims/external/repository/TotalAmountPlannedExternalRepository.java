package com.unilever.claims.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.extenal.model.TotalAmountPlannedExternal;
import com.unilever.global.GlobalVariables;

@Repository
public interface TotalAmountPlannedExternalRepository extends JpaRepository<TotalAmountPlannedExternal, Integer>{
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_TOTAL_AMOUNT_PLANNED etas where etas.USERNAME=:username", nativeQuery = true)
	List<TotalAmountPlannedExternal> findAllTotalAmountPlannedExternalDetails(@Param("username") String username);
	

}
