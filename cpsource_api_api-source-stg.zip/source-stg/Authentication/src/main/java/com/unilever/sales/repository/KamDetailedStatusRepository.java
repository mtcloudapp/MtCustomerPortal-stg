package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.DetailedStatus;
import com.unilever.sales.model.KamDetailedStatus;

@Repository
public interface KamDetailedStatusRepository extends JpaRepository<KamDetailedStatus, Integer>{
	
	/*@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status and tac.USERNAME=:username", nativeQuery = true)
	Page<KamDetailedStatus> findKamDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,@Param("username") String username,Pageable pageable);
	*/
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status and tac.USERNAME=:username  GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS ORDER BY tac.PO_NUMBER ASC", nativeQuery = true)
	Page<KamDetailedStatus> findKamDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,@Param("username") String username,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.STATUS in :status and tac.USERNAME=:username  GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS ORDER BY tac.PO_NUMBER ASC", nativeQuery = true)
	Page<KamDetailedStatus> findKamDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status,@Param("username") String username,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select SUM(tac.PO_VALUE) from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.USERNAME=:username GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUSC", nativeQuery = true)
	List<Double> findSumOfPoValue(@Param("username") String username);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATED_SUM) from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where  tac.USERNAME=:username GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfAllocatedValue(@Param("username") String username);
	
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_SUM) from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where  tac.USERNAME=:username GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfInvoiced(@Param("username") String username);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status and tac.USERNAME=:username GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<KamDetailedStatus> findKamCountDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,@Param("username") String username);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.STATUS in :status and tac.USERNAME=:username GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<KamDetailedStatus> findKamCountDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("status") List<String> status,@Param("username") String username);
	

	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NO) from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status and tac.USERNAME=:username GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS ORDER BY tac.PO_NUMBER ASC", nativeQuery = true)
	List<Integer> findKamNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,@Param("username") String username);
	

	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NO) from "+GlobalVariables.schemaName+".INT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER=:poNumber and tac.STATUS in :status and tac.USERNAME=:username GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Integer> findKamNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") String poNumber,@Param("status") List<String> status,@Param("username") String username);
	
	
	
	
}
