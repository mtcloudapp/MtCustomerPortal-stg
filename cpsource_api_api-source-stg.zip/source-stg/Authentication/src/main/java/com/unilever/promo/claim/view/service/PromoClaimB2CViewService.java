package com.unilever.promo.claim.view.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.unilever.promo.claim.external.model.BaseWorking;
import com.unilever.promo.claim.external.model.OverrunClaim;
import com.unilever.promo.claim.external.model.PromoClaimSummary;
import com.unilever.promo.claim.external.model.PromoClaims;
import com.unilever.promo.claim.external.repository.BaseWorkingRepository;
import com.unilever.promo.claim.external.repository.OverrunClaimRepository;
import com.unilever.promo.claim.external.repository.PromoClaimSummaryRepository;
import com.unilever.promo.claim.external.repository.PromoClaimsRepository;
import com.unilever.promo.claim.view.model.BaseWorkingDto;
import com.unilever.promo.claim.view.model.DeductionBucketDto;
import com.unilever.promo.claim.view.model.FinalPublishDto;
import com.unilever.promo.claim.view.model.OverrunClaimDto;
import com.unilever.promo.claim.view.model.PromoClaimFileDto;
import com.unilever.promo.claim.view.model.PromoClaimsSummaryDto;

@Service
public class PromoClaimB2CViewService {

	@Autowired
	PromoClaimSummaryRepository promoClaimSummaryRepository;

	@Autowired
	BaseWorkingRepository baseWorkingRepository;

	@Autowired
	OverrunClaimRepository overrunClaimRepository;
	
	@Autowired
	PromoClaimsRepository promoClaimsRepository;
	
	//========================================= Final Publish Details Veiw=========================================//
	
	public List<FinalPublishDto> getPromoClaimFinalPublishView(String account,String moc){

		List<FinalPublishDto> finalPublishDetailsList = new ArrayList<>();
//		List<PromoClaimSummary> totalRecords = new ArrayList<PromoClaimSummary>();

		try{
			List<OverrunClaim> finalPublishViewDetails = overrunClaimRepository.finalPublishViewDetailsByAcntAndMoc(account, moc);

			for(OverrunClaim pcs : finalPublishViewDetails){

				FinalPublishDto finalPublishDto = new FinalPublishDto();

				finalPublishDto.setSolCode(pcs.getSolCode());
				finalPublishDto.setBudget(pcs.getBudget());
				finalPublishDto.setApprovedOverrun(pcs.getApprovedOverrun());;
				finalPublishDto.setB2cSignedOffAmt(pcs.getB2cSignedOffAmt());;
				finalPublishDto.setCustomerClaimAmt(pcs.getCustomerClaimAmt());
				finalPublishDto.setOverrunAmt(pcs.getOverrunbAmt());
				finalPublishDto.setOverrunPercentage(pcs.getOverrunPercentage());
				finalPublishDto.setOverrunApprover(pcs.getOverrunApprover());;
				finalPublishDto.setRemainingBudget(pcs.getRemainingBudget());
				finalPublishDetailsList.add(finalPublishDto);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return finalPublishDetailsList;

	}
	
	

	// ===================================================Promoclaim Summary View================================================

	public List<PromoClaimsSummaryDto> getPromoClaimSummaryView(String account,String moc,Integer pageNo, Integer pageSize){

		List<PromoClaimsSummaryDto> promoClaimsSummaryList = new ArrayList<PromoClaimsSummaryDto>();
		List<PromoClaimSummary> totalRecords = new ArrayList<PromoClaimSummary>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);
			Page<PromoClaimSummary> promoClaimSummaryViewDetails = promoClaimSummaryRepository.findPromoClaimsSummaryDetailsByAcntAndMoc(account, moc, paging);
			totalRecords = promoClaimSummaryRepository.findCountByAccountAndMoc(account, moc);

			for(PromoClaimSummary pcs : promoClaimSummaryViewDetails){

				PromoClaimsSummaryDto promoClaimsSummaryDto = new PromoClaimsSummaryDto();

				promoClaimsSummaryDto.setCustomerClaimed(pcs.getCustomerClaimed());
				promoClaimsSummaryDto.setLessDeduction(pcs.getLesssDeduction());
				promoClaimsSummaryDto.setBasepackNotApplicable(pcs.getBasepackNotApplicable());
				promoClaimsSummaryDto.setInvalidClaims(pcs.getInvalidsClaims());
				promoClaimsSummaryDto.setNoSolCode(pcs.getNoSolCode());
				promoClaimsSummaryDto.setHigherMRP(pcs.getHigherMRP());
				promoClaimsSummaryDto.setPosVsClaimQuantity(pcs.getPosVsClaimQty());
				promoClaimsSummaryDto.setPrimaryVsClaimQuantity(pcs.getPrimaryVsClaimQty());
				promoClaimsSummaryDto.setNetClaims(pcs.getNetClaims());
				promoClaimsSummaryDto.setLessOverruns(pcs.getLessOverrun());
				promoClaimsSummaryDto.setOverrunApproved(pcs.getOverrunApproved());
				promoClaimsSummaryDto.setPayables(pcs.getPayables());
				promoClaimsSummaryDto.setTotalRecords(totalRecords.size());

				promoClaimsSummaryList.add(promoClaimsSummaryDto);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return promoClaimsSummaryList;

	}
	
	
	// ===================================================Promoclaim File Details View================================================

		public List<PromoClaimFileDto> getPromoClaimFileView(String account,String moc,Integer pageNo, Integer pageSize){

			List<PromoClaimFileDto> promoClaimsFileList = new ArrayList<>();
			List<PromoClaims> totalRecords = new ArrayList<>();

			try{
				Pageable paging = PageRequest.of(pageNo, pageSize);
				Page<PromoClaims> promoClaimFileViewDetails = promoClaimsRepository.findPromoClaimsFileDetailsByAcntAndMoc(account, moc, paging);
				totalRecords = promoClaimsRepository.findCountByAccountAndMoc(account, moc);

				for(PromoClaims pcs : promoClaimFileViewDetails){

					PromoClaimFileDto promoClaimsFileDto = new PromoClaimFileDto();

					promoClaimsFileDto.setParentSolCode(pcs.getParentSolCode());
					promoClaimsFileDto.setBasepack(pcs.getBasepack());
					promoClaimsFileDto.setArticleCode(pcs.getArticleCode());
					promoClaimsFileDto.setClaimValue(pcs.getClaimValue());
					promoClaimsFileDto.setClaimQty(pcs.getClaimQty());
					promoClaimsFileDto.setMrp(pcs.getMrp());
					promoClaimsFileDto.setClaimPerUnit(pcs.getClaimPerUnit());
					
					promoClaimsFileDto.setTotalRecords(totalRecords.size());

					promoClaimsFileList.add(promoClaimsFileDto);
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return promoClaimsFileList;

		}

	// ===================================================Baseworking View================================================



	public List<BaseWorkingDto> getBaseWorkingView(String account,String moc,Integer pageNo, Integer pageSize){

		List<BaseWorkingDto> baseworkingList = new ArrayList<BaseWorkingDto>();
		List<BaseWorking> totalRecords = new ArrayList<BaseWorking>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);
			Page<BaseWorking> baseworkingViewDetails = baseWorkingRepository.findBaseWorkingDetailsByAcntAndMoc(account, moc, paging);
			totalRecords = baseWorkingRepository.findCountByAccountAndMoc(account, moc);

			for(BaseWorking pcs : baseworkingViewDetails){

				BaseWorkingDto baseWorkingDto = new BaseWorkingDto();

				//baseWorkingDto.setSolCode(pcs.getSolCode());
				baseWorkingDto.setSolCode(pcs.getSolCodeRevised());  //Commented above line and Added By Sarin Jun2021
				baseWorkingDto.setBasepack(pcs.getBasepack());
				baseWorkingDto.setArticleCode(pcs.getArticleCode());
				baseWorkingDto.setSolCodeDescription(pcs.getSoleCodeDesc());
				baseWorkingDto.setHulMRP(pcs.getHulMRP());
				baseWorkingDto.setCustomerMRP(pcs.getCustomerMRP());
				baseWorkingDto.setNetClaimValue(pcs.getNetClaimValue());
				baseWorkingDto.setNetClaimQty(pcs.getNetClaimQty());
				baseWorkingDto.setPromotionAmt(pcs.getPromotionAmt());
				baseWorkingDto.setClaimAmtPerUnit(pcs.getClaimAmtPerUnit());
				baseWorkingDto.setClaimPOSPrimaryQty(pcs.getClaimPosPrimaryQty());
				baseWorkingDto.setCustomerClaimMinQty(pcs.getCustomerClaimMinQty());
				baseWorkingDto.setDiffInCustomerClaims(pcs.getDiffInCustomerClaims());
				baseWorkingDto.setHulClaim(pcs.getHulClaim());
				baseWorkingDto.setNetClaim(pcs.getNetClaims());
				baseWorkingDto.setDiffClaim(pcs.getDiffClaims());
				baseWorkingDto.setPromotionUnit(pcs.getPromotionUnit());
				baseWorkingDto.setDeductionBucket(pcs.getDeductionBucket());
				//Added By Sarin - GoLive Changes 01Apr2022 for POS-Primary Deduction - Starts
				if (pcs.getBasepackRevised() != null && pcs.getBasepackRevised() == 1) {
					baseWorkingDto.setDeductionBucket("POS-PRIMARY DEDUCTION");
				}
				//Added By Sarin - GoLive Changes 01Apr2022 for POS-Primary Deduction - Ends
				baseWorkingDto.setDeductionAmount(pcs.getDeductionAmt());
				baseWorkingDto.setTotalRecords(totalRecords.size());

				baseworkingList.add(baseWorkingDto);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return baseworkingList;

	}

	// ===================================================Overrun View================================================

	public List<OverrunClaimDto> getOverrunView(String account,String moc,Integer pageNo, Integer pageSize){

		List<OverrunClaimDto> overrunClaimList = new ArrayList<OverrunClaimDto>();
		List<OverrunClaim> totalRecords = new ArrayList<OverrunClaim>();
		List<OverrunClaim> overrunViewDetails = new ArrayList<OverrunClaim>();

		try{
//			Pageable paging = PageRequest.of(pageNo, pageSize);
			overrunViewDetails = overrunClaimRepository.findOverrunDetails(account, moc);
			totalRecords = overrunClaimRepository.findCountByAccountAndMoc(account, moc);

			for(OverrunClaim pcs : overrunViewDetails){

				OverrunClaimDto overrunClaimDto = new OverrunClaimDto();

				overrunClaimDto.setSolCode(pcs.getSolCode());
				overrunClaimDto.setSolCode_all(pcs.getSolCode_all());
				overrunClaimDto.setSolCode_name(pcs.getSolCode_name());
				overrunClaimDto.setBudget(pcs.getBudget());
				overrunClaimDto.setCustomerClaimAmountt(pcs.getCustomerClaimAmt());
				overrunClaimDto.setB2cSignedOffAmount(pcs.getB2cSignedOffAmt());
				overrunClaimDto.setRemainingBudget(pcs.getRemainingBudget());
				overrunClaimDto.setOverrunAmt(pcs.getOverrunbAmt());
//				overrunClaimDto.setApprovedOverrun(pcs.getApprovedOverrun());
				overrunClaimDto.setOverrunApprover(pcs.getOverrunApprover());
				overrunClaimDto.setOverrunPercentage(pcs.getOverrunPercentage());
				overrunClaimDto.setApprovedOverrunAmount(pcs.getApprovedOverrun());
				overrunClaimDto.setApprovedOverrunPercentage(pcs.getApprovedOverrunPercentage());
				overrunClaimDto.setRemarks(pcs.getRemarks());
				overrunClaimDto.setTotalRecords(totalRecords.size());

				overrunClaimList.add(overrunClaimDto);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return overrunClaimList;

	}
	
	
	// ===================================================Deduction Bucket View================================================

	public List<DeductionBucketDto> getNoSolCodeView(String account,String moc,String bucket,Integer pageNo, Integer pageSize){

		List<DeductionBucketDto> deductionBucketList = new ArrayList<DeductionBucketDto>();
		List<BaseWorking> totalRecords = new ArrayList<BaseWorking>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);
			Page<BaseWorking> deductionBucketDetails = baseWorkingRepository.findDeductionBucketDetailsByAcntMocBucket(account, moc, bucket, paging);
			totalRecords = baseWorkingRepository.findCountByAccountMocBucket(account, moc, bucket);

			for(BaseWorking pcs : deductionBucketDetails){

				DeductionBucketDto deductionBucketDto = new DeductionBucketDto();

				deductionBucketDto.setSolCode(pcs.getSolCode());
				deductionBucketDto.setBasepack(pcs.getBasepack());
				deductionBucketDto.setArticleCode(pcs.getArticleCode());
				deductionBucketDto.setHulMRP(pcs.getHulMRP());
				deductionBucketDto.setCustomerClaimMinQty(pcs.getCustomerClaimMinQty());
				deductionBucketDto.setNetClaimValue(pcs.getNetClaimValue());
				deductionBucketDto.setDeductionAmt(pcs.getDeductionAmt());
				deductionBucketDto.setCustomerMRP(pcs.getCustomerMRP());
				deductionBucketDto.setTotalRecords(totalRecords.size());

				deductionBucketList.add(deductionBucketDto);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return deductionBucketList;

	}
	
	
}
