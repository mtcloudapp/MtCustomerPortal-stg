package com.unilever.promo.claim.external.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaimFieldMapping;

@Repository
public interface PromoClaimFieldMappingRepository extends JpaRepository<PromoClaimFieldMapping, Integer> {
	
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".PROMO_CLAIMS_FIELDS_MAPPING pcs where pcs.ACCOUNT_NAME=:accountName", nativeQuery = true)
	List<PromoClaimFieldMapping> getClaimFileColumnValuesByAccount(@Param("accountName") String accountName);
	
}
