package com.unilever.sales.model;

public class SalesJsonObj {
	
	private Integer totalPoCount;
	private Integer totalPoLineCount;
	private Integer totalPoValue;
	private Integer totalPoDroppedCount;
	private Integer totalPoInvoicedCount;
	private Double totalPoInvoicedValue;
	private Integer totalPoAllocatedCount;
	private Double totalPoAllocatedValue;
	public SalesJsonObj() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getTotalPoCount() {
		return totalPoCount;
	}
	public void setTotalPoCount(Integer totalPoCount) {
		this.totalPoCount = totalPoCount;
	}
	public Integer getTotalPoLineCount() {
		return totalPoLineCount;
	}
	public void setTotalPoLineCount(Integer totalPoLineCount) {
		this.totalPoLineCount = totalPoLineCount;
	}
	
	public Integer getTotalPoValue() {
		return totalPoValue;
	}
	public void setTotalPoValue(Integer totalPoValue) {
		this.totalPoValue = totalPoValue;
	}
	public Integer getTotalPoDroppedCount() {
		return totalPoDroppedCount;
	}
	public void setTotalPoDroppedCount(Integer totalPoDroppedCount) {
		this.totalPoDroppedCount = totalPoDroppedCount;
	}
	public Integer getTotalPoInvoicedCount() {
		return totalPoInvoicedCount;
	}
	public void setTotalPoInvoicedCount(Integer totalPoInvoicedCount) {
		this.totalPoInvoicedCount = totalPoInvoicedCount;
	}
	
	public Integer getTotalPoAllocatedCount() {
		return totalPoAllocatedCount;
	}
	public void setTotalPoAllocatedCount(Integer totalPoAllocatedCount) {
		this.totalPoAllocatedCount = totalPoAllocatedCount;
	}
	public Double getTotalPoInvoicedValue() {
		return totalPoInvoicedValue;
	}
	public void setTotalPoInvoicedValue(Double totalPoInvoicedValue) {
		this.totalPoInvoicedValue = totalPoInvoicedValue;
	}
	public Double getTotalPoAllocatedValue() {
		return totalPoAllocatedValue;
	}
	public void setTotalPoAllocatedValue(Double totalPoAllocatedValue) {
		this.totalPoAllocatedValue = totalPoAllocatedValue;
	}
	
	

}
