package com.unilever.claims.extenal.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "EXT_APPROVED_EXCEPTIONS_CLAIMS_VALUE")
public class ApprovedExceptionClaimsValueExternal implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1100252998713862963L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="USERNAME")
    private String userName;
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="APPROVED_EXCEPTIONS_CLAIMS_VALUE")
    private Double approvedExceptionClaimsValue;

	public ApprovedExceptionClaimsValueExternal() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApprovedExceptionClaimsValueExternal(Integer rECORD_ID, String regionName, String userName, String categoryNaame,
			String moc, Double approvedExceptionClaimsValue) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.userName = userName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.approvedExceptionClaimsValue = approvedExceptionClaimsValue;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getApprovedExceptionClaimsValue() {
		return approvedExceptionClaimsValue;
	}

	public void setApprovedExceptionClaimsValue(Double approvedExceptionClaimsValue) {
		this.approvedExceptionClaimsValue = approvedExceptionClaimsValue;
	}
	
	


}
