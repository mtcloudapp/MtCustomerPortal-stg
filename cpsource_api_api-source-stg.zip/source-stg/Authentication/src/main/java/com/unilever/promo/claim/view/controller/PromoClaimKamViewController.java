package com.unilever.promo.claim.view.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.promo.claim.view.model.BaseWorkingDto;
import com.unilever.promo.claim.view.model.DeductionBucketDto;
import com.unilever.promo.claim.view.model.OverrunClaimDto;
import com.unilever.promo.claim.view.model.PromoClaimFileDto;
import com.unilever.promo.claim.view.model.PromoClaimsSummaryDto;
import com.unilever.promo.claim.view.service.PromoClaimKamViewService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimKamViewController {
	
		@Autowired
		PromoClaimKamViewService promoClaimKamViewService;

		//======================================= Promo Claim Summary View==================================================
		
		@GetMapping("/getPromoClaimSummaryViewByKAM")
		public List<PromoClaimsSummaryDto> getPromoClaimSummaryViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<PromoClaimsSummaryDto> promoClaimsSummaryDetails = new ArrayList<PromoClaimsSummaryDto>();
			try{

				promoClaimsSummaryDetails = promoClaimKamViewService.getPromoClaimSummaryView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return promoClaimsSummaryDetails;

		}

		//======================================= Promo Claim Customer Claim File==================================================
		
		@GetMapping("/getPromoClaimFileViewByKAM")
		public List<PromoClaimFileDto> getPromoClaimFileViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<PromoClaimFileDto> promoClaimFileDetails = new ArrayList<>();
			try{

				promoClaimFileDetails = promoClaimKamViewService.getPromoClaimFileView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return promoClaimFileDetails;

		}

		//======================================= Baseworking View==================================================
		
		@GetMapping("/getBaseworkingViewByKAM")
		public List<BaseWorkingDto> getBaseworkingViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<BaseWorkingDto> baseworkingDetails = new ArrayList<BaseWorkingDto>();
			try{

				baseworkingDetails = promoClaimKamViewService.getBaseWorkingView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return baseworkingDetails;

		}

		//======================================= Overrun Report View==================================================
		
			@GetMapping("/getOverrunViewByKAM")
			public List<OverrunClaimDto> getOverrunViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
					@RequestParam(defaultValue = "10") Integer pageSize){

				List<OverrunClaimDto> overrunDetails = new ArrayList<OverrunClaimDto>();
				try{

					overrunDetails = promoClaimKamViewService.getOverrunView(account, moc, pageNo, pageSize);

				}
				catch(Exception e){
					e.printStackTrace();
				}
				return overrunDetails;

			}

			
			//======================================= Deduction Bucket For No SolCode==================================================
			
			@GetMapping("/getNoSoleCodeViewByKAM")
			public List<DeductionBucketDto> getNoSoleCodeViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
					@RequestParam("bucket") String bucket,
					@RequestParam(defaultValue = "0") Integer pageNo, 
					@RequestParam(defaultValue = "10") Integer pageSize){

				List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
				try{

					deductionBucketDetails = promoClaimKamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

				}
				catch(Exception e){
					e.printStackTrace();
				}
				return deductionBucketDetails;

			}
			
			
			
			//======================================= Deduction Bucket For No Basepack==================================================
			
					@GetMapping("/getNoBasepackViewByKAM")
					public List<DeductionBucketDto> getNoBasepackViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimKamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}
					
			
					
					//======================================= Deduction Bucket For POS Deduction==================================================
					
					@GetMapping("/getPOSDeductionViewByKAM")
					public List<DeductionBucketDto> getPOSDeductionViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimKamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}
					
			
		//======================================= Deduction Bucket For Primary Deduction==================================================
					
					@GetMapping("/getPrimaryDeductionViewByKAM")
					public List<DeductionBucketDto> getPrimaryDeductionViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimKamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}

					
	//======================================= Deduction Bucket For Invalid Claims==================================================
					
					@GetMapping("/getInvalidClaimsViewByKAM")
					public List<DeductionBucketDto> getInvalidClaimsViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimKamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}

					
	//======================================= Deduction Bucket For Higher MRP==================================================
					
					@GetMapping("/getHigherMRPViewByKAM")
					public List<DeductionBucketDto> getHigherMRPViewByKAM(@RequestParam("account") String account, @RequestParam("moc") String moc,
							@RequestParam("bucket") String bucket,
							@RequestParam(defaultValue = "0") Integer pageNo, 
							@RequestParam(defaultValue = "10") Integer pageSize){

						List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
						try{

							deductionBucketDetails = promoClaimKamViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

						}
						catch(Exception e){
							e.printStackTrace();
						}
						return deductionBucketDetails;

					}

}
	

