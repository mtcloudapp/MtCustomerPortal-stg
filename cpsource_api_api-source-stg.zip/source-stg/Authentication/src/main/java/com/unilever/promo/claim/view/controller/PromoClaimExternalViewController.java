package com.unilever.promo.claim.view.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.promo.claim.view.model.DeductionBucketDto;
import com.unilever.promo.claim.view.model.OverrunClaimDto;
import com.unilever.promo.claim.view.model.PromoClaimsSummaryDto;
import com.unilever.promo.claim.view.service.PromoClaimExternalViewService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimExternalViewController {

	@Autowired
	PromoClaimExternalViewService promoClaimExternalViewService;

	//======================================= Promo Claim Summary View==================================================
	
	@GetMapping("/getPromoClaimSummaryViewByExternal")
	public List<PromoClaimsSummaryDto> getPromoClaimSummaryViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize){

		List<PromoClaimsSummaryDto> promoClaimsSummaryDetails = new ArrayList<PromoClaimsSummaryDto>();
		try{

			promoClaimsSummaryDetails = promoClaimExternalViewService.getPromoClaimSummaryView(account, moc, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return promoClaimsSummaryDetails;

	}
	
	
	//======================================= Overrun Report View==================================================
	
		@GetMapping("/getOverrunViewByExternal")
		public List<OverrunClaimDto> getOverrunViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<OverrunClaimDto> overrunDetails = new ArrayList<OverrunClaimDto>();
			try{

				overrunDetails = promoClaimExternalViewService.getOverrunView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return overrunDetails;

		}

		
		//======================================= Deduction Bucket For No SolCode==================================================
		
		@GetMapping("/getNoSoleCodeViewByExternal")
		public List<DeductionBucketDto> getNoSoleCodeViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,
				@RequestParam("bucket") String bucket,
				@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
			try{

				deductionBucketDetails = promoClaimExternalViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return deductionBucketDetails;

		}
		
		
		
		//======================================= Deduction Bucket For No Basepack==================================================
		
				@GetMapping("/getNoBasepackViewByExternal")
				public List<DeductionBucketDto> getNoBasepackViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimExternalViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}
				
		
				
				//======================================= Deduction Bucket For POS Deduction==================================================
				
				@GetMapping("/getPOSDeductionViewByExternal")
				public List<DeductionBucketDto> getPOSDeductionViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimExternalViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}
				
		
	//======================================= Deduction Bucket For Primary Deduction==================================================
				
				@GetMapping("/getPrimaryDeductionViewByExternal")
				public List<DeductionBucketDto> getPrimaryDeductionViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimExternalViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

				
//======================================= Deduction Bucket For Invalid Claims==================================================
				
				@GetMapping("/getInvalidClaimsViewByExternal")
				public List<DeductionBucketDto> getInvalidClaimsViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimExternalViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

				
//======================================= Deduction Bucket For Higher MRP==================================================
				
				@GetMapping("/getHigherMRPViewByExternal")
				public List<DeductionBucketDto> getHigherMRPViewByExternal(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimExternalViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

}
