package com.unilever.promo.claim.soa.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.external.repository.PromoClaimsExceptionAttachmntRepository;
import com.unilever.promo.claim.external.service.PromoClaimExcelHelper;
import com.unilever.promo.claim.soa.service.SOAWorkflowService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class SOAWorkflowController {

	@Value("${aws.s3.bucket_promo_claims_supporting_doc}")
	private String bucketName;

	@Autowired
	SOAWorkflowService SOAWorkflowService;

	@Autowired
	PromoClaimsExceptionAttachmntRepository promoClaimsExceptionAttachmntRepository;


	@PutMapping(value= "/signOffWithExceptionByB2C")
	public ResponseEntity<ResponseMessage> signOffWithExceptionByB2C(@RequestParam("account") String account,@RequestParam("moc") String moc)  throws IOException{
		String message = "";
		ResponseMessage response = new ResponseMessage();

		try {
			response = SOAWorkflowService.signOffWithExceptionByB2C(account, moc);

			if(response.getMessage().equals("Success")){
				message = "Stage ID Updated successfully: ";

			}else{
				message = response.getMessage();
			}

			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Stage ID Not Updated ";
		}

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	}
	
	@PutMapping(value= "/signOffByB2C")
	public ResponseEntity<ResponseMessage> signOffByB2C(@RequestParam("account") String account,@RequestParam("moc") String moc,@RequestParam("username") String username)  throws IOException{
		String message = "";
		ResponseMessage response = new ResponseMessage();

		try {
			response = SOAWorkflowService.signOffByB2C(account, moc,username);

			if(response.getMessage().equals("Success")){
				message = "Signed Off successfully: ";

			}else{
				message = response.getMessage();
			}

			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Stage ID Not Updated ";
		}

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	}
	
	@PutMapping(value= "/finalPublishByB2C")
	public ResponseEntity<ResponseMessage> finalPublishByB2C(@RequestParam("account") String account,@RequestParam("moc") String moc,@RequestParam("username") String username)  throws IOException{
		String message = "";
		ResponseMessage response = new ResponseMessage();

		try {
			response = SOAWorkflowService.finalPublishByB2C(account, moc,username);

			if(response.getMessage().equals("Success")){
				message = "Published Successfully";

			}else{
				message = response.getMessage();
			}

			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Stage ID Not Updated ";
		}

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	}

	@PostMapping(value= "/uploadSupportingDoc")
	public ResponseEntity<ResponseMessage> uploadSupportingDoc(@RequestParam("file") final MultipartFile [] multipartFiles,
			@RequestParam("account") String account,@RequestParam("moc") String moc) throws IOException {

		ResponseMessage response = new ResponseMessage();

		try{
			List<String> fileNames = new ArrayList<String>();
			String resp="";

			Arrays.asList(multipartFiles).stream().forEach(file -> {

				SOAWorkflowService.save(file, account, moc, resp);
				fileNames.add(file.getOriginalFilename());

			});
			response.setMessage("Uploaded the files successfully: "+fileNames);
			return new ResponseEntity<ResponseMessage>(response, HttpStatus.OK);
		}
		catch(Exception e){
			e.printStackTrace();
			response.setMessage("Sorry!! Files Not Uploaded");
			return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}

	}



	@GetMapping(value = "/downloadSupportingDoc", produces="application/zip")
	public void downloadSupportingDoc(@RequestParam String account,@RequestParam String moc, HttpServletResponse response) throws IOException {
		try{ 
			Set<String> fileNames = new HashSet<String>();
			Set<String> fileNameList = new HashSet<String>();
	
			fileNames = promoClaimsExceptionAttachmntRepository.findFilesByAccountAndMOC(account, moc);
	
			for(String fileName : fileNames){
				String file = null;
				file = account+"_"+"_"+moc+"_"+fileName;
				fileNameList.add(file);
			}
			zipDownload(fileNameList,response);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	 public void zipDownload(@RequestParam Set<String> name, HttpServletResponse response) throws IOException {
		 	ZipOutputStream zipOut = new ZipOutputStream(response.getOutputStream());
		 	String zipFileName ="abc.zip";
		 	 byte bytes[] = new byte[4096];
		    
		 try{
		 	 
		    for (String fileName : name) {
		 		// S3Object s3object = amazonS3.getObject(bucketName, fileName);
		 		ZipEntry zipEntry = new ZipEntry(fileName);
		 		zipOut.putNextEntry(zipEntry);
		 		 InputStream in = SOAWorkflowService.downloadFileAsStream(bucketName, fileName);
		            int bytesRead = -1;

		            while ((bytesRead = in.read(bytes)) != -1) {
		            	zipOut.write(bytes, 0, bytesRead);
		            }
		           
		 	}
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 zipOut.closeEntry();
	         zipOut.finish();
	         zipOut.close();
		 }
		 	
		 	response.setStatus(HttpServletResponse.SC_OK);
		 	response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + zipFileName + "\"");
		 }
	 
	
	 //Added By Sarin Jun2021 - Excel file download for Multi SOLCodes - Starts
	 @GetMapping("/downloadPromoClaimMultiSOLCodes")
	 public ResponseEntity<Resource> downloadMultiSOLCodesDataSheetByB2C(@RequestParam("account") String account,@RequestParam("moc") String moc) {

		 String filename = "PromoClaimMultiSOLCodes.xlsx";
		 InputStreamResource file = new InputStreamResource(SOAWorkflowService.getMultiSOLCodePromoDetails(account, moc));
		 return ResponseEntity.ok()
				 .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				 .contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
				 .body(file);

	 }
	 
	 @PostMapping(value= "/uploadPromoClaimMultiSOLCodeDetailsB2C")
	 public ResponseEntity<ResponseMessage> uploadPromoClaimByExternal(@RequestParam("file") MultipartFile file, @RequestParam("moc") String moc, @RequestParam("account") String account) throws IOException{
		 String message = "";
		 ResponseMessage response = new ResponseMessage();

		 if (PromoClaimExcelHelper.hasExcelFormat(file)) {
			 try {
				 response = SOAWorkflowService.saveMultiSolCodeStage(file, account, moc);
				 message = response.getMessage();

				 return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
			 } catch (Exception e) {
				 e.printStackTrace();
				 message = "Could not upload the file: " + file.getOriginalFilename() + "!";
				 return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
			 }
		 }
		 message = "Please upload an excel file!";
		 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	 }
	 //Added By Sarin Jun2021 - Excel file download for Multi SOLCodes - Ends
	 
}