package com.unilever.asset.commercialB2C.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValue;
import com.unilever.global.GlobalVariables;

@Repository
public interface CommB2CDepotConnectedAssetValueReposiory  extends JpaRepository<CommB2CDepotConnectedAssetValue, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_DEPOT_CONNECTED_ASSETS_VALUE", nativeQuery = true)
	List<CommB2CDepotConnectedAssetValue> findDepotConnectedAssetValueDetails();
}
