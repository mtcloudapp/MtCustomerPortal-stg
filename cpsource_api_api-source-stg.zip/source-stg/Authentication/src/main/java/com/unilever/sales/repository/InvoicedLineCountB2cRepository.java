package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.PoInvoicedLineCount;
import com.unilever.sales.model.PoInvoicedLineCountB2c;

@Repository
public interface InvoicedLineCountB2cRepository extends JpaRepository<PoInvoicedLineCountB2c, Integer> {

	@Transactional
    @Query(value ="select count(distinct etas.PO_NUMBER,etas.CIC_NUMBER) from "+GlobalVariables.schemaName+".INVOICED_LINES_COUNT etas  where etas.BRANCH in :region and etas.ACCOUNT in :account and etas.MOC in :moc and etas.CATEGORY in :category", nativeQuery = true)
	Integer findInvoicedCountOfPo(@Param("region") List<String> region,@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("category") List<String> category);

}
