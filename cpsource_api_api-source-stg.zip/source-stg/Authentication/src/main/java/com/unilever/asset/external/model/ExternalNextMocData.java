package com.unilever.asset.external.model;

public class ExternalNextMocData {
	
	private Double storeListCount;
	private Double storeListValue;
	private Double totalPlannedAssetValue;
	private Double totalPlannedAssetVolume;
	
	public ExternalNextMocData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Double getStoreListCount() {
		return storeListCount;
	}

	public void setStoreListCount(Double storeListCount) {
		this.storeListCount = storeListCount;
	}

	public Double getStoreListValue() {
		return storeListValue;
	}

	public void setStoreListValue(Double storeListValue) {
		this.storeListValue = storeListValue;
	}

	public Double getTotalPlannedAssetValue() {
		return totalPlannedAssetValue;
	}

	public void setTotalPlannedAssetValue(Double totalPlannedAssetValue) {
		this.totalPlannedAssetValue = totalPlannedAssetValue;
	}

	public Double getTotalPlannedAssetVolume() {
		return totalPlannedAssetVolume;
	}

	public void setTotalPlannedAssetVolume(Double totalPlannedAssetVolume) {
		this.totalPlannedAssetVolume = totalPlannedAssetVolume;
	}
	
	
	

}
