package com.unilever.asset.commercialB2C.model;

public class JsonObjCommB2C {
 
	private Double totalAssetValue;
	private Double totalAssetVolume;
	private Double depotConnectedAssetValue;
	private Double depotConnectedAssetVolume;
	private Double deployedAssetValue;
	private Double deployedAssetVolume;
	private Double complieddAssetValue;
	private Double compliedAssetVolume;
	private Double notComplieddAssetValue;
	private Double notCompliedAssetVolume;
	
	
	public JsonObjCommB2C() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Double getTotalAssetValue() {
		return totalAssetValue;
	}


	public void setTotalAssetValue(Double totalAssetValue) {
		this.totalAssetValue = totalAssetValue;
	}


	public Double getTotalAssetVolume() {
		return totalAssetVolume;
	}


	public void setTotalAssetVolume(Double totalAssetVolume) {
		this.totalAssetVolume = totalAssetVolume;
	}


	public Double getDepotConnectedAssetValue() {
		return depotConnectedAssetValue;
	}


	public void setDepotConnectedAssetValue(Double depotConnectedAssetValue) {
		this.depotConnectedAssetValue = depotConnectedAssetValue;
	}


	public Double getDepotConnectedAssetVolume() {
		return depotConnectedAssetVolume;
	}


	public void setDepotConnectedAssetVolume(Double depotConnectedAssetVolume) {
		this.depotConnectedAssetVolume = depotConnectedAssetVolume;
	}


	public Double getDeployedAssetValue() {
		return deployedAssetValue;
	}


	public void setDeployedAssetValue(Double deployedAssetValue) {
		this.deployedAssetValue = deployedAssetValue;
	}


	public Double getDeployedAssetVolume() {
		return deployedAssetVolume;
	}


	public void setDeployedAssetVolume(Double deployedAssetVolume) {
		this.deployedAssetVolume = deployedAssetVolume;
	}


	public Double getComplieddAssetValue() {
		return complieddAssetValue;
	}


	public void setComplieddAssetValue(Double complieddAssetValue) {
		this.complieddAssetValue = complieddAssetValue;
	}


	public Double getCompliedAssetVolume() {
		return compliedAssetVolume;
	}


	public void setCompliedAssetVolume(Double compliedAssetVolume) {
		this.compliedAssetVolume = compliedAssetVolume;
	}


	public Double getNotComplieddAssetValue() {
		return notComplieddAssetValue;
	}


	public void setNotComplieddAssetValue(Double notComplieddAssetValue) {
		this.notComplieddAssetValue = notComplieddAssetValue;
	}


	public Double getNotCompliedAssetVolume() {
		return notCompliedAssetVolume;
	}


	public void setNotCompliedAssetVolume(Double notCompliedAssetVolume) {
		this.notCompliedAssetVolume = notCompliedAssetVolume;
	}
	
	
}
