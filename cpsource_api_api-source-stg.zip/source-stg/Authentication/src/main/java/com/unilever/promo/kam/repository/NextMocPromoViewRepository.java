package com.unilever.promo.kam.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.kam.model.CurrentMocPromoView;
import com.unilever.promo.kam.model.NextMocPromoView;
import com.unilever.promo.kam.model.NextMocPromoView;

@Repository
public interface NextMocPromoViewRepository extends PagingAndSortingRepository<NextMocPromoView, String> {
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMoc(@Param("username") String username,@Param("moc") List<String> moc,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm where icm.MOC in :moc and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findCountByMoc(@Param("username") String username,@Param("moc") List<String> moc);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMocCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm where icm.MOC in :moc and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findCountByMocCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMocAccount(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findCountByAccount(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMocAccountCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findCountByAccountMocCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMocRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm where icm.MOC in :moc and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findCountByMocRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMocAccountRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findCountByAccountMocRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMocRegionCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findAllCountNextMocViewByMocRegionCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.L2_CUSTOMER in :account and icm.CLUSTER in :region and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	Page<NextMocPromoView> findAllNextMocViewByMocRegionAccountCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_NEXT_PROMO icm  where icm.MOC in :moc and icm.L2_CUSTOMER in :account and icm.CLUSTER in :region and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	List<NextMocPromoView> findAllCountNextMocViewByMocRegionAccountCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);
	

}
