package com.unilever.sales.model;

import java.io.Serializable;

public class PieChartDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2388909960384840568L;
	
	
	private Double percentage;


	public PieChartDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Double getPercentage() {
		return percentage;
	}


	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}


	


	
	
	

}
