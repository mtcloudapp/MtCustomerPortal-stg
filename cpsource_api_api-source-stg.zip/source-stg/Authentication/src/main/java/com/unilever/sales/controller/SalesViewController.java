package com.unilever.sales.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.promo.commb2c.model.CurrentMocPromoB2cViewDto;
import com.unilever.sales.model.DetailedStatusDto;
import com.unilever.sales.model.DroppedPODto;
import com.unilever.sales.model.LossTreeDto;
import com.unilever.sales.model.QGPDto;
import com.unilever.sales.service.B2CSalesService;
import com.unilever.sales.service.SalesService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class SalesViewController {
   
	@Value("${aws.s3.bucket_promo_claims}")
	private String bucketName;
	
	@Autowired
	B2CSalesService b2cSalesService;

	@Autowired
	SalesService salesService;

	//==========================================================PO NUMBER LOGIC START========================================================

	@GetMapping("/getPONumberByB2C")
	public List<String> getPONumber(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category){

		List<String> poNumber = new ArrayList<String>();
		try{

			poNumber = b2cSalesService.getPONumberByB2C(account, moc, branch, category);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return poNumber;

	}
	@GetMapping("/getPONumberByKam")
	public List<String> getPONumberByKam(@RequestParam("username") String username, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("account")List<String>account){

		List<String> poNumber = new ArrayList<String>();
		try{

			poNumber = b2cSalesService.getPONumberByKam(username, moc, branch, category,account);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return poNumber;

	}
	@GetMapping("/getPONumberByExternal")
	public List<String> getPONumberByExternal(@RequestParam("account") String account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category){

		List<String> poNumber = new ArrayList<String>();
		try{

			poNumber = b2cSalesService.getPONumberByExternal(account, moc, branch, category);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return poNumber;

	}

	//==========================================================PO NUMBER LOGIC END========================================================

	//==========================================================STATUS LOGIC START========================================================


	@GetMapping("/getStatusByPONumberB2C")
	public List<String> getStatusByPONumberB2C(@RequestParam("poNumber") List<String> poNumber){

		List<String> status = new ArrayList<String>();
		try{

			status = b2cSalesService.getStatusByPONumberB2C(poNumber);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return status;

	}

	@GetMapping("/getStatusByPONumberKam")
	public List<String> getStatusByPONumberKam(@RequestParam("poNumber") List<String> poNumber){

		List<String> status = new ArrayList<String>();
		try{

			status = b2cSalesService.getStatusByPONumberKam(poNumber);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return status;

	}

	@GetMapping("/getStatusByPONumberExternal")
	public List<String> getStatusByPONumberExternal(@RequestParam("poNumber") List<String> poNumber){

		List<String> status = new ArrayList<String>();
		try{

			status = b2cSalesService.getStatusByPONumberExternal(poNumber);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return status;

	}

	//==========================================================STATUS LOGIC END========================================================



	//-=================================================DETAILED SATUS VIEW START========================================================================
	@GetMapping("/getDetailStatusViewByB2C")
	public List<DetailedStatusDto> getDetailStatusViewByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber,
			@RequestParam("status") List<String> status,@RequestParam(defaultValue = "1") Integer pageNo,@RequestParam(defaultValue = "10") Integer pageSize){

		List<DetailedStatusDto> detailedStatusDtoList = new ArrayList<DetailedStatusDto>();

		try{

			detailedStatusDtoList = b2cSalesService.getDetailedStatusViewByB2C(account, moc, branch, category, poNumber, status, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return detailedStatusDtoList;


	}


	@GetMapping("/getDetailedStatusViewByKam")
	public List<DetailedStatusDto> getDetailedStatusViewByKam(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber,
			@RequestParam("status") List<String> status,@RequestParam("username") String username,@RequestParam(defaultValue = "1") Integer pageNo,@RequestParam(defaultValue = "10") Integer pageSize){

		List<DetailedStatusDto> detailedStatusDtoList = new ArrayList<DetailedStatusDto>();

		try{

			detailedStatusDtoList = b2cSalesService.getDetailedStatusViewByKam(account, moc, branch, category, poNumber, status,username, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return detailedStatusDtoList;


	}

	@GetMapping("/getDetailedStatusViewByExternal")
	public List<DetailedStatusDto> getDetailedStatusViewByExternal(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber,
			@RequestParam("status") List<String> status,@RequestParam(defaultValue = "1") Integer pageNo,@RequestParam(defaultValue = "10") Integer pageSize){

		List<DetailedStatusDto> detailedStatusDtoList = new ArrayList<DetailedStatusDto>();

		try{

			detailedStatusDtoList = b2cSalesService.getDetailedStatusViewByExternal(account, moc, branch, category, poNumber, status, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return detailedStatusDtoList;


	}

	//-=================================================DETAILED SATUS VIEW END========================================================================


	//==============================================================QGP LOGIC START ===================================================================

	@GetMapping("/getQGPDetailsByB2C")
	public QGPDto getQGPDetailsByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category){

		QGPDto qgpDto = new QGPDto();
		try{

			qgpDto = b2cSalesService.getQGPDetailsByB2C(account, moc, branch, category);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return qgpDto;

	}

	@GetMapping("/getQGPDetailsByKAM")
	public QGPDto getQGPDetailsByKAM(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("username") String username){

		QGPDto qgpDto = new QGPDto();
		try{

			qgpDto = b2cSalesService.getQGPDetailsByKAM(account, moc, branch, category,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return qgpDto;

	}

	@GetMapping("/getQGPDetailsByExternal")
	public QGPDto getQGPDetailsByExternal(@RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("username") String username){

		QGPDto qgpDto = new QGPDto();
		try{

			qgpDto = b2cSalesService.getQGPDetailsByExternal(moc, branch, category,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return qgpDto;

	}

	//==============================================================QGP LOGIC END ===================================================================

	//========================================================DROPPED PO LOGIC START=================================================

	@GetMapping("/getDroppedPODetailsByB2C")
	public DroppedPODto getDroppedPODetailsByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber")List<String>poNumber,String isAll){

		DroppedPODto droppedPODto = new DroppedPODto();
		try{

			droppedPODto = b2cSalesService.getDroppedPOByB2C(account, moc, branch, category, poNumber, isAll);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return droppedPODto;

	}

	@GetMapping("/getDroppedPODetailsByKam")
	public DroppedPODto getDroppedPODetailsByKam(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber")List<String>poNumber,@RequestParam("username")List<String>username,String isAll){

		DroppedPODto droppedPODto = new DroppedPODto();
		try{

			droppedPODto = b2cSalesService.getDroppedPOByKam(account, moc, branch, category, poNumber, username, isAll);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return droppedPODto;

	}

	@GetMapping("/getDroppedPODetailsByExternal")
	public DroppedPODto getDroppedPODetailsByExternal( @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber")List<String>poNumber,@RequestParam("username")List<String>username,String isAll){

		DroppedPODto droppedPODto = new DroppedPODto();
		try{

			droppedPODto = b2cSalesService.getDroppedPOByExternal(moc, branch, category, poNumber, username, isAll);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return droppedPODto;

	}




	//========================================================DROPPED PO LOGIC END=================================================


	//========================================================EXCEL DOWNLOAD FOR B2C START=================================================

	@GetMapping("/downloadSalesDataSheetByB2C")
	public ResponseEntity<Resource> downloadSalesDataSheetByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category) {
		String filename = "C:\\Users\\subhasishdatvst\\Desktop\\store_list.xlsx";

		InputStreamResource file = new InputStreamResource(salesService.getSalesDataDetails(account, moc, branch, category));

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
				.body(file);


	}

	@GetMapping("/downloadDroppedDataSheetByB2C")
	public ResponseEntity<Resource> downloadDroppedDataSheetByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch) {
		String filename = "C:\\Users\\subhasishdatvst\\Desktop\\store_list.xlsx";

		InputStreamResource file = new InputStreamResource(salesService.getDroppedDetails(account, moc, branch));

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
				.body(file);


	}



}
