package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.ViewTableModel;
import com.unilever.global.GlobalVariables;

public interface ViewTableRepository extends JpaRepository<ViewTableModel, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".viewtable icm  where icm.ACCOUNT=:account and icm.MOC=:moc", nativeQuery = true)
	List<ViewTableModel> findAllCurrentMocView(@Param("account") String account,@Param("moc") String moc);
	

}
