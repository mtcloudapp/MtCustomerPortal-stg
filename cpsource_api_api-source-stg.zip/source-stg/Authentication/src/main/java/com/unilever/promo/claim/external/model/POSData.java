package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "POS_DATA")
public class POSData implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 8645433633297912709L;
	
	@Id
	@Column(name="FILE_NO")
	private Integer fileNo;

	@Column(name="WORKFLOW_STAGE_ID")
	private Integer workflowStageID;

	@Column(name="ACCOUNT_NAME")
	private String accountName;

	@Column(name="MOC")
	private String moc;
	
	@Column(name="UPLOAD_BY")
	private String uploadBy;
	
	@Column(name="ARTICLE_CODE")
	private Integer articleCode;
	
	@Column(name="BILL_QTY")
	private Integer billQty;
	
	@Column(name="AUDIT_CREATE_DATE")
	private String auditCreateDate;

	@Column(name="AUDIT_MODIFIED_DATE")
	private String auditModifiedDate;

	public POSData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public POSData(Integer fileNo, Integer workflowStageID, String accountName, String moc, String uploadBy,
			Integer articleCode, Integer billQty, String auditCreateDate, String auditModifiedDate) {
		super();
		this.fileNo = fileNo;
		this.workflowStageID = workflowStageID;
		this.accountName = accountName;
		this.moc = moc;
		this.uploadBy = uploadBy;
		this.articleCode = articleCode;
		this.billQty = billQty;
		this.auditCreateDate = auditCreateDate;
		this.auditModifiedDate = auditModifiedDate;
	}

	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	public Integer getWorkflowStageID() {
		return workflowStageID;
	}

	public void setWorkflowStageID(Integer workflowStageID) {
		this.workflowStageID = workflowStageID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getUploadBy() {
		return uploadBy;
	}

	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public Integer getBillQty() {
		return billQty;
	}

	public void setBillQty(Integer billQty) {
		this.billQty = billQty;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}

	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}

	

}
