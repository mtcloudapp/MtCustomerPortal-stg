package com.unilever.asset.commercialB2C.model;

public class NextMocJsonCommB2C {
	
	private Double storeListTotalCount;
	private Double storeListTotalValue;
	private Double plannedAssetValue;
	private Double plannedAssetVolume;
	private Double depotConnetedAssetValue;
	private Double depotConnetedAssetVolume;
	
	
	
	public NextMocJsonCommB2C() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Double getStoreListTotalCount() {
		return storeListTotalCount;
	}
	public void setStoreListTotalCount(Double storeListTotalCount) {
		this.storeListTotalCount = storeListTotalCount;
	}
	public Double getStoreListTotalValue() {
		return storeListTotalValue;
	}
	public void setStoreListTotalValue(Double storeListTotalValue) {
		this.storeListTotalValue = storeListTotalValue;
	}
	public Double getPlannedAssetValue() {
		return plannedAssetValue;
	}
	public void setPlannedAssetValue(Double plannedAssetValue) {
		this.plannedAssetValue = plannedAssetValue;
	}
	public Double getPlannedAssetVolume() {
		return plannedAssetVolume;
	}
	public void setPlannedAssetVolume(Double plannedAssetVolume) {
		this.plannedAssetVolume = plannedAssetVolume;
	}
	public Double getDepotConnetedAssetValue() {
		return depotConnetedAssetValue;
	}
	public void setDepotConnetedAssetValue(Double depotConnetedAssetValue) {
		this.depotConnetedAssetValue = depotConnetedAssetValue;
	}
	public Double getDepotConnetedAssetVolume() {
		return depotConnetedAssetVolume;
	}
	public void setDepotConnetedAssetVolume(Double depotConnetedAssetVolume) {
		this.depotConnetedAssetVolume = depotConnetedAssetVolume;
	}
	

}
