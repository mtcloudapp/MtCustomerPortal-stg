package com.unilever.Authentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.Authentication.model.Account;
import com.unilever.global.GlobalVariables;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer>{

 
  @Transactional
  @Query(value ="select us.USER_ID from "+GlobalVariables.schemaName+".USER_MASTER us where us.USERNAME=:username", nativeQuery = true)
  Integer findUserIdByUsername(@Param("username") String username);
  
  @Transactional
  @Query(value ="SELECT distinct  acc.*  FROM "+GlobalVariables.schemaName+".ACCOUNT acc INNER JOIN "+GlobalVariables.schemaName+".USER_ACCOUNT up ON up.ACCOUNT_ID = acc.ACCOUNT_ID where up.USER_ID=:id", nativeQuery = true)
  List<Account> findAccountByUserId(@Param("id") Integer id);
	
 @Transactional
 @Query(value ="SELECT  distinct cat.CATEGORY_NAME , acc.ACCOUNT_NAME FROM "+GlobalVariables.schemaName+".CATEGORY cat  INNER JOIN "+GlobalVariables.schemaName+".USER_ACCOUNT up ON up.CATEGORY_ID = cat.CATEGORY_ID INNER JOIN  "+GlobalVariables.schemaName+".ACCOUNT acc ON up.ACCOUNT_ID = acc.ACCOUNT_ID INNER JOIN  "+GlobalVariables.schemaName+".USER_MASTER u ON up.USER_ID = u.USER_ID where up.USER_ID=:id", nativeQuery = true)
 List<String> findCategoryAccountByAccountId(@Param("id") Integer id);
  

 
 
 
 @Transactional
 @Query(value ="select distinct cat.CATEGORY_NAME from "+GlobalVariables.schemaName+".CATEGORY cat where cat.CATEGORY_ID=:id", nativeQuery = true)
 String findCategoryByCategoryId(@Param("id") Integer id);
 	

	
}


