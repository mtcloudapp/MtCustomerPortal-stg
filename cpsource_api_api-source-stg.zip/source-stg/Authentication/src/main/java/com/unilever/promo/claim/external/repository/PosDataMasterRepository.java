package com.unilever.promo.claim.external.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PosDataMaster;

@Repository
public interface PosDataMasterRepository extends JpaRepository<PosDataMaster, Integer>{
	
	@Transactional
	@Query(value = "CALL sp_LoadPOSData(:accountName, :moc);", nativeQuery = true)
	void insertPosDataByAccountName(@Param("accountName")String accountName, @Param("moc") String moc);  //Added By Sarin Jul2021 - Claim File B2C Approval
	//void insertPosDataByAccountName(@Param("accountName")String accountName);  //Commented By Sarin Jul2021 - Claim File B2C Approval
	
	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".POS_DATA_MASTER pcfm where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNoOfPOSDataMst(@Param("accountName") String accountName, @Param("moc") String moc);


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".POS_DATA_MASTER  pcfm set pcfm.WORKFLOW_STAGE_ID=:stageID  where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updatePOSDataMstByAccountMocFileNo(@Param("stageID") Integer stageID,@Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);


	@Transactional
	@Query(value ="select count(*) from "+GlobalVariables.schemaName+".POS_DATA_MASTER pcfm where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findPOSDataMst(@Param("accountName") String accountName, @Param("moc") String moc);
}
