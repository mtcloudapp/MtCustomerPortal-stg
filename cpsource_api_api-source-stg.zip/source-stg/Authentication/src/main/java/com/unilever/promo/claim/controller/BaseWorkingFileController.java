package com.unilever.promo.claim.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.unilever.message.ResponseMessage;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class BaseWorkingFileController {
	
	@PostMapping(value= "/baseWorkingSheetUploadByB2C")
	public ResponseEntity<ResponseMessage> uploadByB2C(@RequestParam("file") final MultipartFile [] multipartFiles,
			@RequestParam("account") String account,@RequestParam("moc") String moc)  throws IOException{
		
		 ResponseMessage response = new ResponseMessage();
		
		try{
			List<String> fileNames = new ArrayList<String>();
			Integer count = 1;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
		
	}

}
