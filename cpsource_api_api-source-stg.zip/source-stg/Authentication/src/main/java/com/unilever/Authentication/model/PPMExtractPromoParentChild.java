package com.unilever.Authentication.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PPM_EXTRACT_PROMO_PARENT_CHILD")
public class PPMExtractPromoParentChild implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4168252945115557280L;
	
	@Id
	private Integer PARENT_PROMOTION_ID;
	
	@Column(name="CHILD_PROMOTION_ID")
    private Integer childPromotionID;
  	
  	@Column(name="RELATIONSHIP")
    private Integer relationship;

	public PPMExtractPromoParentChild() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PPMExtractPromoParentChild(Integer pARENT_PROMOTION_ID, Integer childPromotionID, Integer relationship) {
		super();
		PARENT_PROMOTION_ID = pARENT_PROMOTION_ID;
		this.childPromotionID = childPromotionID;
		this.relationship = relationship;
	}

	public Integer getPARENT_PROMOTION_ID() {
		return PARENT_PROMOTION_ID;
	}

	public void setPARENT_PROMOTION_ID(Integer pARENT_PROMOTION_ID) {
		PARENT_PROMOTION_ID = pARENT_PROMOTION_ID;
	}

	public Integer getChildPromotionID() {
		return childPromotionID;
	}

	public void setChildPromotionID(Integer childPromotionID) {
		this.childPromotionID = childPromotionID;
	}

	public Integer getRelationship() {
		return relationship;
	}

	public void setRelationship(Integer relationship) {
		this.relationship = relationship;
	}
  	
  	

}
