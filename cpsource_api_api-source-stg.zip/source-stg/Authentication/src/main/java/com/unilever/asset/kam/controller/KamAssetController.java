package com.unilever.asset.kam.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.asset.kam.model.CompliedAssetValue;
import com.unilever.asset.kam.model.CompliedAssetVolume;
import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.CurrentMocViewDto;
import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.asset.kam.model.NextMocViewDto;
import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.asset.kam.model.PreviousMocView;
import com.unilever.asset.kam.model.PreviousMocViewDto;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.model.ViewTableModel;
import com.unilever.asset.kam.service.KamAssetService;
import com.unilever.asset.kam.service.KamNextMocAssetService;
import com.unilever.message.ResponseMessage;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class KamAssetController {

	@Autowired
	KamAssetService kamAssetService;





	@GetMapping("/getAllTotalAssetValue")
	public TotalAssetCreatedValue getAllTotalAssetValue(@RequestParam("username") String username, @RequestParam("region") List<String> region,@RequestParam("account") List<String> account, @RequestParam("moc") String moc,@RequestParam("category") List<String> category) {
		int totalAssetValueSum=0;
		TotalAssetCreatedValue totalAssetValue = new TotalAssetCreatedValue();
		try{
			/*String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}*/
	//		totalAssetValue = kamAssetService.getTotalAssetCreatedValue(username, region, account, moc, category);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetValue;		

	}

	/*@GetMapping("/getAllTotalAssetVolume")
	public TotalAssetCreatedVolume getAllTotalAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		TotalAssetCreatedVolume totalAssetCreatedVolumeSum = new TotalAssetCreatedVolume();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			totalAssetCreatedVolumeSum = kamAssetService.getTotalAssetCreatedVolume(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetCreatedVolumeSum;		

	}
*/

	//====================================== Depot conected Asset Start=================================


	/*@GetMapping("/getAllDepotConnectedAssetValue")
	public DepotConnectedAssetValue getAllDepotConnectedAssetValue(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetValueSum=0;
		DepotConnectedAssetValue totalAssetValue = new DepotConnectedAssetValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}

			totalAssetValue = kamAssetService.getAllDepotConnectedAssetValue(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetValue;		

	}
*/
	@GetMapping("/getAllDepotConnectedAssetVolume")
	public DepotConnectedAssetVolume getAllDepotConnectedAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		DepotConnectedAssetVolume totalAssetCreatedVolumeSum = new DepotConnectedAssetVolume();
		try{

			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}

			//totalAssetCreatedVolumeSum = kamAssetService.getAllDepotConnectedAssetVolume(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetCreatedVolumeSum;		

	}


	//=================================================================== Deployed Asset Start =====================================================

	@GetMapping("/getAllDeployedAssetValue")
	public DeployedAssetValue getAllDeployedAssetValue(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetValueSum=0;
		DeployedAssetValue totalAssetValue = new DeployedAssetValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			//totalAssetValue = kamAssetService.getDeployedAssetValue(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetValue;		

	}

	@GetMapping("/getAllDeployedAssetVolume")
	public DepolyedAssetVolume getAllDeployedAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		DepolyedAssetVolume totalAssetCreatedVolumeSum = new DepolyedAssetVolume();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}

		//	totalAssetCreatedVolumeSum = kamAssetService.getAllDeployedAssetVolume(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetCreatedVolumeSum;		

	}



	//==========================================Complied Asset Start=============================================


	@GetMapping("/getAllCompliedAssetValue")
	public CompliedAssetValue getAllCompliedAssetValue(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetValueSum=0;
		CompliedAssetValue totalAssetValue = new CompliedAssetValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			//totalAssetValue = kamAssetService.getCompliedAssetValue(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetValue;		

	}

	@GetMapping("/getAllCompliedAssetVolume")
	public CompliedAssetVolume getAllCompliedAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		CompliedAssetVolume totalAssetCreatedVolumeSum = new CompliedAssetVolume();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			//totalAssetCreatedVolumeSum = kamAssetService.getAllCompliedAssetVolume(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetCreatedVolumeSum;		

	}



	//==========================================Not Complied Asset Start============================================

	@GetMapping("/getAllNotCompliedAssetValue")
	public NotCompliedAssetValue getAllNotCompliedAssetValue(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {

		NotCompliedAssetValue totalAssetValue = new NotCompliedAssetValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			//totalAssetValue = kamAssetService.getNotCompliedAssetValue(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetValue;		

	}

	@GetMapping("/getAllNotCompliedAssetVolume")
	public NotCompliedAssetVolume getAllNotCompliedAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {

		NotCompliedAssetVolume totalAssetCreatedVolumeSum = new NotCompliedAssetVolume();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
		//	totalAssetCreatedVolumeSum = kamAssetService.getNotCompliedAssetVolume(username, region, account, moc, catgory);


		}catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetCreatedVolumeSum;		

	}

	//======================================= Current MOC View==================================================

	@GetMapping("/getCurrentMocView")
	public List<CurrentMocViewDto> getCurrentMocView(@RequestParam("region") List<String> region,@RequestParam("accounts") List<String> accounts,
												  @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
												  @RequestParam(defaultValue = "10") Integer pageSize){
		
    List<CurrentMocViewDto> currentMocViewDetails = new ArrayList<CurrentMocViewDto>();
		
		try{
			 	currentMocViewDetails = kamAssetService.getCurrentMocView(region,accounts,moc,category,pageNo,pageSize);
			
		    }
		catch(Exception e){
			e.printStackTrace();
		}
		return currentMocViewDetails;

	}

	



	//======================================= Previous MOC View==================================================
	@GetMapping("/getPreviousMocView")
	public List<PreviousMocViewDto> getPreviousMocView(@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
		    @RequestParam(defaultValue = "10") Integer pageSize){

		List<PreviousMocViewDto> previousMocDetails = new ArrayList<>();
		try{
			
				previousMocDetails = kamAssetService.getPreviousMocView(region,accounts, moc, category,pageNo,pageSize);
		
		   }
		catch(Exception e){
			e.printStackTrace();
		}
		return previousMocDetails;

	}

	//======================================= Next MOC View==================================================
	@GetMapping("/getNextMocView")
	public List<NextMocViewDto> getNextMocView(@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
		    @RequestParam(defaultValue = "10") Integer pageSize){

		List<NextMocViewDto> nextMocDetails = new ArrayList<NextMocViewDto>();
		try{
		
				nextMocDetails = kamAssetService.getNextMocView(region,accounts, moc, category,pageNo,pageSize);
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return nextMocDetails;

	}

}
