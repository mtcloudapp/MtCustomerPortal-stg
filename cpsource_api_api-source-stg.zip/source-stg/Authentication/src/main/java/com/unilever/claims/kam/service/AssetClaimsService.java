package com.unilever.claims.kam.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unilever.claims.extenal.model.ExternalServiceNoteMaster;
import com.unilever.claims.external.repository.ExternalPaymetStatusRepository;
import com.unilever.claims.external.repository.ExternalServiceNoteMasterRepository;
import com.unilever.claims.kam.model.ApprovedExceptionClaimValue;
import com.unilever.claims.kam.model.ApprovedExceptionClaimVolume;
import com.unilever.claims.kam.model.ClaimsRaised;
import com.unilever.claims.kam.model.GreenClaimValue;
import com.unilever.claims.kam.model.GreenClaimVolume;
import com.unilever.claims.kam.model.RedClaimValue;
import com.unilever.claims.kam.model.RedClaimVolume;
import com.unilever.claims.kam.model.TotalAmountPaid;
import com.unilever.claims.kam.model.TotalAmountPayable;
import com.unilever.claims.kam.model.TotalAmountPending;
import com.unilever.claims.kam.model.TotalAmountPlanned;
import com.unilever.claims.kam.repository.ApprovedExceptiobClaimsValueRepository;
import com.unilever.claims.kam.repository.ApprovedExceptiobClaimsVolumeRepository;
import com.unilever.claims.kam.repository.ClaimsRaisedRepository;
import com.unilever.claims.kam.repository.GreenClaimsValueRepository;
import com.unilever.claims.kam.repository.GreenClaimsVolumeRepository;
import com.unilever.claims.kam.repository.RedClaimsValueRepository;
import com.unilever.claims.kam.repository.RedClaimsVolumeRepository;
import com.unilever.claims.kam.repository.TotalAmountPaidRepository;
import com.unilever.claims.kam.repository.TotalAmountPayableRepository;
import com.unilever.claims.kam.repository.TotalAmountPendingRepository;
import com.unilever.claims.kam.repository.TotalAmountPlannedRepository;

@Service
public class AssetClaimsService {
	
	@Autowired
	TotalAmountPlannedRepository totalAmountPlannedRepository;
	
	@Autowired
	GreenClaimsValueRepository greenClaimsValueRepository;
	
	@Autowired
	GreenClaimsVolumeRepository greenClaimsVolumeRepository;
	
	@Autowired
	ApprovedExceptiobClaimsValueRepository approvedExceptiobClaimsValueRepository;
	
	@Autowired
	ApprovedExceptiobClaimsVolumeRepository approvedExceptiobClaimsVolumeRepository;
	
	@Autowired
	RedClaimsValueRepository redClaimsValueRepository;
	
	@Autowired
	RedClaimsVolumeRepository redClaimsVolumeRepository;
	
	@Autowired
	TotalAmountPayableRepository totalAmountPayableRepository;
	
	@Autowired
	TotalAmountPaidRepository totalAmountPaidRepository;
	
	@Autowired
	TotalAmountPendingRepository totalAmountPendingRepository;
	
	@Autowired
	ClaimsRaisedRepository claimsRaisedRepository; 
	
	@Autowired
	ExternalServiceNoteMasterRepository externalServiceNoteMasterRepository;
	
	@Autowired
	ExternalPaymetStatusRepository externalPaymetStatusRepository;
	
	//=========================================================Total Amount Planned Start========================================================================
	
	public TotalAmountPlanned getTotalAmountPlanned(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TotalAmountPlanned totalAssetAmountSum = new TotalAmountPlanned();


		try{
			List<TotalAmountPlanned> totalAssetValues = new ArrayList<TotalAmountPlanned>();
			List<TotalAmountPlanned> totalAssetValuesByUsername = new ArrayList<TotalAmountPlanned>();
			List<TotalAmountPlanned> mocList = new ArrayList<TotalAmountPlanned>();
			
			totalAssetValuesByUsername = totalAmountPlannedRepository.findAllTotalAmountPlanned(username);
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlanned mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(TotalAmountPlanned t : mocList){
					totalAssetAmount += t.getTotalAmountPlanned();

				}

				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<TotalAmountPlanned> categoryList = new ArrayList<TotalAmountPlanned>();
				
				//filtered by category

				for(String c : category){
					for(TotalAmountPlanned cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlanned mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(TotalAmountPlanned t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();

				}
				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<TotalAmountPlanned> accountList = new ArrayList<TotalAmountPlanned>();
				
				
				for(String accnt : account){
					for(TotalAmountPlanned acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlanned mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAmountPlanned t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();

				}
				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<TotalAmountPlanned> accountList = new ArrayList<TotalAmountPlanned>();
				List<TotalAmountPlanned> filteredAccountCategoryList = new ArrayList<TotalAmountPlanned>();
				

				//filterd by account
				for(String accnt : account){
					for(TotalAmountPlanned acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(TotalAmountPlanned cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlanned mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAmountPlanned t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();
				}
				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<TotalAmountPlanned> regionList = new ArrayList<TotalAmountPlanned>();
				
				
				//filter by region
				for(String regon : region){
					for(TotalAmountPlanned reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlanned mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPlanned t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();
				}

				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<TotalAmountPlanned> regionList = new ArrayList<TotalAmountPlanned>();
				List<TotalAmountPlanned> filteredRegionAccountList = new ArrayList<TotalAmountPlanned>();
				
				
				//filter by region
				for(String regon : region){
					for(TotalAmountPlanned reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(TotalAmountPlanned acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlanned mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(TotalAmountPlanned t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();

				}
				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<TotalAmountPlanned> regionList = new ArrayList<TotalAmountPlanned>();
				List<TotalAmountPlanned> filteredRegionCategoryList = new ArrayList<TotalAmountPlanned>();
				
				//filterd by region

				for(String regon : region){
					for(TotalAmountPlanned reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(TotalAmountPlanned cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlanned mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPlanned t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();
				}
				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<TotalAmountPlanned> regionList = new ArrayList<TotalAmountPlanned>();
				List<TotalAmountPlanned> accountList = new ArrayList<TotalAmountPlanned>();
				List<TotalAmountPlanned> filteredRegionCategoryList = new ArrayList<TotalAmountPlanned>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(TotalAmountPlanned reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(TotalAmountPlanned acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(TotalAmountPlanned cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPlanned mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAmountPlanned t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPlanned();
					}

					totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	
	//=========================================================Green Claims Value Start==========================================================================
	
	public GreenClaimValue getGreenClaimsValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		GreenClaimValue totalAssetAmountSum = new GreenClaimValue();


		try{
			List<GreenClaimValue> totalAssetValues = new ArrayList<GreenClaimValue>();
			List<GreenClaimValue> totalAssetValuesByUsername = new ArrayList<GreenClaimValue>();
			List<GreenClaimValue> mocList = new ArrayList<GreenClaimValue>();
			
			totalAssetValuesByUsername = greenClaimsValueRepository.findAllGreenClaimValue(username);
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimValue mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(GreenClaimValue t : mocList){
					totalAssetAmount += t.getGreenClaimValue();

				}

				totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<GreenClaimValue> categoryList = new ArrayList<GreenClaimValue>();
				
				//filtered by category

				for(String c : category){
					for(GreenClaimValue cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(GreenClaimValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(GreenClaimValue t : totalAssetValues){
					totalAssetAmount += t.getGreenClaimValue();

				}
				totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<GreenClaimValue> accountList = new ArrayList<GreenClaimValue>();
				
				
				for(String accnt : account){
					for(GreenClaimValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(GreenClaimValue t : totalAssetValues){
					totalAssetAmount += t.getGreenClaimValue();

				}
				totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<GreenClaimValue> accountList = new ArrayList<GreenClaimValue>();
				List<GreenClaimValue> filteredAccountCategoryList = new ArrayList<GreenClaimValue>();
				

				//filterd by account
				for(String accnt : account){
					for(GreenClaimValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(GreenClaimValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(GreenClaimValue t : totalAssetValues){
					totalAssetAmount += t.getGreenClaimValue();
				}
				totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<GreenClaimValue> regionList = new ArrayList<GreenClaimValue>();
				
				
				//filter by region
				for(String regon : region){
					for(GreenClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(GreenClaimValue t : totalAssetValues){
					totalAssetAmount += t.getGreenClaimValue();
				}

				totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<GreenClaimValue> regionList = new ArrayList<GreenClaimValue>();
				List<GreenClaimValue> filteredRegionAccountList = new ArrayList<GreenClaimValue>();
				
				
				//filter by region
				for(String regon : region){
					for(GreenClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(GreenClaimValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(GreenClaimValue t : totalAssetValues){
					totalAssetAmount += t.getGreenClaimValue();

				}
				totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<GreenClaimValue> regionList = new ArrayList<GreenClaimValue>();
				List<GreenClaimValue> filteredRegionCategoryList = new ArrayList<GreenClaimValue>();
				
				//filterd by region

				for(String regon : region){
					for(GreenClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(GreenClaimValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(GreenClaimValue t : totalAssetValues){
					totalAssetAmount += t.getGreenClaimValue();
				}
				totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<GreenClaimValue> regionList = new ArrayList<GreenClaimValue>();
				List<GreenClaimValue> accountList = new ArrayList<GreenClaimValue>();
				List<GreenClaimValue> filteredRegionCategoryList = new ArrayList<GreenClaimValue>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(GreenClaimValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(GreenClaimValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(GreenClaimValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(GreenClaimValue t : totalAssetValues){
						totalAssetAmount += t.getGreenClaimValue();
					}

					totalAssetAmountSum.setGreenClaimValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	
	//=========================================================Green Claims Volume Start==========================================================================
	
	
	public GreenClaimVolume getGreenClaimsVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		GreenClaimVolume totalAssetVolumeSum= new GreenClaimVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<GreenClaimVolume> totalAssetVolumes = new ArrayList<GreenClaimVolume>();
			List<GreenClaimVolume> totalAssetVolumeByUsername = new ArrayList<GreenClaimVolume>();
			List<GreenClaimVolume> mocList = new ArrayList<GreenClaimVolume>();
			
			totalAssetVolumeByUsername = greenClaimsVolumeRepository.findAllGreenClaimVolume(username);
           

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimVolume mocc : totalAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				for(GreenClaimVolume t : mocList){
					totalAssetVolume += t.getGreenClaimVolume();

				}

				totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<GreenClaimVolume> categoryList = new ArrayList<GreenClaimVolume>();

				//filtered by category

				for(String c : category){
					for(GreenClaimVolume cat : totalAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(GreenClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getGreenClaimVolume();

				}
				totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<GreenClaimVolume> accountList = new ArrayList<GreenClaimVolume>();
				
				for(String accnt : account){
					for(GreenClaimVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(GreenClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getGreenClaimVolume();

				}
				totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<GreenClaimVolume> accountList = new ArrayList<GreenClaimVolume>();
				List<GreenClaimVolume> filteredAccountCategoryList = new ArrayList<GreenClaimVolume>();


				//filterd by account
				for(String accnt : account){
					for(GreenClaimVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(GreenClaimVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(GreenClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getGreenClaimVolume();
				}
				totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<GreenClaimVolume> regionList = new ArrayList<GreenClaimVolume>();
				
				//filter by region
				for(String regon : region){
					for(GreenClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(GreenClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getGreenClaimVolume();
				}

				totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<GreenClaimVolume> regionList = new ArrayList<GreenClaimVolume>();
				List<GreenClaimVolume> filteredRegionAccountList = new ArrayList<GreenClaimVolume>();
				
				//filter by region
				for(String regon : region){
					for(GreenClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(GreenClaimVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(GreenClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getGreenClaimVolume();

				}
				totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<GreenClaimVolume> regionList = new ArrayList<GreenClaimVolume>();
				List<GreenClaimVolume> filteredRegionCategoryList = new ArrayList<GreenClaimVolume>();
			
				//filterd by region

				for(String regon : region){
					for(GreenClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(GreenClaimVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(GreenClaimVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(GreenClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getGreenClaimVolume();
				}
				totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<GreenClaimVolume> regionList = new ArrayList<GreenClaimVolume>();
				List<GreenClaimVolume> accountList = new ArrayList<GreenClaimVolume>();
				List<GreenClaimVolume> filteredRegionCategoryList = new ArrayList<GreenClaimVolume>();
				
				if(totalAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(GreenClaimVolume reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(GreenClaimVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(GreenClaimVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(GreenClaimVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(GreenClaimVolume t : totalAssetVolumes){
						totalAssetVolume += t.getGreenClaimVolume();
					}

					totalAssetVolumeSum.setGreenClaimVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}

	
	
	//=========================================================Approved Exception Claim Value Start==========================================================================
	
	public ApprovedExceptionClaimValue getApprovedExceptionClaimValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		ApprovedExceptionClaimValue totalAssetAmountSum = new ApprovedExceptionClaimValue();


		try{
			List<ApprovedExceptionClaimValue> totalAssetValues = new ArrayList<ApprovedExceptionClaimValue>();
			List<ApprovedExceptionClaimValue> totalAssetValuesByUsername = new ArrayList<ApprovedExceptionClaimValue>();
			List<ApprovedExceptionClaimValue> mocList = new ArrayList<ApprovedExceptionClaimValue>();
			
			totalAssetValuesByUsername = approvedExceptiobClaimsValueRepository.findAllApprovedExceptionClaimValue(username);
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimValue mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(ApprovedExceptionClaimValue t : mocList){
					totalAssetAmount += t.getApprovedExceptionClaimValue();

				}

				totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<ApprovedExceptionClaimValue> categoryList = new ArrayList<ApprovedExceptionClaimValue>();
				
				//filtered by category

				for(String c : category){
					for(ApprovedExceptionClaimValue cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(ApprovedExceptionClaimValue t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimValue();

				}
				totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<ApprovedExceptionClaimValue> accountList = new ArrayList<ApprovedExceptionClaimValue>();
				
				
				for(String accnt : account){
					for(ApprovedExceptionClaimValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(ApprovedExceptionClaimValue t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimValue();

				}
				totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<ApprovedExceptionClaimValue> accountList = new ArrayList<ApprovedExceptionClaimValue>();
				List<ApprovedExceptionClaimValue> filteredAccountCategoryList = new ArrayList<ApprovedExceptionClaimValue>();
				

				//filterd by account
				for(String accnt : account){
					for(ApprovedExceptionClaimValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(ApprovedExceptionClaimValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(ApprovedExceptionClaimValue t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimValue();
				}
				totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<ApprovedExceptionClaimValue> regionList = new ArrayList<ApprovedExceptionClaimValue>();
				
				
				//filter by region
				for(String regon : region){
					for(ApprovedExceptionClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(ApprovedExceptionClaimValue t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimValue();
				}

				totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<ApprovedExceptionClaimValue> regionList = new ArrayList<ApprovedExceptionClaimValue>();
				List<ApprovedExceptionClaimValue> filteredRegionAccountList = new ArrayList<ApprovedExceptionClaimValue>();
				
				
				//filter by region
				for(String regon : region){
					for(ApprovedExceptionClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(ApprovedExceptionClaimValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(ApprovedExceptionClaimValue t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimValue();

				}
				totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<ApprovedExceptionClaimValue> regionList = new ArrayList<ApprovedExceptionClaimValue>();
				List<ApprovedExceptionClaimValue> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimValue>();
				
				//filterd by region

				for(String regon : region){
					for(ApprovedExceptionClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(ApprovedExceptionClaimValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(ApprovedExceptionClaimValue t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimValue();
				}
				totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<ApprovedExceptionClaimValue> regionList = new ArrayList<ApprovedExceptionClaimValue>();
				List<ApprovedExceptionClaimValue> accountList = new ArrayList<ApprovedExceptionClaimValue>();
				List<ApprovedExceptionClaimValue> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimValue>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(ApprovedExceptionClaimValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(ApprovedExceptionClaimValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(ApprovedExceptionClaimValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(ApprovedExceptionClaimValue t : totalAssetValues){
						totalAssetAmount += t.getApprovedExceptionClaimValue();
					}

					totalAssetAmountSum.setApprovedExceptionClaimValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	
	//=========================================================Approved Exception Claim Value Start==========================================================================
	
	
	public ApprovedExceptionClaimVolume getApprovedExceptionClaimVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		ApprovedExceptionClaimVolume totalAssetVolumeSum= new ApprovedExceptionClaimVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<ApprovedExceptionClaimVolume> totalAssetVolumes = new ArrayList<ApprovedExceptionClaimVolume>();
			List<ApprovedExceptionClaimVolume> totalAssetVolumeByUsername = new ArrayList<ApprovedExceptionClaimVolume>();
			List<ApprovedExceptionClaimVolume> mocList = new ArrayList<ApprovedExceptionClaimVolume>();
			
			totalAssetVolumeByUsername = approvedExceptiobClaimsVolumeRepository.findAllApprovedExceptionClaimVolume(username);
           

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimVolume mocc : totalAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				for(ApprovedExceptionClaimVolume t : mocList){
					totalAssetVolume += t.getApprovedExceptionClaimVolume();

				}

				totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<ApprovedExceptionClaimVolume> categoryList = new ArrayList<ApprovedExceptionClaimVolume>();

				//filtered by category

				for(String c : category){
					for(ApprovedExceptionClaimVolume cat : totalAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(ApprovedExceptionClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getApprovedExceptionClaimVolume();

				}
				totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<ApprovedExceptionClaimVolume> accountList = new ArrayList<ApprovedExceptionClaimVolume>();
				
				for(String accnt : account){
					for(ApprovedExceptionClaimVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(ApprovedExceptionClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getApprovedExceptionClaimVolume();

				}
				totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<ApprovedExceptionClaimVolume> accountList = new ArrayList<ApprovedExceptionClaimVolume>();
				List<ApprovedExceptionClaimVolume> filteredAccountCategoryList = new ArrayList<ApprovedExceptionClaimVolume>();


				//filterd by account
				for(String accnt : account){
					for(ApprovedExceptionClaimVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(ApprovedExceptionClaimVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(ApprovedExceptionClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getApprovedExceptionClaimVolume();
				}
				totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<ApprovedExceptionClaimVolume> regionList = new ArrayList<ApprovedExceptionClaimVolume>();
				
				//filter by region
				for(String regon : region){
					for(ApprovedExceptionClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(ApprovedExceptionClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getApprovedExceptionClaimVolume();
				}

				totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<ApprovedExceptionClaimVolume> regionList = new ArrayList<ApprovedExceptionClaimVolume>();
				List<ApprovedExceptionClaimVolume> filteredRegionAccountList = new ArrayList<ApprovedExceptionClaimVolume>();
				
				//filter by region
				for(String regon : region){
					for(ApprovedExceptionClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(ApprovedExceptionClaimVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(ApprovedExceptionClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getApprovedExceptionClaimVolume();

				}
				totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<ApprovedExceptionClaimVolume> regionList = new ArrayList<ApprovedExceptionClaimVolume>();
				List<ApprovedExceptionClaimVolume> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimVolume>();
			
				//filterd by region

				for(String regon : region){
					for(ApprovedExceptionClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(ApprovedExceptionClaimVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(ApprovedExceptionClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getApprovedExceptionClaimVolume();
				}
				totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<ApprovedExceptionClaimVolume> regionList = new ArrayList<ApprovedExceptionClaimVolume>();
				List<ApprovedExceptionClaimVolume> accountList = new ArrayList<ApprovedExceptionClaimVolume>();
				List<ApprovedExceptionClaimVolume> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimVolume>();
				
				if(totalAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(ApprovedExceptionClaimVolume reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(ApprovedExceptionClaimVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(ApprovedExceptionClaimVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(ApprovedExceptionClaimVolume t : totalAssetVolumes){
						totalAssetVolume += t.getApprovedExceptionClaimVolume();
					}

					totalAssetVolumeSum.setApprovedExceptionClaimVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}

	
	//=========================================================Red Claim Value Start==========================================================================
	
	
	
	public RedClaimValue getRedClaimValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		RedClaimValue totalAssetAmountSum = new RedClaimValue();


		try{
			List<RedClaimValue> totalAssetValues = new ArrayList<RedClaimValue>();
			List<RedClaimValue> totalAssetValuesByUsername = new ArrayList<RedClaimValue>();
			List<RedClaimValue> mocList = new ArrayList<RedClaimValue>();
			
			totalAssetValuesByUsername = redClaimsValueRepository.findAllRedClaimValue(username);
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimValue mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(RedClaimValue t : mocList){
					totalAssetAmount += t.getRedClaimValue();

				}

				totalAssetAmountSum.setRedClaimValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<RedClaimValue> categoryList = new ArrayList<RedClaimValue>();
				
				//filtered by category

				for(String c : category){
					for(RedClaimValue cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(RedClaimValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(RedClaimValue t : totalAssetValues){
					totalAssetAmount += t.getRedClaimValue();

				}
				totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<RedClaimValue> accountList = new ArrayList<RedClaimValue>();
				
				
				for(String accnt : account){
					for(RedClaimValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(RedClaimValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(RedClaimValue t : totalAssetValues){
					totalAssetAmount += t.getRedClaimValue();

				}
				totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<RedClaimValue> accountList = new ArrayList<RedClaimValue>();
				List<RedClaimValue> filteredAccountCategoryList = new ArrayList<RedClaimValue>();
				

				//filterd by account
				for(String accnt : account){
					for(RedClaimValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(RedClaimValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(RedClaimValue t : totalAssetValues){
					totalAssetAmount += t.getRedClaimValue();
				}
				totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<RedClaimValue> regionList = new ArrayList<RedClaimValue>();
				
				
				//filter by region
				for(String regon : region){
					for(RedClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(RedClaimValue t : totalAssetValues){
					totalAssetAmount += t.getRedClaimValue();
				}

				totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<RedClaimValue> regionList = new ArrayList<RedClaimValue>();
				List<RedClaimValue> filteredRegionAccountList = new ArrayList<RedClaimValue>();
				
				
				//filter by region
				for(String regon : region){
					for(RedClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(RedClaimValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(RedClaimValue t : totalAssetValues){
					totalAssetAmount += t.getRedClaimValue();

				}
				totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<RedClaimValue> regionList = new ArrayList<RedClaimValue>();
				List<RedClaimValue> filteredRegionCategoryList = new ArrayList<RedClaimValue>();
				
				//filterd by region

				for(String regon : region){
					for(RedClaimValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(RedClaimValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(RedClaimValue t : totalAssetValues){
					totalAssetAmount += t.getRedClaimValue();
				}
				totalAssetAmountSum.setRedClaimValue(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<RedClaimValue> regionList = new ArrayList<RedClaimValue>();
				List<RedClaimValue> accountList = new ArrayList<RedClaimValue>();
				List<RedClaimValue> filteredRegionCategoryList = new ArrayList<RedClaimValue>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(RedClaimValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(RedClaimValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(RedClaimValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(RedClaimValue t : totalAssetValues){
						totalAssetAmount += t.getRedClaimValue();
					}

					totalAssetAmountSum.setRedClaimValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	
	//=========================================================Red Claim Volume Start==========================================================================
	
	
	public RedClaimVolume getRedClaimVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		RedClaimVolume totalAssetVolumeSum= new RedClaimVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<RedClaimVolume> totalAssetVolumes = new ArrayList<RedClaimVolume>();
			List<RedClaimVolume> totalAssetVolumeByUsername = new ArrayList<RedClaimVolume>();
			List<RedClaimVolume> mocList = new ArrayList<RedClaimVolume>();
			
			totalAssetVolumeByUsername = redClaimsVolumeRepository.findAllRedClaimVolume(username);
           

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimVolume mocc : totalAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				for(RedClaimVolume t : mocList){
					totalAssetVolume += t.getRedClaimVolume();

				}

				totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<RedClaimVolume> categoryList = new ArrayList<RedClaimVolume>();

				//filtered by category

				for(String c : category){
					for(RedClaimVolume cat : totalAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(RedClaimVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(RedClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getRedClaimVolume();

				}
				totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<RedClaimVolume> accountList = new ArrayList<RedClaimVolume>();
				
				for(String accnt : account){
					for(RedClaimVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(RedClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getRedClaimVolume();

				}
				totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<RedClaimVolume> accountList = new ArrayList<RedClaimVolume>();
				List<RedClaimVolume> filteredAccountCategoryList = new ArrayList<RedClaimVolume>();


				//filterd by account
				for(String accnt : account){
					for(RedClaimVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(RedClaimVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(RedClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getRedClaimVolume();
				}
				totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<RedClaimVolume> regionList = new ArrayList<RedClaimVolume>();
				
				//filter by region
				for(String regon : region){
					for(RedClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(RedClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getRedClaimVolume();
				}

				totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<RedClaimVolume> regionList = new ArrayList<RedClaimVolume>();
				List<RedClaimVolume> filteredRegionAccountList = new ArrayList<RedClaimVolume>();
				
				//filter by region
				for(String regon : region){
					for(RedClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(RedClaimVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(RedClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getRedClaimVolume();

				}
				totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<RedClaimVolume> regionList = new ArrayList<RedClaimVolume>();
				List<RedClaimVolume> filteredRegionCategoryList = new ArrayList<RedClaimVolume>();
			
				//filterd by region

				for(String regon : region){
					for(RedClaimVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(RedClaimVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(RedClaimVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(RedClaimVolume t : totalAssetVolumes){
					totalAssetVolume += t.getRedClaimVolume();
				}
				totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<RedClaimVolume> regionList = new ArrayList<RedClaimVolume>();
				List<RedClaimVolume> accountList = new ArrayList<RedClaimVolume>();
				List<RedClaimVolume> filteredRegionCategoryList = new ArrayList<RedClaimVolume>();
				
				if(totalAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(RedClaimVolume reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(RedClaimVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(RedClaimVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(RedClaimVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(RedClaimVolume t : totalAssetVolumes){
						totalAssetVolume += t.getRedClaimVolume();
					}

					totalAssetVolumeSum.setRedClaimVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}

	
	
	//=========================================================Total Amount Payable Start==========================================================================
	
	public TotalAmountPayable getTotalAmountPayable(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TotalAmountPayable totalAssetAmountSum = new TotalAmountPayable();


		try{
			List<TotalAmountPayable> totalAssetValues = new ArrayList<TotalAmountPayable>();
			List<TotalAmountPayable> totalAssetValuesByUsername = new ArrayList<TotalAmountPayable>();
			List<TotalAmountPayable> mocList = new ArrayList<TotalAmountPayable>();
			
			totalAssetValuesByUsername = totalAmountPayableRepository.findAllTotalAmountPayable(username);
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPayable mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(TotalAmountPayable t : mocList){
					totalAssetAmount += t.getTotalAmountPayable();

				}

				totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<TotalAmountPayable> categoryList = new ArrayList<TotalAmountPayable>();
				
				//filtered by category

				for(String c : category){
					for(TotalAmountPayable cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPayable mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(TotalAmountPayable t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPayable();

				}
				totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<TotalAmountPayable> accountList = new ArrayList<TotalAmountPayable>();
				
				
				for(String accnt : account){
					for(TotalAmountPayable acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPayable mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAmountPayable t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPayable();

				}
				totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<TotalAmountPayable> accountList = new ArrayList<TotalAmountPayable>();
				List<TotalAmountPayable> filteredAccountCategoryList = new ArrayList<TotalAmountPayable>();
				

				//filterd by account
				for(String accnt : account){
					for(TotalAmountPayable acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(TotalAmountPayable cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPayable mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAmountPayable t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPayable();
				}
				totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<TotalAmountPayable> regionList = new ArrayList<TotalAmountPayable>();
				
				
				//filter by region
				for(String regon : region){
					for(TotalAmountPayable reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPayable mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPayable t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPayable();
				}

				totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<TotalAmountPayable> regionList = new ArrayList<TotalAmountPayable>();
				List<TotalAmountPayable> filteredRegionAccountList = new ArrayList<TotalAmountPayable>();
				
				
				//filter by region
				for(String regon : region){
					for(TotalAmountPayable reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(TotalAmountPayable acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPayable mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(TotalAmountPayable t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPayable();

				}
				totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<TotalAmountPayable> regionList = new ArrayList<TotalAmountPayable>();
				List<TotalAmountPayable> filteredRegionCategoryList = new ArrayList<TotalAmountPayable>();
				
				//filterd by region

				for(String regon : region){
					for(TotalAmountPayable reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(TotalAmountPayable cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPayable mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPayable t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPayable();
				}
				totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<TotalAmountPayable> regionList = new ArrayList<TotalAmountPayable>();
				List<TotalAmountPayable> accountList = new ArrayList<TotalAmountPayable>();
				List<TotalAmountPayable> filteredRegionCategoryList = new ArrayList<TotalAmountPayable>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(TotalAmountPayable reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(TotalAmountPayable acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(TotalAmountPayable cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPayable mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAmountPayable t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPayable();
					}

					totalAssetAmountSum.setTotalAmountPayable(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	//=========================================================Total Amount Paid Start==========================================================================
	
	
	public Double getTotalAmountPaid(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		
		try{
			if(region.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				totalAssetAmount = externalPaymetStatusRepository.findKamClaimRaisedByMoc(moc, account);
			
			}

			else if(region.get(0).equals("All")  && category !=null && moc !=null){//2

				totalAssetAmount = externalPaymetStatusRepository.findKamClaimRaisedByMocCategory(moc, account, category);
			}

			else if(region !=null  && category.get(0).equals("All")  && moc !=null){//3

				totalAssetAmount = externalPaymetStatusRepository.findKamClaimRaisedByMocRegion(moc, account, region);
			}

			else if(region.get(0).equals("All") && category !=null  && moc !=null){//4
				
				totalAssetAmount = externalPaymetStatusRepository.findKamClaimRaisedByMocRegionCategory(moc, account, region, category);
			}


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmount;

	}
	
	
	//=========================================================Total Amount Pending Start==========================================================================
	
	
	public TotalAmountPending getTotalAmountPending(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TotalAmountPending totalAssetAmountSum = new TotalAmountPending();


		try{
			List<TotalAmountPending> totalAssetValues = new ArrayList<TotalAmountPending>();
			List<TotalAmountPending> totalAssetValuesByUsername = new ArrayList<TotalAmountPending>();
			List<TotalAmountPending> mocList = new ArrayList<TotalAmountPending>();
			
			totalAssetValuesByUsername = totalAmountPendingRepository.findAllTotalAmountPending(username);
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPending mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(TotalAmountPending t : mocList){
					totalAssetAmount += t.getTotalAmountPending();

				}

				totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<TotalAmountPending> categoryList = new ArrayList<TotalAmountPending>();
				
				//filtered by category

				for(String c : category){
					for(TotalAmountPending cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPending mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(TotalAmountPending t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPending();

				}
				totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<TotalAmountPending> accountList = new ArrayList<TotalAmountPending>();
				
				
				for(String accnt : account){
					for(TotalAmountPending acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPending mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAmountPending t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPending();

				}
				totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<TotalAmountPending> accountList = new ArrayList<TotalAmountPending>();
				List<TotalAmountPending> filteredAccountCategoryList = new ArrayList<TotalAmountPending>();
				

				//filterd by account
				for(String accnt : account){
					for(TotalAmountPending acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(TotalAmountPending cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPending mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(TotalAmountPending t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPending();
				}
				totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
				
				
				//filter by region
				for(String regon : region){
					for(TotalAmountPending reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPending mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPending t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPending();
				}

				totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
				List<TotalAmountPending> filteredRegionAccountList = new ArrayList<TotalAmountPending>();
				
				
				//filter by region
				for(String regon : region){
					for(TotalAmountPending reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(TotalAmountPending acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPending mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(TotalAmountPending t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPending();

				}
				totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
				List<TotalAmountPending> filteredRegionCategoryList = new ArrayList<TotalAmountPending>();
				
				//filterd by region

				for(String regon : region){
					for(TotalAmountPending reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(TotalAmountPending cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPending mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPending t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPending();
				}
				totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<TotalAmountPending> regionList = new ArrayList<TotalAmountPending>();
				List<TotalAmountPending> accountList = new ArrayList<TotalAmountPending>();
				List<TotalAmountPending> filteredRegionCategoryList = new ArrayList<TotalAmountPending>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(TotalAmountPending reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(TotalAmountPending acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(TotalAmountPending cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(TotalAmountPending mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(TotalAmountPending t : totalAssetValues){
						totalAssetAmount += t.getTotalAmountPending();
					}

					totalAssetAmountSum.setTotalAmountPending(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	
	
	//=========================================================Claims Raised Start==========================================================================
	
	
	public Double getClaimsRaised(List<String> region,List<String> account,List<String> moc,List<String> category){

		double totalAssetAmount = 0.00;
		
		try{
			
            
			if(region.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				totalAssetAmount = externalServiceNoteMasterRepository.findKamClaimRaisedByMoc(moc, account);
			
			}

			else if(region.get(0).equals("All")  && category !=null && moc !=null){//2

				totalAssetAmount = externalServiceNoteMasterRepository.findKamClaimRaisedByMocCategory(moc, account, category);
			}

			else if(region !=null  && category.get(0).equals("All")  && moc !=null){//3

				totalAssetAmount = externalServiceNoteMasterRepository.findKamClaimRaisedByMocRegion(moc, account, region);
			}

			else if(region.get(0).equals("All") && category !=null  && moc !=null){//4
				
				totalAssetAmount = externalServiceNoteMasterRepository.findKamClaimRaisedByMocRegionCategory(moc, account, region, category);
			}

		

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmount;

	}
	
}
