package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INT_ORDER_TABLE")
public class KamOrderTable implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -936234596346151152L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="BRANCH")
    private String branch;
	
	@Column(name="CATEGORY")
    private String category;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="PO_NUMBER")
    private String poNumber;
	
	@Column(name="PO_COUNT")
    private Integer poCount;
	
	@Column(name="STATUS")
    private String status;
	
	@Column(name="USERNAME")
    private String username;
	
	

	public KamOrderTable() {
		super();
		// TODO Auto-generated constructor stub
	}


	public KamOrderTable(Integer rECORD_ID, String branch, String category, String account, String moc, String poNumber,
			Integer poCount, String status, String username) {
		super();
		RECORD_ID = rECORD_ID;
		this.branch = branch;
		this.category = category;
		this.account = account;
		this.moc = moc;
		this.poNumber = poNumber;
		this.poCount = poCount;
		this.status = status;
		this.username = username;
	}






	public Integer getRECORD_ID() {
		return RECORD_ID;
	}



	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public String getMoc() {
		return moc;
	}



	public void setMoc(String moc) {
		this.moc = moc;
	}



	public String getPoNumber() {
		return poNumber;
	}



	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}



	public Integer getPoCount() {
		return poCount;
	}



	public void setPoCount(Integer poCount) {
		this.poCount = poCount;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}


	public String getAccount() {
		return account;
	}


	public void setAccount(String account) {
		this.account = account;
	}
	
	

}
