package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.KamAvailablePO;

@Repository
public interface KamAvailaiblePORepository extends JpaRepository<KamAvailablePO, Integer>{
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamFInalReasonHeaderList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamFInalReasonHeaderList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER2 from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and  tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamFInalReasonHeader2List(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER2 from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and  tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamFInalReasonHeader2List(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER2 in :headerTwo  and tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamFinalReasonList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerTwo") List<String> headerTwo,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamFinalReasonList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerTwo") List<String> headerTwo,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_ACTION from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON in :finalReason and tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamCactionList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("finalReason") List<String> finalReason,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_ACTION from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON in :finalReason and tac.USERNAME in :username", nativeQuery = true)
	List<String> findKamCactionList(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("finalReason") List<String> finalReason,@Param("username") List<String> username);
//=====================================================================================================================================================

	
	
/////////////////////////////////////////////WITHOUT PONUMBER Header 1////////////////////////////////////////////////////////
	
	
@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamOrderValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,
		@Param("category") List<String> category,@Param("headerOne") String headerOne,@Param("username") List<String> username);



@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") String headerOne,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamInvoicedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") String headerOne,@Param("username") List<String> username);


/////////////////////////////////////////////WITH PONUMBER Header 1////////////////////////////////////////////////////////	
	
@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and  tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamOrderValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,
		@Param("category") List<String> category,@Param("headerOne") String headerOne,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);



@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") String headerOne,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamInvoicedValue(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") String headerOne,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);
	
	
/////////////////////////////////////////////WITHOUT PONUMBER Header 2////////////////////////////////////////////////////////	
	
	
@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo  and tac.USERNAME in :username", nativeQuery = true)
Double findCounKamtOrderValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo  and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo  and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamInvoicedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);

	
	
/////////////////////////////////////////////WITH PONUMBER Header 2////////////////////////////////////////////////////////
	
@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo  and tac.USERNAME in :username", nativeQuery = true)
Double findCounKamtOrderValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo  and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo  and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamInvoicedValueHeader2(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);
	
	
	
/////////////////////////////////////////////WITHOUT PONUMBER FINAL REASON////////////////////////////////////////////////////////	
	
	
@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamOrderValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCounKamtInvoicedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);



/////////////////////////////////////////////WITH PONUMBER FINAL REASON////////////////////////////////////////////////////////	


@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamOrderValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCounKamtInvoicedValueFinalReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);
	
	
//////////////////////////////////////////////////////////WITHOUT PONUMBER C_ACTION//////////////////////////////////////////////////////////

@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamOrderValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamInvoicedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);



//////////////////////////////////////////////////////////WITH PONUMBER C_ACTION//////////////////////////////////////////////////////////

@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamOrderValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamAllocatedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where  tac.ACCOUNT in :account and tac.MOC in :moc and"
		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountKamInvoicedValueC_Action(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);










///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
	Integer findKamNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.USERNAME in :username", nativeQuery = true)
	Integer findKamNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.USERNAME in :username", nativeQuery = true)
	Integer findKamNoOfLinesCountByHeaderOne(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo  and tac.USERNAME in :username", nativeQuery = true)
	Integer findKamCFinalReasonNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("username") List<String> username);
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".INT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne "
    		+ "and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :cFinalReason and tac.USERNAME in :username", nativeQuery = true)
	Integer findKamCActionNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("cFinalReason") List<String> cFinalReason,@Param("username") List<String> username);
	

}
