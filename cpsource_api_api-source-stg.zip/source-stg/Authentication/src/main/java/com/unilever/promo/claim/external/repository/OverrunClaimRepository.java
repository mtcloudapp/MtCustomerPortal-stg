package com.unilever.promo.claim.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.OverrunClaim;

@Repository
public interface OverrunClaimRepository  extends JpaRepository<OverrunClaim, Integer>{
	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".OVERRUN_CLAIM pcfm where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNoOfOverrunClaim(@Param("accountName") String accountName, @Param("moc") String moc);


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".OVERRUN_CLAIM  pcfm set pcfm.WORKFLOW_STAGE_ID=:stageID  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updateOverrunClaimByAccountMocFileNo(@Param("stageID") Integer stageID,@Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);


	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".OVERRUN_CLAIM pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Page<OverrunClaim> findOverrunDetailsByAcntAndMoc(@Param("accountName") String accountName,@Param("moc") String moc,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".OVERRUN_CLAIM pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	List<OverrunClaim> findOverrunDetails(@Param("accountName") String accountName,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".OVERRUN_CLAIM pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	List<OverrunClaim> findCountByAccountAndMoc(@Param("accountName") String accountName,@Param("moc") String moc);
	
//	@Transactional
//	@Query(value = "CALL sp_promo_claims_overrun_claims();", nativeQuery = true)
//	void insertIntoOverrunClaim();
	
	@Transactional
	@Procedure(procedureName = "sp_promo_claims_overrun_claims")
	void insertIntoOverrunClaim(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".OVERRUN_CLAIM pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	List<OverrunClaim> finalPublishViewDetailsByAcntAndMoc(@Param("accountName") String accountName,@Param("moc") String moc);
	
	@Transactional
	@Procedure(procedureName = "sp_SetWorkflowStage")
	void updateOverrunClaim(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc,
					@Param("p_Role") String role,@Param("p_Action") String action,@Param("p_SOL_Code") Integer solcode);
	
	@Transactional
	@Procedure(procedureName = "sp_promo_claims_overrun_claims_final")
	void updateOverrunClaimFinal(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc,
					@Param("p_Username") String role,@Param("p_Action") String action);
	
	@Transactional
	@Procedure(procedureName = "sp_promo_claims_overrun_claims_final")
	void updateOverrunClaimFinal(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
	
	@Transactional
	@Procedure(procedureName = "sp_promo_claims_overrun_claims_final")
	void updateOverrunClaimFinal(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc,
					@Param("p_Username") String role,@Param("p_Action") String action,@Param("p_overrun") String overrun);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".OVERRUN_CLAIM  pcfm set pcfm.APPROVED_OVERRUN_PERCENTAGE=:approvedOverrunPercnt  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc and pcfm.SOL_CODE=:solcode", nativeQuery = true)
	void updateOverrunClaimByAccountMocSolcode(@Param("approvedOverrunPercnt") Double approvedOverrunPercnt,@Param("accountName") String accountName,@Param("moc") String moc,@Param("solcode") Integer solcode);

	@Transactional
	@Query(value ="select count(*) from "+GlobalVariables.schemaName+".OVERRUN_CLAIM pcfm where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findOverrunClaimByAccountMOC(@Param("accountName") String accountName, @Param("moc") String moc);

}
