package com.unilever.asset.kam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetVolume;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.asset.kam.service.KamNextMocAssetService;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class KamNextMocController {
	
	@Autowired
	KamNextMocAssetService kamNextMocAssetService;
	
	@GetMapping("/getAllStoreListTotalCount")
	public StoreListTotalCount getAllStoreListTotalCount(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		StoreListTotalCount totalAssetValue = new StoreListTotalCount();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			// totalAssetValue = kamNextMocAssetService.getStoreListTotalCount(username, region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	
	
	@GetMapping("/getAllStoreListTotalValue")
	public StoreListTotalValue getAllStoreListTotalValue(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		StoreListTotalValue totalAssetValue = new StoreListTotalValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			// totalAssetValue = kamNextMocAssetService.getStoreListTotalValue(username, region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	@GetMapping("/getAllPlannedAssetValue")
	public PlannedAssetValue getAllPlannedAssetValue(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		PlannedAssetValue totalAssetValue = new PlannedAssetValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			// totalAssetValue = kamNextMocAssetService.getAllPlannedAssetValue(username, region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	@GetMapping("/getAllPlannedAssetVolume")
	public PlannedAssetVolume getAllPlannedAssetVolume(@RequestParam("username") String username, @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		PlannedAssetVolume totalAssetValue = new PlannedAssetVolume();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			// totalAssetValue = kamNextMocAssetService.getAllPlannedAssetVolume(username, region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}

}
