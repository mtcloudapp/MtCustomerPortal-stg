package com.unilever.promo.kam.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;

public class CurrentMocPromoViewDto implements Serializable{
	
private static final long serialVersionUID = -5922087877145840252L;
	
	
	private String promo_id;
	
	
	private Integer sol_code;
	
	
	private String promo_description;
	
	
	private String offer;
	
	
	private String l1_customer;
	
	
	private String l2_customer;
	
	
	private Integer basepack;
	
	
	private String category;
	
	
	private String brand;
	
	
	private String cluster;
	

	private Integer planned_volume;
	
	
	private Double utilized_volume;
	
	
	private Double planned_budget;
	
	
	private Double utilized_budget;
	
	
	private String moc;
	
	private Integer totalRecords;

	public CurrentMocPromoViewDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	


	





	public CurrentMocPromoViewDto(String promo_id, Integer sol_code, String promo_description, String offer,
			String l1_customer, String l2_customer, Integer basepack, String category, String brand, String cluster,
			Integer planned_volume, Double utilized_volume, Double planned_budget, Double utilized_budget, String moc,
			Integer totalRecords) {
		super();
		this.promo_id = promo_id;
		this.sol_code = sol_code;
		this.promo_description = promo_description;
		this.offer = offer;
		this.l1_customer = l1_customer;
		this.l2_customer = l2_customer;
		this.basepack = basepack;
		this.category = category;
		this.brand = brand;
		this.cluster = cluster;
		this.planned_volume = planned_volume;
		this.utilized_volume = utilized_volume;
		this.planned_budget = planned_budget;
		this.utilized_budget = utilized_budget;
		this.moc = moc;
		this.totalRecords = totalRecords;
	}
	public String getPromo_id() {
		return promo_id;
	}
	public void setPromo_id(String promo_id) {
		this.promo_id = promo_id;
	}
  public Integer getSol_code() {
		return sol_code;
	}
	public void setSol_code(Integer sol_code) {
		this.sol_code = sol_code;
	}
	public String getPromo_description() {
		return promo_description;
	}
	public void setPromo_description(String promo_description) {
		this.promo_description = promo_description;
	}
	public String getOffer() {
		return offer;
	}
	public void setOffer(String offer) {
		this.offer = offer;
	}
	public String getL1_customer() {
		return l1_customer;
	}
	public void setL1_customer(String l1_customer) {
		this.l1_customer = l1_customer;
	}

	public String getL2_customer() {
		return l2_customer;
	}
	public void setL2_customer(String l2_customer) {
		this.l2_customer = l2_customer;
	}

public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}
 public String getCategory() {
		return category;
	}
 public void setCategory(String category) {
		this.category = category;
	}

	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCluster() {
		return cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	public Integer getPlanned_volume() {
		return planned_volume;
	}
	public void setPlanned_volume(Integer planned_volume) {
		this.planned_volume = planned_volume;
	}

public Double getUtilized_volume() {
		return utilized_volume;
	}

	public void setUtilized_volume(Double utilized_volume) {
		this.utilized_volume = utilized_volume;
	}

	public Double getPlanned_budget() {
		return planned_budget;
	}

	public void setPlanned_budget(Double planned_budget) {
		this.planned_budget = planned_budget;
	}

	public Double getUtilized_budget() {
		return utilized_budget;
	}

	public void setUtilized_budget(Double utilized_budget) {
		this.utilized_budget = utilized_budget;
	}


	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}


	public Integer getTotalRecords() {
		return totalRecords;
	}


	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	

}
