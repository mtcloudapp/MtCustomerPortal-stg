package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROMO_CLAIM_MULTI_SOLCODE_STAGE")
public class PromoClaimMultiSOLCodeStage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7047406125599098991L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="RECORD_ID")
	private String recordID;

	@Column(name="ACCOUNT_NAME")
	private String accountName;
	
	@Column(name="MOC")
	private String moc;
	
	@Column(name="SOL_CODE")
	private String solCode;

	@Column(name="PROMOTION_UNIT")
	private String promotionUnit;

	@Column(name="PROMOTION_AMOUNT")
	private String promotionAmount;
	
	@Column(name="LOAD_DATE")
	private String loadDate;
	
	public PromoClaimMultiSOLCodeStage() {
		
	}
	
	public PromoClaimMultiSOLCodeStage(String recordID, String accountName, String moc, String solCode,
			String promotionUnit, String promotionAmount, String loadDate) {
		super();
		this.recordID = recordID;
		this.accountName = accountName;
		this.moc = moc;
		this.solCode = solCode;
		this.promotionUnit = promotionUnit;
		this.promotionAmount = promotionAmount;
		this.loadDate = loadDate;
	}

	public String getRecordID() {
		return recordID;
	}

	public void setRecordID(String recordID) {
		this.recordID = recordID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}
	
	public String getSolCode() {
		return solCode;
	}

	public void setSolCode(String solCode) {
		this.solCode = solCode;
	}

	public String getPromotionUnit() {
		return promotionUnit;
	}

	public void setPromotionUnit(String promotionUnit) {
		this.promotionUnit = promotionUnit;
	}

	public String getPromotionAmount() {
		return promotionAmount;
	}

	public void setPromotionAmount(String promotionAmount) {
		this.promotionAmount = promotionAmount;
	}

	public String getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(String loadDate) {
		this.loadDate = loadDate;
	}
	
}
