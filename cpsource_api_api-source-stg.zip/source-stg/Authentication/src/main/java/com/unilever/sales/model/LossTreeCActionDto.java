package com.unilever.sales.model;

import java.io.Serializable;
import java.util.List;

public class LossTreeCActionDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4447355930589894752L;
	

	private List<String> cAction_2;
	private List<Double> orderValue;
	private List<Double> allocatedValue;
	private List<Double> invoicedValue;
	private Integer count;
	
	public LossTreeCActionDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<String> getcAction_2() {
		return cAction_2;
	}


	public void setcAction_2(List<String> cAction_2) {
		this.cAction_2 = cAction_2;
	}

	

	

	public List<Double> getOrderValue() {
		return orderValue;
	}


	public void setOrderValue(List<Double> orderValue) {
		this.orderValue = orderValue;
	}


	public List<Double> getAllocatedValue() {
		return allocatedValue;
	}


	public void setAllocatedValue(List<Double> allocatedValue) {
		this.allocatedValue = allocatedValue;
	}


	public List<Double> getInvoicedValue() {
		return invoicedValue;
	}


	public void setInvoicedValue(List<Double> invoicedValue) {
		this.invoicedValue = invoicedValue;
	}


	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
	
	

}
