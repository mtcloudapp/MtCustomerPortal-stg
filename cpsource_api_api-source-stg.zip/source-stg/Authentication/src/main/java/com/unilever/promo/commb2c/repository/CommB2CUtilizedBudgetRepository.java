package com.unilever.promo.commb2c.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.commb2c.model.CommB2CUtilizedBudget;

@Repository
public interface CommB2CUtilizedBudgetRepository extends JpaRepository<CommB2CUtilizedBudget, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_UTILIZED_BUDGET", nativeQuery = true)
	List<CommB2CUtilizedBudget> findAllUtilizedBudget();

}
