package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "POS_VS_PRIMARY")
public class POS_VS_Primary implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3354427717142527185L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="FILE_NO")
	private Integer fileNo;

	@Column(name="WORKFLOW_STAGE_ID")
	private Integer workflowStageID;

	@Column(name="ACCOUNT")
	private String accountName;

	@Column(name="MOC")
	private String moc;

	@Column(name="ARTICLE_CODE")
	private Integer articleCode;

	@Column(name="CLAIM_QUANTITY")
	private Double claimQty;

	@Column(name="NET_CLAIM_VALUE")
	private Double netClaimValue;

	@Column(name="POS_QUANTITY")
	private Double posQty;

	@Column(name="POS_DIFFERENCE")
	private Double posDiff;

	@Column(name="POS_DEDUCTION")
	private Double posDeduction;

	@Column(name="POS_MINIMUM_QUANTITY")
	private Double posMinQty;

	@Column(name="PRIMARY_QUANTITY")
	private Double primaryOty;

	@Column(name="PRIMARY_QUANTITY_DIFFERENCE")
	private Double primaryQtyDiff;

	@Column(name="PRIMARY_QUANTITY_DEDUCTION")
	private Double primaryQtyDeduction;

	@Column(name="PRIMARY_MINIMUM_QUANTITY")
	private Double primaryMinQty;

	@Column(name="AUDIT_CREATE_DATE")
	private String auditCreateDate;

	@Column(name="AUDIT_MODIFIED_DATE")
	private String auditModifiedDate;

	public POS_VS_Primary() {
		super();
		// TODO Auto-generated constructor stub
	}

	public POS_VS_Primary(Integer rECORD_ID, Integer fileNo, Integer workflowStageID, String accountName, String moc,
			Integer articleCode, Double claimQty, Double netClaimValue, Double posQty, Double posDiff,
			Double posDeduction, Double posMinQty, Double primaryOty, Double primaryQtyDiff, Double primaryQtyDeduction,
			Double primaryMinQty, String auditCreateDate, String auditModifiedDate) {
		super();
		RECORD_ID = rECORD_ID;
		this.fileNo = fileNo;
		this.workflowStageID = workflowStageID;
		this.accountName = accountName;
		this.moc = moc;
		this.articleCode = articleCode;
		this.claimQty = claimQty;
		this.netClaimValue = netClaimValue;
		this.posQty = posQty;
		this.posDiff = posDiff;
		this.posDeduction = posDeduction;
		this.posMinQty = posMinQty;
		this.primaryOty = primaryOty;
		this.primaryQtyDiff = primaryQtyDiff;
		this.primaryQtyDeduction = primaryQtyDeduction;
		this.primaryMinQty = primaryMinQty;
		this.auditCreateDate = auditCreateDate;
		this.auditModifiedDate = auditModifiedDate;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	public Integer getWorkflowStageID() {
		return workflowStageID;
	}

	public void setWorkflowStageID(Integer workflowStageID) {
		this.workflowStageID = workflowStageID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public Double getClaimQty() {
		return claimQty;
	}

	public void setClaimQty(Double claimQty) {
		this.claimQty = claimQty;
	}

	public Double getNetClaimValue() {
		return netClaimValue;
	}

	public void setNetClaimValue(Double netClaimValue) {
		this.netClaimValue = netClaimValue;
	}

	public Double getPosQty() {
		return posQty;
	}

	public void setPosQty(Double posQty) {
		this.posQty = posQty;
	}

	public Double getPosDiff() {
		return posDiff;
	}

	public void setPosDiff(Double posDiff) {
		this.posDiff = posDiff;
	}

	public Double getPosDeduction() {
		return posDeduction;
	}

	public void setPosDeduction(Double posDeduction) {
		this.posDeduction = posDeduction;
	}

	public Double getPosMinQty() {
		return posMinQty;
	}

	public void setPosMinQty(Double posMinQty) {
		this.posMinQty = posMinQty;
	}

	public Double getPrimaryOty() {
		return primaryOty;
	}

	public void setPrimaryOty(Double primaryOty) {
		this.primaryOty = primaryOty;
	}

	public Double getPrimaryQtyDiff() {
		return primaryQtyDiff;
	}

	public void setPrimaryQtyDiff(Double primaryQtyDiff) {
		this.primaryQtyDiff = primaryQtyDiff;
	}

	public Double getPrimaryQtyDeduction() {
		return primaryQtyDeduction;
	}

	public void setPrimaryQtyDeduction(Double primaryQtyDeduction) {
		this.primaryQtyDeduction = primaryQtyDeduction;
	}

	public Double getPrimaryMinQty() {
		return primaryMinQty;
	}

	public void setPrimaryMinQty(Double primaryMinQty) {
		this.primaryMinQty = primaryMinQty;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}

	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}



}
