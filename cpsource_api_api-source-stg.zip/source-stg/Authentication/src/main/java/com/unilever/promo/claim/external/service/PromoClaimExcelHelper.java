package com.unilever.promo.claim.external.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.activation.MailcapCommandMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.unilever.promo.claim.external.model.BaseWorking;
import com.unilever.promo.claim.external.model.PosDataStage;
import com.unilever.promo.claim.external.model.PromoClaimMultiSOLCodeStage;
import com.unilever.promo.claim.external.model.PromoClaimStage;
import com.unilever.promo.claim.external.model.PromoClaimStageFileValidate;

import com.monitorjbl.xlsx.StreamingReader;

public class PromoClaimExcelHelper {
	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

	static String SHEET = "PromoClaimDetails";

	static String[] BASE_WORKING_ACTUAL_HEADERS = { "SOL_CODE", "BASEPACK", "ARTICLE_CODE","SOL_CODE_DESCRIPTION","HUL_MRP","CUSTOMER_MRP",
			"NET_CLAIM_VALUE", "NET_CLAIM_QUANTITY", "PROMOTION_AMOUNT","CLAIM_AMOUNT_PER_UNIT","CLAIM_POS_PRIMARY_QUANTITY","CUSTOMER_CLAIM_QUANTITY",
			"DIFFERENCE_IN_CUSTOMER_CLAIMS", "HUL_CLAIM", "NET_CLAIMS","DIFFERENCE_CLAIMS","DEDUCTION_BUCKET","DEDUCTION_AMOUNT"};

	static String[] BASE_WORKING_REVISED_HEADERS = { "SOL_CODE", "BASEPACK", "ARTICLE_CODE","SOL_CODE_DESCRIPTION","HUL_MRP","CUSTOMER_MRP",
			"NET_CLAIM_VALUE_REVISED", "NET_CLAIM_QUANTITY_REVISED", "PROMOTION_AMOUNT_REVISED","CLAIM_AMOUNT_PER_UNIT_REVISED","CLAIM_POS_PRIMARY_QUANTITY_REVISED","CUSTOMER_CLAIM_QUANTITY_REVISED",
			"DIFFERENCE_IN_CUSTOMER_CLAIMS_REVISED", "HUL_CLAIM_REVISED", "NET_CLAIMS_REVISED","DIFFERENCE_CLAIMS_REVISED"};


	static String BASE_WORKING_ACTUAL_SHEET = "BASE_WORKING_ACTUAL_DATA";
	static String BASE_WORKING_REVISED_SHEET = "BASE_WORKING_REVISED_DATA";
	
	//Added By Sarin Jun2021
	static String[] PROMO_CLAIM_MULTI_SOL_CODES_HEADERS = {"SOL_CODE", "Promotion Unit (Rs/%)", "Promotion Amount (p.u)"};

	public static boolean hasExcelFormat(MultipartFile file) {

		if (!TYPE.equals(file.getContentType())) {
			return false;
		}

		return true;
	}


	public static List<PromoClaimStage> excelToPromoClaimStage(InputStream is) {


		try {
			//Workbook workbook = new XSSFWorkbook(is);
			XSSFWorkbook workbook = new XSSFWorkbook(is); 

			//XSSFSheet sheet = workbook.createSheet(SHEET);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> rows = datatypeSheet.iterator();

			List<PromoClaimStage> promoClaimStageList = new ArrayList<PromoClaimStage>();

			//int rowNumber = 0;
			while (rows.hasNext()) {

				Row currentRow = rows.next();

				//Commented - Sarin Changes 22Jun2021
				// skip header
				/*if (rowNumber == 0) {
					rowNumber++;
					continue;
				}*/

				Iterator<Cell> cellsInRow = currentRow.iterator();

				PromoClaimStage promoClaimStage = new PromoClaimStage();

				int cellIdx = 0;
				while (cellsInRow.hasNext()) {

					Cell currentCell = cellsInRow.next();
					cellIdx = currentCell.getColumnIndex();  //Added - Sarin Changes 22Jun2021


					switch (cellIdx) {

					case 0:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnA(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnA(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnA = (int)currentCell.getNumericCellValue();
							String colA = Integer.toString(columnA); 
							promoClaimStage.setColumnA(colA);
						} */
						
						promoClaimStage.setColumnA(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;


					case 1:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnB(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnB(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnB = (int)currentCell.getNumericCellValue();
							String colB = Integer.toString(columnB);
							promoClaimStage.setColumnB(colB);
						} */
						promoClaimStage.setColumnB(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;


					case 2:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnC(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnC(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnC = (int)currentCell.getNumericCellValue();
							String colC = Integer.toString(columnC);
							promoClaimStage.setColumnC(colC);
						} */
						promoClaimStage.setColumnC(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 3:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnD(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnD(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnD = (int)currentCell.getNumericCellValue();
							String colD = Integer.toString(columnD);
							promoClaimStage.setColumnD(colD);
						} */
						promoClaimStage.setColumnD(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021

						break;


					case 4:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnE(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnE(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnE = (int)currentCell.getNumericCellValue();
							String colE = Integer.toString(columnE);
							promoClaimStage.setColumnE(colE);
						} */
						promoClaimStage.setColumnE(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021

						break;

					case 5:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnF(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnF(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnF = (int)currentCell.getNumericCellValue();
							String colF = Integer.toString(columnF);
							promoClaimStage.setColumnF(colF);
						} */
						promoClaimStage.setColumnF(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 6:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnG(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnG(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnG = (int)currentCell.getNumericCellValue();
							String colG = Integer.toString(columnG);
							promoClaimStage.setColumnG(colG);
						} */
						promoClaimStage.setColumnG(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 7:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnH(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnH(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnH = (int)currentCell.getNumericCellValue();
							String colH = Integer.toString(columnH);
							promoClaimStage.setColumnH(colH);
						} */
						promoClaimStage.setColumnH(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;


					case 8:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnI(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnI(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnI = (int)currentCell.getNumericCellValue();
							String colI = Integer.toString(columnI);
							promoClaimStage.setColumnI(colI);
						} */
						promoClaimStage.setColumnI(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 9:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnJ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnJ(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnJ = (int)currentCell.getNumericCellValue();
							String colJ = Integer.toString(columnJ);
							promoClaimStage.setColumnJ(colJ);
						} */
						promoClaimStage.setColumnJ(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 10:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnK(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnK(currentCell.getStringCellValue());
						}
						else{
							Integer columnK = (int)currentCell.getNumericCellValue();
							String colK = Integer.toString(columnK);
							promoClaimStage.setColumnK(colK);
						} */
						promoClaimStage.setColumnK(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 11:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnL(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnL(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnL = (int)currentCell.getNumericCellValue();
							String colL = Integer.toString(columnL);
							promoClaimStage.setColumnL(colL);
						} */
						promoClaimStage.setColumnL(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 12:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnM(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnM(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnM = (int)currentCell.getNumericCellValue();
							String colM = Integer.toString(columnM);
							promoClaimStage.setColumnM(colM);
						} */
						promoClaimStage.setColumnM(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 13:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnN(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnN(currentCell.getStringCellValue());
						}
						else{
							Integer columnN = (int)currentCell.getNumericCellValue();
							String colN = Integer.toString(columnN);
							promoClaimStage.setColumnN(colN);
						} */
						promoClaimStage.setColumnN(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 14:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnO(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							//							promoClaimStage.setColumnO(currentCell.getStringCellValue());
							DataFormatter formatter = new DataFormatter();
							String colO = formatter.formatCellValue(currentCell);
							promoClaimStage.setColumnO(colO);
						}

						else if(currentCell.getCellType() == CellType.NUMERIC) {
							DataFormatter formatter = new DataFormatter();
							String colO = formatter.formatCellValue(currentCell);
							promoClaimStage.setColumnO(colO);
						} */
						promoClaimStage.setColumnO(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 15:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnP(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnP(currentCell.getStringCellValue());
						}
						else {
							Integer columnP = (int)currentCell.getNumericCellValue();
							String colP = Integer.toString(columnP);
							promoClaimStage.setColumnP(colP);
						} */
						promoClaimStage.setColumnP(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 16:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnQ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnQ(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							DataFormatter formatter = new DataFormatter();
							String colQ = formatter.formatCellValue(currentCell);
							promoClaimStage.setColumnQ(colQ);
						} */
						promoClaimStage.setColumnQ(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 17:
						//Commented - Sarin Changes 22Jun2021
						/*
						currentCell = currentRow.getCell(17);
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnR(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnR(currentCell.getStringCellValue());
						}
						else{
							Integer columnR = (int)currentCell.getNumericCellValue();
							String colR = Integer.toString(columnR);
							promoClaimStage.setColumnR(colR);
						} */
						promoClaimStage.setColumnR(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 18:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnS(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnS(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnS = (int)currentCell.getNumericCellValue();
							String colS = Integer.toString(columnS);
							promoClaimStage.setColumnS(colS);
						} */
						promoClaimStage.setColumnS(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 19:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnT(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnT(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnT = (int)currentCell.getNumericCellValue();
							String colT = Integer.toString(columnT);
							promoClaimStage.setColumnT(colT);
						} */
						promoClaimStage.setColumnT(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 20:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnU(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnU(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){						
							DataFormatter formatter = new DataFormatter();
							String colU = formatter.formatCellValue(currentCell);
							promoClaimStage.setColumnU(colU);
						} */
						promoClaimStage.setColumnU(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 21:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnV(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnV(currentCell.getStringCellValue());
						}
						else{
							Integer columnV = (int)currentCell.getNumericCellValue();
							String colV = Integer.toString(columnV);
							promoClaimStage.setColumnV(colV);
						} */
						promoClaimStage.setColumnV(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 22:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnW(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnW(currentCell.getStringCellValue());
						}
						else{
							Integer columnW = (int)currentCell.getNumericCellValue();
							String colW = Integer.toString(columnW);
							promoClaimStage.setColumnW(colW);
						} */
						promoClaimStage.setColumnW(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 23:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnX(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnX(currentCell.getStringCellValue());
						}
						else{
							Integer columnX = (int)currentCell.getNumericCellValue();
							String colX = Integer.toString(columnX);
							promoClaimStage.setColumnX(colX);
						} */
						promoClaimStage.setColumnX(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 24:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnY(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnY(currentCell.getStringCellValue());
						}
						else{
							Integer columnY = (int)currentCell.getNumericCellValue();
							String colY = Integer.toString(columnY);
							promoClaimStage.setColumnY(colY);
						} */
						promoClaimStage.setColumnY(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;


					case 25:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnZ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnZ(currentCell.getStringCellValue());
						}
						else{
							Integer columnZ = (int)currentCell.getNumericCellValue();
							String colZ = Integer.toString(columnZ);
							promoClaimStage.setColumnZ(colZ);
						} */
						promoClaimStage.setColumnZ(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 26:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAA(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAA(currentCell.getStringCellValue());
						}
						else{
							Integer columnAA = (int)currentCell.getNumericCellValue();
							String colAA = Integer.toString(columnAA);
							promoClaimStage.setColumnAA(colAA);
						} */
						promoClaimStage.setColumnAA(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 27:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAB(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAB(currentCell.getStringCellValue());
						}
						else{
							Integer columnAB = (int)currentCell.getNumericCellValue();
							String colAB = Integer.toString(columnAB);
							promoClaimStage.setColumnAB(colAB);
						} */
						promoClaimStage.setColumnAB(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 28:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAC(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAC(currentCell.getStringCellValue());
						}
						else{
							Integer columnAC = (int)currentCell.getNumericCellValue();
							String colAC = Integer.toString(columnAC);
							promoClaimStage.setColumnAC(colAC);
						}
						*/
						promoClaimStage.setColumnAC(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 29:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAD(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAD(currentCell.getStringCellValue());
						}
						else{
							Integer columnAD = (int)currentCell.getNumericCellValue();
							String colAD = Integer.toString(columnAD);
							promoClaimStage.setColumnAD(colAD);
						}
						*/
						promoClaimStage.setColumnAD(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 30:
						//Commented - Sarin Changes 22Jun2021
						/*
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAE(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAE(currentCell.getStringCellValue());
						}
						else{
							Integer columnAE = (int)currentCell.getNumericCellValue();
							String colAE = Integer.toString(columnAE);
							promoClaimStage.setColumnAE(colAE);
						}
						*/
						promoClaimStage.setColumnAE(getCellValue(currentCell));  //Added - Sarin Changes 22Jun2021
						break;

					case 31:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAF(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAF(currentCell.getStringCellValue());
						}
						else{
							Integer columnAF = (int)currentCell.getNumericCellValue();
							String colAF = Integer.toString(columnAF);
							promoClaimStage.setColumnAF(colAF);
						}
						break;

					case 32:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAG(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAG(currentCell.getStringCellValue());
						}
						else{
							Integer columnAG = (int)currentCell.getNumericCellValue();
							String colAG = Integer.toString(columnAG);
							promoClaimStage.setColumnAG(colAG);
						}
						break;

					case 33:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAH(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAH(currentCell.getStringCellValue());
						}
						else{
							Integer columnAH = (int)currentCell.getNumericCellValue();
							String colAH = Integer.toString(columnAH);
							promoClaimStage.setColumnAH(colAH);
						}
						break;

					case 34:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAI(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAI(currentCell.getStringCellValue());
						}
						else{
							Integer columnAI = (int)currentCell.getNumericCellValue();
							String colAI = Integer.toString(columnAI);
							promoClaimStage.setColumnAI(colAI);
						}
						break;

					case 35:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAJ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAJ(currentCell.getStringCellValue());
						}
						else{
							Integer columnAJ = (int)currentCell.getNumericCellValue();
							String colAJ = Integer.toString(columnAJ);
							promoClaimStage.setColumnAJ(colAJ);
						}
						break;

					case 36:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAK(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAK(currentCell.getStringCellValue());
						}
						else{
							Integer columnAK = (int)currentCell.getNumericCellValue();
							String colAK = Integer.toString(columnAK);
							promoClaimStage.setColumnAK(colAK);
						}
						break;


					case 37:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAL(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAL(currentCell.getStringCellValue());
						}
						else{
							Integer columnAL = (int)currentCell.getNumericCellValue();
							String colAL = Integer.toString(columnAL);
							promoClaimStage.setColumnAL(colAL);
						}
						break;

					case 38:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAM(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAM(currentCell.getStringCellValue());
						}
						else{
							Integer columnAM = (int)currentCell.getNumericCellValue();
							String colAM = Integer.toString(columnAM);
							promoClaimStage.setColumnAM(colAM);
						}
						break;

					case 39:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAN(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAN(currentCell.getStringCellValue());
						}
						else{
							Integer columnAN = (int)currentCell.getNumericCellValue();
							String colAN = Integer.toString(columnAN);
							promoClaimStage.setColumnAN(colAN);
						}
						break;

					case 40:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAO(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAO(currentCell.getStringCellValue());
						}
						else{
							Integer columnAO = (int)currentCell.getNumericCellValue();
							String colAO = Integer.toString(columnAO);
							promoClaimStage.setColumnAO(colAO);
						}
						break;


					case 41:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAP(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAP(currentCell.getStringCellValue());
						}
						else{
							Integer columnAP = (int)currentCell.getNumericCellValue();
							String colAP = Integer.toString(columnAP);
							promoClaimStage.setColumnAP(colAP);
						}
						break;

					case 42:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAQ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAQ(currentCell.getStringCellValue());
						}
						else{
							Integer columnAQ = (int)currentCell.getNumericCellValue();
							String colAQ = Integer.toString(columnAQ);
							promoClaimStage.setColumnAQ(colAQ);
						}
						break;

					case 43:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAR(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAR(currentCell.getStringCellValue());
						}
						else{
							Integer columnAR = (int)currentCell.getNumericCellValue();
							String colAR = Integer.toString(columnAR);
							promoClaimStage.setColumnAR(colAR);
						}
						break;

					case 44:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAS(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAS(currentCell.getStringCellValue());
						}
						else{
							Integer columnAS = (int)currentCell.getNumericCellValue();
							String colAS = Integer.toString(columnAS);
							promoClaimStage.setColumnAS(colAS);
						}
						break;

					case 45:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAT(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAT(currentCell.getStringCellValue());
						}
						else{
							Integer columnAT = (int)currentCell.getNumericCellValue();
							String colAT = Integer.toString(columnAT);
							promoClaimStage.setColumnAT(colAT);
						}
						break;

					case 46:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAU(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAU(currentCell.getStringCellValue());
						}
						else{
							Integer columnAU = (int)currentCell.getNumericCellValue();
							String colAU = Integer.toString(columnAU);
							promoClaimStage.setColumnAU(colAU);
						}
						break;

					case 47:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAV(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAV(currentCell.getStringCellValue());
						}
						else{
							Integer columnAV = (int)currentCell.getNumericCellValue();
							String colAV = Integer.toString(columnAV);
							promoClaimStage.setColumnAV(colAV);
						}
						break;

					case 48:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAW(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAW(currentCell.getStringCellValue());
						}
						else{
							Integer columnAW = (int)currentCell.getNumericCellValue();
							String colAW = Integer.toString(columnAW);
							promoClaimStage.setColumnAW(colAW);
						}
						break;

					case 49:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAX(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAX(currentCell.getStringCellValue());
						}
						else{
							Integer columnAX = (int)currentCell.getNumericCellValue();
							String colAX = Integer.toString(columnAX);
							promoClaimStage.setColumnAX(colAX);
						}
						break;

					case 50:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAY(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAY(currentCell.getStringCellValue());
						}
						else{
							Integer columnAY = (int)currentCell.getNumericCellValue();
							String colAY = Integer.toString(columnAY);
							promoClaimStage.setColumnAY(colAY);
						}
						break;

					case 51:
						if (currentCell.getCellType() == CellType.BLANK) {
							promoClaimStage.setColumnAZ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							promoClaimStage.setColumnAZ(currentCell.getStringCellValue());
						}
						else{
							Integer columnAZ = (int)currentCell.getNumericCellValue();
							String colAZ = Integer.toString(columnAZ);
							promoClaimStage.setColumnAZ(colAZ);
						}
						break;


					default:
						break;

					}
					promoClaimStage.setNoOfColumns(cellIdx + 1);
					//cellIdx++; //Commented - Sarin Changes 22Jun2021 


				}//end of  inner while

				promoClaimStageList.add(promoClaimStage);

			}//end of while

			workbook.close();

			return promoClaimStageList;

		}catch(IOException e){
			e.printStackTrace();
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}

	}


	public static List<PosDataStage> excelToPosDataStage(InputStream is) {


		try {
			//Workbook workbook = new XSSFWorkbook(is);
			XSSFWorkbook workbook = new XSSFWorkbook(is); 

			//XSSFSheet sheet = workbook.createSheet(SHEET);
			Sheet datatypeSheet = workbook.getSheetAt(0); 
			Iterator<Row> rows = datatypeSheet.iterator();


			List<PosDataStage> posDataStageList = new ArrayList<PosDataStage>();

			int rowNumber = 0;
			while (rows.hasNext()) {

				Row currentRow = rows.next();

				//Commented - Sarin Changes 20Jun2022 - Excel file validation for POS file
				// skip header
				/*if (rowNumber == 0) {
					rowNumber++;
					continue;
				}*/

				Iterator<Cell> cellsInRow = currentRow.iterator();

				PosDataStage posDataStage = new PosDataStage();

				int cellIdx = 0;
				while (cellsInRow.hasNext()) {

					Cell currentCell = cellsInRow.next();


					switch (cellIdx) {

					case 0:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnA(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnA(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnA = (int)currentCell.getNumericCellValue();
							String colA = Integer.toString(columnA);
							posDataStage.setColumnA(colA);
						}

						break;


					case 1:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnB(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnB(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnB = (int)currentCell.getNumericCellValue();
							String colB = Integer.toString(columnB);
							posDataStage.setColumnB(colB);
						}
						break;


					case 2:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnC(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnC(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnC = (int)currentCell.getNumericCellValue();
							String colC = Integer.toString(columnC);
							posDataStage.setColumnC(colC);
						}
						break;

					case 3:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnD(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnD(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnD = (int)currentCell.getNumericCellValue();
							String colD = Integer.toString(columnD);
							posDataStage.setColumnD(colD);
						}

						break;


					case 4:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnE(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnE(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnE = (int)currentCell.getNumericCellValue();
							String colE = Integer.toString(columnE);
							posDataStage.setColumnE(colE);
						}

						break;

					case 5:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnF(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnF(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnF = (int)currentCell.getNumericCellValue();
							String colF = Integer.toString(columnF);
							posDataStage.setColumnF(colF);
						}
						break;

					case 6:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnG(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnG(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnG = (int)currentCell.getNumericCellValue();
							String colG = Integer.toString(columnG);
							posDataStage.setColumnG(colG);
						}
						break;

					case 7:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnH(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnH(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnH = (int)currentCell.getNumericCellValue();
							String colH = Integer.toString(columnH);
							posDataStage.setColumnH(colH);
						}
						break;


					case 8:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnI(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnI(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnI = (int)currentCell.getNumericCellValue();
							String colI = Integer.toString(columnI);
							posDataStage.setColumnI(colI);
						}
						break;

					case 9:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnJ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnJ(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnJ = (int)currentCell.getNumericCellValue();
							String colJ = Integer.toString(columnJ);
							posDataStage.setColumnJ(colJ);
						}
						break;

					case 10:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnK(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnK(currentCell.getStringCellValue());
						}
						else{
							Integer columnK = (int)currentCell.getNumericCellValue();
							String colK = Integer.toString(columnK);
							posDataStage.setColumnK(colK);
						}
						break;

					case 11:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnL(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnL(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnL = (int)currentCell.getNumericCellValue();
							String colL = Integer.toString(columnL);
							posDataStage.setColumnL(colL);
						}

						break;

					case 12:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnM(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnM(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnM = (int)currentCell.getNumericCellValue();
							String colM = Integer.toString(columnM);
							posDataStage.setColumnM(colM);
						}
						break;

					case 13:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnN(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnN(currentCell.getStringCellValue());
						}
						else{
							Integer columnN = (int)currentCell.getNumericCellValue();
							String colN = Integer.toString(columnN);
							posDataStage.setColumnN(colN);
						}
						break;

					case 14:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnO(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnO(currentCell.getStringCellValue());
						}
						else {
							Integer columnO = (int)currentCell.getNumericCellValue();
							String colO = Integer.toString(columnO);
							posDataStage.setColumnO(colO);
						}
						break;

					case 15:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnP(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnP(currentCell.getStringCellValue());
						}
						else {
							Integer columnP = (int)currentCell.getNumericCellValue();
							String colP = Integer.toString(columnP);
							posDataStage.setColumnP(colP);
						}
						break;

					case 16:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnQ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnQ(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnQ = (int)currentCell.getNumericCellValue();
							String colQ = Integer.toString(columnQ);
							posDataStage.setColumnQ(colQ);
						}
						break;

					case 17:
						currentCell = currentRow.getCell(17);
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnR(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnR(currentCell.getStringCellValue());
						}
						else{
							Integer columnR = (int)currentCell.getNumericCellValue();
							String colR = Integer.toString(columnR);
							posDataStage.setColumnR(colR);
						}
						break;

					case 18:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnS(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnS(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnS = (int)currentCell.getNumericCellValue();
							String colS = Integer.toString(columnS);
							posDataStage.setColumnS(colS);
						}
						break;

					case 19:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnT(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnT(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnT = (int)currentCell.getNumericCellValue();
							String colT = Integer.toString(columnT);
							posDataStage.setColumnT(colT);
						}
						break;

					case 20:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnU(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnU(currentCell.getStringCellValue());
						}
						else if(currentCell.getCellType() == CellType.NUMERIC){
							Integer columnU = (int)currentCell.getNumericCellValue();
							String colU = Integer.toString(columnU);
							posDataStage.setColumnU(colU);
						}
						break;

					case 21:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnV(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnV(currentCell.getStringCellValue());
						}
						else{
							Integer columnV = (int)currentCell.getNumericCellValue();
							String colV = Integer.toString(columnV);
							posDataStage.setColumnV(colV);
						}

						break;

					case 22:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnW(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnW(currentCell.getStringCellValue());
						}
						else{
							Integer columnW = (int)currentCell.getNumericCellValue();
							String colW = Integer.toString(columnW);
							posDataStage.setColumnW(colW);
						}
						break;

					case 23:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnX(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnX(currentCell.getStringCellValue());
						}
						else{
							Integer columnX = (int)currentCell.getNumericCellValue();
							String colX = Integer.toString(columnX);
							posDataStage.setColumnX(colX);
						}
						break;

					case 24:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnY(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnY(currentCell.getStringCellValue());
						}
						else{
							Integer columnY = (int)currentCell.getNumericCellValue();
							String colY = Integer.toString(columnY);
							posDataStage.setColumnY(colY);
						}
						break;


					case 25:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnZ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnZ(currentCell.getStringCellValue());
						}
						else{
							Integer columnZ = (int)currentCell.getNumericCellValue();
							String colZ = Integer.toString(columnZ);
							posDataStage.setColumnZ(colZ);
						}
						break;

					case 26:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAA(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAA(currentCell.getStringCellValue());
						}
						else{
							Integer columnAA = (int)currentCell.getNumericCellValue();
							String colAA = Integer.toString(columnAA);
							posDataStage.setColumnAA(colAA);
						}
						break;

					case 27:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAB(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAB(currentCell.getStringCellValue());
						}
						else{
							Integer columnAB = (int)currentCell.getNumericCellValue();
							String colAB = Integer.toString(columnAB);
							posDataStage.setColumnAB(colAB);
						}
						break;

					case 28:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAC(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAC(currentCell.getStringCellValue());
						}
						else{
							Integer columnAC = (int)currentCell.getNumericCellValue();
							String colAC = Integer.toString(columnAC);
							posDataStage.setColumnAC(colAC);
						}
						break;


					case 29:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAD(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAD(currentCell.getStringCellValue());
						}
						else{
							Integer columnAD = (int)currentCell.getNumericCellValue();
							String colAD = Integer.toString(columnAD);
							posDataStage.setColumnAD(colAD);
						}
						break;

					case 30:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAE(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAE(currentCell.getStringCellValue());
						}
						else{
							Integer columnAE = (int)currentCell.getNumericCellValue();
							String colAE = Integer.toString(columnAE);
							posDataStage.setColumnAE(colAE);
						}
						break;

					case 31:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAF(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAF(currentCell.getStringCellValue());
						}
						else{
							Integer columnAF = (int)currentCell.getNumericCellValue();
							String colAF = Integer.toString(columnAF);
							posDataStage.setColumnAF(colAF);
						}
						break;

					case 32:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAG(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAG(currentCell.getStringCellValue());
						}
						else{
							Integer columnAG = (int)currentCell.getNumericCellValue();
							String colAG = Integer.toString(columnAG);
							posDataStage.setColumnAG(colAG);
						}
						break;

					case 33:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAH(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAH(currentCell.getStringCellValue());
						}
						else{
							Integer columnAH = (int)currentCell.getNumericCellValue();
							String colAH = Integer.toString(columnAH);
							posDataStage.setColumnAH(colAH);
						}
						break;

					case 34:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAI(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAI(currentCell.getStringCellValue());
						}
						else{
							Integer columnAI = (int)currentCell.getNumericCellValue();
							String colAI = Integer.toString(columnAI);
							posDataStage.setColumnAI(colAI);
						}
						break;

					case 35:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAJ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAJ(currentCell.getStringCellValue());
						}
						else{
							Integer columnAJ = (int)currentCell.getNumericCellValue();
							String colAJ = Integer.toString(columnAJ);
							posDataStage.setColumnAJ(colAJ);
						}
						break;

					case 36:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAK(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAK(currentCell.getStringCellValue());
						}
						else{
							Integer columnAK = (int)currentCell.getNumericCellValue();
							String colAK = Integer.toString(columnAK);
							posDataStage.setColumnAK(colAK);
						}
						break;


					case 37:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAL(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAL(currentCell.getStringCellValue());
						}
						else{
							Integer columnAL = (int)currentCell.getNumericCellValue();
							String colAL = Integer.toString(columnAL);
							posDataStage.setColumnAL(colAL);
						}
						break;

					case 38:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAM(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAM(currentCell.getStringCellValue());
						}
						else{
							Integer columnAM = (int)currentCell.getNumericCellValue();
							String colAM = Integer.toString(columnAM);
							posDataStage.setColumnAM(colAM);
						}
						break;

					case 39:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAN(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAN(currentCell.getStringCellValue());
						}
						else{
							Integer columnAN = (int)currentCell.getNumericCellValue();
							String colAN = Integer.toString(columnAN);
							posDataStage.setColumnAN(colAN);
						}
						break;

					case 40:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAO(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAO(currentCell.getStringCellValue());
						}
						else{
							Integer columnAO = (int)currentCell.getNumericCellValue();
							String colAO = Integer.toString(columnAO);
							posDataStage.setColumnAO(colAO);
						}
						break;


					case 41:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAP(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAP(currentCell.getStringCellValue());
						}
						else{
							Integer columnAP = (int)currentCell.getNumericCellValue();
							String colAP = Integer.toString(columnAP);
							posDataStage.setColumnAP(colAP);
						}
						break;

					case 42:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAQ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAQ(currentCell.getStringCellValue());
						}
						else{
							Integer columnAQ = (int)currentCell.getNumericCellValue();
							String colAQ = Integer.toString(columnAQ);
							posDataStage.setColumnAQ(colAQ);
						}
						break;

					case 43:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAR(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAR(currentCell.getStringCellValue());
						}
						else{
							Integer columnAR = (int)currentCell.getNumericCellValue();
							String colAR = Integer.toString(columnAR);
							posDataStage.setColumnAR(colAR);
						}
						break;

					case 44:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAS(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAS(currentCell.getStringCellValue());
						}
						else{
							Integer columnAS = (int)currentCell.getNumericCellValue();
							String colAS = Integer.toString(columnAS);
							posDataStage.setColumnAS(colAS);
						}
						break;

					case 45:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAT(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAT(currentCell.getStringCellValue());
						}
						else{
							Integer columnAT = (int)currentCell.getNumericCellValue();
							String colAT = Integer.toString(columnAT);
							posDataStage.setColumnAT(colAT);
						}
						break;

					case 46:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAU(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAU(currentCell.getStringCellValue());
						}
						else{
							Integer columnAU = (int)currentCell.getNumericCellValue();
							String colAU = Integer.toString(columnAU);
							posDataStage.setColumnAU(colAU);
						}
						break;

					case 47:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAV(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAV(currentCell.getStringCellValue());
						}
						else{
							Integer columnAV = (int)currentCell.getNumericCellValue();
							String colAV = Integer.toString(columnAV);
							posDataStage.setColumnAV(colAV);
						}
						break;

					case 48:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAW(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAW(currentCell.getStringCellValue());
						}
						else{
							Integer columnAW = (int)currentCell.getNumericCellValue();
							String colAW = Integer.toString(columnAW);
							posDataStage.setColumnAW(colAW);
						}
						break;

					case 49:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAX(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAX(currentCell.getStringCellValue());
						}
						else{
							Integer columnAX = (int)currentCell.getNumericCellValue();
							String colAX = Integer.toString(columnAX);
							posDataStage.setColumnAX(colAX);
						}
						break;

					case 50:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAY(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAY(currentCell.getStringCellValue());
						}
						else{
							Integer columnAY = (int)currentCell.getNumericCellValue();
							String colAY = Integer.toString(columnAY);
							posDataStage.setColumnAY(colAY);
						}
						break;

					case 51:
						if (currentCell.getCellType() == CellType.BLANK) {
							posDataStage.setColumnAZ(" ");
						}else if(currentCell.getCellType() == CellType.STRING){
							posDataStage.setColumnAZ(currentCell.getStringCellValue());
						}
						else{
							Integer columnAZ = (int)currentCell.getNumericCellValue();
							String colAZ = Integer.toString(columnAZ);
							posDataStage.setColumnAZ(colAZ);
						}
						break;


					default:
						break;

					}

					cellIdx++;


				}//end of  inner while
				
				posDataStage.setNoOfColumns(cellIdx + 1);  //Added By Sarin Jun2022 - Excel file validation for POS file
				
				posDataStageList.add(posDataStage);

			}//end of while

			workbook.close();

			return posDataStageList;

		}catch(IOException e){
			e.printStackTrace();
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}

	}
	public static ByteArrayInputStream generateDataToExcel(List<BaseWorking> actualDataList) {

		try {
		Workbook workbook = new XSSFWorkbook();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		Sheet sheet = workbook.createSheet(BASE_WORKING_ACTUAL_SHEET);


		//CellStyle cellStyle = workbook.createCellStyle();
		/*CreationHelper createHelper = workbook.getCreationHelper();
		cellStyle.setDataFormat(
		createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
		*/
		// Header
		Row headerRow = sheet.createRow(0);


		for (int col = 0; col < BASE_WORKING_ACTUAL_HEADERS.length; col++) {
		Cell cell = headerRow.createCell(col);
		cell.setCellValue(BASE_WORKING_ACTUAL_HEADERS[col]);
		}


		int rowIdx = 1;
		for (BaseWorking sl : actualDataList) {
		Row row = sheet.createRow(rowIdx++);
//		if(sl.getPromotionUnit().equals("NO")) {
//		if(sl.getSolCode() !=null) {
//		row.createCell(0).setCellValue(sl.getSolCode());
//		}
//		if(sl.getBasepack() !=null) {
//		row.createCell(1).setCellValue(sl.getBasepack());
//		}
//
//		if(sl.getArticleCode() !=null) {
//		row.createCell(2).setCellValue(sl.getArticleCode());
//		}
//		if(sl.getSoleCodeDesc() !=null) {
//		row.createCell(3).setCellValue(sl.getSoleCodeDesc());
//		}
//		else {
//			row.createCell(3).setCellValue(" ");
//		}
//		if(sl.getHulMRP() !=null) {
//		row.createCell(4).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getCustomerMRP() !=null) {
//		row.createCell(5).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getNetClaimValue() !=null) {
//		row.createCell(6).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getNetClaimQty() !=null) {
//		row.createCell(7).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getPromotionAmt() !=null) {
//		row.createCell(8).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getClaimAmtPerUnit() !=null) {
//		row.createCell(9).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getClaimPosPrimaryQty() !=null) {
//		row.createCell(10).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getCustomerClaimMinQty() !=null) {
//		row.createCell(11).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDiffInCustomerClaims() !=null) {
//		row.createCell(12).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getHulClaim() !=null) {
//		row.createCell(13).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getNetClaims() !=null) {
//		row.createCell(14).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDiffClaims() !=null) {
//		row.createCell(15).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDeductionBucket() !=null) {
//		row.createCell(16).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDeductionAmt() !=null) {
//		row.createCell(17).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//
//		}//end of first if block

//		if(sl.getHulMRP() == null) {
//		if(sl.getSolCode() !=null) {
//		row.createCell(0).setCellValue(sl.getSolCode());
//		}
//		if(sl.getBasepack() !=null) {
//		row.createCell(1).setCellValue(sl.getBasepack());
//		}
//
//		if(sl.getArticleCode() !=null) {
//		row.createCell(2).setCellValue(sl.getArticleCode());
//		}
//		if(sl.getSoleCodeDesc() !=null) {
//		row.createCell(3).setCellValue(sl.getSoleCodeDesc());
//		}
//		if(sl.getHulMRP() !=null) {
//		row.createCell(4).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getCustomerMRP() !=null) {
//		row.createCell(5).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getNetClaimValue() !=null) {
//		row.createCell(6).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getNetClaimQty() !=null) {
//		row.createCell(7).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getPromotionAmt() !=null) {
//		row.createCell(8).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getClaimAmtPerUnit() !=null) {
//		row.createCell(9).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getClaimPosPrimaryQty() !=null) {
//		row.createCell(10).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getCustomerClaimMinQty() !=null) {
//		row.createCell(11).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getDiffInCustomerClaims() !=null) {
//		row.createCell(12).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getHulClaim() !=null) {
//		row.createCell(13).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getNetClaims() !=null) {
//		row.createCell(14).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getDiffClaims() !=null) {
//		row.createCell(15).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getDeductionBucket() !=null) {
//		row.createCell(16).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//		if(sl.getDeductionAmt() !=null) {
//		row.createCell(17).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
//		}
//
//		}//end of third if block

//		if(sl.getPromotionUnit().equals("NO") && sl.getHulMRP() == null) {
//
//		if(sl.getSolCode() !=null) {
//		row.createCell(0).setCellValue(sl.getSolCode());
//		}
//		if(sl.getBasepack() !=null) {
//		row.createCell(1).setCellValue(sl.getBasepack());
//		}
//
//		if(sl.getArticleCode() !=null) {
//		row.createCell(2).setCellValue(sl.getArticleCode());
//		}
//		if(sl.getSoleCodeDesc() !=null) {
//		row.createCell(3).setCellValue(sl.getSoleCodeDesc());
//		}
//		if(sl.getHulMRP() !=null) {
//		row.createCell(4).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getCustomerMRP() !=null) {
//		row.createCell(5).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getNetClaimValue() !=null) {
//		row.createCell(6).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getNetClaimQty() !=null) {
//		row.createCell(7).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getPromotionAmt() !=null) {
//		row.createCell(8).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getClaimAmtPerUnit() !=null) {
//		row.createCell(9).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getClaimPosPrimaryQty() !=null) {
//		row.createCell(10).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getCustomerClaimMinQty() !=null) {
//		row.createCell(11).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDiffInCustomerClaims() !=null) {
//		row.createCell(12).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getHulClaim() !=null) {
//		row.createCell(13).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getNetClaims() !=null) {
//		row.createCell(14).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDiffClaims() !=null) {
//		row.createCell(15).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDeductionBucket() !=null) {
//		row.createCell(16).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//		if(sl.getDeductionAmt() !=null) {
//		row.createCell(17).setCellValue("Calculation on Hold : Incorrect Sol Description");
//		}
//
//		}//end of forth if block

	

		if(sl.getSolCode() !=null) {
		row.createCell(0).setCellValue(sl.getSolCode());
		}
		if(sl.getBasepack() !=null) {
		row.createCell(1).setCellValue(sl.getBasepack());
		}

		if(sl.getArticleCode() !=null) {
		row.createCell(2).setCellValue(sl.getArticleCode());
		}
		if(sl.getSoleCodeDesc() !=null) {
		row.createCell(3).setCellValue(sl.getSoleCodeDesc());
		}
		if(sl.getHulMRP() !=null) {
		row.createCell(4).setCellValue(sl.getHulMRP());
		}
		if(sl.getCustomerMRP() !=null) {
		row.createCell(5).setCellValue(sl.getCustomerMRP());
		}
		if(sl.getNetClaimValue() !=null) {
		row.createCell(6).setCellValue(sl.getNetClaimValue());
		}
		if(sl.getNetClaimQty() !=null) {
		row.createCell(7).setCellValue(sl.getNetClaimQty());
		}
		if(sl.getPromotionAmt() !=null) {
		row.createCell(8).setCellValue(sl.getPromotionAmt());
		}
		if(sl.getClaimAmtPerUnit() !=null) {
		row.createCell(9).setCellValue(sl.getClaimAmtPerUnit());
		}
		if(sl.getClaimPosPrimaryQty() !=null) {
		row.createCell(10).setCellValue(sl.getClaimPosPrimaryQty());
		}
		if(sl.getCustomerClaimMinQty() !=null) {
		row.createCell(11).setCellValue(sl.getCustomerClaimMinQty());
		}
		if(sl.getDiffInCustomerClaims() !=null) {
		row.createCell(12).setCellValue(sl.getDiffInCustomerClaims());
		}
		if(sl.getHulClaim() !=null) {
		row.createCell(13).setCellValue(sl.getHulClaim());
		}
		if(sl.getNetClaims() !=null) {
		row.createCell(14).setCellValue(sl.getNetClaims());
		}
		if(sl.getDiffClaims() !=null) {
		row.createCell(15).setCellValue(sl.getDiffClaims());
		}
		if(sl.getDeductionBucket() !=null) {
		row.createCell(16).setCellValue(sl.getDeductionBucket());
		}
		if(sl.getDeductionAmt() !=null) {
		row.createCell(17).setCellValue(sl.getDeductionAmt());
		}
//
//
//		}//end of fifth if block
		
//		if((sl.getSoleCodeDesc() == null || sl.getSoleCodeDesc().isEmpty() ) && (sl.getPromotionUnit() == null || sl.getPromotionUnit().isEmpty())) {
//
//			if(sl.getSolCode() !=null) {
//			row.createCell(0).setCellValue(sl.getSolCode());
//			}
//			if(sl.getBasepack() !=null) {
//			row.createCell(1).setCellValue(sl.getBasepack());
//			}
//
//			if(sl.getArticleCode() !=null) {
//			row.createCell(2).setCellValue(sl.getArticleCode());
//			}
//			if(sl.getSoleCodeDesc() !=null) {
//			row.createCell(3).setCellValue(sl.getSoleCodeDesc());
//			}
//			else {
//				row.createCell(3).setCellValue(" ");
//			}
//			if(sl.getHulMRP() !=null) {
//			row.createCell(4).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(4).setCellValue(" ");
//			}
//			if(sl.getCustomerMRP() !=null) {
//			row.createCell(5).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(5).setCellValue(" ");
//			}
//			if(sl.getNetClaimValue() !=null) {
//			row.createCell(6).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(6).setCellValue(" ");
//			}
//			if(sl.getNetClaimQty() !=null) {
//			row.createCell(7).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(7).setCellValue(" ");
//			}
//			if(sl.getPromotionAmt() !=null) {
//			row.createCell(8).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(8).setCellValue(" ");
//			}
//			if(sl.getClaimAmtPerUnit() !=null) {
//			row.createCell(9).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(9).setCellValue(" ");
//			}
//			if(sl.getClaimPosPrimaryQty() !=null) {
//			row.createCell(10).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(10).setCellValue(" ");
//			}
//			if(sl.getCustomerClaimMinQty() !=null) {
//			row.createCell(11).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(11).setCellValue(" ");
//			}
//			if(sl.getDiffInCustomerClaims() !=null) {
//			row.createCell(12).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(12).setCellValue(" ");
//			}
//			if(sl.getHulClaim() !=null) {
//			row.createCell(13).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(13).setCellValue(" ");
//			}
//			if(sl.getNetClaims() !=null) {
//			row.createCell(14).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(14).setCellValue(" ");
//			}
//			if(sl.getDiffClaims() !=null) {
//			row.createCell(15).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(15).setCellValue(" ");
//			}
//			if(sl.getDeductionBucket() !=null) {
//			row.createCell(16).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(16).setCellValue(" ");
//			}
//			if(sl.getDeductionAmt() !=null) {
//			row.createCell(17).setCellValue("Calculation on Hold : SOL Code mIssing in PPM");
//			}
//			else {
//				row.createCell(17).setCellValue(" ");
//			}
//
//
//			}//end of sixth if block

		

		}

		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());

		} catch (IOException e) {
		throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
		}

//	public static ByteArrayInputStream generateDataToExcel(List<BaseWorking> actualDataList) {
//
//		try {
//			Workbook workbook = new XSSFWorkbook();
//			ByteArrayOutputStream out = new ByteArrayOutputStream();
//			Sheet sheet = workbook.createSheet(BASE_WORKING_ACTUAL_SHEET);
//
//
//			//CellStyle cellStyle = workbook.createCellStyle();
//			/*CreationHelper createHelper = workbook.getCreationHelper();
//		cellStyle.setDataFormat(
//		createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
//			 */
//			// Header
//			Row headerRow = sheet.createRow(0);
//
//
//			for (int col = 0; col < BASE_WORKING_ACTUAL_HEADERS.length; col++) {
//				Cell cell = headerRow.createCell(col);
//				cell.setCellValue(BASE_WORKING_ACTUAL_HEADERS[col]);
//			}
//
//
//			int rowIdx = 1;
//			for (BaseWorking sl : actualDataList) {
//				Row row = sheet.createRow(rowIdx++);
//				if(sl.getPromotionUnit().equals("NO")) {
//					if(sl.getSolCode() !=null) {
//						row.createCell(0).setCellValue(sl.getSolCode());
//					}
//					else {
//						row.createCell(0).setCellValue(" ");
//					}
//					if(sl.getBasepack() !=null) {
//						row.createCell(1).setCellValue(sl.getBasepack());
//					}
//					else {
//						row.createCell(1).setCellValue(" ");
//					}
//					if(sl.getArticleCode() !=null) {
//						row.createCell(2).setCellValue(sl.getArticleCode());
//					}
//					else {
//						row.createCell(2).setCellValue(" ");
//					}
//					if(sl.getSoleCodeDesc() !=null) {
//						row.createCell(3).setCellValue(sl.getSoleCodeDesc());
//					}
//					else {
//						row.createCell(3).setCellValue(" ");
//					}
//					if(sl.getHulMRP() !=null) {
//						row.createCell(4).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(4).setCellValue(" ");
//					}
//					if(sl.getCustomerMRP() !=null) {
//						row.createCell(5).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(5).setCellValue(" ");
//					}
//					if(sl.getNetClaimValue() !=null) {
//						row.createCell(6).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(6).setCellValue(" ");
//					}
//					if(sl.getNetClaimQty() !=null) {
//						row.createCell(7).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(7).setCellValue(" ");
//					}
//					if(sl.getPromotionAmt() !=null) {
//						row.createCell(8).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(8).setCellValue(" ");
//					}
//					if(sl.getClaimAmtPerUnit() !=null) {
//						row.createCell(9).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(9).setCellValue(" ");
//					}
//					if(sl.getClaimPosPrimaryQty() !=null) {
//						row.createCell(10).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(10).setCellValue(" ");
//					}
//					if(sl.getCustomerClaimMinQty() !=null) {
//						row.createCell(11).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(11).setCellValue(" ");
//					}
//					if(sl.getDiffInCustomerClaims() !=null) {
//						row.createCell(12).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(12).setCellValue(" ");
//					}
//					if(sl.getHulClaim() !=null) {
//						row.createCell(13).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(13).setCellValue(" ");
//					}
//					if(sl.getNetClaims() !=null) {
//						row.createCell(14).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(14).setCellValue(" ");
//					}
//					if(sl.getDiffClaims() !=null) {
//						row.createCell(15).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(15).setCellValue(" ");
//					}
//					if(sl.getDeductionBucket() !=null) {
//						row.createCell(16).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(16).setCellValue(" ");
//					}
//					if(sl.getDeductionAmt() !=null) {
//						row.createCell(17).setCellValue("Calculation on Hold : Incorrect Sol Description");
//					}
//					else {
//						row.createCell(17).setCellValue(" ");
//					}
//					
//
//				}//end of first if block
//				
////				if(sl.getPromotionUnit() == null) {
////					if(sl.getSolCode() !=null) {
////						row.createCell(0).setCellValue(sl.getSolCode());
////					}
////					if(sl.getBasepack() !=null) {
////						row.createCell(1).setCellValue(sl.getBasepack());
////					}
////
////					if(sl.getArticleCode() !=null) {
////						row.createCell(2).setCellValue(sl.getArticleCode());
////					}
////					if(sl.getSoleCodeDesc() !=null) {
////						row.createCell(3).setCellValue(sl.getSoleCodeDesc());
////					}
////					if(sl.getHulMRP() !=null) {
////						row.createCell(4).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getCustomerMRP() !=null) {
////						row.createCell(5).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getNetClaimValue() !=null) {
////						row.createCell(6).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getNetClaimQty() !=null) {
////						row.createCell(7).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getPromotionAmt() !=null) {
////						row.createCell(8).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getClaimAmtPerUnit() !=null) {
////						row.createCell(9).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getClaimPosPrimaryQty() !=null) {
////						row.createCell(10).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getCustomerClaimMinQty() !=null) {
////						row.createCell(11).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getDiffInCustomerClaims() !=null) {
////						row.createCell(12).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getHulClaim() !=null) {
////						row.createCell(13).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getNetClaims() !=null) {
////						row.createCell(14).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getDiffClaims() !=null) {
////						row.createCell(15).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getDeductionBucket() !=null) {
////						row.createCell(16).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////					if(sl.getDeductionAmt() !=null) {
////						row.createCell(17).setCellValue("Calculation on Hold:Sol Code not in PPM");
////					}
////
////				}//end of second if block 
//				
////				if(sl.getHulMRP() == null) {
////					if(sl.getSolCode() !=null) {
////						row.createCell(0).setCellValue(sl.getSolCode());
////					}
////					if(sl.getBasepack() !=null) {
////						row.createCell(1).setCellValue(sl.getBasepack());
////					}
////
////					if(sl.getArticleCode() !=null) {
////						row.createCell(2).setCellValue(sl.getArticleCode());
////					}
////					if(sl.getSoleCodeDesc() !=null) {
////						row.createCell(3).setCellValue(sl.getSoleCodeDesc());
////					}
////					if(sl.getHulMRP() !=null) {
////						row.createCell(4).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getCustomerMRP() !=null) {
////						row.createCell(5).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getNetClaimValue() !=null) {
////						row.createCell(6).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getNetClaimQty() !=null) {
////						row.createCell(7).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getPromotionAmt() !=null) {
////						row.createCell(8).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getClaimAmtPerUnit() !=null) {
////						row.createCell(9).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getClaimPosPrimaryQty() !=null) {
////						row.createCell(10).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getCustomerClaimMinQty() !=null) {
////						row.createCell(11).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getDiffInCustomerClaims() !=null) {
////						row.createCell(12).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getHulClaim() !=null) {
////						row.createCell(13).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getNetClaims() !=null) {
////						row.createCell(14).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getDiffClaims() !=null) {
////						row.createCell(15).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getDeductionBucket() !=null) {
////						row.createCell(16).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					if(sl.getDeductionAmt() !=null) {
////						row.createCell(17).setCellValue("Calculation on Hold : IAR to Customer Name Mapping mIssing");
////					}
////					
////				}//end of third if block
//				
////				if(sl.getPromotionUnit().equals("NO") && sl.getHulMRP() == null) {
////					
////					if(sl.getSolCode() !=null) {
////						row.createCell(0).setCellValue(sl.getSolCode());
////					}
////					if(sl.getBasepack() !=null) {
////						row.createCell(1).setCellValue(sl.getBasepack());
////					}
////
////					if(sl.getArticleCode() !=null) {
////						row.createCell(2).setCellValue(sl.getArticleCode());
////					}
////					if(sl.getSoleCodeDesc() !=null) {
////						row.createCell(3).setCellValue(sl.getSoleCodeDesc());
////					}
////					if(sl.getHulMRP() !=null) {
////						row.createCell(4).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getCustomerMRP() !=null) {
////						row.createCell(5).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getNetClaimValue() !=null) {
////						row.createCell(6).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getNetClaimQty() !=null) {
////						row.createCell(7).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getPromotionAmt() !=null) {
////						row.createCell(8).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getClaimAmtPerUnit() !=null) {
////						row.createCell(9).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getClaimPosPrimaryQty() !=null) {
////						row.createCell(10).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getCustomerClaimMinQty() !=null) {
////						row.createCell(11).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getDiffInCustomerClaims() !=null) {
////						row.createCell(12).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getHulClaim() !=null) {
////						row.createCell(13).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getNetClaims() !=null) {
////						row.createCell(14).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getDiffClaims() !=null) {
////						row.createCell(15).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getDeductionBucket() !=null) {
////						row.createCell(16).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					if(sl.getDeductionAmt() !=null) {
////						row.createCell(17).setCellValue("Calculation on Hold : Incorrect Sol Description");
////					}
////					
////				}//end of forth if block
//				
////				if(!sl.getPromotionUnit().equals("NO") && sl.getHulMRP() != null) {
////					
////					if(sl.getSolCode() !=null) {
////						row.createCell(0).setCellValue(sl.getSolCode());
////					}
////					if(sl.getBasepack() !=null) {
////						row.createCell(1).setCellValue(sl.getBasepack());
////					}
////
////					if(sl.getArticleCode() !=null) {
////						row.createCell(2).setCellValue(sl.getArticleCode());
////					}
////					if(sl.getSoleCodeDesc() !=null) {
////						row.createCell(3).setCellValue(sl.getSoleCodeDesc());
////					}
////					if(sl.getHulMRP() !=null) {
////						row.createCell(4).setCellValue(sl.getHulMRP());
////					}
////					if(sl.getCustomerMRP() !=null) {
////						row.createCell(5).setCellValue(sl.getCustomerMRP());
////					}
////					if(sl.getNetClaimValue() !=null) {
////						row.createCell(6).setCellValue(sl.getNetClaimValue());
////					}
////					if(sl.getNetClaimQty() !=null) {
////						row.createCell(7).setCellValue(sl.getNetClaimQty());
////					}
////					if(sl.getPromotionAmt() !=null) {
////						row.createCell(8).setCellValue(sl.getPromotionAmt());
////					}
////					if(sl.getClaimAmtPerUnit() !=null) {
////						row.createCell(9).setCellValue(sl.getClaimAmtPerUnit());
////					}
////					if(sl.getClaimPosPrimaryQty() !=null) {
////						row.createCell(10).setCellValue(sl.getClaimPosPrimaryQty());
////					}
////					if(sl.getCustomerClaimMinQty() !=null) {
////						row.createCell(11).setCellValue(sl.getCustomerClaimMinQty());
////					}
////					if(sl.getDiffInCustomerClaims() !=null) {
////						row.createCell(12).setCellValue(sl.getDiffInCustomerClaims());
////					}
////					if(sl.getHulClaim() !=null) {
////						row.createCell(13).setCellValue(sl.getHulClaim());
////					}
////					if(sl.getNetClaims() !=null) {
////						row.createCell(14).setCellValue(sl.getNetClaims());
////					}
////					if(sl.getDiffClaims() !=null) {
////						row.createCell(15).setCellValue(sl.getDiffClaims());
////					}
////					if(sl.getDeductionBucket() !=null) {
////						row.createCell(16).setCellValue(sl.getDeductionBucket());
////					}
////					if(sl.getDeductionAmt() !=null) {
////						row.createCell(17).setCellValue(sl.getDeductionAmt());
////					}
////					
////				
////				}//end of fifth if block
//				
//				
//		}
//
//			workbook.write(out);
//			return new ByteArrayInputStream(out.toByteArray());
//
//		} catch (IOException e) {
//			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
//		}
//	}

	public static ByteArrayInputStream generateRevisedDataToExcel(List<BaseWorking> revisedDataList) {

		try {
			Workbook workbook = new XSSFWorkbook();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Sheet sheet = workbook.createSheet(BASE_WORKING_REVISED_SHEET);


			//CellStyle cellStyle = workbook.createCellStyle();
			/*CreationHelper createHelper = workbook.getCreationHelper();
		cellStyle.setDataFormat(
		createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
			 */
			// Header
			Row headerRow = sheet.createRow(0);


			for (int col = 0; col < BASE_WORKING_REVISED_HEADERS.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(BASE_WORKING_REVISED_HEADERS[col]);
			}


			int rowIdx = 1;
			for (BaseWorking sl : revisedDataList) {
				Row row = sheet.createRow(rowIdx++);
				if(sl.getSolCode() !=null) {
					row.createCell(0).setCellValue(sl.getSolCode());
				}
				if(sl.getBasepack() !=null) {
					row.createCell(1).setCellValue(sl.getBasepack()); 
				}
				if(sl.getArticleCode() !=null) {
					row.createCell(2).setCellValue(sl.getArticleCode());
				}
				if(sl.getSoleCodeDesc() !=null) {
					row.createCell(3).setCellValue(sl.getSoleCodeDesc());
				}
				if(sl.getHulMRP() !=null) {
					row.createCell(4).setCellValue(sl.getHulMRP());
				}
				if(sl.getCustomerMRP() !=null) {
					row.createCell(5).setCellValue(sl.getCustomerMRP());
				}
				if(sl.getNetClaimValueRevised() !=null){
					row.createCell(6).setCellValue(sl.getNetClaimValueRevised());
				}
				else {
					row.createCell(6).setCellValue(sl.getNetClaimValue());
				}
				if(sl.getNetClaimQtyRevised() !=null){
					row.createCell(7).setCellValue(sl.getNetClaimQtyRevised());
				}
				else {
					row.createCell(7).setCellValue(sl.getNetClaimQty());
				}
				if(sl.getPromotionAmtRevised() !=null){
					row.createCell(8).setCellValue(sl.getPromotionAmtRevised());
				}
				else {
					row.createCell(8).setCellValue(" ");
				}
				if(sl.getClaimAmtPerUnitRevised() !=null){
					row.createCell(9).setCellValue(sl.getClaimAmtPerUnitRevised());
				}
				else {
					row.createCell(9).setCellValue(sl.getClaimAmtPerUnit());
				}
				if(sl.getClaimPosPrimaryQtyRevised() !=null){
					row.createCell(10).setCellValue(sl.getClaimPosPrimaryQtyRevised());
				}
				else {
					row.createCell(10).setCellValue(sl.getClaimPosPrimaryQty());
				}
				if(sl.getCustClaimMinQtyRevised() !=null){
					row.createCell(11).setCellValue(sl.getCustClaimMinQtyRevised());
				}
				else {
					row.createCell(11).setCellValue(sl.getCustomerClaimMinQty());
				}
				if(sl.getDiffInCustomerClaimRevised() !=null){

					row.createCell(12).setCellValue(sl.getDiffInCustomerClaimRevised());
				}
				else {
					row.createCell(12).setCellValue(sl.getDiffInCustomerClaims());
				}
				if(sl.getHulClaimRevised() !=null){

					row.createCell(13).setCellValue(sl.getHulClaimRevised());
				}
				else {
					row.createCell(13).setCellValue(sl.getHulClaim());
				}
				if(sl.getNetClaimRevised() !=null){

					row.createCell(14).setCellValue(sl.getNetClaimRevised());
				}
				else {
					row.createCell(14).setCellValue(sl.getNetClaims());
				}
				if(sl.getDiffClaimsRevised() !=null){

					row.createCell(15).setCellValue(sl.getDiffClaimsRevised());
				}
				else {
					row.createCell(15).setCellValue(sl.getDiffClaims());

				}

			}

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());

		} catch (IOException e) {
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}


	//Added By Sarin Jun2021
	public static String getCellValue(Cell currentCellValues) {

		String cellValue = "";
		DataFormatter dfPromoClaim = new DataFormatter();

		if (currentCellValues.getCellType() == CellType.BLANK) {
			cellValue = " ";
		} else if(currentCellValues.getCellType() == CellType.STRING){
			cellValue = currentCellValues.getStringCellValue();
		} else if(currentCellValues.getCellType() == CellType.NUMERIC){
			String colValue = dfPromoClaim.formatCellValue(currentCellValues); 
			cellValue = colValue.replace(",", "");
		} else if (currentCellValues.getCellType() == CellType.FORMULA) {
			switch (currentCellValues.getCachedFormulaResultType()) {
			case NUMERIC:
				cellValue = Double.toString(currentCellValues.getNumericCellValue());
				break;
			case STRING:
				cellValue = currentCellValues.getStringCellValue();
				break;
			default:
				break;
			}
		}

		return cellValue;
	}
		
	//Added By Sarin Jun2021
	public static ByteArrayInputStream generatePromoClaimErrorDataToExcel(List<PromoClaimStageFileValidate> promoClaimErrorList) {
	
		try {
			
			//Workbook workbook = new XSSFWorkbook();
			Workbook workbook = new SXSSFWorkbook(10000);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Sheet sheet = workbook.createSheet("Promo Errors");
			
			int rowIndex = 0; int errorColumn = 0;
			for (PromoClaimStageFileValidate claimError: promoClaimErrorList) {
				
				Row newRow = sheet.createRow(rowIndex++);
				
				if (errorColumn == 0) {
					errorColumn = claimError.getNoOfColumns();
				}
				if (claimError.getColumnA() != null) {
					newRow.createCell(0).setCellValue(claimError.getColumnA());
				}
				if (claimError.getColumnB() != null) {
					newRow.createCell(1).setCellValue(claimError.getColumnB());
				}
				if (claimError.getColumnC() != null) {
					newRow.createCell(2).setCellValue(claimError.getColumnC());
				}
				if (claimError.getColumnD() != null) {
					newRow.createCell(3).setCellValue(claimError.getColumnD());
				}
				if (claimError.getColumnE() != null) {
					newRow.createCell(4).setCellValue(claimError.getColumnE());
				}
				if (claimError.getColumnF() != null) {
					newRow.createCell(5).setCellValue(claimError.getColumnF());
				}
				if (claimError.getColumnG() != null) {
					newRow.createCell(6).setCellValue(claimError.getColumnG());
				}
				if (claimError.getColumnH() != null) {
					newRow.createCell(7).setCellValue(claimError.getColumnH());
				}
				if (claimError.getColumnI() != null) {
					newRow.createCell(8).setCellValue(claimError.getColumnI());
				}
				if (claimError.getColumnJ() != null) {
					newRow.createCell(9).setCellValue(claimError.getColumnJ());
				}
				if (claimError.getColumnK() != null) {
					newRow.createCell(10).setCellValue(claimError.getColumnK());
				}
				if (claimError.getColumnL() != null) {
					newRow.createCell(11).setCellValue(claimError.getColumnL());
				}
				if (claimError.getColumnM() != null) {
					newRow.createCell(12).setCellValue(claimError.getColumnM());
				}
				if (claimError.getColumnN() != null) {
					newRow.createCell(13).setCellValue(claimError.getColumnN());
				}
				if (claimError.getColumnO() != null) {
					newRow.createCell(14).setCellValue(claimError.getColumnO());
				}
				if (claimError.getColumnP() != null) {
					newRow.createCell(15).setCellValue(claimError.getColumnP());
				}
				if (claimError.getColumnQ() != null) {
					newRow.createCell(16).setCellValue(claimError.getColumnQ());
				}
				if (claimError.getColumnR() != null) {
					newRow.createCell(17).setCellValue(claimError.getColumnR());
				}
				if (claimError.getColumnS() != null) {
					newRow.createCell(18).setCellValue(claimError.getColumnS());
				}
				if (claimError.getColumnT() != null) {
					newRow.createCell(19).setCellValue(claimError.getColumnT());
				}
				if (claimError.getColumnU() != null) {
					newRow.createCell(20).setCellValue(claimError.getColumnU());
				}
				if (claimError.getColumnV() != null) {
					newRow.createCell(21).setCellValue(claimError.getColumnV());
				}
				if (claimError.getColumnW() != null) {
					newRow.createCell(22).setCellValue(claimError.getColumnW());
				}
				if (claimError.getColumnX() != null) {
					newRow.createCell(23).setCellValue(claimError.getColumnX());
				}
				if (claimError.getColumnY() != null) {
					newRow.createCell(24).setCellValue(claimError.getColumnY());
				}
				if (claimError.getColumnZ() != null) {
					newRow.createCell(25).setCellValue(claimError.getColumnZ());
				}
				
				if (claimError.getColumnAA() != null) {
					newRow.createCell(26).setCellValue(claimError.getColumnAA());
				}
				if (claimError.getColumnAB() != null) {
					newRow.createCell(27).setCellValue(claimError.getColumnAB());
				}
				if (claimError.getColumnAC() != null) {
					newRow.createCell(28).setCellValue(claimError.getColumnAC());
				}
				if (claimError.getColumnAD() != null) {
					newRow.createCell(29).setCellValue(claimError.getColumnAD());
				}
				if (claimError.getColumnAE() != null) {
					newRow.createCell(30).setCellValue(claimError.getColumnAE());
				}
				if (claimError.getColumnAF() != null) {
					newRow.createCell(31).setCellValue(claimError.getColumnAF());
				}
				if (claimError.getColumnAG() != null) {
					newRow.createCell(32).setCellValue(claimError.getColumnAG());
				}
				if (claimError.getColumnAH() != null) {
					newRow.createCell(33).setCellValue(claimError.getColumnAH());
				}
				if (claimError.getColumnAI() != null) {
					newRow.createCell(34).setCellValue(claimError.getColumnAI());
				}
				if (claimError.getColumnAJ() != null) {
					newRow.createCell(35).setCellValue(claimError.getColumnAJ());
				}
				if (claimError.getColumnAK() != null) {
					newRow.createCell(36).setCellValue(claimError.getColumnAK());
				}
				if (claimError.getColumnAL() != null) {
					newRow.createCell(37).setCellValue(claimError.getColumnAL());
				}
				if (claimError.getColumnAM() != null) {
					newRow.createCell(38).setCellValue(claimError.getColumnAM());
				}
				if (claimError.getColumnAN() != null) {
					newRow.createCell(39).setCellValue(claimError.getColumnAN());
				}
				if (claimError.getColumnAO() != null) {
					newRow.createCell(40).setCellValue(claimError.getColumnAO());
				}
				if (claimError.getColumnAP() != null) {
					newRow.createCell(41).setCellValue(claimError.getColumnAP());
				}
				if (claimError.getColumnAQ() != null) {
					newRow.createCell(42).setCellValue(claimError.getColumnAQ());
				}
				if (claimError.getColumnAR() != null) {
					newRow.createCell(43).setCellValue(claimError.getColumnAR());
				}
				if (claimError.getColumnAS() != null) {
					newRow.createCell(44).setCellValue(claimError.getColumnAS());
				}
				if (claimError.getColumnAT() != null) {
					newRow.createCell(45).setCellValue(claimError.getColumnAT());
				}
				if (claimError.getColumnAU() != null) {
					newRow.createCell(46).setCellValue(claimError.getColumnAU());
				}
				if (claimError.getColumnAV() != null) {
					newRow.createCell(47).setCellValue(claimError.getColumnAV());
				}
				if (claimError.getColumnAW() != null) {
					newRow.createCell(48).setCellValue(claimError.getColumnAW());
				}
				if (claimError.getColumnAX() != null) {
					newRow.createCell(49).setCellValue(claimError.getColumnAX());
				}
				if (claimError.getColumnAY() != null) {
					newRow.createCell(50).setCellValue(claimError.getColumnAY());
				}
				if (claimError.getColumnAZ() != null) {
					newRow.createCell(51).setCellValue(claimError.getColumnAZ());
				}
				if (rowIndex == 1) {
					newRow.createCell(errorColumn).setCellValue("Error Msg");
				} else {
					newRow.createCell(errorColumn).setCellValue(claimError.getErrorMsg());
				}
				
			}
			
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
			
		} catch (IOException e) {
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}

	//Added By Sarin Jun2021
	public static ByteArrayInputStream generatePromoClaimMultiSOLCodeDataToExcel(List<String> multiSOLCodeList) {

		try {
			Workbook workbook = new XSSFWorkbook();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Sheet sheet = workbook.createSheet("Promo Claim Multi SOLCode");

			Row headerRow = sheet.createRow(0);
			if (multiSOLCodeList.size() > 0) {
				for (int hCol = 0; hCol < PROMO_CLAIM_MULTI_SOL_CODES_HEADERS.length; hCol++) {
					Cell cell = headerRow.createCell(hCol);
					cell.setCellValue(PROMO_CLAIM_MULTI_SOL_CODES_HEADERS[hCol]);
				}
				
				int rowIndex = 1;
				for (String multiSOLCode: multiSOLCodeList) {
					Row newRow = sheet.createRow(rowIndex++);
					newRow.createCell(0).setCellValue(multiSOLCode);
					newRow.createCell(1).setCellValue("");
					newRow.createCell(2).setCellValue("");
				}
			} else {
				headerRow.createCell(0).setCellValue("No Data Available with Multi SOL Codes");
			}
			
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());

		} catch (IOException e) {
			throw new RuntimeException("fail to download Excel file: " + e.getMessage());
		}
	}
	
	//Added By Sarin Jun2021
	public static List<PromoClaimMultiSOLCodeStage> excelToPromoClaimMultiSOLCodeStage(InputStream is, String accountName, String moc) {
		
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(is); 
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> rows = datatypeSheet.iterator();

			List<PromoClaimMultiSOLCodeStage> promoClaimMultiSOLCodeStageList = new ArrayList<PromoClaimMultiSOLCodeStage>();

			int rowNumber = 0;
			while (rows.hasNext()) {

				Row currentRow = rows.next();

				// skip header
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}

				Iterator<Cell> cellsInRow = currentRow.iterator();
				PromoClaimMultiSOLCodeStage promoClaimMultiSOLStage = new PromoClaimMultiSOLCodeStage();
				int cellIdx = 0;
				
				while (cellsInRow.hasNext()) {
					Cell currentCell = cellsInRow.next();
					cellIdx = currentCell.getColumnIndex();

					switch (cellIdx) {
						case 0:
							promoClaimMultiSOLStage.setSolCode(getCellValue(currentCell));
							break;
						case 1:
							promoClaimMultiSOLStage.setPromotionUnit(getCellValue(currentCell));
							break;
						case 2:
							promoClaimMultiSOLStage.setPromotionAmount(getCellValue(currentCell));
							break;
						default:
							break;
					}
				}//end of  inner while
				promoClaimMultiSOLStage.setAccountName(accountName);
				promoClaimMultiSOLStage.setMoc(moc);
				promoClaimMultiSOLStage.setLoadDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
				promoClaimMultiSOLCodeStageList.add(promoClaimMultiSOLStage);
			}//end of while
			workbook.close();
			return promoClaimMultiSOLCodeStageList;

		}catch(IOException e){
			e.printStackTrace();
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}
	}
	
	//Added By Harsha Aug2021 - Excel file validation for Claim file - Starts
	
	public static List<PosDataStage> excelToPosDataStageLargeFile(InputStream inputStream) throws FileNotFoundException, IOException {
		List<PosDataStage> posDataStageList = new ArrayList<PosDataStage>();
		try (StreamingReader reader = StreamingReader.builder().rowCacheSize(200).bufferSize(40960).sheetIndex(0)
				.read(inputStream);) {
			int totalColumns=52;

			for (Row r1 : reader) {
				//posDataStage posDataStage = new posDataStage();
				PosDataStage posDataStage = new PosDataStage();

				if(r1.getRowNum()>0) {

					for (int i=0; i<totalColumns; i++) {
						Cell cell = r1.getCell(i);
						if (cell != null) {
							if(i==0) {
								posDataStage.setColumnA(cell.getStringCellValue().trim().trim());
							}

							if(i==1) {
								posDataStage.setColumnB(cell.getStringCellValue().trim());
							}
							if(i==2) {
								posDataStage.setColumnC(cell.getStringCellValue().trim());
							}
							if(i==3) {
								posDataStage.setColumnD(cell.getStringCellValue().trim());
							}
							if(i==4) {
								posDataStage.setColumnE(cell.getStringCellValue().trim());
							}
							if(i==5) {
								posDataStage.setColumnF(cell.getStringCellValue().trim());
							}
							if(i==6) {
								posDataStage.setColumnG(cell.getStringCellValue().trim());
							}
							if(i==7) {
								posDataStage.setColumnH(cell.getStringCellValue().trim());
							}
							if(i==8) {
								posDataStage.setColumnI(cell.getStringCellValue().trim());
							}
							if(i==9) {
								posDataStage.setColumnJ(cell.getStringCellValue().trim());
							}
							if(i==10) {
								posDataStage.setColumnK(cell.getStringCellValue().trim());
							}
							if(i==11) {
								posDataStage.setColumnL(cell.getStringCellValue().trim());
							}
							if(i==12) {
								posDataStage.setColumnM(cell.getStringCellValue().trim());
							}
							if(i==13) {
								posDataStage.setColumnN(cell.getStringCellValue().trim());
							}
							if(i==14) {
								posDataStage.setColumnO(cell.getStringCellValue().trim());
							}
							if(i==15) {
								posDataStage.setColumnP(cell.getStringCellValue().trim());
							}
							if(i==16) {
								posDataStage.setColumnQ(cell.getStringCellValue().trim());
							}

							if(i==17) {
								posDataStage.setColumnR(cell.getStringCellValue().trim());
							}

							if(i==18) {
								posDataStage.setColumnS(cell.getStringCellValue().trim());
							}
							if(i==19) {
								posDataStage.setColumnT(cell.getStringCellValue().trim());
							}
							if(i==20) {
								posDataStage.setColumnU(cell.getStringCellValue().trim());
							}
							if(i==21) {
								posDataStage.setColumnV(cell.getStringCellValue().trim());
							}
							if(i==22) {
								posDataStage.setColumnW(cell.getStringCellValue().trim());
							}
							if(i==23) {
								posDataStage.setColumnX(cell.getStringCellValue().trim());
							}
							if(i==24) {
								posDataStage.setColumnY(cell.getStringCellValue().trim());
							}
							if(i==25) {
								posDataStage.setColumnZ(cell.getStringCellValue().trim());
							}
							if(i==26) {
								posDataStage.setColumnAA(cell.getStringCellValue().trim());
							}
							if(i==27) {
								posDataStage.setColumnAB(cell.getStringCellValue().trim());
							}
							if(i==28) {
								posDataStage.setColumnAC(cell.getStringCellValue().trim());
							}
							if(i==29) {
								posDataStage.setColumnAD(cell.getStringCellValue().trim());
							}
							if(i==30) {
								posDataStage.setColumnAE(cell.getStringCellValue().trim());
							}
							if(i==31) {
								posDataStage.setColumnAF(cell.getStringCellValue().trim());
							}
							if(i==32) {
								posDataStage.setColumnAG(cell.getStringCellValue().trim());
							}
							if(i==33) {
								posDataStage.setColumnAH(cell.getStringCellValue().trim());
							}
							if(i==34) {
								posDataStage.setColumnAI(cell.getStringCellValue().trim());
							}

							if(i==35) {
								posDataStage.setColumnAJ(cell.getStringCellValue().trim());
							}
							if(i==36) {
								posDataStage.setColumnAK(cell.getStringCellValue().trim());
							}
							if(i==37) {
								posDataStage.setColumnAL(cell.getStringCellValue().trim());
							}
							if(i==38) {
								posDataStage.setColumnAM(cell.getStringCellValue().trim());
							}
							if(i==39) {
								posDataStage.setColumnAN(cell.getStringCellValue().trim());
							}
							if(i==40) {
								posDataStage.setColumnAO(cell.getStringCellValue().trim());
							}
							if(i==42) {
								posDataStage.setColumnAP(cell.getStringCellValue().trim());
							}
							if(i==42) {
								posDataStage.setColumnAQ(cell.getStringCellValue().trim());
							}
							if(i==43) {
								posDataStage.setColumnAR(cell.getStringCellValue().trim());
							}
							if(i==44) {
								posDataStage.setColumnAS(cell.getStringCellValue().trim());
							}
							if(i==45) {
								posDataStage.setColumnAT(cell.getStringCellValue().trim());
							}
							if(i==46) {
								posDataStage.setColumnAU(cell.getStringCellValue().trim());
							}
							if(i==47) {
								posDataStage.setColumnAV(cell.getStringCellValue().trim());
							}
							if(i==48) {
								posDataStage.setColumnAW(cell.getStringCellValue().trim());
							}
							if(i==49) {
								posDataStage.setColumnAX(cell.getStringCellValue().trim());
							}
							if(i==50) {
								posDataStage.setColumnAY(cell.getStringCellValue().trim());
							}
							if(i==51) {
								posDataStage.setColumnAZ(cell.getStringCellValue().trim());
							}

						}  

						posDataStageList.add(posDataStage);}

				}
			}

		}   


		return posDataStageList;

	}

	public static List<PromoClaimStage> excelTopromoClaimStageLargeFile(InputStream inputStream) throws FileNotFoundException, IOException {
		List<PromoClaimStage> promoClaimStageList = new ArrayList<PromoClaimStage>();

		//try (StreamingReader reader = StreamingReader.builder().rowCacheSize(10).bufferSize(4096).sheetIndex(0)
		try (StreamingReader reader = StreamingReader.builder().rowCacheSize(200).bufferSize(40960).sheetIndex(0)
				.read(inputStream);) {
			int totalColumns=52; boolean isRecordExits = false; int colCount = 0;

			for (Row r1 : reader) {
				PromoClaimStage promoClaimStage = new PromoClaimStage();
				if(r1.getRowNum() >= 0) {
					isRecordExits = false;
					for (int i=0; i<totalColumns; i++) {
						Cell cell = r1.getCell(i);
						if ((r1.getRowNum() == 0) && (cell != null) ) {
							colCount++;  //To get column count in excel
						}
						if (cell != null) {
							isRecordExits = true;
							if(i==0) {
								promoClaimStage.setColumnA(cell.getStringCellValue());
							}

							if(i==1) {
								promoClaimStage.setColumnB(cell.getStringCellValue());
							}
							if(i==2) {
								promoClaimStage.setColumnC(cell.getStringCellValue());
							}
							if(i==3) {
								promoClaimStage.setColumnD(cell.getStringCellValue());
							}
							if(i==4) {
								promoClaimStage.setColumnE(cell.getStringCellValue());
							}
							if(i==5) {
								promoClaimStage.setColumnF(cell.getStringCellValue());
							}
							if(i==6) {
								promoClaimStage.setColumnG(cell.getStringCellValue());
							}
							if(i==7) {
								promoClaimStage.setColumnH(cell.getStringCellValue());
							}
							if(i==8) {
								promoClaimStage.setColumnI(cell.getStringCellValue());
							}
							if(i==9) {
								promoClaimStage.setColumnJ(cell.getStringCellValue());
							}
							if(i==10) {
								promoClaimStage.setColumnK(cell.getStringCellValue());
							}
							if(i==11) {
								promoClaimStage.setColumnL(cell.getStringCellValue());
							}
							if(i==12) {
								promoClaimStage.setColumnM(cell.getStringCellValue());
							}
							if(i==13) {
								promoClaimStage.setColumnN(cell.getStringCellValue());
							}
							if(i==14) {
								promoClaimStage.setColumnO(cell.getStringCellValue());
							}
							if(i==15) {
								promoClaimStage.setColumnP(cell.getStringCellValue());
							}
							if(i==16) {
								promoClaimStage.setColumnQ(cell.getStringCellValue());
							}

							if(i==17) {
								promoClaimStage.setColumnR(cell.getStringCellValue());
							}

							if(i==18) {
								promoClaimStage.setColumnS(cell.getStringCellValue());
							}
							if(i==19) {
								promoClaimStage.setColumnT(cell.getStringCellValue());
							}
							if(i==20) {
								promoClaimStage.setColumnU(cell.getStringCellValue());
							}
							if(i==21) {
								promoClaimStage.setColumnV(cell.getStringCellValue());
							}
							if(i==22) {
								promoClaimStage.setColumnW(cell.getStringCellValue());
							}
							if(i==23) {
								promoClaimStage.setColumnX(cell.getStringCellValue());
							}
							if(i==24) {
								promoClaimStage.setColumnY(cell.getStringCellValue());
							}
							if(i==25) {
								promoClaimStage.setColumnZ(cell.getStringCellValue());
							}
							if(i==26) {
								promoClaimStage.setColumnAA(cell.getStringCellValue());
							}
							if(i==27) {
								promoClaimStage.setColumnAB(cell.getStringCellValue());
							}
							if(i==28) {
								promoClaimStage.setColumnAC(cell.getStringCellValue());
							}
							if(i==29) {
								promoClaimStage.setColumnAD(cell.getStringCellValue());
							}
							if(i==30) {
								promoClaimStage.setColumnAE(cell.getStringCellValue());
							}
							if(i==31) {
								promoClaimStage.setColumnAF(cell.getStringCellValue());
							}
							if(i==32) {
								promoClaimStage.setColumnAG(cell.getStringCellValue());
							}
							if(i==33) {
								promoClaimStage.setColumnAH(cell.getStringCellValue());
							}
							if(i==34) {
								promoClaimStage.setColumnAI(cell.getStringCellValue());
							}

							if(i==35) {
								promoClaimStage.setColumnAJ(cell.getStringCellValue());
							}
							if(i==36) {
								promoClaimStage.setColumnAK(cell.getStringCellValue());
							}
							if(i==37) {
								promoClaimStage.setColumnAL(cell.getStringCellValue());
							}
							if(i==38) {
								promoClaimStage.setColumnAM(cell.getStringCellValue());
							}
							if(i==39) {
								promoClaimStage.setColumnAN(cell.getStringCellValue());
							}
							if(i==40) {
								promoClaimStage.setColumnAO(cell.getStringCellValue());
							}
							if(i==42) {
								promoClaimStage.setColumnAP(cell.getStringCellValue());
							}
							if(i==42) {
								promoClaimStage.setColumnAQ(cell.getStringCellValue());
							}
							if(i==43) {
								promoClaimStage.setColumnAR(cell.getStringCellValue());
							}
							if(i==44) {
								promoClaimStage.setColumnAS(cell.getStringCellValue());
							}
							if(i==45) {
								promoClaimStage.setColumnAT(cell.getStringCellValue());
							}
							if(i==46) {
								promoClaimStage.setColumnAU(cell.getStringCellValue());
							}
							if(i==47) {
								promoClaimStage.setColumnAV(cell.getStringCellValue());
							}
							if(i==48) {
								promoClaimStage.setColumnAW(cell.getStringCellValue());
							}
							if(i==49) {
								promoClaimStage.setColumnAX(cell.getStringCellValue());
							}
							if(i==50) {
								promoClaimStage.setColumnAY(cell.getStringCellValue());
							}
							if(i==51) {
								promoClaimStage.setColumnAZ(cell.getStringCellValue());
							}
						}
						
					}
					promoClaimStage.setNoOfColumns(colCount);
					if (isRecordExits) {
						promoClaimStageList.add(promoClaimStage);
					}
				}
			}
		}   

		return promoClaimStageList;
	}

	//Added By Harsha Aug2021 - Excel file validation for Claim file - Ends
	
}
