package com.unilever.promo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.asset.kam.model.CurrentMocViewDto;
import com.unilever.asset.kam.model.PreviousMocViewDto;
import com.unilever.asset.kam.service.KamAssetService;
import com.unilever.promo.kam.model.CurrentMocPromoViewDto;
import com.unilever.promo.kam.model.NextMocPromoViewDto;
import com.unilever.promo.kam.model.PreviousMocPromoViewDto;
import com.unilever.promo.kam.service.KamPromoService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class KamPromoController {
	
	@Autowired
	KamPromoService kamPromoService;

	//======================================= Current MOC View==================================================

		@GetMapping("/getPromoCurrentMocView")
		public List<CurrentMocPromoViewDto> getPromoCurrentMocView(@RequestParam("region") List<String> region,@RequestParam("accounts") List<String> accounts,
													  @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
													  @RequestParam(defaultValue = "10") Integer pageSize){
			
	    List<CurrentMocPromoViewDto> currentPromoMocViewDetails = new ArrayList<>();
			
			try{
				 	currentPromoMocViewDetails = kamPromoService.getPromoCurrentMocView(region,accounts,moc,category,pageNo,pageSize);
				
			    }
			catch(Exception e){
				e.printStackTrace();
			}
			return currentPromoMocViewDetails;

		}

		



		//======================================= Previous MOC View==================================================
		@GetMapping("/getPromoPreviousMocView")
		public List<PreviousMocPromoViewDto> getPromoPreviousMocView(@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			    @RequestParam(defaultValue = "10") Integer pageSize){

			List<PreviousMocPromoViewDto> previousPromoMocDetails = new ArrayList<>();
			try{
				
					previousPromoMocDetails = kamPromoService.getPromoPreviousMocView(region,accounts, moc, category,pageNo,pageSize);
			
			   }
			catch(Exception e){
				e.printStackTrace();
			}
			return previousPromoMocDetails;

		}
		
		//======================================= Next MOC View==================================================
				@GetMapping("/getPromoNextMocView")
				public List<NextMocPromoViewDto> getPromoNextMocView(@RequestParam("username") String username,@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
					    @RequestParam(defaultValue = "10") Integer pageSize){

					List<NextMocPromoViewDto> nextPromoMocDetails = new ArrayList<>();
					try{
						
						nextPromoMocDetails = kamPromoService.getPromoNextMocView(username,region,accounts, moc, category,pageNo,pageSize);
					
					   }
					catch(Exception e){
						e.printStackTrace();
					}
					return nextPromoMocDetails;

				}
		
		
}
