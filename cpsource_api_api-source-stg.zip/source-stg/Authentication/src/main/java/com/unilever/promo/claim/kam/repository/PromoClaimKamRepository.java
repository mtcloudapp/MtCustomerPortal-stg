package com.unilever.promo.claim.kam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.BaseWorking;

@Repository
public interface PromoClaimKamRepository extends JpaRepository<BaseWorking, Integer>{
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".BASE_WORKING  pcfm set pcfm.SOL_CODE_REVISED=:solcodeRevised  where "
			+ "pcfm.SOL_CODE=:solcode and pcfm.ARTICLE_CODE=:articleCode and pcfm.BASEPACK=:basepack", nativeQuery = true)
	void updateNoSolCodeByKam(@Param("solcodeRevised") Integer solcodeRevised,@Param("solcode") Integer solcode,@Param("articleCode") Integer articleCode,@Param("basepack") Integer basepack);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".BASE_WORKING  pcfm set pcfm.BASEPACK_REVISED=:basepackRevised  where "
			+ "pcfm.SOL_CODE=:solcode and pcfm.ARTICLE_CODE=:articleCode and pcfm.BASEPACK=:basepack", nativeQuery = true)
	void updateNoBasepackByKam(@Param("basepackRevised") Integer basepackRevised,@Param("solcode") Integer solcode,@Param("articleCode") Integer articleCode,@Param("basepack") Integer basepack);


}
