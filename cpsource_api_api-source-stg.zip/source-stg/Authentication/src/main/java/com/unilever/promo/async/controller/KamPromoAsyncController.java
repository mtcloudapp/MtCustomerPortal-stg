package com.unilever.promo.async.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.claims.asyncs.service.AssetClaimAsyncsService;
import com.unilever.claims.kam.model.ApprovedExceptionClaimValue;
import com.unilever.claims.kam.model.ApprovedExceptionClaimVolume;
import com.unilever.claims.kam.model.AssetClaimsJsonObj;
import com.unilever.claims.kam.model.GreenClaimValue;
import com.unilever.claims.kam.model.GreenClaimVolume;
import com.unilever.claims.kam.model.RedClaimValue;
import com.unilever.claims.kam.model.RedClaimVolume;
import com.unilever.claims.kam.model.TotalAmountPayable;
import com.unilever.claims.kam.model.TotalAmountPlanned;
import com.unilever.promo.async.service.KamPromoAsyncService;
import com.unilever.promo.kam.model.KamNoOfPromotion;
import com.unilever.promo.kam.model.KamSolCodeReleased;
import com.unilever.promo.kam.model.KamTotalPlannedBudget;
import com.unilever.promo.kam.model.KamTotalPlannedPromVolume;
import com.unilever.promo.kam.model.KamTotalPlannedPromoValue;
import com.unilever.promo.kam.model.KamTotalUtilizedValue;
import com.unilever.promo.kam.model.KamTotalUtilizedVolume;
import com.unilever.promo.kam.model.KamUtilizedBudget;
import com.unilever.promo.kam.model.PromoJsonObj;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class KamPromoAsyncController {
	
	private static Logger log = LoggerFactory.getLogger(KamPromoAsyncController.class);
	
	@Autowired
	private KamPromoAsyncService kamPromoAsyncService;
	
	
	@GetMapping("/getKamCurrentMocPromoData")
	public String getKamCurrentMocPromoData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			
			CompletableFuture<Integer> noOfPromotion = kamPromoAsyncService.getNoOfPromotion(username, region, account, moc, category);
			CompletableFuture<Integer> solCodeReleased = kamPromoAsyncService.getSolCodeRealeased(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedBudget> totalPlannedBudget = kamPromoAsyncService.getTotalPlannedBudget(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedPromoValue> totalPlannedPromoValue = kamPromoAsyncService.getTotalPlannedPromoValue(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedPromVolume> totalPlannedPromoVolume = kamPromoAsyncService.getTotalPlannedPromoVolume(username, region, account, moc, category);
			CompletableFuture<KamTotalUtilizedValue> totalUtilizedValue = kamPromoAsyncService.getTotalUtilizedValue(username, region, account, moc, category);
			CompletableFuture<KamTotalUtilizedVolume> totalUtilizedVolume = kamPromoAsyncService.getTotalUtilizedVolume(username, region, account, moc, category);
			CompletableFuture<KamUtilizedBudget> utilizedBudget = kamPromoAsyncService.getUtilizedBudget(username, region, account, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfPromotion,solCodeReleased,totalPlannedBudget,totalPlannedPromoValue,totalPlannedPromoVolume,totalUtilizedValue,totalUtilizedVolume,utilizedBudget).join();

			log.info("noOfPromotion--> " + noOfPromotion.get());
			log.info("solCodeReleased--> " + solCodeReleased.get());
			log.info("totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("totalPlannedPromoValue--> " + totalPlannedPromoValue.get());
			log.info("totalPlannedPromoVolume--> " + totalPlannedPromoVolume.get());
			log.info("totalUtilizedValue--> " + totalUtilizedValue.get());
			log.info("totalUtilizedVolume--> " + totalUtilizedVolume.get());
			log.info("utilizedBudget--> " + utilizedBudget.get());
			
			PromoJsonObj obj = new PromoJsonObj();
			Gson gson = new Gson();

			obj.setNoOfPromotion(noOfPromotion.get().intValue());
			obj.setSolCodeReleased(solCodeReleased.get().intValue());
			obj.setTotalPlannedBudget(totalPlannedBudget.get().getTotalPlannedBudget());
			obj.setTotalPlannedPromoValue(totalPlannedPromoValue.get().getTotalPlannedPromoValue());
			obj.setTotalPlannedPromoVolume(totalPlannedPromoVolume.get().getTotalPlannedPromoVolume());
			obj.setTotalUtilizedValue(totalUtilizedValue.get().getTotalUtilizedValue());
			obj.setTotalUtilizedVolume(totalUtilizedVolume.get().getTotalUtilizedVolume());
			obj.setUtilizedBudget(utilizedBudget.get().getUtilizedBudget());
		
			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}


	
	@GetMapping("/getKamPreviousMocPromoData")
	public String getKamPreviousMocPromoData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			
			CompletableFuture<Integer> noOfPromotion = kamPromoAsyncService.getNoOfPromotion(username, region, account, moc, category);
			CompletableFuture<Integer> solCodeReleased = kamPromoAsyncService.getSolCodeRealeased(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedBudget> totalPlannedBudget = kamPromoAsyncService.getTotalPlannedBudget(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedPromoValue> totalPlannedPromoValue = kamPromoAsyncService.getTotalPlannedPromoValue(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedPromVolume> totalPlannedPromoVolume = kamPromoAsyncService.getTotalPlannedPromoVolume(username, region, account, moc, category);
			CompletableFuture<KamTotalUtilizedValue> totalUtilizedValue = kamPromoAsyncService.getTotalUtilizedValue(username, region, account, moc, category);
			CompletableFuture<KamTotalUtilizedVolume> totalUtilizedVolume = kamPromoAsyncService.getTotalUtilizedVolume(username, region, account, moc, category);
			CompletableFuture<KamUtilizedBudget> utilizedBudget = kamPromoAsyncService.getUtilizedBudget(username, region, account, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfPromotion,solCodeReleased,totalPlannedBudget,totalPlannedPromoValue,totalPlannedPromoVolume,totalUtilizedValue,totalUtilizedVolume,utilizedBudget).join();

			log.info("noOfPromotion--> " + noOfPromotion.get());
			log.info("solCodeReleased--> " + solCodeReleased.get());
			log.info("totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("totalPlannedPromoValue--> " + totalPlannedPromoValue.get());
			log.info("totalPlannedPromoVolume--> " + totalPlannedPromoVolume.get());
			log.info("totalUtilizedValue--> " + totalUtilizedValue.get());
			log.info("totalUtilizedVolume--> " + totalUtilizedVolume.get());
			log.info("utilizedBudget--> " + utilizedBudget.get());
			
			PromoJsonObj obj = new PromoJsonObj();
			Gson gson = new Gson();

			obj.setNoOfPromotion(noOfPromotion.get().intValue());
			obj.setSolCodeReleased(solCodeReleased.get().intValue());
			obj.setTotalPlannedBudget(totalPlannedBudget.get().getTotalPlannedBudget());
			obj.setTotalPlannedPromoValue(totalPlannedPromoValue.get().getTotalPlannedPromoValue());
			obj.setTotalPlannedPromoVolume(totalPlannedPromoVolume.get().getTotalPlannedPromoVolume());
			obj.setTotalUtilizedValue(totalUtilizedValue.get().getTotalUtilizedValue());
			obj.setTotalUtilizedVolume(totalUtilizedVolume.get().getTotalUtilizedVolume());
			obj.setUtilizedBudget(utilizedBudget.get().getUtilizedBudget());
		
			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}



	@GetMapping("/getKamNextMocPromoData")
	public String getKamNextMocPromoData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			
			CompletableFuture<Integer> noOfPromotion = kamPromoAsyncService.getNoOfPromotion(username, region, account, moc, category);
			CompletableFuture<Integer> solCodeReleased = kamPromoAsyncService.getSolCodeRealeased(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedBudget> totalPlannedBudget = kamPromoAsyncService.getTotalPlannedBudget(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedPromoValue> totalPlannedPromoValue = kamPromoAsyncService.getTotalPlannedPromoValue(username, region, account, moc, category);
			CompletableFuture<KamTotalPlannedPromVolume> totalPlannedPromoVolume = kamPromoAsyncService.getTotalPlannedPromoVolume(username, region, account, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfPromotion,solCodeReleased,totalPlannedBudget,totalPlannedPromoValue,totalPlannedPromoVolume).join();

			log.info("noOfPromotion--> " + noOfPromotion.get());
			log.info("solCodeReleased--> " + solCodeReleased.get());
			log.info("totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("totalPlannedPromoValue--> " + totalPlannedPromoValue.get());
			log.info("totalPlannedPromoVolume--> " + totalPlannedPromoVolume.get());
			
			
			PromoJsonObj obj = new PromoJsonObj();
			Gson gson = new Gson();

			obj.setNoOfPromotion(noOfPromotion.get().intValue());
			obj.setSolCodeReleased(solCodeReleased.get().intValue());
			obj.setTotalPlannedBudget(totalPlannedBudget.get().getTotalPlannedBudget());
			obj.setTotalPlannedPromoValue(totalPlannedPromoValue.get().getTotalPlannedPromoValue());
			obj.setTotalPlannedPromoVolume(totalPlannedPromoVolume.get().getTotalPlannedPromoVolume());
		
			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}


















}
