package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.DepotConnectedAssetVolumeNext;
import com.unilever.global.GlobalVariables;

@Repository
public interface DepotConectedAssetVolumeNextRepository extends JpaRepository<DepotConnectedAssetVolumeNext, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPOT_CONNECTED_ASSETS_VOLUME_NEXT tav where tav.USERNAME=:username", nativeQuery = true)
	List<DepotConnectedAssetVolumeNext> findAllDepotConnectdAssetVolume(@Param("username") String username);
	
}
