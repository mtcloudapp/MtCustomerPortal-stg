package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.global.GlobalVariables;

public interface PlannedAssetValueRepository extends JpaRepository<PlannedAssetValue, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValue(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValueByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValueByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValueByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValueByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValueByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValueByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<PlannedAssetValue> findAllPlannedAssetValueByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);


	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueDetails();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where  tac.MOC=:moc", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_PLANNED_ASSETS_VALUE tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<PlannedAssetValue> findAllPlannedAssetValueByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		











}
