package com.unilever.promo.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.external.model.ExtenalTotalUtilizeVolume;

@Repository
public interface ExternalTotalUtilizedVolumeRepository extends JpaRepository<ExtenalTotalUtilizeVolume, Integer>{

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_TOTAL_UTILIZED_VOLUME etas where etas.USERNAME=:username", nativeQuery = true)
	List<ExtenalTotalUtilizeVolume> findAllTotalUtilizedVolume(@Param("username") String username);
	

}
