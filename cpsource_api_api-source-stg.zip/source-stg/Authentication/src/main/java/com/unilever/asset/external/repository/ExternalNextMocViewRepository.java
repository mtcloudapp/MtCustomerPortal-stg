package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.ExternalNextMocView;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.global.GlobalVariables;

@Repository
public interface ExternalNextMocViewRepository extends PagingAndSortingRepository<ExternalNextMocView, Integer>{

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC ecn  where ecn.MOC=:moc and ecn.ACCOUNT=:account", nativeQuery = true)
	List<ExternalNextMocView> findExtrnalNextMocView(@Param("moc") String moc,@Param("account") String account);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account", nativeQuery = true)
	Page<ExternalNextMocView> findExtrnalNextMocViewByAccount(@Param("moc") List<String> moc,@Param("account") String account,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account", nativeQuery = true)
	Page<ExternalNextMocView> findExtrnalNextMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") String account,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.CATEGORY in :category", nativeQuery = true)
	Page<ExternalNextMocView> findExtrnalNextMocViewByMocCategoryAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.REGION in :region", nativeQuery = true)
	Page<ExternalNextMocView> findExtrnalNextMocViewByMocRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("region") List<String> region,Pageable pageable);

	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC ecn  where ecn.MOC in :moc and ecn.ACCOUNT=:account and ecn.CATEGORY in :category and ecn.REGION in :region", nativeQuery = true)
	Page<ExternalNextMocView> findExtrnalNextMocViewByMocCategoryRegionAccount(@Param("moc") List<String> moc,@Param("account") String account,@Param("category") List<String> category,@Param("region") List<String> region,Pageable pageable);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC icm where icm.MOC in :moc and icm.ACCOUNT=:account", nativeQuery = true)
	List<ExternalNextMocView> findCountByMoc(@Param("moc") List<String> moc,@Param("account") String account);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC icm where icm.MOC in :moc and icm.CATEGORY in :category and icm.ACCOUNT=:account", nativeQuery = true)
	List<ExternalNextMocView> findCountByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,@Param("account") String account);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC icm where icm.MOC in :moc and icm.REGION in :region and icm.ACCOUNT=:account", nativeQuery = true)
	List<ExternalNextMocView> findCountByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("account") String account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_EXT_NEXT_MOC icm  where icm.MOC in :moc and icm.REGION in :region and icm.CATEGORY in :category and icm.ACCOUNT=:account", nativeQuery = true)
	List<ExternalNextMocView> findAllCountNextMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,@Param("account") String account);
	
	
	

}
