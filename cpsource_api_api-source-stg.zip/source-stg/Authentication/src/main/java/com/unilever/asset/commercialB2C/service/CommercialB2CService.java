package com.unilever.asset.commercialB2C.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.unilever.asset.commercialB2C.model.CommB2CCompliedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CCompliedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDeployedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CDeployedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValueNext;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetVolumeNext;
import com.unilever.asset.commercialB2C.model.CommB2CNotCompliedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CNotCompliedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalCount;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalValue;
import com.unilever.asset.commercialB2C.model.CommB2CTotalaAssetCreatedValue;
import com.unilever.asset.commercialB2C.model.CommB2CTotalaAssetCreatedVolume;
import com.unilever.asset.commercialB2C.model.CurrentMocCommB2CView;
import com.unilever.asset.commercialB2C.model.CurrentMocCommB2CViewDto;
import com.unilever.asset.commercialB2C.model.NextMocCommB2CView;
import com.unilever.asset.commercialB2C.model.NextMocCommB2CViewDto;
import com.unilever.asset.commercialB2C.model.PreviousMocCommB2CView;
import com.unilever.asset.commercialB2C.model.PreviousMocCommB2CViewDto;
import com.unilever.asset.commercialB2C.repository.CommB2CCompliedAssetValueReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CCompliedAssetVolumeReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CDeployedAssetValueReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CDeployedAssetVolumeReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CDepotConnectedAssetValueNextReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CDepotConnectedAssetValueReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CDepotConnectedAssetVolumeNextReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CDepotConnectedAssetVolumeReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CNotCompliedAssetValueReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CNotCompliedAssetVolumeReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CPlannedAssetValueReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CPlannedAssetVolumeReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CStoreListTotalCountReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CStoreListTotalValueReposiory;
import com.unilever.asset.commercialB2C.repository.CommB2CTotalAssetCreatedValueRepository;
import com.unilever.asset.commercialB2C.repository.CommB2CTotalAssetCreatedVolumeRepository;
import com.unilever.asset.commercialB2C.repository.CurrentMocCommB2CViewRepository;
import com.unilever.asset.commercialB2C.repository.NextMocCommB2CViewRepository;
import com.unilever.asset.commercialB2C.repository.PreviousMocCommB2CViewRepository;
import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.NextMocView;
import com.unilever.asset.kam.model.PreviousMocView;
import com.unilever.asset.kam.repository.CompliedAssetValueRepository;
import com.unilever.asset.kam.repository.CompliedAssetVolumeRepository;
import com.unilever.asset.kam.repository.CurrentMocViewRepository;
import com.unilever.asset.kam.repository.DeployedAssetValueRepository;
import com.unilever.asset.kam.repository.DeployedAssetVolumeRepository;
import com.unilever.asset.kam.repository.DepotConnetedAssetValueRepository;
import com.unilever.asset.kam.repository.DepotConnetedAssetVolumeRepository;
import com.unilever.asset.kam.repository.NextMocViewRepository;
import com.unilever.asset.kam.repository.NotCompliedAssetValueRepository;
import com.unilever.asset.kam.repository.NotCompliedAssetVolumeRepository;
import com.unilever.asset.kam.repository.PreviousMocViewRepository;
import com.unilever.asset.kam.repository.TotalAssetCreatedValueRepository;
import com.unilever.asset.kam.repository.TotalAssetCreatedVolumeRepository;

@Service
public class CommercialB2CService {

	@Autowired
	TotalAssetCreatedValueRepository totalAssetCreatedValueRepository;
	
	@Autowired
	TotalAssetCreatedVolumeRepository totalAssetCreatedVolumeRepository;

	@Autowired
	DepotConnetedAssetValueRepository depotConnetedAssetValueRepository;
	
	@Autowired
	DepotConnetedAssetVolumeRepository depotConnetedAssetVolumeRepository;
    
	@Autowired
	DeployedAssetValueRepository deployedAssetValueRepository;
	
	@Autowired
	DeployedAssetVolumeRepository deployedAssetVolumeRepository;

	@Autowired
	CompliedAssetValueRepository compliedAssetValueRepository;
	
	@Autowired
	CompliedAssetVolumeRepository compliedAssetVolumeRepository;
	
	@Autowired
	NotCompliedAssetValueRepository notCompliedAssetValueRepository;
	
	@Autowired
	NotCompliedAssetVolumeRepository notCompliedAssetVolumeRepository;
	
	@Autowired
	CurrentMocCommB2CViewRepository currentMocViewRepository;
	
	@Autowired
	PreviousMocCommB2CViewRepository previousMocViewRepository;
    
	@Autowired
	NextMocCommB2CViewRepository nextMocViewRepository;
	
	@Autowired
	CommB2CCompliedAssetValueReposiory commB2CCompliedAssetValueReposiory;
	
	@Autowired
	CommB2CCompliedAssetVolumeReposiory commB2CCompliedAssetVolumeReposiory;
	
	@Autowired
	CommB2CDeployedAssetValueReposiory commB2CDeployedAssetValueReposiory;
	
	@Autowired
	CommB2CDeployedAssetVolumeReposiory commB2CDeployedAssetVolumeReposiory;
	
	@Autowired
	CommB2CDepotConnectedAssetValueNextReposiory commB2CDepotConnectedAssetValueNextReposiory;
	
	@Autowired
	CommB2CDepotConnectedAssetValueReposiory commB2CDepotConnectedAssetValueReposiory;
	
	@Autowired
	CommB2CDepotConnectedAssetVolumeNextReposiory commB2CDepotConnectedAssetVolumeNextReposiory;
	
	@Autowired
	CommB2CDepotConnectedAssetVolumeReposiory commB2CDepotConnectedAssetVolumeReposiory;
	
	@Autowired
	CommB2CNotCompliedAssetValueReposiory commB2CNotCompliedAssetValueReposiory;
	
	@Autowired
	CommB2CNotCompliedAssetVolumeReposiory commB2CNotCompliedAssetVolumeReposiory;
	
	@Autowired
	CommB2CPlannedAssetValueReposiory commB2CPlannedAssetValueReposiory;
	
	@Autowired
	CommB2CPlannedAssetVolumeReposiory commB2CPlannedAssetVolumeReposiory;
	
	@Autowired
	CommB2CStoreListTotalCountReposiory commB2CStoreListTotalCountReposiory;
	
	@Autowired
	CommB2CStoreListTotalValueReposiory commB2CStoreListTotalValueReposiory;
	
	@Autowired
	CommB2CTotalAssetCreatedValueRepository commB2CTotalAssetCreatedValueRepository;
	
	@Autowired
	CommB2CTotalAssetCreatedVolumeRepository commB2CTotalAssetCreatedVolumeRepository;
	
	
	
	
	
	public CommB2CTotalaAssetCreatedValue getTotalAssetCreatedValue(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CTotalaAssetCreatedValue totalAssetAmountSum = new CommB2CTotalaAssetCreatedValue();


		try{
			List<CommB2CTotalaAssetCreatedValue> totalAssetValues = new ArrayList<CommB2CTotalaAssetCreatedValue>();
			List<CommB2CTotalaAssetCreatedValue> totalAssetValuesByUsername = new ArrayList<CommB2CTotalaAssetCreatedValue>();
			List<CommB2CTotalaAssetCreatedValue> mocList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
			
			totalAssetValuesByUsername = commB2CTotalAssetCreatedValueRepository.findAllTotalAssetCreatedValueDetails();
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedValue mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CTotalaAssetCreatedValue t : mocList){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}

				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CTotalaAssetCreatedValue> categoryList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CTotalaAssetCreatedValue cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(CommB2CTotalaAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CTotalaAssetCreatedValue> accountList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				
				
				for(String accnt : account){
					for(CommB2CTotalaAssetCreatedValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalaAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CTotalaAssetCreatedValue> accountList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				List<CommB2CTotalaAssetCreatedValue> filteredAccountCategoryList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CTotalaAssetCreatedValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CTotalaAssetCreatedValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalaAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CTotalaAssetCreatedValue> regionList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalaAssetCreatedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalaAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}

				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CTotalaAssetCreatedValue> regionList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				List<CommB2CTotalaAssetCreatedValue> filteredRegionAccountList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalaAssetCreatedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CTotalaAssetCreatedValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CTotalaAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();

				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CTotalaAssetCreatedValue> regionList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				List<CommB2CTotalaAssetCreatedValue> filteredRegionCategoryList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CTotalaAssetCreatedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CTotalaAssetCreatedValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalaAssetCreatedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalAssetCreatedValue();
				}
				totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CTotalaAssetCreatedValue> regionList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				List<CommB2CTotalaAssetCreatedValue> accountList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				List<CommB2CTotalaAssetCreatedValue> filteredRegionCategoryList = new ArrayList<CommB2CTotalaAssetCreatedValue>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CTotalaAssetCreatedValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CTotalaAssetCreatedValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CTotalaAssetCreatedValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CTotalaAssetCreatedValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CTotalaAssetCreatedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalAssetCreatedValue();
					}

					totalAssetAmountSum.setTotalAssetCreatedValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	
	//=======================Start Total Asset Created Volume===========================================//

	public CommB2CTotalaAssetCreatedVolume getTotalAssetCreatedVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		CommB2CTotalaAssetCreatedVolume totalAssetVolumeSum= new CommB2CTotalaAssetCreatedVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CommB2CTotalaAssetCreatedVolume> totalAssetVolumes = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
			List<CommB2CTotalaAssetCreatedVolume> totalAssetVolumeByUsername = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
			List<CommB2CTotalaAssetCreatedVolume> mocList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
			
			totalAssetVolumeByUsername = commB2CTotalAssetCreatedVolumeRepository.findAllTotalAssetCreatedVolumeDetails();
           

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedVolume mocc : totalAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				for(CommB2CTotalaAssetCreatedVolume t : mocList){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}

				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CTotalaAssetCreatedVolume> categoryList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();

				//filtered by category

				for(String c : category){
					for(CommB2CTotalaAssetCreatedVolume cat : totalAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CTotalaAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CTotalaAssetCreatedVolume> accountList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				
				for(String accnt : account){
					for(CommB2CTotalaAssetCreatedVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CTotalaAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CTotalaAssetCreatedVolume> accountList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				List<CommB2CTotalaAssetCreatedVolume> filteredAccountCategoryList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();


				//filterd by account
				for(String accnt : account){
					for(CommB2CTotalaAssetCreatedVolume acc : totalAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CTotalaAssetCreatedVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CTotalaAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CTotalaAssetCreatedVolume> regionList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalaAssetCreatedVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CTotalaAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}

				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CTotalaAssetCreatedVolume> regionList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				List<CommB2CTotalaAssetCreatedVolume> filteredRegionAccountList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalaAssetCreatedVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CTotalaAssetCreatedVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CTotalaAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CTotalaAssetCreatedVolume> regionList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				List<CommB2CTotalaAssetCreatedVolume> filteredRegionCategoryList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
			
				//filterd by region

				for(String regon : region){
					for(CommB2CTotalaAssetCreatedVolume reg : totalAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CTotalaAssetCreatedVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalaAssetCreatedVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(CommB2CTotalaAssetCreatedVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CTotalaAssetCreatedVolume> regionList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				List<CommB2CTotalaAssetCreatedVolume> accountList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				List<CommB2CTotalaAssetCreatedVolume> filteredRegionCategoryList = new ArrayList<CommB2CTotalaAssetCreatedVolume>();
				
				if(totalAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CTotalaAssetCreatedVolume reg : totalAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CTotalaAssetCreatedVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CTotalaAssetCreatedVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CTotalaAssetCreatedVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(CommB2CTotalaAssetCreatedVolume t : totalAssetVolumes){
						totalAssetVolume += t.getTotalCompliedAssetVolume();
					}

					totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//=======================Start Depot connected Asset Value===========================================//


	public CommB2CDepotConnectedAssetValue getAllDepotConnectedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CDepotConnectedAssetValue totalAssetAmountSum = new CommB2CDepotConnectedAssetValue();


		try{

			List<CommB2CDepotConnectedAssetValue> totalAssetValues = new ArrayList<CommB2CDepotConnectedAssetValue>();
			List<CommB2CDepotConnectedAssetValue> totalDepotAssetValuesByUsername = new ArrayList<CommB2CDepotConnectedAssetValue>();
			List<CommB2CDepotConnectedAssetValue> mocList = new ArrayList<CommB2CDepotConnectedAssetValue>();
			
			totalDepotAssetValuesByUsername = commB2CDepotConnectedAssetValueReposiory.findDepotConnectedAssetValueDetails();
	           

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetValue mocc : totalDepotAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(CommB2CDepotConnectedAssetValue t : mocList){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}

				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CDepotConnectedAssetValue> categoryList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CDepotConnectedAssetValue cat : totalDepotAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(CommB2CDepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CDepotConnectedAssetValue> accountList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				
				for(String accnt : account){
					for(CommB2CDepotConnectedAssetValue acc : totalDepotAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CDepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CDepotConnectedAssetValue> accountList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				List<CommB2CDepotConnectedAssetValue> filteredAccountCategoryList = new ArrayList<CommB2CDepotConnectedAssetValue>();

				

				//filterd by account
				for(String accnt : account){
					for(CommB2CDepotConnectedAssetValue acc : totalDepotAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CDepotConnectedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CDepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CDepotConnectedAssetValue> regionList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CDepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}

				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CDepotConnectedAssetValue> regionList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				List<CommB2CDepotConnectedAssetValue> filteredRegionAccountList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CDepotConnectedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CDepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CDepotConnectedAssetValue> regionList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				List<CommB2CDepotConnectedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CDepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CDepotConnectedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(CommB2CDepotConnectedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}	
			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CDepotConnectedAssetValue> regionList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				List<CommB2CDepotConnectedAssetValue> accountList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				List<CommB2CDepotConnectedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetValue>();
				
				if(totalDepotAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CDepotConnectedAssetValue reg : totalDepotAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CDepotConnectedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CDepotConnectedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(CommB2CDepotConnectedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getDepotConnectedAssetValue();
					}

					totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	//=======================Start Depot connected Asset Volume===========================================//

	public CommB2CDepotConnectedAssetVolume getAllDepotConnectedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		CommB2CDepotConnectedAssetVolume totalAssetVolumeSum= new CommB2CDepotConnectedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CommB2CDepotConnectedAssetVolume> totalAssetVolumes = new ArrayList<CommB2CDepotConnectedAssetVolume>();
			List<CommB2CDepotConnectedAssetVolume> totalDepotAssetVolumeByUsername = new ArrayList<CommB2CDepotConnectedAssetVolume>();
			List<CommB2CDepotConnectedAssetVolume> mocList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
			
			totalDepotAssetVolumeByUsername = commB2CDepotConnectedAssetVolumeReposiory.findAllDepotConnectedAssetVolumeDetails();


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetVolume mocc : totalDepotAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				
				for(CommB2CDepotConnectedAssetVolume t : mocList){
					totalAssetVolume += t.getDepotConnectedAssetsVolume();

				}

				totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CDepotConnectedAssetVolume> categoryList = new ArrayList<CommB2CDepotConnectedAssetVolume>();

				
				//filtered by category

				for(String c : category){
					for(CommB2CDepotConnectedAssetVolume cat : totalDepotAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CDepotConnectedAssetVolume t : mocList){
					totalAssetVolume += t.getDepotConnectedAssetsVolume();

				}

				totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);

			
			
			
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CDepotConnectedAssetVolume> accountList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				
				for(String accnt : account){
					for(CommB2CDepotConnectedAssetVolume acc : totalDepotAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				


				totalAssetVolumes.addAll(mocList);

				for(CommB2CDepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetsVolume();

				}
				totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);
			}


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CDepotConnectedAssetVolume> accountList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				List<CommB2CDepotConnectedAssetVolume> filteredAccountCategoryList = new ArrayList<CommB2CDepotConnectedAssetVolume>();


				//filterd by account
				for(String accnt : account){
					for(CommB2CDepotConnectedAssetVolume acc : totalDepotAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CDepotConnectedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CDepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetsVolume();
				}
				totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CDepotConnectedAssetVolume> regionList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CDepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetsVolume();
				}

				totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CDepotConnectedAssetVolume> regionList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				List<CommB2CDepotConnectedAssetVolume> filteredRegionAccountList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CDepotConnectedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(CommB2CDepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetsVolume();

				}
				totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CDepotConnectedAssetVolume> regionList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				List<CommB2CDepotConnectedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
			
				//filterd by region

				for(String regon : region){
					for(CommB2CDepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CDepotConnectedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDepotConnectedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CDepotConnectedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetsVolume();
				}
				totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CDepotConnectedAssetVolume> regionList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				List<CommB2CDepotConnectedAssetVolume> accountList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				List<CommB2CDepotConnectedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CDepotConnectedAssetVolume>();
				
				if(totalDepotAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CDepotConnectedAssetVolume reg : totalDepotAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CDepotConnectedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CDepotConnectedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDepotConnectedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(CommB2CDepotConnectedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnectedAssetsVolume();
					}

					totalAssetVolumeSum.setDepotConnectedAssetsVolume(totalAssetVolume);

				}//end of if

			}// end of else if
		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}

	//=================================================== Start Deployed Asset=====================================

	public CommB2CDeployedAssetValue getDeployedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00 ;
		//Integer totalAssetAmountSum = 0;
		CommB2CDeployedAssetValue totalAssetAmountSum = new CommB2CDeployedAssetValue();


		try{

			List<CommB2CDeployedAssetValue> totalAssetValues = new ArrayList<CommB2CDeployedAssetValue>();
			List<CommB2CDeployedAssetValue> totalCommB2CDeployedAssetValuesByUsername = new ArrayList<CommB2CDeployedAssetValue>();
			List<CommB2CDeployedAssetValue> mocList = new ArrayList<CommB2CDeployedAssetValue>();
			
			totalCommB2CDeployedAssetValuesByUsername = commB2CDeployedAssetValueReposiory.findAllDeployedAssetValueDetails();



			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetValue mocc : totalCommB2CDeployedAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CDeployedAssetValue t : mocList){
					totalAssetAmount += t.getDeployedAssetValue();

				}

				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CDeployedAssetValue> categoryList = new ArrayList<CommB2CDeployedAssetValue>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CDeployedAssetValue cat : totalCommB2CDeployedAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CDeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();

				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CDeployedAssetValue> accountList = new ArrayList<CommB2CDeployedAssetValue>();
				
				for(String accnt : account){
					for(CommB2CDeployedAssetValue acc : totalCommB2CDeployedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CDeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();

				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CDeployedAssetValue> accountList = new ArrayList<CommB2CDeployedAssetValue>();
				List<CommB2CDeployedAssetValue> filteredAccountCategoryList = new ArrayList<CommB2CDeployedAssetValue>();
			

				//filterd by account
				for(String accnt : account){
					for(CommB2CDeployedAssetValue acc : totalCommB2CDeployedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CDeployedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CDeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();
				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}



			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CDeployedAssetValue> regionList = new ArrayList<CommB2CDeployedAssetValue>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDeployedAssetValue reg : totalCommB2CDeployedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CDeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();
				}

				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CDeployedAssetValue> regionList = new ArrayList<CommB2CDeployedAssetValue>();
				List<CommB2CDeployedAssetValue> filteredRegionAccountList = new ArrayList<CommB2CDeployedAssetValue>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDeployedAssetValue reg : totalCommB2CDeployedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CDeployedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CDeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();

				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CDeployedAssetValue> regionList = new ArrayList<CommB2CDeployedAssetValue>();
				List<CommB2CDeployedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CDeployedAssetValue>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CDeployedAssetValue reg : totalCommB2CDeployedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CDeployedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(CommB2CDeployedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getDeployedAssetValue();
				}
				totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CDeployedAssetValue> regionList = new ArrayList<CommB2CDeployedAssetValue>();
				List<CommB2CDeployedAssetValue> accountList = new ArrayList<CommB2CDeployedAssetValue>();
				List<CommB2CDeployedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CDeployedAssetValue>();

				if(totalCommB2CDeployedAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CDeployedAssetValue reg : totalCommB2CDeployedAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CDeployedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CDeployedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDeployedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CDeployedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getDeployedAssetValue();
					}

					totalAssetAmountSum.setDeployedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	public CommB2CDeployedAssetVolume getAllDeployedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		CommB2CDeployedAssetVolume totalAssetVolumeSum= new CommB2CDeployedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CommB2CDeployedAssetVolume> totalAssetVolumes = new ArrayList<CommB2CDeployedAssetVolume>();
			List<CommB2CDeployedAssetVolume> totalDeployedAssetVolumeByUsername = new ArrayList<CommB2CDeployedAssetVolume>();
			List<CommB2CDeployedAssetVolume> mocList = new ArrayList<CommB2CDeployedAssetVolume>();
			
			totalDeployedAssetVolumeByUsername = commB2CDeployedAssetVolumeReposiory.findAllDeployedAssetVolumeDetails();



			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetVolume mocc : totalDeployedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				
				for(CommB2CDeployedAssetVolume t : mocList){
					totalAssetVolume += t.getDeployedAssetVolume();

				}

				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CDeployedAssetVolume> categoryList = new ArrayList<CommB2CDeployedAssetVolume>();


				//filtered by category

				for(String c : category){
					for(CommB2CDeployedAssetVolume cat : totalDeployedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
				
				}
				
				totalAssetVolumes.addAll(mocList);

				for(CommB2CDeployedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();

				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			
			
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CDeployedAssetVolume> accountList = new ArrayList<CommB2CDeployedAssetVolume>();
				
				for(String accnt : account){
					for(CommB2CDeployedAssetVolume acc : totalDeployedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
				
				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CDeployedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();

				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}



			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CDeployedAssetVolume> accountList = new ArrayList<CommB2CDeployedAssetVolume>();
				List<CommB2CDeployedAssetVolume> filteredAccountCategoryList = new ArrayList<CommB2CDeployedAssetVolume>();

				

				//filterd by account
				for(String accnt : account){
					for(CommB2CDeployedAssetVolume acc : totalDeployedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CDeployedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
				
				}
				totalAssetVolumes.addAll(mocList);

				for(CommB2CDeployedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();
				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CDeployedAssetVolume> regionList = new ArrayList<CommB2CDeployedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDeployedAssetVolume reg : totalDeployedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
				
				}

				totalAssetVolumes.addAll(regionList);
				for(CommB2CDeployedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();
				}

				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CDeployedAssetVolume> regionList = new ArrayList<CommB2CDeployedAssetVolume>();
				List<CommB2CDeployedAssetVolume> filteredRegionAccountList = new ArrayList<CommB2CDeployedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CDeployedAssetVolume reg : totalDeployedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CDeployedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				

				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
				
				}

				totalAssetVolumes.addAll(mocList);

				for(CommB2CDeployedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();

				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CDeployedAssetVolume> regionList = new ArrayList<CommB2CDeployedAssetVolume>();
				List<CommB2CDeployedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CDeployedAssetVolume>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CDeployedAssetVolume reg : totalDeployedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CDeployedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CDeployedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
				
				}


				totalAssetVolumes.addAll(mocList);
				for(CommB2CDeployedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getDeployedAssetVolume();
				}
				totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);
			}	



			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CDeployedAssetVolume> regionList = new ArrayList<CommB2CDeployedAssetVolume>();
				List<CommB2CDeployedAssetVolume> accountList = new ArrayList<CommB2CDeployedAssetVolume>();
				List<CommB2CDeployedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CDeployedAssetVolume>();
				
				if(totalDeployedAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CDeployedAssetVolume reg : totalDeployedAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CDeployedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CDeployedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CDeployedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
					
					}

					totalAssetVolumes.addAll(mocList);

					for(CommB2CDeployedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getDeployedAssetVolume();
					}

					totalAssetVolumeSum.setDeployedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//==========================================Start Complied Asset========================================================

	public CommB2CCompliedAssetValue getCompliedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00 ;
		//Integer totalAssetAmountSum = 0;
		CommB2CCompliedAssetValue totalAssetAmountSum = new CommB2CCompliedAssetValue();


		try{

			List<CommB2CCompliedAssetValue> totalAssetValues = new ArrayList<CommB2CCompliedAssetValue>();
			List<CommB2CCompliedAssetValue> totalCommB2CCompliedAssetValuesByUsername = new ArrayList<CommB2CCompliedAssetValue>();
			List<CommB2CCompliedAssetValue> mocList = new ArrayList<CommB2CCompliedAssetValue>();
			
			totalCommB2CCompliedAssetValuesByUsername = commB2CCompliedAssetValueReposiory.findAllCompliedAssetValueDetails();



			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetValue mocc : totalCommB2CCompliedAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				for(CommB2CCompliedAssetValue t : mocList){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}

				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CCompliedAssetValue> categoryList = new ArrayList<CommB2CCompliedAssetValue>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CCompliedAssetValue cat : totalCommB2CCompliedAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CCompliedAssetValue> accountList = new ArrayList<CommB2CCompliedAssetValue>();
			
				
				for(String accnt : account){
					for(CommB2CCompliedAssetValue acc : totalCommB2CCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CCompliedAssetValue> accountList = new ArrayList<CommB2CCompliedAssetValue>();
				List<CommB2CCompliedAssetValue> filteredAccountCategoryList = new ArrayList<CommB2CCompliedAssetValue>();
			

				//filterd by account
				for(String accnt : account){
					for(CommB2CCompliedAssetValue acc : totalCommB2CCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CCompliedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();
				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}




			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CCompliedAssetValue> regionList = new ArrayList<CommB2CCompliedAssetValue>();
			
				//filter by region
				for(String regon : region){
					for(CommB2CCompliedAssetValue reg : totalCommB2CCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();
				}

				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CCompliedAssetValue> regionList = new ArrayList<CommB2CCompliedAssetValue>();
				List<CommB2CCompliedAssetValue> filteredRegionAccountList = new ArrayList<CommB2CCompliedAssetValue>();
			
				//filter by region
				for(String regon : region){
					for(CommB2CCompliedAssetValue reg : totalCommB2CCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CCompliedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();

				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CCompliedAssetValue> regionList = new ArrayList<CommB2CCompliedAssetValue>();
				List<CommB2CCompliedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CCompliedAssetValue>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CCompliedAssetValue reg : totalCommB2CCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CCompliedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getTotalCompliedAssetValue();
				}
				totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);
			}	





			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CCompliedAssetValue> regionList = new ArrayList<CommB2CCompliedAssetValue>();
				List<CommB2CCompliedAssetValue> accountList = new ArrayList<CommB2CCompliedAssetValue>();
				List<CommB2CCompliedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CCompliedAssetValue>();

			
				if(totalCommB2CCompliedAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CCompliedAssetValue reg : totalCommB2CCompliedAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CCompliedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CCompliedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CCompliedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CCompliedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getTotalCompliedAssetValue();
					}

					totalAssetAmountSum.setTotalCompliedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

//===================================================Complied Asset Volume==================================================================================
	
	
	public CommB2CCompliedAssetVolume getAllCompliedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		CommB2CCompliedAssetVolume totalAssetVolumeSum= new CommB2CCompliedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<CommB2CCompliedAssetVolume> totalAssetVolumes = new ArrayList<CommB2CCompliedAssetVolume>();
			List<CommB2CCompliedAssetVolume> totalCommB2CCompliedAssetVolumeByUsername = new ArrayList<CommB2CCompliedAssetVolume>();
			List<CommB2CCompliedAssetVolume> mocList = new ArrayList<CommB2CCompliedAssetVolume>();
			
			totalCommB2CCompliedAssetVolumeByUsername = commB2CCompliedAssetVolumeReposiory.findAllCompliedAssetVolumeDetails();


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetVolume mocc : totalCommB2CCompliedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				for(CommB2CCompliedAssetVolume t : mocList){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}

				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);

			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CCompliedAssetVolume> categoryList = new ArrayList<CommB2CCompliedAssetVolume>();

				
				//filtered by category

				for(String c : category){
					for(CommB2CCompliedAssetVolume cat : totalCommB2CCompliedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				totalAssetVolumes.addAll(mocList);

				for(CommB2CCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CCompliedAssetVolume> accountList = new ArrayList<CommB2CCompliedAssetVolume>();
			
				for(String accnt : account){
					for(CommB2CCompliedAssetVolume acc : totalCommB2CCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				

				totalAssetVolumes.addAll(mocList);

				for(CommB2CCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CCompliedAssetVolume> accountList = new ArrayList<CommB2CCompliedAssetVolume>();
				List<CommB2CCompliedAssetVolume> filteredAccountCategoryList = new ArrayList<CommB2CCompliedAssetVolume>();


				//filterd by account
				for(String accnt : account){
					for(CommB2CCompliedAssetVolume acc : totalCommB2CCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CCompliedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(CommB2CCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CCompliedAssetVolume> regionList = new ArrayList<CommB2CCompliedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CCompliedAssetVolume reg : totalCommB2CCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}

				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CCompliedAssetVolume> regionList = new ArrayList<CommB2CCompliedAssetVolume>();
				List<CommB2CCompliedAssetVolume> filteredRegionAccountList = new ArrayList<CommB2CCompliedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CCompliedAssetVolume reg : totalCommB2CCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CCompliedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				totalAssetVolumes.addAll(mocList);

				for(CommB2CCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();

				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CCompliedAssetVolume> regionList = new ArrayList<CommB2CCompliedAssetVolume>();
				List<CommB2CCompliedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CCompliedAssetVolume>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CCompliedAssetVolume reg : totalCommB2CCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CCompliedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CCompliedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getTotalCompliedAssetVolume();
				}
				totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);
			}	
			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CCompliedAssetVolume> regionList = new ArrayList<CommB2CCompliedAssetVolume>();
				List<CommB2CCompliedAssetVolume> accountList = new ArrayList<CommB2CCompliedAssetVolume>();
				List<CommB2CCompliedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CCompliedAssetVolume>();
				
				if(totalCommB2CCompliedAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CCompliedAssetVolume reg : totalCommB2CCompliedAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CCompliedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CCompliedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CCompliedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetVolumes.addAll(mocList);

					for(CommB2CCompliedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getTotalCompliedAssetVolume();
					}

					totalAssetVolumeSum.setTotalCompliedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}

	//===============================================Start Not Complied Asset=============================================


	public CommB2CNotCompliedAssetValue getNotCompliedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CNotCompliedAssetValue totalAssetAmountSum = new CommB2CNotCompliedAssetValue();


		try{

			List<CommB2CNotCompliedAssetValue> totalAssetValues = new ArrayList<CommB2CNotCompliedAssetValue>();
			List<CommB2CNotCompliedAssetValue> totalCommB2CNotCompliedAssetValuesByUsername = new ArrayList<CommB2CNotCompliedAssetValue>();
			List<CommB2CNotCompliedAssetValue> mocList = new ArrayList<CommB2CNotCompliedAssetValue>();
			
			totalCommB2CNotCompliedAssetValuesByUsername = commB2CNotCompliedAssetValueReposiory.findAllNotCompliedTotalAssetValueDetails();


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetValue mocc : totalCommB2CNotCompliedAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CNotCompliedAssetValue t : mocList){
					totalAssetAmount += t.getNotCompliedAssetValue();

				}

				totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);

			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CNotCompliedAssetValue> categoryList = new ArrayList<CommB2CNotCompliedAssetValue>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CNotCompliedAssetValue cat : totalCommB2CNotCompliedAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CNotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getNotCompliedAssetValue();

				}
				totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CNotCompliedAssetValue> accountList = new ArrayList<CommB2CNotCompliedAssetValue>();
				
				
				for(String accnt : account){
					for(CommB2CNotCompliedAssetValue acc : totalCommB2CNotCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CNotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getNotCompliedAssetValue();

				}
				totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CNotCompliedAssetValue> accountList = new ArrayList<CommB2CNotCompliedAssetValue>();
				List<CommB2CNotCompliedAssetValue> filteredAccountCategoryList = new ArrayList<CommB2CNotCompliedAssetValue>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CNotCompliedAssetValue acc : totalCommB2CNotCompliedAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CNotCompliedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CNotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getNotCompliedAssetValue();
				}
				totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);
			}



			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CNotCompliedAssetValue> regionList = new ArrayList<CommB2CNotCompliedAssetValue>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CNotCompliedAssetValue reg : totalCommB2CNotCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(CommB2CNotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getNotCompliedAssetValue();
				}

				totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CNotCompliedAssetValue> regionList = new ArrayList<CommB2CNotCompliedAssetValue>();
				List<CommB2CNotCompliedAssetValue> filteredRegionAccountList = new ArrayList<CommB2CNotCompliedAssetValue>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CNotCompliedAssetValue reg : totalCommB2CNotCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CNotCompliedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CNotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getNotCompliedAssetValue();

				}
				totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CNotCompliedAssetValue> regionList = new ArrayList<CommB2CNotCompliedAssetValue>();
				List<CommB2CNotCompliedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CNotCompliedAssetValue>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CNotCompliedAssetValue reg : totalCommB2CNotCompliedAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CNotCompliedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CNotCompliedAssetValue t : totalAssetValues){
					totalAssetAmount += t.getNotCompliedAssetValue();
				}
				totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);
			}	





			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CNotCompliedAssetValue> regionList = new ArrayList<CommB2CNotCompliedAssetValue>();
				List<CommB2CNotCompliedAssetValue> accountList = new ArrayList<CommB2CNotCompliedAssetValue>();
				List<CommB2CNotCompliedAssetValue> filteredRegionCategoryList = new ArrayList<CommB2CNotCompliedAssetValue>();

				if(totalCommB2CNotCompliedAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CNotCompliedAssetValue reg : totalCommB2CNotCompliedAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CNotCompliedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CNotCompliedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CNotCompliedAssetValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CNotCompliedAssetValue t : totalAssetValues){
						totalAssetAmount += t.getNotCompliedAssetValue();
					}

					totalAssetAmountSum.setNotCompliedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	public CommB2CNotCompliedAssetVolume getNotCompliedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category){


		Double totalAssetVolume = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CNotCompliedAssetVolume totalAssetVolumeSum = new CommB2CNotCompliedAssetVolume();


		try{

			List<CommB2CNotCompliedAssetVolume> totalAssetVolumes = new ArrayList<CommB2CNotCompliedAssetVolume>();
			List<CommB2CNotCompliedAssetVolume> totalCommB2CNotCompliedAssetVolumeByUsername = new ArrayList<CommB2CNotCompliedAssetVolume>();
			List<CommB2CNotCompliedAssetVolume> mocList = new ArrayList<CommB2CNotCompliedAssetVolume>();
			
			totalCommB2CNotCompliedAssetVolumeByUsername = commB2CNotCompliedAssetVolumeReposiory.findAllNotCompliedTotalAssetVolumeDetails();


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetVolume mocc : totalCommB2CNotCompliedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				for(CommB2CNotCompliedAssetVolume t : mocList){
					totalAssetVolume += t.getNotCompliedAssetVolume();

				}

				totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);

			}
			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CNotCompliedAssetVolume> categoryList = new ArrayList<CommB2CNotCompliedAssetVolume>();

				//filtered by category

				for(String c : category){
					for(CommB2CNotCompliedAssetVolume cat : totalCommB2CNotCompliedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				totalAssetVolumes.addAll(mocList);

				for(CommB2CNotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getNotCompliedAssetVolume();

				}
				totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);
				
			
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CNotCompliedAssetVolume> accountList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				
				for(String accnt : account){
					for(CommB2CNotCompliedAssetVolume acc : totalCommB2CNotCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CNotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getNotCompliedAssetVolume();

				}
				totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CNotCompliedAssetVolume> accountList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				List<CommB2CNotCompliedAssetVolume> filteredAccountCategoryList = new ArrayList<CommB2CNotCompliedAssetVolume>();


				//filterd by account
				for(String accnt : account){
					for(CommB2CNotCompliedAssetVolume acc : totalCommB2CNotCompliedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CNotCompliedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CNotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getNotCompliedAssetVolume();
				}
				totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CNotCompliedAssetVolume> regionList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CNotCompliedAssetVolume reg : totalCommB2CNotCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);
				for(CommB2CNotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getNotCompliedAssetVolume();
				}

				totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CNotCompliedAssetVolume> regionList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				List<CommB2CNotCompliedAssetVolume> filteredRegionAccountList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				
				//filter by region
				for(String regon : region){
					for(CommB2CNotCompliedAssetVolume reg : totalCommB2CNotCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CNotCompliedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(CommB2CNotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getNotCompliedAssetVolume();

				}
				totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CNotCompliedAssetVolume> regionList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				List<CommB2CNotCompliedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CNotCompliedAssetVolume reg : totalCommB2CNotCompliedAssetVolumeByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CNotCompliedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CNotCompliedAssetVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(CommB2CNotCompliedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getNotCompliedAssetVolume();
				}
				totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CNotCompliedAssetVolume> regionList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				List<CommB2CNotCompliedAssetVolume> accountList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				List<CommB2CNotCompliedAssetVolume> filteredRegionCategoryList = new ArrayList<CommB2CNotCompliedAssetVolume>();
				
				if(totalCommB2CNotCompliedAssetVolumeByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CNotCompliedAssetVolume reg : totalCommB2CNotCompliedAssetVolumeByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CNotCompliedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CNotCompliedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CNotCompliedAssetVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetVolumes.addAll(mocList);

					for(CommB2CNotCompliedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getNotCompliedAssetVolume();
					}

					totalAssetVolumeSum.setNotCompliedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}
//=====================================================================View Start =============================================================================

	public List<CurrentMocView> getCurrentMocView(String account,String moc){
		List<CurrentMocView> currentMocViewDetails = new ArrayList<CurrentMocView>();
		//List<ViewTableModel> currentMocViewDetails = new ArrayList<ViewTableModel>();
		try{
		//	currentMocViewDetails=currentMocViewRepository.findAllCurrentMocView(account,moc);
			//currentMocViewDetails = viewTableRepository.findAllCurrentMocView(account, moc);

		}catch(Exception e){
			e.printStackTrace();
		}
		return currentMocViewDetails;
	}


	public List<PreviousMocView> getPreviousMocView(String account,String moc){
		List<PreviousMocView> previousMocViewDetails = new ArrayList<PreviousMocView>();
		try{
		//	previousMocViewDetails=previousMocViewRepository.findAllPreviousMocView(account,moc);

		}catch(Exception e){
			e.printStackTrace();
		}
		return previousMocViewDetails;
	}



	public List<NextMocView> getNextMocView(String account,String moc){
		List<NextMocView> nextMocViewDetails = new ArrayList<NextMocView>();
		try{
		//	nextMocViewDetails=nextMocViewRepository.findAllNextMocView(account,moc);

		}catch(Exception e){
			e.printStackTrace();
		}
		return nextMocViewDetails;
	}
	
	//=====================================================================View Start =============================================================================

	public List<CurrentMocCommB2CViewDto> getCurrentMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
		//		List<CurrentMocView> currentMocViewDetails = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> regionList = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> mocList = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> categoryList = new ArrayList<CurrentMocView>();
		//		List<CurrentMocView> filteredViewList = new ArrayList<CurrentMocView>();
		//		
		//		try{
		//			currentMocViewDetails=currentMocViewRepository.findAllCurrentMocViewByAccount(account);
		//			//Pageable paging = PageRequest.of(pageNo, pageSize);
		//			
		//			//Page<CurrentMocView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewDetails(paging);
		//			
		//			
		//			//filtered by MOC
		//			for(String m : moc){
		//				for(CurrentMocView mocc : currentMocViewDetails){
		//					if(m.equals(mocc.getMoc())){
		//						mocList.add(mocc);
		//					}
		//
		//				}
		//
		//			}
		//			
		//			//filtered by region
		//			for(String r :region){
		//				for(CurrentMocView reg : mocList){
		//					if(r.equals(reg.getRegion())){
		//						regionList.add(reg);
		//					}
		//
		//				}
		//
		//			}
		//			
		//			//-----filter by category------//
		//
		//			for(String c : category){
		//				for(CurrentMocView cat : regionList){
		//					if(c.equals(cat.getCategory())){
		//						categoryList.add(cat);
		//					}
		//
		//				}
		//
		//			}
		//			
		//			filteredViewList.addAll(categoryList);
		//		}catch(Exception e){
		//			e.printStackTrace();
		//		}
		//		return filteredViewList;
		List<CurrentMocCommB2CViewDto> filteredViewList = new ArrayList<CurrentMocCommB2CViewDto>();
		List<CurrentMocCommB2CView> totalRecords = new ArrayList<CurrentMocCommB2CView>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMoc(moc, paging);
				totalRecords = currentMocViewRepository.findCountByMoc(moc);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}
			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocCategory(moc,category, paging);
				totalRecords = currentMocViewRepository.findCountByMocCategory(moc,category);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3


				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocAccount(moc,account, paging);
				totalRecords = currentMocViewRepository.findCountByAccount(moc,account);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4

				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocAccountCategory(moc, account, category, paging);
				totalRecords = currentMocViewRepository.findCountByAccountMocCategory(moc, account, category);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}

			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocRegion(moc, region, paging);
				totalRecords = currentMocViewRepository.findCountByMocRegion(moc, region);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}



			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocAccountRegion(moc, account, region, paging);
				totalRecords = currentMocViewRepository.findCountByAccountMocRegion(moc, account, region);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}




			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocRegionCategory(moc, region, category, paging);
				totalRecords = currentMocViewRepository.findAllCountCurrentMocViewByMocRegionCategory(moc, region, category);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}


			}

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				Page<CurrentMocCommB2CView> currentMocViewDetails = currentMocViewRepository.findAllCurrentMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
				totalRecords = currentMocViewRepository.findAllCountCurrentMocViewByMocRegionAccountCategory(moc, account, region, category);

				for(CurrentMocCommB2CView c : currentMocViewDetails.getContent()){
					CurrentMocCommB2CViewDto currentMocViewDto = new CurrentMocCommB2CViewDto();

					currentMocViewDto.setRegion(c.getRegion());
					currentMocViewDto.setBranch(c.getBranch());
					currentMocViewDto.setAccount(c.getAccount());
					currentMocViewDto.setVisiRefNo(c.getVisiRefNo());
					currentMocViewDto.setHulCode(c.getHulCode());
					currentMocViewDto.setMoc(c.getMoc());
					currentMocViewDto.setCategory(c.getCategory());
					currentMocViewDto.setCity(c.getCity());
					currentMocViewDto.setAssetType(c.getAssetType());
					currentMocViewDto.setAssetDescription(c.getAssetDescription());
					currentMocViewDto.setCreatedOn(c.getCreatedOn());
					currentMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					currentMocViewDto.setDeployedOn(c.getDeployedOn());
					currentMocViewDto.setCompliance(c.getCompliance());
					currentMocViewDto.setLossTree(c.getLossTree());
					currentMocViewDto.setGodownCode(c.getGodownCode());
					currentMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocViewDto);
				}
			}


		}catch(Exception e){
			e.printStackTrace();
		}
		return filteredViewList;
	}

	//=========================Previous Moc View==========================================================================

	public List<PreviousMocCommB2CViewDto> getPreviousMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){

		List<PreviousMocCommB2CViewDto> filteredViewList = new ArrayList<PreviousMocCommB2CViewDto>();
		List<PreviousMocCommB2CView> totalRecords = new ArrayList<PreviousMocCommB2CView>();

		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMoc(moc, paging);
				totalRecords = previousMocViewRepository.findCountByMoc(moc);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}
			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocCategory(moc,category, paging);
				totalRecords = previousMocViewRepository.findCountByMocCategory(moc,category);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3


				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocAccount(moc,account, paging);
				totalRecords = previousMocViewRepository.findCountByAccount(moc,account);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4

				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocAccountCategory(moc, account, category, paging);
				totalRecords = previousMocViewRepository.findCountByAccountMocCategory(moc, account, category);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}	

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocRegion(moc, region, paging);
				totalRecords = previousMocViewRepository.findCountByMocRegion(moc, region);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}


			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocAccountRegion(moc, account, region, paging);
				totalRecords = previousMocViewRepository.findCountByAccountMocRegion(moc, account, region);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}

			}
			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocRegionCategory(moc, region, category, paging);
				totalRecords = previousMocViewRepository.findAllCountPreviousMocViewByMocRegionCategory(moc, region, category);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}


			}

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				Page<PreviousMocCommB2CView> previousMocViewDetails = previousMocViewRepository.findAllPreviousMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
				totalRecords = previousMocViewRepository.findAllCountPreviousMocViewByMocRegionAccountCategory(moc, account, region, category);

				for(PreviousMocCommB2CView c : previousMocViewDetails.getContent()){
					PreviousMocCommB2CViewDto previousMocViewDto = new PreviousMocCommB2CViewDto();

					previousMocViewDto.setRegion(c.getRegion());
					previousMocViewDto.setBranch(c.getBranch());
					previousMocViewDto.setAccount(c.getAccount());
					previousMocViewDto.setVisiRefNo(c.getVisiRefNo());
					previousMocViewDto.setHulCode(c.getHulCode());
					previousMocViewDto.setMoc(c.getMoc());
					previousMocViewDto.setCategory(c.getCategory());
					previousMocViewDto.setCity(c.getCity());
					previousMocViewDto.setAssetType(c.getAssetType());
					previousMocViewDto.setAssetDescription(c.getAssetDescription());
					previousMocViewDto.setCreatedOn(c.getCreatedOn());
					previousMocViewDto.setDepotConnectOn(c.getDepotConnectOn());
					previousMocViewDto.setDeployedOn(c.getDeployedOn());
					previousMocViewDto.setCompliance(c.getCompliance());
					previousMocViewDto.setLossTree(c.getLossTree());
					previousMocViewDto.setGodownCode(c.getGodownCode());
					previousMocViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocViewDto);
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return filteredViewList;
	}

//	//=========================Next Moc View==========================================================================
//
//	public List<NextMocCommB2CViewDto> getNextMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
//
//		List<NextMocCommB2CView> regionList = new ArrayList<NextMocCommB2CView>();
//		List<NextMocCommB2CView> categoryList = new ArrayList<NextMocCommB2CView>();
//		List<NextMocCommB2CView> filteredViewList = new ArrayList<NextMocCommB2CView>();
//		List<NextMocCommB2CView> totalRecords = new ArrayList<>();
//		NextMocCommB2CViewDto nextMocViewDto = new NextMocCommB2CViewDto();
//		List<NextMocCommB2CView> mocList = new ArrayList<NextMocCommB2CView>();
//		List<NextMocCommB2CViewDto> nextMocViewList = new ArrayList<>();
//		List<NextMocCommB2CView> finalRecords = new ArrayList<>();
//
//		try{
//			Pageable paging = PageRequest.of(pageNo, pageSize);
//			Page<NextMocCommB2CView>nextMocViewDetails=nextMocViewRepository.findAllNextMocViewByAccounts(moc,account,paging);
//			totalRecords = 	nextMocViewRepository.findAllCountNextMocViewByMocRegionAccountCategory(moc, account, category);
//
//			for(String r :region){
//				for(NextMocCommB2CView reg : totalRecords){
//					Pattern pattern = Pattern.compile("(^|,)"+r+"(,|$)");
//					Matcher matcher = pattern.matcher(reg.getRegion());
//					if(matcher.find()){
//						finalRecords.add(reg);
//					}
//
//				}
//
//			}
//
//			//-----filter by region------//
//
//			for(String r :region){
//				for(NextMocCommB2CView reg : nextMocViewDetails){
//					Pattern pattern = Pattern.compile("(^|,)"+r+"(,|$)");
//					Matcher matcher = pattern.matcher(reg.getRegion());
//					if(matcher.find()){
//						regionList.add(reg);
//					}
//
//				}
//
//			}
//
//
//			//-----filter by category------//
//
//			for(String c : category){
//				for(NextMocCommB2CView cat : regionList){
//					if(c.equals(cat.getCategory().trim())){
//						categoryList.add(cat);
//					}
//
//				}
//
//			}
//
//			filteredViewList.addAll(categoryList);
//
//
//			for(NextMocCommB2CView c : filteredViewList){
//				NextMocCommB2CViewDto nextMocViewDtoDetails = new NextMocCommB2CViewDto();
//
//				nextMocViewDtoDetails.setRefNo(c.getVisiRefNo());
//				nextMocViewDtoDetails.setMoc(c.getMoc());
//				nextMocViewDtoDetails.setCategory(c.getCategory());
//				nextMocViewDtoDetails.setRegion(c.getRegion());
//				nextMocViewDtoDetails.setCity(c.getCity());
//				nextMocViewDtoDetails.setAssetDescription(c.getAssetDescription());
//				nextMocViewDtoDetails.setAssetType(c.getAssetType());
//				nextMocViewDtoDetails.setNoOfStores(c.getNoOfStores());
//				nextMocViewDtoDetails.setAccount(c.getAccount());
//				nextMocViewDtoDetails.setTotalRecords(finalRecords.size());
//				
//
//				nextMocViewList.add(nextMocViewDtoDetails);
//			}
//
//
//
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//		return nextMocViewList;
//	}

	
	//=========================Next Moc View==========================================================================

		public List<NextMocCommB2CViewDto> getNextMocView(List<String> region,List<String> account,List<String> moc,List<String>category){

			List<NextMocCommB2CView> regionList = new ArrayList<NextMocCommB2CView>();
			List<NextMocCommB2CView> categoryList = new ArrayList<NextMocCommB2CView>();
			List<NextMocCommB2CView> filteredViewList = new ArrayList<NextMocCommB2CView>();
			List<NextMocCommB2CView> totalRecords = new ArrayList<>();
			NextMocCommB2CViewDto nextMocViewDto = new NextMocCommB2CViewDto();
			List<NextMocCommB2CView> mocList = new ArrayList<NextMocCommB2CView>();
			List<NextMocCommB2CViewDto> nextMocViewList = new ArrayList<>();
			List<NextMocCommB2CView> finalRecords = new ArrayList<>();

			try{
//				Pageable paging = PageRequest.of(pageNo, pageSize);
				List<NextMocCommB2CView>nextMocViewDetails=nextMocViewRepository.findAllNextMocViewByAccounts(moc,account);
				totalRecords = 	nextMocViewRepository.findAllCountNextMocViewByMocRegionAccountCategory(moc, account, category);

				for(String r :region){
					for(NextMocCommB2CView reg : totalRecords){
						Pattern pattern = Pattern.compile("(^|,)"+r+"(,|$)");
						Matcher matcher = pattern.matcher(reg.getRegion());
						if(matcher.find()){
							finalRecords.add(reg);
						}

					}

				}

				//-----filter by region------//

				for(String r :region){
					for(NextMocCommB2CView reg : nextMocViewDetails){
						Pattern pattern = Pattern.compile("(^|,)"+r+"(,|$)");
						Matcher matcher = pattern.matcher(reg.getRegion());
						if(matcher.find()){
							regionList.add(reg);
						}

					}

				}


				//-----filter by category------//

				for(String c : category){
					for(NextMocCommB2CView cat : regionList){
						if(c.equals(cat.getCategory().trim())){
							categoryList.add(cat);
						}

					}

				}

				filteredViewList.addAll(categoryList);


				for(NextMocCommB2CView c : filteredViewList){
					NextMocCommB2CViewDto nextMocViewDtoDetails = new NextMocCommB2CViewDto();

					nextMocViewDtoDetails.setRefNo(c.getVisiRefNo());
					nextMocViewDtoDetails.setMoc(c.getMoc());
					nextMocViewDtoDetails.setCategory(c.getCategory());
					nextMocViewDtoDetails.setRegion(c.getRegion());
					nextMocViewDtoDetails.setCity(c.getCity());
					nextMocViewDtoDetails.setAssetDescription(c.getAssetDescription());
					nextMocViewDtoDetails.setAssetType(c.getAssetType());
					nextMocViewDtoDetails.setNoOfStores(c.getNoOfStores());
					nextMocViewDtoDetails.setAccount(c.getAccount());
					nextMocViewDtoDetails.setTotalRecords(finalRecords.size());
					

					nextMocViewList.add(nextMocViewDtoDetails);
				}



			}catch(Exception e){
				e.printStackTrace();
			}
			return nextMocViewList;
		}




}
