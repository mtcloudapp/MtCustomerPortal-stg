package com.unilever.Authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.Authentication.model.SolcodeDescriptionTemp;

@Repository
public interface SolCodeDescriptionTempRepository extends JpaRepository<SolcodeDescriptionTemp, Integer>{
	
	@Transactional
	@Procedure(procedureName = "sp_promo_claims_sol_description_temp")
	void insertIntoSolCodeDescriptionTemp(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
	


}
