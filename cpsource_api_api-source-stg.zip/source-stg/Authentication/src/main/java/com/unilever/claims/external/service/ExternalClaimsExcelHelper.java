package com.unilever.claims.external.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.unilever.claims.extenal.model.CpsMtFinanceDto;
import com.unilever.claims.extenal.model.ExternalPaymentStatus;
import com.unilever.claims.extenal.model.ExternalServiceNoteMaster;
import com.unilever.promo.claim.external.model.BaseWorking;
import com.unilever.upload.model.StoreListCurrentDetails;

public class ExternalClaimsExcelHelper {

	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	static String[] HEADERs = { "customer_Name", "solecode", "state","moc","payable_claim","invoice_no",
			"base_amt","tax_amt","net_claims"};
	static String SHEET = "Claim_History";
	
	public static List<ExternalPaymentStatus> excelToExternalPaymentStatus(InputStream is) {
		try {
			//Workbook workbook = new XSSFWorkbook(is);
			XSSFWorkbook workbook = new XSSFWorkbook(is); 

			//XSSFSheet sheet = workbook.createSheet(SHEET);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> rows = datatypeSheet.iterator();


			List<ExternalPaymentStatus> externalPaymentStatusList = new ArrayList<ExternalPaymentStatus>();

			int rowNumber = 0;
			while (rows.hasNext()) {
				Row currentRow = rows.next();

				// skip header
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}

				Iterator<Cell> cellsInRow = currentRow.iterator();

				ExternalPaymentStatus externalPaymentStatus = new ExternalPaymentStatus();

				int cellIdx = 0;
				while (cellsInRow.hasNext()) {
					Cell currentCell = cellsInRow.next();
					CellType cellType = currentCell.getCellType();
					String cellDataType = cellType.toString();

					switch (cellIdx) {


					case 18:
						if(cellDataType == "NUMERIC"){
							Integer cellValue = (int)currentCell.getNumericCellValue();
							externalPaymentStatus.setInvoiceNo(cellValue.toString());
						}else{

							externalPaymentStatus.setInvoiceNo(currentCell.getStringCellValue());

						}
						break;


					case 26:

						externalPaymentStatus.setPaidAmt((Double)currentCell.getNumericCellValue());
						break;


					default:
						break;
					}

					cellIdx++;
				}

				externalPaymentStatusList.add(externalPaymentStatus);
			}

			workbook.close();

			return externalPaymentStatusList;
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}
	}


	public static ByteArrayInputStream claimHistoryToExcelByB2C(List<CpsMtFinanceDto> cpsMtFinanceDtoList) {

		try {
			Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();
			Sheet sheet = workbook.createSheet(SHEET);



			//			CellStyle cellStyle = workbook.createCellStyle();
			//			
			//			CellStyle cellStyleColour = workbook.createCellStyle();
			//			CreationHelper createHelper = workbook.getCreationHelper();
			//			

			// Header
			Row headerRow = sheet.createRow(0);



			for (int col = 0; col < HEADERs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERs[col]);
			}


			int rowIdx = 1;
			for (CpsMtFinanceDto sl : cpsMtFinanceDtoList) {


				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(sl.getAccountName());
				row.createCell(1).setCellValue(sl.getSolCode());
				row.createCell(2).setCellValue(sl.getState());
				row.createCell(3).setCellValue(sl.getMoc());
				row.createCell(4).setCellValue(sl.getTotalPayableAmt());

				row.createCell(5).setCellValue(sl.getInvoiceNo());
				row.createCell(6).setCellValue(sl.getBaseAmt());
				row.createCell(7).setCellValue(sl.getTaxAmt());
				row.createCell(8).setCellValue(sl.getClaimRaised());

			}

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}
	
	
}
