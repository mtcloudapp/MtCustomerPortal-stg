package com.unilever.promo.claim.view.model;

import java.io.Serializable;

public class PromoClaimsSummaryDto  implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8621873133366806259L;
	
	private Double customerClaimed;

	private Double lessDeduction;

	private Double basepackNotApplicable;

	private Double invalidClaims;

	private Double noSolCode;
	
	private Double higherMRP;
	
	private Double posVsClaimQuantity;
	
	private Double primaryVsClaimQuantity;
	
	private Double netClaims;
	
	private Double lessOverruns;
	
	private Double overrunApproved;
	
	private Double payables;
	
	private Integer totalRecords;

	public PromoClaimsSummaryDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Double getCustomerClaimed() {
		return customerClaimed;
	}

	public void setCustomerClaimed(Double customerClaimed) {
		this.customerClaimed = customerClaimed;
	}

	public Double getLessDeduction() {
		return lessDeduction;
	}

	public void setLessDeduction(Double lessDeduction) {
		this.lessDeduction = lessDeduction;
	}

	public Double getBasepackNotApplicable() {
		return basepackNotApplicable;
	}

	public void setBasepackNotApplicable(Double basepackNotApplicable) {
		this.basepackNotApplicable = basepackNotApplicable;
	}

	public Double getInvalidClaims() {
		return invalidClaims;
	}

	public void setInvalidClaims(Double invalidClaims) {
		this.invalidClaims = invalidClaims;
	}

	public Double getNoSolCode() {
		return noSolCode;
	}

	public void setNoSolCode(Double noSolCode) {
		this.noSolCode = noSolCode;
	}

	public Double getHigherMRP() {
		return higherMRP;
	}

	public void setHigherMRP(Double higherMRP) {
		this.higherMRP = higherMRP;
	}

	public Double getPosVsClaimQuantity() {
		return posVsClaimQuantity;
	}

	public void setPosVsClaimQuantity(Double posVsClaimQuantity) {
		this.posVsClaimQuantity = posVsClaimQuantity;
	}

	public Double getPrimaryVsClaimQuantity() {
		return primaryVsClaimQuantity;
	}

	public void setPrimaryVsClaimQuantity(Double primaryVsClaimQuantity) {
		this.primaryVsClaimQuantity = primaryVsClaimQuantity;
	}

	public Double getNetClaims() {
		return netClaims;
	}

	public void setNetClaims(Double netClaims) {
		this.netClaims = netClaims;
	}

	public Double getLessOverruns() {
		return lessOverruns;
	}

	public void setLessOverruns(Double lessOverruns) {
		this.lessOverruns = lessOverruns;
	}

	public Double getOverrunApproved() {
		return overrunApproved;
	}

	public void setOverrunApproved(Double overrunApproved) {
		this.overrunApproved = overrunApproved;
	}

	public Double getPayables() {
		return payables;
	}

	public void setPayables(Double payables) {
		this.payables = payables;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	
	
	


}
