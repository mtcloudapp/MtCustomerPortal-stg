package com.unilever.claims.asyncs.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.asset.external.model.CustomerNonCompliantValue;
import com.unilever.asset.external.model.CustomerNonCompliantVolume;
import com.unilever.asset.external.model.ExternalJsonData;
import com.unilever.asset.external.model.OtherIssuesValue;
import com.unilever.asset.external.model.OtherIssuesVolume;
import com.unilever.asset.external.model.TotalAssetValueExternal;
import com.unilever.asset.external.model.TotalAssetVolumeExternal;
import com.unilever.asset.external.model.TrackAndCompliedValue;
import com.unilever.asset.external.model.TrackAndCompliedVolume;
import com.unilever.claims.asyncs.service.AssetClaimAsyncsService;
import com.unilever.claims.extenal.model.ApprovedExceptionClaimsValueExternal;
import com.unilever.claims.extenal.model.ApprovedExceptionClaimsVolumeExternal;
import com.unilever.claims.extenal.model.ClaimsRaisedExternal;
import com.unilever.claims.extenal.model.ExternalClaimsJson;
import com.unilever.claims.extenal.model.PaidClaimsValueExternal;
import com.unilever.claims.extenal.model.RejectedClaimValueExternal;
import com.unilever.claims.extenal.model.RejectedClaimVolumeExternal;
import com.unilever.claims.extenal.model.TotalAmountPlannedExternal;
import com.unilever.claims.extenal.model.UnpaidClaimsValueExternal;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class ExternalAssetClaimsAsyncsController {
	
	private static Logger log = LoggerFactory.getLogger(ExternalAssetClaimsAsyncsController.class);
	
	@Autowired
	private AssetClaimAsyncsService assetClaimAsyncsService;


	@RequestMapping(value = "/getExternalAssetsClaimsData", method = RequestMethod.GET)
	public String getExternalAssetsClaimsData(@RequestParam("account") String account, @RequestParam("region") List<String> region, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
	   
		try{
			 
			CompletableFuture<ApprovedExceptionClaimsValueExternal> approvedExceptionClaimsValue = assetClaimAsyncsService.getApprovedExceptionClaimsValue(account, region, moc, category);
			CompletableFuture<ApprovedExceptionClaimsVolumeExternal> approvedExceptionClaimsVolume = assetClaimAsyncsService.getApprovedExceptionClaimsVolume(account, region, moc, category);
			CompletableFuture<RejectedClaimValueExternal> rejectedClaimValue = assetClaimAsyncsService.getRejectedClaimValue(account, region, moc, category);
			CompletableFuture<RejectedClaimVolumeExternal> rejectedClaimVolume = assetClaimAsyncsService.getRejectedClaimVolume(account, region, moc, category);
			CompletableFuture<TotalAmountPlannedExternal> totalAmountPlanned = assetClaimAsyncsService.getTotalAmountPlaned(account, region, moc, category);
			CompletableFuture<Double> claimsRaised = assetClaimAsyncsService.getClaimRaised(account, region, moc, category);
			CompletableFuture<Double> paidClaimsValue = assetClaimAsyncsService.getPaidClaimsValue(account, region, moc, category);
			CompletableFuture<UnpaidClaimsValueExternal> unpaidClaimsValue = assetClaimAsyncsService.getUnpaidClaimsValue(account, region, moc, category);

			// Wait until they are all done
			CompletableFuture.allOf(approvedExceptionClaimsValue, approvedExceptionClaimsVolume,rejectedClaimValue,rejectedClaimVolume,totalAmountPlanned,claimsRaised,paidClaimsValue,unpaidClaimsValue).join();

			log.info("External ApprovedExceptionClaimsValue--> " + approvedExceptionClaimsValue.get());
			log.info("External ApprovedExceptionClaimsVolume--> " + approvedExceptionClaimsVolume.get());
			log.info("External RejectedClaimValue--> " + rejectedClaimValue.get());
			log.info("External RejectedClaimVolume--> " + rejectedClaimVolume.get());
			log.info("External TotalAmountPlanned--> " + totalAmountPlanned.get());
			log.info("External ClaimsRaised--> " + claimsRaised.get());
			log.info("External PaidClaimsValue--> " + paidClaimsValue.get());
			log.info("External UnpaidClaimsValue--> " + unpaidClaimsValue.get());

			ExternalClaimsJson obj = new ExternalClaimsJson();
			Gson gson = new Gson();

			obj.setApprovedExceptnClaimValue(approvedExceptionClaimsValue.get().getApprovedExceptionClaimsValue());
			obj.setApprovedExceptnClaimVolume(approvedExceptionClaimsVolume.get().getApprovedExceptionClaimsVolume());
			obj.setRejectedClaimValue(rejectedClaimValue.get().getRejectedClaimsValue());
			obj.setRejectedClaimVolume(rejectedClaimVolume.get().getRejectedClaimsVolume());
			obj.setTotalAmountPlanned(totalAmountPlanned.get().getTotalAmountPlanned());
			obj.setClaimsRaised(claimsRaised.get().doubleValue());
			obj.setPaidClaimValue(paidClaimsValue.get().doubleValue());
			obj.setUnpaidClaimValue(unpaidClaimsValue.get().getUnpaidClaimsValue());
			
			json = gson.toJson(obj); 

		}  catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	

}
