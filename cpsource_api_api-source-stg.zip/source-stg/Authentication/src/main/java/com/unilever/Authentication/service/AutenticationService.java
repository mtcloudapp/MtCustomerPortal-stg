package com.unilever.Authentication.service;

import java.io.ByteArrayInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.unilever.Authentication.message.response.ResponseMessage;
import com.unilever.Authentication.model.PPMExtractMOC;
import com.unilever.Authentication.model.SupportUser;
import com.unilever.Authentication.model.UserLog;
import com.unilever.Authentication.repository.PPMExtarxtRepository;
import com.unilever.Authentication.repository.PPMExtractBasePackRepository;
import com.unilever.Authentication.repository.PPMExtractMasterRepository;
import com.unilever.Authentication.repository.PPMExtractMocRepository;
import com.unilever.Authentication.repository.PPMExtractPromoParentChildRepository;
import com.unilever.Authentication.repository.SolCodeDescriptionMasterRepository;
import com.unilever.Authentication.repository.SolCodeDescriptionTempRepository;
import com.unilever.Authentication.repository.SupportUserRepository;
import com.unilever.Authentication.repository.UserLogRepository;
import com.unilever.Authentication.repository.UserRepository;
import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.repository.BaseWorkingRepository;
import com.unilever.promo.claim.external.repository.OverrunClaimRepository;
import com.unilever.promo.claim.external.repository.PromoClaimSummaryRepository;
import com.unilever.upload.service.ExcelHelper;



@Service
public class AutenticationService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JavaMailSender javaMailSender;

	@Autowired
	UserLogRepository userLogRepository;

	@Autowired
	SupportUserRepository supportUserRepository;

	@Autowired
	SolCodeDescriptionTempRepository solCodeDescriptionTempRepository;

	@Autowired
	SolCodeDescriptionMasterRepository solCodeDescriptionMasterRepository;

	@Autowired
	PPMExtractPromoParentChildRepository ppmExtractPromoParentChildRepository;

	@Autowired
	BaseWorkingRepository baseWorkingRepository;

	@Autowired
	OverrunClaimRepository overrunClaimRepository;

	@Autowired
	PromoClaimSummaryRepository promoClaimSummaryRepository;

	@Autowired
	PPMExtractMasterRepository ppmExtractMasterRepository;
	
	@Autowired
	PPMExtractBasePackRepository ppmExtractBasePackRepository;
	
	@Autowired
	PPMExtractMocRepository ppmExtractMocRepository;
	
	@Autowired
	PPMExtarxtRepository ppmExtarxtRepository;

	
	
	private static Logger log = LoggerFactory.getLogger(AutenticationService.class);


	public ResponseMessage changePassword(String username, String recoveryPasswd, String newPassword){

		ResponseMessage respn = new ResponseMessage();

		try{
			List<String> userNameList = new ArrayList<>();
			userNameList = userRepository.findUserNames();

			if(userNameList.contains(username)){

				String dbPassword = userRepository.findPasswordByUsername(username);
				BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

				if(passwordEncoder.matches(recoveryPasswd, dbPassword)){
					String newPass = encoder.encode(newPassword);
					userRepository.updatePassword(newPass, username);
					respn.setMessage("Password Updated Successfully!!");

				}else{
					respn.setMessage("Provided Recovery Password is not correct");
				}

			}else{
				respn.setMessage("Provided Username does not exit");
			}





		}catch(Exception e){
			e.printStackTrace();
		}

		return respn;

	}

	public ResponseMessage chanegePasswordByEmail(String username, String recoveryPasswd, String newPassword){

		ResponseMessage respn = new ResponseMessage();

		try{
			List<String> userNameList = new ArrayList<>();
			userNameList = userRepository.findUserNames();

			if(userNameList.contains(username)){

				String encodedAccessCode = encoder.encode(recoveryPasswd);
				userRepository.updateAccessCodeByUserName(encodedAccessCode, username);
				String dbAccessCode = userRepository.findAccessCodeByUsername(username);
				BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

				if(passwordEncoder.matches(recoveryPasswd, dbAccessCode)){
					String newPass = encoder.encode(newPassword);
					userRepository.updatePassword(newPass, username);
					respn.setMessage("Password Updated Successfully!!");

				}else{
					respn.setMessage("Provided Recovery Password is not correct");
				}

			}else{
				respn.setMessage("Provided Username does not exit");
			}





		}catch(Exception e){
			e.printStackTrace();
		}

		return respn;

	}


	public ResponseMessage validateEmail(String email){
		ResponseMessage respn = new ResponseMessage();
		try{
			List<String>emailList = new ArrayList<>();
			emailList = userRepository.findEmails();
			String username = userRepository.findUsernameByEmailId(email);
			Integer otp = 100000000 + new Random().nextInt(900000000);

			if(emailList.contains(email.trim())){
				log.info("Sending mail start....");
				sendEmail(username,email,otp);
				userRepository.updateAccessCodeByEmail(encoder.encode(otp.toString()), email);
				respn.setMessage("Email Sent");
			}else{
				respn.setMessage("Sorry!! Email does not exist");
			}

		}catch(Exception e){
			e.getStackTrace();
			log.info("Enter catch block 1 "+e);
			System.out.println(e.getStackTrace());

		}
		return respn;
	}


	void sendEmail(String username,String emailId,Integer otp) {

		String from = "no-reply@hulcd.com";
		String host = "localhost";
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);
		String otpMsg = "<b>"+otp+"</b>";
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailId));
			message.setSubject("MT Customer Portal Password Recovery");
			message.setContent("Hi "+username+","
					+ "<br/>"
					+ "Please access the below link to reset your password."
					+ "<br/><br/>"
					+ GlobalVariables.MAIL_URL

					+ "<br/><br/>"+"Please use recovery password "+otpMsg+" to set up your new password from the above link.", "text/html");
			Transport.send(message);
			log.info("Email Sent Successfully");

		} catch (MessagingException mex) {
			// TODO Auto-generated catch block
			mex.printStackTrace();
			log.info("Enter catch block 2"+mex);
		}


	}
	public ByteArrayInputStream getUserLogData() {
		List<UserLog> userLogData = userLogRepository.findUserDetails();
		ByteArrayInputStream in = ExcelHelper.userLogToExcel(userLogData);
		return in;
	}

	public ResponseMessage updateBySupportUserBySolcode(Integer solcode,String solCodeDescpNew){

		ResponseMessage respn = new ResponseMessage();

		try{
			if(solcode !=null){
				Integer supportUserSize = supportUserRepository.findSupportUserBySolCode(solcode);

				if(supportUserSize > 0){
					supportUserRepository.updateBySupportUser(solCodeDescpNew, solcode);
				}

				respn.setMessage("Updated Successfully!!");
			}else{
				respn.setMessage("Provide Solcode to update!!");
			}

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return respn;


	}

	/*public List<SupportUserDto> getSupportUserView(String account,String moc,Integer pageNo, Integer pageSize){

		List<SupportUserDto> supportUserList = new ArrayList<>();
		List<SupportUser> totalRecords = new ArrayList<>();
		try{
			Pageable paging = PageRequest.of(pageNo, pageSize);
			Page<SupportUser> supportUserViewDetails = supportUserRepository.findSupportUserDetailsByAcntAndMoc(account,moc,paging);
			totalRecords = supportUserRepository.findCountByAccountAndMoc();

			for(SupportUser pcs : supportUserViewDetails){

				SupportUserDto supportUserDto = new SupportUserDto();

				supportUserDto.setArticleCode(pcs.getArticleCode());
				supportUserDto.setAccountName(pcs.getAccountName());
				supportUserDto.setMoc(pcs.getMoc());
				supportUserDto.setBasepack(pcs.getBasepack());
				supportUserDto.setSolCode(pcs.getSolCode());
				supportUserDto.setSolCodeDescription(pcs.getSolCodeDescriptionOld());
				supportUserDto.setEntryFieldForUpdatingSolCodeDescription(pcs.getSolCodeDescriptionNew());
				supportUserDto.setTotalRecords(totalRecords.size());

				supportUserList.add(supportUserDto);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return supportUserList;


	}*/

	public ResponseMessage saveBySupportUser(String accountName,String moc){

		ResponseMessage respn = new ResponseMessage();

		try{
			solCodeDescriptionTempRepository.insertIntoSolCodeDescriptionTemp(accountName, moc);
			solCodeDescriptionMasterRepository.insertIntoSolCodeDescriptionMaster();
			ppmExtractPromoParentChildRepository.insertIntoPromoParentChild();
			baseWorkingRepository.insertIntoBaseworking(accountName, moc);
			overrunClaimRepository.insertIntoOverrunClaim(accountName, moc);
			overrunClaimRepository.updateOverrunClaimFinal(accountName, moc);
			promoClaimSummaryRepository.insertIntoPromoClaimSummaryByAccountMOC(accountName, moc);
			respn.setMessage("Saved Successfully");
		}catch(Exception e){
			e.printStackTrace();
			respn.setMessage("Sorry!! Not Saved..");
		}
		return respn;
	}


	public ResponseMessage updateSupportUserBySolcode(List<Integer> solcode,List<String> solCodeDescOld,
			List<String> solCodeDescNew,String account,String moc){

		ResponseMessage respn = new ResponseMessage();

		try{
			
				List<Integer>SolCodeList = supportUserRepository.findSolCode();

				for(int i=0;i<solcode.size();i++){

					SupportUser supportUser = new SupportUser();
					String solCodeDesOld = null;
					Integer solCode = solcode.get(i);
					if(solCodeDescOld.get(i).contains("NULL")){
						solCodeDesOld="";
					}else{
						solCodeDesOld = solCodeDescOld.get(i);
					}
					String  solCodeDesNew = solCodeDescNew.get(i);
					supportUser.setSolCode(solCode);
					supportUser.setSolCodeDescriptionOld(solCodeDesOld);
					supportUser.setSolCodeDescriptionNew(solCodeDesNew);

					if(SolCodeList.contains(solCode)){
						Date date = Calendar.getInstance().getTime();  
						DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
						String strDate = dateFormat.format(date);  

						supportUserRepository.updateBySolcode(solCode, solCodeDesOld, solCodeDesNew,strDate);
					}
					else{

						supportUserRepository.save(supportUser);

					}
				
				}// End of for 
				
				log.info("PPM EXTRACT SP START");
				ppmExtractMasterRepository.insertIntoPPMExtractMaster();
				log.info("PPM EXTRACT SP END");
				
				log.info("PPM Parent Child SP START");
				ppmExtractPromoParentChildRepository.insertIntoPromoParentChild();
				log.info("PPM Parent Child SP END");
				
				log.info("PPM Extract  SP START");
				ppmExtarxtRepository.insertIntoPPMExtarct();
				log.info("PPM Extarct  SP END");
				
				log.info("Convert MOC SP START");
				ppmExtractMocRepository.insertIntoConvertMOC();
				log.info("Convert MOC SP END");
				
				log.info("Baseworking  SP START");
				baseWorkingRepository.insertIntoBaseworking(account, moc);
				log.info("Baseworking  SP END");
				
		
				respn.setMessage("Updated Successfully!!");
			

		}
		catch(Exception e){
			respn.setMessage("Sorry!! Not Update");
			e.printStackTrace();
			
		}
		return respn;
		


	}

}
