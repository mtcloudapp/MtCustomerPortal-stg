package com.unilever.asset.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_STORE_LIST_TOTAL_COUNT")
public class StoreListCount implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4065706904536946484L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="USERNAME")
    private String userName;
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="STORE_LIST_TOTAL_COUNT")
    private Double storeListTotalCount;

	public StoreListCount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StoreListCount(Integer rECORD_ID, String regionName, String userName, String categoryNaame, String moc,
			Double storeListTotalCount) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.userName = userName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.storeListTotalCount = storeListTotalCount;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getStoreListTotalCount() {
		return storeListTotalCount;
	}

	public void setStoreListTotalCount(Double storeListTotalCount) {
		this.storeListTotalCount = storeListTotalCount;
	}
	
	
	

}
