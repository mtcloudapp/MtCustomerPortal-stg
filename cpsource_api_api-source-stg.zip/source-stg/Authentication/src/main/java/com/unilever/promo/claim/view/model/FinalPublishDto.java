package com.unilever.promo.claim.view.model;

import java.io.Serializable;

public class FinalPublishDto implements Serializable{

	
	private static final long serialVersionUID = -6075397445936250818L;
	
	private Integer solCode;
	
	private Double budget;
	
	private Double customerClaimAmt;
	
	private Double b2cSignedOffAmt;
	
	private Double overrunPercentage;
	
	private Double overrunAmt;
	
//	private Double budgetUtilized;
	
	private Double remainingBudget;
	
	private Double approvedOverrun;
	
	private String overrunApprover;

	public FinalPublishDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}

	public Double getBudget() {
		return budget;
	}

	public void setBudget(Double budget) {
		this.budget = budget;
	}

	public Double getCustomerClaimAmt() {
		return customerClaimAmt;
	}

	public void setCustomerClaimAmt(Double customerClaimAmt) {
		this.customerClaimAmt = customerClaimAmt;
	}

	public Double getB2cSignedOffAmt() {
		return b2cSignedOffAmt;
	}

	public void setB2cSignedOffAmt(Double b2cSignedOffAmt) {
		this.b2cSignedOffAmt = b2cSignedOffAmt;
	}

	public Double getOverrunPercentage() {
		return overrunPercentage;
	}

	public void setOverrunPercentage(Double overrunPercentage) {
		this.overrunPercentage = overrunPercentage;
	}

	public Double getOverrunAmt() {
		return overrunAmt;
	}

	public void setOverrunAmt(Double overrunAmt) {
		this.overrunAmt = overrunAmt;
	}

//	public Double getBudgetUtilized() {
//		return budgetUtilized;
//	}
//
//	public void setBudgetUtilized(Double budgetUtilized) {
//		this.budgetUtilized = budgetUtilized;
//	}

	public Double getRemainingBudget() {
		return remainingBudget;
	}

	public void setRemainingBudget(Double remainingBudget) {
		this.remainingBudget = remainingBudget;
	}

	public Double getApprovedOverrun() {
		return approvedOverrun;
	}

	public void setApprovedOverrun(Double approvedOverrun) {
		this.approvedOverrun = approvedOverrun;
	}

	public String getOverrunApprover() {
		return overrunApprover;
	}

	public void setOverrunApprover(String overrunApprover) {
		this.overrunApprover = overrunApprover;
	}
	
	
	
}
