package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.ExternalOtherIssuseValuePrev;
import com.unilever.global.GlobalVariables;

@Repository
public interface OtherIssuseValuePrevRepository  extends JpaRepository<ExternalOtherIssuseValuePrev, Integer>{
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_OTHER_ISSUES_VALUE_PREV etas where etas.USERNAME=:username", nativeQuery = true)
	List<ExternalOtherIssuseValuePrev> findAllOtherIssuesValueExternalDetails(@Param("username") String username);
	
}
