package com.unilever.asset.asyncs.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.asset.asyncs.service.AsyncService;
import com.unilever.asset.external.model.TotalAssetValueExternal;
import com.unilever.asset.external.model.TotalAssetVolumeExternal;
import com.unilever.asset.kam.model.CompliedAssetValue;
import com.unilever.asset.kam.model.CompliedAssetVolume;
import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetValueNext;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetVolumeNext;
import com.unilever.asset.kam.model.JsonObject;
import com.unilever.asset.kam.model.NextMocJson;
import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetVolume;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class KamAsyncController {

	private static Logger log = LoggerFactory.getLogger(KamAsyncController.class);

	@Autowired
	private AsyncService service;

	@GetMapping("/getCurrentMOCKamAssetsData")
	public String getKamAssetsData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			
			CompletableFuture<TotalAssetCreatedValue> totalAssetValues = service.getTotalAssetValue(username, region, account, moc, category);
			CompletableFuture<TotalAssetCreatedVolume> totalAssetVolumes = service.getTotalAssetCreatedVolume(username, region, account, moc, category);
			CompletableFuture<DepotConnectedAssetValue> totalDepotAssetValues = service.getAllDepotConnectedAssetValue(username, region, account, moc, category);
			CompletableFuture<DepotConnectedAssetVolume> totalDepotAssetVolumes = service.getAllDepotConnectedAssetVolume(username, region, account, moc, category);
			CompletableFuture<DeployedAssetValue> totalDeployedAssetValues = service.getAllDeployedAssetValue(username, region, account, moc, category);
			CompletableFuture<DepolyedAssetVolume> totalDeployedAssetVolumes = service.getAllDeployedAssetVolume(username, region, account, moc, category);
			CompletableFuture<CompliedAssetValue> totalCompliedAssetValues = service.getAllCompliedAssetValue(username, region, account, moc, category);
			CompletableFuture<CompliedAssetVolume> totalCompliedAssetVolumes = service.getAllCompliedAssetVolume(username, region, account, moc, category);
			CompletableFuture<NotCompliedAssetValue> totalNotCompliedAssetValues = service.getAllNotCompliedAssetValue(username, region, account, moc, category);
			CompletableFuture<NotCompliedAssetVolume> totalNotCompliedAssetVolumes = service.getAllNotCompliedAssetVolume(username, region, account, moc, category);

			// Wait until they are all done
			CompletableFuture.allOf(totalAssetValues,totalAssetVolumes,totalDepotAssetValues,totalDepotAssetVolumes,totalDeployedAssetValues,totalDeployedAssetVolumes,totalCompliedAssetValues,totalCompliedAssetVolumes,totalNotCompliedAssetValues,totalNotCompliedAssetVolumes).join();

			log.info("TotalAssetValues--> " + totalAssetValues.get());
			log.info("totalAssetVolumes--> " + totalAssetVolumes.get());
			log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
			log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
			log.info("totalDeployedAssetValues--> " + totalDeployedAssetValues.get());
			log.info("totalDeployedAssetVolumes--> " + totalDeployedAssetVolumes.get());
			log.info("totalCompliedAssetValues--> " + totalCompliedAssetValues.get());
			log.info("totalCompliedAssetVolumes--> " + totalCompliedAssetVolumes.get());
			log.info("totalNotCompliedAssetValues--> " + totalNotCompliedAssetValues.get());
			log.info("totalNotCompliedAssetVolumes--> " + totalNotCompliedAssetVolumes.get());

			JsonObject obj = new JsonObject();
			Gson gson = new Gson();

			obj.setTotalAssetValue(totalAssetValues.get().getTotalAssetCreatedValue());
			obj.setTotalAssetVolume(totalAssetVolumes.get().getTotalAssetCreatedVolume());
			obj.setDepotConnectedAssetValue(totalDepotAssetValues.get().getDepotConnectedAssetValue());
			obj.setDepotConnectedAssetVolume(totalDepotAssetVolumes.get().getDepotConnectedAssetVolume());
			obj.setDeployedAssetValue(totalDeployedAssetValues.get().getDeployedAssetValue());
			obj.setDeployedAssetVolume(totalDeployedAssetVolumes.get().getDeployedAssetVolume());
			obj.setComplieddAssetValue(totalCompliedAssetValues.get().getTotalCompliedAssetValue());
			obj.setCompliedAssetVolume(totalCompliedAssetVolumes.get().getTotalCompliedAssetVolume());
			obj.setNotComplieddAssetValue(totalNotCompliedAssetValues.get().getTotalNotCompliedAssetValue());
			obj.setNotCompliedAssetVolume(totalNotCompliedAssetVolumes.get().getTotalNotCompliedAssetVolume());

			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}


	@GetMapping("/getPreviousMOCKamAssetsData")
	public String getPreviousMOCKamAssetsData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
	
		try{

			CompletableFuture<TotalAssetCreatedValue> totalAssetValues = service.getTotalAssetValue(username, region, account, moc, category);
			CompletableFuture<TotalAssetCreatedVolume> totalAssetVolumes = service.getTotalAssetCreatedVolume(username, region, account, moc, category);
			CompletableFuture<DepotConnectedAssetValue> totalDepotAssetValues = service.getAllDepotConnectedAssetValue(username, region, account, moc, category);
			CompletableFuture<DepotConnectedAssetVolume> totalDepotAssetVolumes = service.getAllDepotConnectedAssetVolume(username, region, account, moc, category);
			CompletableFuture<DeployedAssetValue> totalDeployedAssetValues = service.getAllDeployedAssetValue(username, region, account, moc, category);
			CompletableFuture<DepolyedAssetVolume> totalDeployedAssetVolumes = service.getAllDeployedAssetVolume(username, region, account, moc, category);
			CompletableFuture<CompliedAssetValue> totalCompliedAssetValues = service.getAllCompliedAssetValue(username, region, account, moc, category);
			CompletableFuture<CompliedAssetVolume> totalCompliedAssetVolumes = service.getAllCompliedAssetVolume(username, region, account, moc, category);
			CompletableFuture<NotCompliedAssetValue> totalNotCompliedAssetValues = service.getAllNotCompliedAssetValue(username, region, account, moc, category);
			CompletableFuture<NotCompliedAssetVolume> totalNotCompliedAssetVolumes = service.getAllNotCompliedAssetVolume(username, region, account, moc, category);

			
			// Wait until they are all done
			CompletableFuture.allOf(totalAssetValues, totalAssetVolumes, totalDepotAssetValues, totalDepotAssetVolumes,totalDeployedAssetValues,totalDeployedAssetVolumes,totalCompliedAssetValues,totalCompliedAssetVolumes,totalNotCompliedAssetValues,totalNotCompliedAssetVolumes).join();

			log.info("TotalAssetValues--> " + totalAssetValues.get());
			log.info("totalAssetVolumes--> " + totalAssetVolumes.get());
			log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
			log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
			log.info("totalDeployedAssetValues--> " + totalDeployedAssetValues.get());
			log.info("totalDeployedAssetVolumes--> " + totalDeployedAssetVolumes.get());
			log.info("totalCompliedAssetValues--> " + totalCompliedAssetValues.get());
			log.info("totalCompliedAssetVolumes--> " + totalCompliedAssetVolumes.get());
			log.info("totalNotCompliedAssetValues--> " + totalNotCompliedAssetValues.get());
			log.info("totalNotCompliedAssetVolumes--> " + totalNotCompliedAssetVolumes.get());

			JsonObject obj = new JsonObject();
			Gson gson = new Gson();

			obj.setTotalAssetValue(totalAssetValues.get().getTotalAssetCreatedValue());
			obj.setTotalAssetVolume(totalAssetVolumes.get().getTotalAssetCreatedVolume());
			obj.setDepotConnectedAssetValue(totalDepotAssetValues.get().getDepotConnectedAssetValue());
			obj.setDepotConnectedAssetVolume(totalDepotAssetVolumes.get().getDepotConnectedAssetVolume());
			obj.setDeployedAssetValue(totalDeployedAssetValues.get().getDeployedAssetValue());
			obj.setDeployedAssetVolume(totalDeployedAssetVolumes.get().getDeployedAssetVolume());
			obj.setComplieddAssetValue(totalCompliedAssetValues.get().getTotalCompliedAssetValue());
			obj.setCompliedAssetVolume(totalCompliedAssetVolumes.get().getTotalCompliedAssetVolume());
			obj.setNotComplieddAssetValue(totalNotCompliedAssetValues.get().getTotalNotCompliedAssetValue());
			obj.setNotCompliedAssetVolume(totalNotCompliedAssetVolumes.get().getTotalNotCompliedAssetVolume());

			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}


    @GetMapping("/getNextMOCKamAssetsData")
	public String getNextMocKamAssetsData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		  String json = null;
		
          try{
			
        	CompletableFuture<StoreListTotalCount> storeListTotalCount = service.getAllStoreListTotalCount(username, region, account, moc, category);
			CompletableFuture<StoreListTotalValue> storeListTotalValue = service.getAllStoreListTotalValue(username, region, account, moc, category);
			CompletableFuture<PlannedAssetValue> plannedAssetValue = service.getAllPlannedAssetValue(username, region, account, moc, category);
			CompletableFuture<PlannedAssetVolume> plannedAssetVolume = service.getAllPlannedAssetVolume(username, region, account, moc, category);
			CompletableFuture<DepotConnectedAssetValueNext> totalDepotAssetValues = service.getAllNextMocDepotConnectedAssetValue(username, region, account, moc, category);
			CompletableFuture<DepotConnectedAssetVolumeNext> totalDepotAssetVolumes = service.getAllNextMocDepotConnectedAssetVolume(username, region, account, moc, category);



			// Wait until they are all done
			CompletableFuture.allOf(storeListTotalCount, storeListTotalValue,plannedAssetValue,plannedAssetVolume,totalDepotAssetValues,totalDepotAssetVolumes).join();

			log.info("storeListTotalCount--> " + storeListTotalCount.get());
			log.info("storeListTotalValue--> " + storeListTotalValue.get());
			log.info("plannedAssetValue--> " + plannedAssetValue.get());
			log.info("plannedAssetVolume--> " + plannedAssetVolume.get());
			log.info("totalDepotAssetValues--> " + totalDepotAssetValues.get());
			log.info("totalDepotAssetVolumes--> " + totalDepotAssetVolumes.get());

			NextMocJson obj = new NextMocJson();
			Gson gson = new Gson();

			obj.setStoreListTotalCount(storeListTotalCount.get().getStoreListTotalCount());
			obj.setStoreListTotalValue(storeListTotalValue.get().getStoreListTotalValue());
			obj.setPlannedAssetValue(plannedAssetValue.get().getPlannedAssetValue());
			obj.setPlannedAssetVolume(plannedAssetVolume.get().getPlannedAssetVolume());
			obj.setDepotConnetedAssetValue(totalDepotAssetValues.get().getDepotConnectedAssetValue());
			obj.setDepotConnetedAssetVolume(totalDepotAssetVolumes.get().getDepotConnectedAssetVolume());
		    json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}


}
