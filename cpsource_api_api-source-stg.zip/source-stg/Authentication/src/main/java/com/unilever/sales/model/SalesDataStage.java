package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SALES_DATA_DOWNLOAD")
public class SalesDataStage implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7555892249984017940L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
	@Column(name="SHIPTOPARTY")
    private String shiptoparty;
	
	@Column(name="DEPOT")
    private String depot;
	
	@Column(name="BRANCH")
    private String branch;
	
	@Column(name="CATEGORY")
    private String category;
	
	@Column(name="CLUSTER_CODE")
    private String clusterCode;
	
	@Column(name="SALES_CATEGORY")
    private String salesCategory;
	
	@Column(name="SALES_CATEGORY_DESC")
    private String salesCategoryDesc;
	
	@Column(name="CUSTOMER_CHAIN")
    private String custmerChain;
	
	@Column(name="BASEPACK")
    private String basepack;
	
	@Column(name="MATERIAL")
    private String material;
	
	@Column(name="MATERIAL_DESC")
    private String materialDesc;
	
	@Column(name="CIC")
    private String cic;
	
	@Column(name="CUSTOMER_CHAIN_DESC")
    private String customerChainDesc;
	
	@Column(name="ORDER_VALUE")
    private Double orderValue;
	
	@Column(name="ALLOCATE_VALUE")
    private Double allocatedValue;
	
	@Column(name="INVOICE_VALUE")
    private Double invoiceValue;
	
	@Column(name="PO_NUMBER")
    private String poNumber;
	
	@Column(name="SALES_ORDER")
    private String salesOrder;
	
	@Column(name="LINE")
    private String line;
	
	@Column(name="PO_DATE")
    private String poDate;
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="DELIVERY_DATE")
    private String deliveryDate;
	
	@Column(name="C_FINAL_REASON")
    private String cFinalReason;
	
	@Column(name="C_FINAL_HEADER")
    private String cFinalHeader;
	
	@Column(name="C_FINAL_HEADER2")
    private String cFinalHeader2;
	
	@Column(name="C_ACTION")
    private String cAction;

	public SalesDataStage() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

	public SalesDataStage(Integer rECORD_ID, String shiptoparty, String depot, String branch, String category,
			String clusterCode, String salesCategory, String salesCategoryDesc, String custmerChain, String basepack,
			String material, String materialDesc, String cic, String customerChainDesc, Double orderValue,
			Double allocatedValue, Double invoiceValue, String poNumber, String salesOrder, String line, String poDate,
			String moc, String account, String deliveryDate, String cFinalReason, String cFinalHeader,
			String cFinalHeader2, String cAction) {
		super();
		RECORD_ID = rECORD_ID;
		this.shiptoparty = shiptoparty;
		this.depot = depot;
		this.branch = branch;
		this.category = category;
		this.clusterCode = clusterCode;
		this.salesCategory = salesCategory;
		this.salesCategoryDesc = salesCategoryDesc;
		this.custmerChain = custmerChain;
		this.basepack = basepack;
		this.material = material;
		this.materialDesc = materialDesc;
		this.cic = cic;
		this.customerChainDesc = customerChainDesc;
		this.orderValue = orderValue;
		this.allocatedValue = allocatedValue;
		this.invoiceValue = invoiceValue;
		this.poNumber = poNumber;
		this.salesOrder = salesOrder;
		this.line = line;
		this.poDate = poDate;
		this.moc = moc;
		this.account = account;
		this.deliveryDate = deliveryDate;
		this.cFinalReason = cFinalReason;
		this.cFinalHeader = cFinalHeader;
		this.cFinalHeader2 = cFinalHeader2;
		this.cAction = cAction;
	}




	public Integer getRECORD_ID() {
		return RECORD_ID;
	}


	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}


	public String getShiptoparty() {
		return shiptoparty;
	}


	public void setShiptoparty(String shiptoparty) {
		this.shiptoparty = shiptoparty;
	}


	public String getDepot() {
		return depot;
	}


	public void setDepot(String depot) {
		this.depot = depot;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getClusterCode() {
		return clusterCode;
	}


	public void setClusterCode(String clusterCode) {
		this.clusterCode = clusterCode;
	}


	public String getSalesCategory() {
		return salesCategory;
	}


	public void setSalesCategory(String salesCategory) {
		this.salesCategory = salesCategory;
	}


	public String getSalesCategoryDesc() {
		return salesCategoryDesc;
	}


	public void setSalesCategoryDesc(String salesCategoryDesc) {
		this.salesCategoryDesc = salesCategoryDesc;
	}


	public String getCustmerChain() {
		return custmerChain;
	}


	public void setCustmerChain(String custmerChain) {
		this.custmerChain = custmerChain;
	}


	public String getBasepack() {
		return basepack;
	}


	public void setBasepack(String basepack) {
		this.basepack = basepack;
	}


	public String getMaterial() {
		return material;
	}


	public void setMaterial(String material) {
		this.material = material;
	}


	public String getMaterialDesc() {
		return materialDesc;
	}


	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}


	public String getCic() {
		return cic;
	}


	public void setCic(String cic) {
		this.cic = cic;
	}


	public String getCustomerChainDesc() {
		return customerChainDesc;
	}


	public void setCustomerChainDesc(String customerChainDesc) {
		this.customerChainDesc = customerChainDesc;
	}


	public Double getOrderValue() {
		return orderValue;
	}


	public void setOrderValue(Double orderValue) {
		this.orderValue = orderValue;
	}


	public Double getAllocatedValue() {
		return allocatedValue;
	}


	public void setAllocatedValue(Double allocatedValue) {
		this.allocatedValue = allocatedValue;
	}


	public Double getInvoiceValue() {
		return invoiceValue;
	}


	public void setInvoiceValue(Double invoiceValue) {
		this.invoiceValue = invoiceValue;
	}


	public String getPoNumber() {
		return poNumber;
	}


	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}


	public String getSalesOrder() {
		return salesOrder;
	}


	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}


	public String getLine() {
		return line;
	}


	public void setLine(String line) {
		this.line = line;
	}


	public String getPoDate() {
		return poDate;
	}


	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}


	public String getMoc() {
		return moc;
	}


	public void setMoc(String moc) {
		this.moc = moc;
	}


	public String getAccount() {
		return account;
	}


	public void setAccount(String account) {
		this.account = account;
	}


	public String getDeliveryDate() {
		return deliveryDate;
	}


	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}


	public String getcFinalReason() {
		return cFinalReason;
	}


	public void setcFinalReason(String cFinalReason) {
		this.cFinalReason = cFinalReason;
	}


	public String getcFinalHeader() {
		return cFinalHeader;
	}


	public void setcFinalHeader(String cFinalHeader) {
		this.cFinalHeader = cFinalHeader;
	}


	public String getcFinalHeader2() {
		return cFinalHeader2;
	}


	public void setcFinalHeader2(String cFinalHeader2) {
		this.cFinalHeader2 = cFinalHeader2;
	}


	public String getcAction() {
		return cAction;
	}


	public void setcAction(String cAction) {
		this.cAction = cAction;
	}


	
	
	

}
