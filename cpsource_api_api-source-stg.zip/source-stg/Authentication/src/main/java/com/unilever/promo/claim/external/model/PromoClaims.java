package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROMO_CLAIMS")
public class PromoClaims implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -247364704457153812L;
	@Id
	@Column(name="RECORD_ID")
	private Integer recordId;
	
	@Column(name="FILE_NO")
	private Integer fileNo;

	@Column(name="WORKFLOW_STAGE_ID")
	private Integer workflowStageID;

	@Column(name="ACCOUNT_NAME")
	private String accountName;

	@Column(name="MOC")
	private String moc;

	@Column(name="UPLOAD_BY")
	private String uploadBy;

	@Column(name="PARENT_SOL_CODE")
	private Integer parentSolCode;


	@Column(name="CHILD_SOL_CODE")
	private Integer childSolCode;


	@Column(name="BASEPACK")
	private Integer basepack;


	@Column(name="ARTICLE_CODE")
	private Integer articleCode;


	@Column(name="CLAIM_VALUE")
	private Double claimValue;


	@Column(name="CLAIM_QTY")
	private Integer claimQty;


	@Column(name="MRP")
	private Double mrp;

	@Column(name="CLAIM_PER_UNIT")
	private Integer claimPerUnit;

	@Column(name="AUDIT_CREATE_DATE")
	private String auditCreateDate;

	@Column(name="AUDIT_MODIFIED_DATE")
	private String auditModifiedDate;

	public PromoClaims() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public PromoClaims(Integer recordId, Integer fileNo, Integer workflowStageID, String accountName, String moc,
			String uploadBy, Integer parentSolCode, Integer childSolCode, Integer basepack, Integer articleCode,
			Double claimValue, Integer claimQty, Double mrp, Integer claimPerUnit, String auditCreateDate,
			String auditModifiedDate) {
		super();
		this.recordId = recordId;
		this.fileNo = fileNo;
		this.workflowStageID = workflowStageID;
		this.accountName = accountName;
		this.moc = moc;
		this.uploadBy = uploadBy;
		this.parentSolCode = parentSolCode;
		this.childSolCode = childSolCode;
		this.basepack = basepack;
		this.articleCode = articleCode;
		this.claimValue = claimValue;
		this.claimQty = claimQty;
		this.mrp = mrp;
		this.claimPerUnit = claimPerUnit;
		this.auditCreateDate = auditCreateDate;
		this.auditModifiedDate = auditModifiedDate;
	}



	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	public Integer getWorkflowStageID() {
		return workflowStageID;
	}

	public void setWorkflowStageID(Integer workflowStageID) {
		this.workflowStageID = workflowStageID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getUploadBy() {
		return uploadBy;
	}

	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}

	public Integer getParentSolCode() {
		return parentSolCode;
	}

	public void setParentSolCode(Integer parentSolCode) {
		this.parentSolCode = parentSolCode;
	}

	public Integer getChildSolCode() {
		return childSolCode;
	}

	public void setChildSolCode(Integer childSolCode) {
		this.childSolCode = childSolCode;
	}

	public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public Double getClaimValue() {
		return claimValue;
	}

	public void setClaimValue(Double claimValue) {
		this.claimValue = claimValue;
	}

	public Integer getClaimQty() {
		return claimQty;
	}

	public void setClaimQty(Integer claimQty) {
		this.claimQty = claimQty;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}

	public Integer getClaimPerUnit() {
		return claimPerUnit;
	}

	public void setClaimPerUnit(Integer claimPerUnit) {
		this.claimPerUnit = claimPerUnit;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}

	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}

	

}
