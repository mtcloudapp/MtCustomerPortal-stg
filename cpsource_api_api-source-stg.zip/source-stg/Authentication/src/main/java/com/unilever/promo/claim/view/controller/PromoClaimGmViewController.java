package com.unilever.promo.claim.view.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.promo.claim.view.model.BaseWorkingDto;
import com.unilever.promo.claim.view.model.DeductionBucketDto;
import com.unilever.promo.claim.view.model.OverrunClaimDto;
import com.unilever.promo.claim.view.model.PromoClaimFileDto;
import com.unilever.promo.claim.view.model.PromoClaimsSummaryDto;
import com.unilever.promo.claim.view.service.PromoClaimGmViewService;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimGmViewController {
	
	@Autowired
	PromoClaimGmViewService promoClaimGmViewService;

	//======================================= Promo Claim Summary View==================================================
	
	@GetMapping("/getPromoClaimSummaryViewByGM")
	public List<PromoClaimsSummaryDto> getPromoClaimSummaryViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize){

		List<PromoClaimsSummaryDto> promoClaimsSummaryDetails = new ArrayList<PromoClaimsSummaryDto>();
		try{

			promoClaimsSummaryDetails = promoClaimGmViewService.getPromoClaimSummaryView(account, moc, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return promoClaimsSummaryDetails;

	}
	
	//======================================= Promo Claim Customer Claim File==================================================
	
			@GetMapping("/getPromoClaimFileViewByGM")
			public List<PromoClaimFileDto> getPromoClaimFileViewByGM(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
					@RequestParam(defaultValue = "10") Integer pageSize){

				List<PromoClaimFileDto> promoClaimFileDetails = new ArrayList<>();
				try{

					promoClaimFileDetails = promoClaimGmViewService.getPromoClaimFileView(account, moc, pageNo, pageSize);

				}
				catch(Exception e){
					e.printStackTrace();
				}
				return promoClaimFileDetails;

			}

	//======================================= Baseworking View==================================================
	
	@GetMapping("/getBaseworkingViewByGM")
	public List<BaseWorkingDto> getBaseworkingViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
			@RequestParam(defaultValue = "10") Integer pageSize){

		List<BaseWorkingDto> baseworkingDetails = new ArrayList<BaseWorkingDto>();
		try{

			baseworkingDetails = promoClaimGmViewService.getBaseWorkingView(account, moc, pageNo, pageSize);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return baseworkingDetails;

	}

	//======================================= Overrun Report View==================================================
	
		@GetMapping("/getOverrunViewByGM")
		public List<OverrunClaimDto> getOverrunViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<OverrunClaimDto> overrunDetails = new ArrayList<OverrunClaimDto>();
			try{

				overrunDetails = promoClaimGmViewService.getOverrunView(account, moc, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return overrunDetails;

		}

		
		//======================================= Deduction Bucket For No SolCode==================================================
		
		@GetMapping("/getNoSoleCodeViewByGM")
		public List<DeductionBucketDto> getNoSoleCodeViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,
				@RequestParam("bucket") String bucket,
				@RequestParam(defaultValue = "0") Integer pageNo, 
				@RequestParam(defaultValue = "10") Integer pageSize){

			List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
			try{

				deductionBucketDetails = promoClaimGmViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return deductionBucketDetails;

		}
		
		
		
		//======================================= Deduction Bucket For No Basepack==================================================
		
				@GetMapping("/getNoBasepackViewByGM")
				public List<DeductionBucketDto> getNoBasepackViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimGmViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}
				
		
				
				//======================================= Deduction Bucket For POS Deduction==================================================
				
				@GetMapping("/getPOSDeductionViewByGM")
				public List<DeductionBucketDto> getPOSDeductionViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimGmViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}
				
		
	//======================================= Deduction Bucket For Primary Deduction==================================================
				
				@GetMapping("/getPrimaryDeductionViewByGM")
				public List<DeductionBucketDto> getPrimaryDeductionViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimGmViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

				
//======================================= Deduction Bucket For Invalid Claims==================================================
				
				@GetMapping("/getInvalidClaimsViewByGM")
				public List<DeductionBucketDto> getInvalidClaimsViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimGmViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}

				
//======================================= Deduction Bucket For Higher MRP==================================================
				
				@GetMapping("/getHigherMRPViewByGM")
				public List<DeductionBucketDto> getHigherMRPViewByGm(@RequestParam("account") String account, @RequestParam("moc") String moc,
						@RequestParam("bucket") String bucket,
						@RequestParam(defaultValue = "0") Integer pageNo, 
						@RequestParam(defaultValue = "10") Integer pageSize){

					List<DeductionBucketDto> deductionBucketDetails = new ArrayList<DeductionBucketDto>();
					try{

						deductionBucketDetails = promoClaimGmViewService.getNoSolCodeView(account, moc, bucket, pageNo, pageSize);

					}
					catch(Exception e){
						e.printStackTrace();
					}
					return deductionBucketDetails;

				}
}
