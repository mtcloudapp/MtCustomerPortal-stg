package com.unilever.claims.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.extenal.model.ClaimsRaisedExternal;
import com.unilever.global.GlobalVariables;

@Repository
public interface ClaimsRaisedExternalRepository extends JpaRepository<ClaimsRaisedExternal, Integer>{
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_CLAIMS_RAISED etas where etas.USERNAME=:username", nativeQuery = true)
	List<ClaimsRaisedExternal> findAllClaimsRaisedExternalDetails(@Param("username") String username);
	

}
