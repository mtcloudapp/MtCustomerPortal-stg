package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DROP_DATA_DOWNLOAD")
public class DroppedDataStage implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4042043899059981263L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	
	@Column(name="BRANCH")
    private String branch;
	
	@Column(name="ACCOUNT")
    private String account;
	
	@Column(name="CUSTOMER")
    private String customer;
	
	@Column(name="CUSTOMER_CHAIN")
    private String custmerChain;
	
	@Column(name="CIC_CODE")
    private String cicCode;
	

	@Column(name="MOC_MONTH")
    private String mocMonth;
	
	@Column(name="PO_NUMBER")
    private String poNumber;
	
	@Column(name="ORDER_DATE")
    private String oderDate;
	
	@Column(name="MOC")
    private String moc;
	
	@Column(name="DELIVERY_DATE")
    private String delevaryDate;
	
	@Column(name="REASON_CODE")
    private String reasonCode;
	
	@Column(name="SALES_BRAND_VARIANT")
    private String salesBrandCode;
	
	@Column(name="HUL_CBU")
    private String hulCbu;
	
	@Column(name="HUL_CBU_DESC")
    private String hulCbuDesc;
	
	@Column(name="SALES_CATEGORY")
    private String salesCategory;
	
	@Column(name="ORDER_QUANTITY")
    private Integer orderQuentity;

	public DroppedDataStage() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public DroppedDataStage(Integer rECORD_ID, String branch, String account, String customer, String custmerChain,
			String cicCode, String mocMonth, String poNumber, String oderDate, String moc, String delevaryDate,
			String reasonCode, String salesBrandCode, String hulCbu, String hulCbuDesc, String salesCategory,
			Integer orderQuentity) {
		super();
		RECORD_ID = rECORD_ID;
		this.branch = branch;
		this.account = account;
		this.customer = customer;
		this.custmerChain = custmerChain;
		this.cicCode = cicCode;
		this.mocMonth = mocMonth;
		this.poNumber = poNumber;
		this.oderDate = oderDate;
		this.moc = moc;
		this.delevaryDate = delevaryDate;
		this.reasonCode = reasonCode;
		this.salesBrandCode = salesBrandCode;
		this.hulCbu = hulCbu;
		this.hulCbuDesc = hulCbuDesc;
		this.salesCategory = salesCategory;
		this.orderQuentity = orderQuentity;
	}



	public Integer getRECORD_ID() {
		return RECORD_ID;
	}



	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	public String getAccount() {
		return account;
	}



	public void setAccount(String account) {
		this.account = account;
	}



	public String getCustomer() {
		return customer;
	}



	public void setCustomer(String customer) {
		this.customer = customer;
	}



	public String getCustmerChain() {
		return custmerChain;
	}



	public void setCustmerChain(String custmerChain) {
		this.custmerChain = custmerChain;
	}



	public String getCicCode() {
		return cicCode;
	}



	public void setCicCode(String cicCode) {
		this.cicCode = cicCode;
	}



	public String getMocMonth() {
		return mocMonth;
	}



	public void setMocMonth(String mocMonth) {
		this.mocMonth = mocMonth;
	}



	public String getPoNumber() {
		return poNumber;
	}



	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}



	public String getOderDate() {
		return oderDate;
	}



	public void setOderDate(String oderDate) {
		this.oderDate = oderDate;
	}



	public String getMoc() {
		return moc;
	}



	public void setMoc(String moc) {
		this.moc = moc;
	}



	public String getDelevaryDate() {
		return delevaryDate;
	}



	public void setDelevaryDate(String delevaryDate) {
		this.delevaryDate = delevaryDate;
	}



	public String getReasonCode() {
		return reasonCode;
	}



	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}



	public String getSalesBrandCode() {
		return salesBrandCode;
	}



	public void setSalesBrandCode(String salesBrandCode) {
		this.salesBrandCode = salesBrandCode;
	}



	public String getHulCbu() {
		return hulCbu;
	}



	public void setHulCbu(String hulCbu) {
		this.hulCbu = hulCbu;
	}



	public String getHulCbuDesc() {
		return hulCbuDesc;
	}



	public void setHulCbuDesc(String hulCbuDesc) {
		this.hulCbuDesc = hulCbuDesc;
	}



	public String getSalesCategory() {
		return salesCategory;
	}



	public void setSalesCategory(String salesCategory) {
		this.salesCategory = salesCategory;
	}



	public Integer getOrderQuentity() {
		return orderQuentity;
	}



	public void setOrderQuentity(Integer orderQuentity) {
		this.orderQuentity = orderQuentity;
	}



	

}
