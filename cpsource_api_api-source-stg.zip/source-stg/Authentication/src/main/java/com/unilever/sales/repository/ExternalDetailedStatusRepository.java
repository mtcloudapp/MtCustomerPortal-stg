package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.DetailedStatus;
import com.unilever.sales.model.ExternalDetailedStatus;
import com.unilever.sales.model.KamDetailedStatus;

@Repository
public interface ExternalDetailedStatusRepository extends JpaRepository<ExternalDetailedStatus, Integer>{
	
	/*@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status", nativeQuery = true)
	Page<ExternalDetailedStatus> findExternalDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,Pageable pageable);
	*/
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS ORDER BY tac.PO_NUMBER ASC", nativeQuery = true)
	Page<ExternalDetailedStatus> findExternalDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS ORDER BY tac.PO_NUMBER ASC", nativeQuery = true)
	Page<ExternalDetailedStatus> findExternalDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status,Pageable pageable);
	
	@Transactional
    @Query(value ="select SUM(tac.PO_VALUE) from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfPoValue(@Param("account") List<String> account);
	
	
	@Transactional
    @Query(value ="select sum(tac.ALLOCATED_SUM) from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfAllocatedValue(@Param("account") List<String> account);
	
	
	@Transactional
    @Query(value ="select sum(tac.INVOICED_SUM) from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Double> findSumOfInvoiced(@Param("account") List<String> account);
	
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<ExternalDetailedStatus> findExternalCountDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("status") List<String> status);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<ExternalDetailedStatus> findExternalCountDetailedStatusDetails(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
		@Param("status") List<String> status);

	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NO) from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER=:poNumber and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	List<Integer> findExternalNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") String poNumber,@Param("status") List<String> status);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NO) from "+GlobalVariables.schemaName+".EXT_DETAILED_STATUS tac where tac.USERNAME in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.STATUS in :status GROUP BY tac.PO_NUMBER,tac.PO_DATE,tac.DEPOT,tac.DELIVERY_DATE,tac.STATUS", nativeQuery = true)
	Integer findExternalNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("status") List<String> status);

}
