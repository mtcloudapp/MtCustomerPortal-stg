package com.unilever.promo.claim.external.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaimStageFileValidate;

@Repository
public interface PromoClaimStageFileValidateRepository extends JpaRepository<PromoClaimStageFileValidate, Integer>{
  
	@Transactional
    //@Query(value ="select count(1) from "+GlobalVariables.schemaName+".POS_CLAIM_ACCOUNT_FILE_VALIDATE", nativeQuery = true)  //Commented By Sarin Jun2022 - Excel file validation for POS file 
	//Integer findCountPromoClaimStageFileValidate();  //Commented By Sarin Jun2022 - Excel file validation for POS file 
    @Query(value ="select count(1) from "+GlobalVariables.schemaName+".POS_CLAIM_ACCOUNT_FILE_VALIDATE WHERE ACCOUNT_NAME = :account AND FILE_TYPE = :fileType", nativeQuery = true)  //Added By Sarin Jun2022 - Excel file validation for POS file
	Integer findCountPromoClaimStageFileValidate(@Param("account") String account, @Param("fileType") String fileType);  //Added By Sarin Jun2022 - Excel file validation for POS file
	
	@Transactional
	//@Query(value ="select * from "+GlobalVariables.schemaName+".POS_CLAIM_ACCOUNT_FILE_VALIDATE", nativeQuery = true)  //Commented By Sarin Jun2022 - Excel file validation for POS file
	//List<PromoClaimStageFileValidate> getPromoClaimFileErrorList();  //Commented By Sarin Jun2022 - Excel file validation for POS file
	@Query(value ="select * from "+GlobalVariables.schemaName+".POS_CLAIM_ACCOUNT_FILE_VALIDATE WHERE ACCOUNT_NAME = :account AND FILE_TYPE = :fileType", nativeQuery = true)  //Added By Sarin Jun2022 - Excel file validation for POS file 
	List<PromoClaimStageFileValidate> getPromoClaimFileErrorList(@Param("account") String account, @Param("fileType") String fileType);  //Added By Sarin Jun2022 - Excel file validation for POS file 
	
	@Modifying
	@Transactional
    //@Query(value ="truncate table "+GlobalVariables.schemaName+".POS_CLAIM_ACCOUNT_FILE_VALIDATE", nativeQuery = true)  //Commented By Sarin Jun2022 - Excel file validation for POS file
	//void deletePromoClaimStageFileValidate();  //Commented By Sarin Jun2022 - Excel file validation for POS file
	@Query(value ="delete from "+GlobalVariables.schemaName+".POS_CLAIM_ACCOUNT_FILE_VALIDATE WHERE ACCOUNT_NAME = :account AND FILE_TYPE = :fileType", nativeQuery = true)  //Added By Sarin Jun2022 - Excel file validation for POS file
    void deletePromoClaimStageFileValidate(@Param("account") String account, @Param("fileType") String fileType);  //Added By Sarin Jun2022 - Excel file validation for POS file
	
}
