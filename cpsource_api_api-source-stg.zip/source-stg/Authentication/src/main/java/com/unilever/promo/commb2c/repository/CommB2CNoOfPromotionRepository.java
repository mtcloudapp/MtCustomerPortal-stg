package com.unilever.promo.commb2c.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.commb2c.model.CommB2CNoOfPromotion;

@Repository
public interface CommB2CNoOfPromotionRepository extends JpaRepository<CommB2CNoOfPromotion, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_NO_OF_PROMOTIONS", nativeQuery = true)
	List<CommB2CNoOfPromotion> findAllNoOfPromotion();
	
	@Transactional
    @Query(value ="select cnf.NO_OF_PROMOTIONS from "+GlobalVariables.schemaName+".COMMB2C_NO_OF_PROMOTIONS cnf where cnf.ACCOUNT_NAME in :account "
    		+ "and cnf.MOC in :moc and cnf.REGION_NAME in :region and cnf.CATEGORY_NAME in :category", nativeQuery = true)
	List<String> findDistinctNoOfPromotion(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);

}
