package com.unilever.asset.kam.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INT_DEPOT_CONNECTED_ASSETS_VOLUME")
public class DepotConnectedAssetVolume implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7335905648700165987L;
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="USERNAME")
    private String userName;
	
	@Column(name="ACCOUNT_NAME")
    private String accountName;
	
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="DEPOT_CONNECTED_ASSETS_Volume")
    private Integer depotConnectedAssetVolume;

	public DepotConnectedAssetVolume() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DepotConnectedAssetVolume(Integer rECORD_ID, String regionName, String userName, String accountName,
			String categoryNaame, String moc, Integer depotConnectedAssetVolume) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.userName = userName;
		this.accountName = accountName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.depotConnectedAssetVolume = depotConnectedAssetVolume;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Integer getDepotConnectedAssetVolume() {
		return depotConnectedAssetVolume;
	}

	public void setDepotConnectedAssetVolume(Integer depotConnectedAssetVolume) {
		this.depotConnectedAssetVolume = depotConnectedAssetVolume;
	}

	
}
