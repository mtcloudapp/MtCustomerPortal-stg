package com.unilever.claims.kam.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INT_GREEN_CLAIMS_VALUE")
public class GreenClaimValue implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7823311432566626687L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="USERNAME")
    private String userName;
	
	@Column(name="ACCOUNT_NAME")
    private String accountName;
	
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="GREEN_CLAIMS_VALUE")
    private Double greenClaimValue;

	public GreenClaimValue() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GreenClaimValue(Integer rECORD_ID, String regionName, String userName, String accountName,
			String categoryNaame, String moc, Double greenClaimValue) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.userName = userName;
		this.accountName = accountName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.greenClaimValue = greenClaimValue;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getGreenClaimValue() {
		return greenClaimValue;
	}

	public void setGreenClaimValue(Double greenClaimValue) {
		this.greenClaimValue = greenClaimValue;
	}
	
	

}
