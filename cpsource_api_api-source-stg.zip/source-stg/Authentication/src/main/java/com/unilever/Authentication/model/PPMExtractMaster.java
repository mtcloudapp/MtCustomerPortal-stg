package com.unilever.Authentication.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "PPM_EXTRACT_MASTER")
public class PPMExtractMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7231327164954191132L;
	
	@Id
	private Integer PROMOTION_ID;
	
	@Column(name="PROMOTION_NAME")
    private String PROMOTION_NAME;
	
	@Column(name="CREATED_BY")
    private String CREATED_BY;
	
	@Column(name="CREATED_ON")
    private Date CREATED_ON;
	
	@Column(name="PROJECT_ID")
    private Integer PROJECT_ID;
	
	@Column(name="PROJECT_NAME")
    private String PROJECT_NAME;
	
	@Column(name="BUNDLE_ID")
    private Integer BUNDLE_ID;
	
	@Column(name="BUNDLE_NAME")
    private String BUNDLE_NAME;
	
	@Column(name="PROMOTION_QUALIFICATION")
    private String PROMOTION_QUALIFICATION;
	
	@Column(name="PROMOTION_OBJECTIVE")
    private String PROMOTION_OBJECTIVE;
	
	@Column(name="MARKETING_OBJECTIVE")
    private String MARKETING_OBJECTIVE;
	
	@Column(name="PROMOTION_START_DATE")
    private Date PROMOTION_START_DATE;
	
	@Column(name="PROMOTION_END_DATE")
    private Date PROMOTION_END_DATE;
	
	@Column(name="PRE_DIP_START_DATE")
    private Date PRE_DIP_START_DATE;
	
	@Column(name="POST_DIP_END_DATE")
    private Date POST_DIP_END_DATE;
	
	@Column(name="CUSTOMER")
    private String CUSTOMER;
	
	@Column(name="BUSINESS")
    private String BUSINESS;
	
	@Column(name="DIVISION")
    private String DIVISION;
	
	@Column(name="PRODUCT")
    private String PRODUCT;
	
	@Column(name="CATEGORY")
    private String CATEGORY;
	
	@Column(name="BRAND")
    private String BRAND;
	
	@Column(name="SUB_BRAND")
    private String SUB_BRAND;
	
	@Column(name="PROMOTION_STATUS")
    private String PROMOTION_STATUS;
	
	@Column(name="INVESTMENT_TYPE")
    private String INVESTMENT_TYPE;
	
	@Column(name="MOC")
    private String MOC;
	
	@Column(name="SUBMISSION_DATE")
    private Date SUBMISSION_DATE;
	
	@Column(name="APPROVED_DATE")
    private Date APPROVED_DATE;
	
	@Column(name="MODIFIED_DATE")
    private Date MODIFIED_DATE;
	
	@Column(name="PROMOTION_TYPE")
    private String PROMOTION_TYPE;
	
	@Column(name="DURATION")
    private String DURATION;
	
	@Column(name="FREE_PRODUCT_NAME")
    private String FREE_PRODUCT_NAME;
	
	@Column(name="PRICE_OFF")
    private Double PRICE_OFF;
	
	@Column(name="BASELINE_QUANTITY")
    private Double BASELINE_QUANTITY;
	
	@Column(name="BASELINE_GSV")
    private Double BASELINE_GSV;
	
	@Column(name="BASELINE_TURNOVER")
    private Double BASELINE_TURNOVER;
	
	@Column(name="BASELINE_GROSS_PROFIT")
    private Double BASELINE_GROSS_PROFIT;
	
	@Column(name="PROMOTION_VOLUME_BEFORE")
    private Double PROMOTION_VOLUME_BEFORE;
	
	@Column(name="PROMOTION_VOLUME_DURING")
    private Double PROMOTION_VOLUME_DURING;
	
	@Column(name="PROMOTION_VOLUME_AFTER")
    private Double PROMOTION_VOLUME_AFTER;
	
	@Column(name="PLANNED_GSV")
    private Double PLANNED_GSV;
	
	@Column(name="PLANNED_TURNOVER")
    private Double PLANNED_TURNOVER;
	
	@Column(name="PLANNED_INVESTMENT_AMOUNT")
    private String PLANNED_INVESTMENT_AMOUNT;
	
	@Column(name="PLANNED_UPLIFT")
    private Double PLANNED_UPLIFT;
	
	@Column(name="PLANNED_INCREMENTAL_GROSS_PROFIT")
    private Double PLANNED_INCREMENTAL_GROSS_PROFIT;
	
	@Column(name="PLANNED_GROSS_PROFIT")
    private Double PLANNED_GROSS_PROFIT;
	
	@Column(name="PLANNED_INCREMENTAL_TURNOVER")
    private Double PLANNED_INCREMENTAL_TURNOVER;
	
	@Column(name="PLANNED_CUSTOMER_ROI")
    private Double PLANNED_CUSTOMER_ROI;
	
	@Column(name="PLANNED_COST_PRICE_BASED_ROI")
    private Double PLANNED_COST_PRICE_BASED_ROI;
	
	@Column(name="PLANNED_PROMOTION_ROI")
    private Double PLANNED_PROMOTION_ROI;
	
	@Column(name="ACTUAL_QUANTITY")
    private Double ACTUAL_QUANTITY;
	
	@Column(name="ACTUAL_GSV")
    private Double ACTUAL_GSV;
	
	@Column(name="ACTUAL_TURNOVER")
    private Double ACTUAL_TURNOVER;
	
	@Column(name="ACTUAL_INVESTMENT_AMOUNT")
    private Double ACTUAL_INVESTMENT_AMOUNT;
	
	@Column(name="ACTUAL_UPLIFT")
    private Double ACTUAL_UPLIFT;
	
	@Column(name="ACTUAL_INCREMENTAL_GROSS_PROFIT")
    private Double ACTUAL_INCREMENTAL_GROSS_PROFIT;
	
	@Column(name="ACTUAL_GROSS_PROFIT")
    private Double ACTUAL_GROSS_PROFIT;
	
	@Column(name="ACTUAL_INCREMENTAL_TURNOVER")
    private Double ACTUAL_INCREMENTAL_TURNOVER;
	
	@Column(name="ACTUAL_CUSTOMER_ROI")
    private Double ACTUAL_CUSTOMER_ROI;
	
	@Column(name="ACTUAL_COST_PRICE_BASED_ROI")
    private Double ACTUAL_COST_PRICE_BASED_ROI;
	
	@Column(name="ACTUAL_PROMOTION_ROI")
    private Double ACTUAL_PROMOTION_ROI;
	
	@Column(name="UPLOAD_REFERENCE_NUMBER")
    private String UPLOAD_REFERENCE_NUMBER;
	
	@Column(name="IS_DUPLICATE")
    private String IS_DUPLICATE;

	public PPMExtractMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PPMExtractMaster(Integer pROMOTION_ID, String pROMOTION_NAME, String cREATED_BY, Date cREATED_ON,
			Integer pROJECT_ID, String pROJECT_NAME, Integer bUNDLE_ID, String bUNDLE_NAME,
			String pROMOTION_QUALIFICATION, String pROMOTION_OBJECTIVE, String mARKETING_OBJECTIVE,
			Date pROMOTION_START_DATE, Date pROMOTION_END_DATE, Date pRE_DIP_START_DATE, Date pOST_DIP_END_DATE,
			String cUSTOMER, String bUSINESS, String dIVISION, String pRODUCT, String cATEGORY, String bRAND,
			String sUB_BRAND, String pROMOTION_STATUS, String iNVESTMENT_TYPE, String mOC, Date sUBMISSION_DATE,
			Date aPPROVED_DATE, Date mODIFIED_DATE, String pROMOTION_TYPE, String dURATION, String fREE_PRODUCT_NAME,
			Double pRICE_OFF, Double bASELINE_QUANTITY, Double bASELINE_GSV, Double bASELINE_TURNOVER,
			Double bASELINE_GROSS_PROFIT, Double pROMOTION_VOLUME_BEFORE, Double pROMOTION_VOLUME_DURING,
			Double pROMOTION_VOLUME_AFTER, Double pLANNED_GSV, Double pLANNED_TURNOVER,
			String pLANNED_INVESTMENT_AMOUNT, Double pLANNED_UPLIFT, Double pLANNED_INCREMENTAL_GROSS_PROFIT,
			Double pLANNED_GROSS_PROFIT, Double pLANNED_INCREMENTAL_TURNOVER, Double pLANNED_CUSTOMER_ROI,
			Double pLANNED_COST_PRICE_BASED_ROI, Double pLANNED_PROMOTION_ROI, Double aCTUAL_QUANTITY,
			Double aCTUAL_GSV, Double aCTUAL_TURNOVER, Double aCTUAL_INVESTMENT_AMOUNT, Double aCTUAL_UPLIFT,
			Double aCTUAL_INCREMENTAL_GROSS_PROFIT, Double aCTUAL_GROSS_PROFIT, Double aCTUAL_INCREMENTAL_TURNOVER,
			Double aCTUAL_CUSTOMER_ROI, Double aCTUAL_COST_PRICE_BASED_ROI, Double aCTUAL_PROMOTION_ROI,
			String uPLOAD_REFERENCE_NUMBER, String iS_DUPLICATE) {
		super();
		PROMOTION_ID = pROMOTION_ID;
		PROMOTION_NAME = pROMOTION_NAME;
		CREATED_BY = cREATED_BY;
		CREATED_ON = cREATED_ON;
		PROJECT_ID = pROJECT_ID;
		PROJECT_NAME = pROJECT_NAME;
		BUNDLE_ID = bUNDLE_ID;
		BUNDLE_NAME = bUNDLE_NAME;
		PROMOTION_QUALIFICATION = pROMOTION_QUALIFICATION;
		PROMOTION_OBJECTIVE = pROMOTION_OBJECTIVE;
		MARKETING_OBJECTIVE = mARKETING_OBJECTIVE;
		PROMOTION_START_DATE = pROMOTION_START_DATE;
		PROMOTION_END_DATE = pROMOTION_END_DATE;
		PRE_DIP_START_DATE = pRE_DIP_START_DATE;
		POST_DIP_END_DATE = pOST_DIP_END_DATE;
		CUSTOMER = cUSTOMER;
		BUSINESS = bUSINESS;
		DIVISION = dIVISION;
		PRODUCT = pRODUCT;
		CATEGORY = cATEGORY;
		BRAND = bRAND;
		SUB_BRAND = sUB_BRAND;
		PROMOTION_STATUS = pROMOTION_STATUS;
		INVESTMENT_TYPE = iNVESTMENT_TYPE;
		MOC = mOC;
		SUBMISSION_DATE = sUBMISSION_DATE;
		APPROVED_DATE = aPPROVED_DATE;
		MODIFIED_DATE = mODIFIED_DATE;
		PROMOTION_TYPE = pROMOTION_TYPE;
		DURATION = dURATION;
		FREE_PRODUCT_NAME = fREE_PRODUCT_NAME;
		PRICE_OFF = pRICE_OFF;
		BASELINE_QUANTITY = bASELINE_QUANTITY;
		BASELINE_GSV = bASELINE_GSV;
		BASELINE_TURNOVER = bASELINE_TURNOVER;
		BASELINE_GROSS_PROFIT = bASELINE_GROSS_PROFIT;
		PROMOTION_VOLUME_BEFORE = pROMOTION_VOLUME_BEFORE;
		PROMOTION_VOLUME_DURING = pROMOTION_VOLUME_DURING;
		PROMOTION_VOLUME_AFTER = pROMOTION_VOLUME_AFTER;
		PLANNED_GSV = pLANNED_GSV;
		PLANNED_TURNOVER = pLANNED_TURNOVER;
		PLANNED_INVESTMENT_AMOUNT = pLANNED_INVESTMENT_AMOUNT;
		PLANNED_UPLIFT = pLANNED_UPLIFT;
		PLANNED_INCREMENTAL_GROSS_PROFIT = pLANNED_INCREMENTAL_GROSS_PROFIT;
		PLANNED_GROSS_PROFIT = pLANNED_GROSS_PROFIT;
		PLANNED_INCREMENTAL_TURNOVER = pLANNED_INCREMENTAL_TURNOVER;
		PLANNED_CUSTOMER_ROI = pLANNED_CUSTOMER_ROI;
		PLANNED_COST_PRICE_BASED_ROI = pLANNED_COST_PRICE_BASED_ROI;
		PLANNED_PROMOTION_ROI = pLANNED_PROMOTION_ROI;
		ACTUAL_QUANTITY = aCTUAL_QUANTITY;
		ACTUAL_GSV = aCTUAL_GSV;
		ACTUAL_TURNOVER = aCTUAL_TURNOVER;
		ACTUAL_INVESTMENT_AMOUNT = aCTUAL_INVESTMENT_AMOUNT;
		ACTUAL_UPLIFT = aCTUAL_UPLIFT;
		ACTUAL_INCREMENTAL_GROSS_PROFIT = aCTUAL_INCREMENTAL_GROSS_PROFIT;
		ACTUAL_GROSS_PROFIT = aCTUAL_GROSS_PROFIT;
		ACTUAL_INCREMENTAL_TURNOVER = aCTUAL_INCREMENTAL_TURNOVER;
		ACTUAL_CUSTOMER_ROI = aCTUAL_CUSTOMER_ROI;
		ACTUAL_COST_PRICE_BASED_ROI = aCTUAL_COST_PRICE_BASED_ROI;
		ACTUAL_PROMOTION_ROI = aCTUAL_PROMOTION_ROI;
		UPLOAD_REFERENCE_NUMBER = uPLOAD_REFERENCE_NUMBER;
		IS_DUPLICATE = iS_DUPLICATE;
	}

	public Integer getPROMOTION_ID() {
		return PROMOTION_ID;
	}

	public void setPROMOTION_ID(Integer pROMOTION_ID) {
		PROMOTION_ID = pROMOTION_ID;
	}

	public String getPROMOTION_NAME() {
		return PROMOTION_NAME;
	}

	public void setPROMOTION_NAME(String pROMOTION_NAME) {
		PROMOTION_NAME = pROMOTION_NAME;
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}

	public Date getCREATED_ON() {
		return CREATED_ON;
	}

	public void setCREATED_ON(Date cREATED_ON) {
		CREATED_ON = cREATED_ON;
	}

	public Integer getPROJECT_ID() {
		return PROJECT_ID;
	}

	public void setPROJECT_ID(Integer pROJECT_ID) {
		PROJECT_ID = pROJECT_ID;
	}

	public String getPROJECT_NAME() {
		return PROJECT_NAME;
	}

	public void setPROJECT_NAME(String pROJECT_NAME) {
		PROJECT_NAME = pROJECT_NAME;
	}

	public Integer getBUNDLE_ID() {
		return BUNDLE_ID;
	}

	public void setBUNDLE_ID(Integer bUNDLE_ID) {
		BUNDLE_ID = bUNDLE_ID;
	}

	public String getBUNDLE_NAME() {
		return BUNDLE_NAME;
	}

	public void setBUNDLE_NAME(String bUNDLE_NAME) {
		BUNDLE_NAME = bUNDLE_NAME;
	}

	public String getPROMOTION_QUALIFICATION() {
		return PROMOTION_QUALIFICATION;
	}

	public void setPROMOTION_QUALIFICATION(String pROMOTION_QUALIFICATION) {
		PROMOTION_QUALIFICATION = pROMOTION_QUALIFICATION;
	}

	public String getPROMOTION_OBJECTIVE() {
		return PROMOTION_OBJECTIVE;
	}

	public void setPROMOTION_OBJECTIVE(String pROMOTION_OBJECTIVE) {
		PROMOTION_OBJECTIVE = pROMOTION_OBJECTIVE;
	}

	public String getMARKETING_OBJECTIVE() {
		return MARKETING_OBJECTIVE;
	}

	public void setMARKETING_OBJECTIVE(String mARKETING_OBJECTIVE) {
		MARKETING_OBJECTIVE = mARKETING_OBJECTIVE;
	}

	public Date getPROMOTION_START_DATE() {
		return PROMOTION_START_DATE;
	}

	public void setPROMOTION_START_DATE(Date pROMOTION_START_DATE) {
		PROMOTION_START_DATE = pROMOTION_START_DATE;
	}

	public Date getPROMOTION_END_DATE() {
		return PROMOTION_END_DATE;
	}

	public void setPROMOTION_END_DATE(Date pROMOTION_END_DATE) {
		PROMOTION_END_DATE = pROMOTION_END_DATE;
	}

	public Date getPRE_DIP_START_DATE() {
		return PRE_DIP_START_DATE;
	}

	public void setPRE_DIP_START_DATE(Date pRE_DIP_START_DATE) {
		PRE_DIP_START_DATE = pRE_DIP_START_DATE;
	}

	public Date getPOST_DIP_END_DATE() {
		return POST_DIP_END_DATE;
	}

	public void setPOST_DIP_END_DATE(Date pOST_DIP_END_DATE) {
		POST_DIP_END_DATE = pOST_DIP_END_DATE;
	}

	public String getCUSTOMER() {
		return CUSTOMER;
	}

	public void setCUSTOMER(String cUSTOMER) {
		CUSTOMER = cUSTOMER;
	}

	public String getBUSINESS() {
		return BUSINESS;
	}

	public void setBUSINESS(String bUSINESS) {
		BUSINESS = bUSINESS;
	}

	public String getDIVISION() {
		return DIVISION;
	}

	public void setDIVISION(String dIVISION) {
		DIVISION = dIVISION;
	}

	public String getPRODUCT() {
		return PRODUCT;
	}

	public void setPRODUCT(String pRODUCT) {
		PRODUCT = pRODUCT;
	}

	public String getCATEGORY() {
		return CATEGORY;
	}

	public void setCATEGORY(String cATEGORY) {
		CATEGORY = cATEGORY;
	}

	public String getBRAND() {
		return BRAND;
	}

	public void setBRAND(String bRAND) {
		BRAND = bRAND;
	}

	public String getSUB_BRAND() {
		return SUB_BRAND;
	}

	public void setSUB_BRAND(String sUB_BRAND) {
		SUB_BRAND = sUB_BRAND;
	}

	public String getPROMOTION_STATUS() {
		return PROMOTION_STATUS;
	}

	public void setPROMOTION_STATUS(String pROMOTION_STATUS) {
		PROMOTION_STATUS = pROMOTION_STATUS;
	}

	public String getINVESTMENT_TYPE() {
		return INVESTMENT_TYPE;
	}

	public void setINVESTMENT_TYPE(String iNVESTMENT_TYPE) {
		INVESTMENT_TYPE = iNVESTMENT_TYPE;
	}

	public String getMOC() {
		return MOC;
	}

	public void setMOC(String mOC) {
		MOC = mOC;
	}

	public Date getSUBMISSION_DATE() {
		return SUBMISSION_DATE;
	}

	public void setSUBMISSION_DATE(Date sUBMISSION_DATE) {
		SUBMISSION_DATE = sUBMISSION_DATE;
	}

	public Date getAPPROVED_DATE() {
		return APPROVED_DATE;
	}

	public void setAPPROVED_DATE(Date aPPROVED_DATE) {
		APPROVED_DATE = aPPROVED_DATE;
	}

	public Date getMODIFIED_DATE() {
		return MODIFIED_DATE;
	}

	public void setMODIFIED_DATE(Date mODIFIED_DATE) {
		MODIFIED_DATE = mODIFIED_DATE;
	}

	public String getPROMOTION_TYPE() {
		return PROMOTION_TYPE;
	}

	public void setPROMOTION_TYPE(String pROMOTION_TYPE) {
		PROMOTION_TYPE = pROMOTION_TYPE;
	}

	public String getDURATION() {
		return DURATION;
	}

	public void setDURATION(String dURATION) {
		DURATION = dURATION;
	}

	public String getFREE_PRODUCT_NAME() {
		return FREE_PRODUCT_NAME;
	}

	public void setFREE_PRODUCT_NAME(String fREE_PRODUCT_NAME) {
		FREE_PRODUCT_NAME = fREE_PRODUCT_NAME;
	}

	public Double getPRICE_OFF() {
		return PRICE_OFF;
	}

	public void setPRICE_OFF(Double pRICE_OFF) {
		PRICE_OFF = pRICE_OFF;
	}

	public Double getBASELINE_QUANTITY() {
		return BASELINE_QUANTITY;
	}

	public void setBASELINE_QUANTITY(Double bASELINE_QUANTITY) {
		BASELINE_QUANTITY = bASELINE_QUANTITY;
	}

	public Double getBASELINE_GSV() {
		return BASELINE_GSV;
	}

	public void setBASELINE_GSV(Double bASELINE_GSV) {
		BASELINE_GSV = bASELINE_GSV;
	}

	public Double getBASELINE_TURNOVER() {
		return BASELINE_TURNOVER;
	}

	public void setBASELINE_TURNOVER(Double bASELINE_TURNOVER) {
		BASELINE_TURNOVER = bASELINE_TURNOVER;
	}

	public Double getBASELINE_GROSS_PROFIT() {
		return BASELINE_GROSS_PROFIT;
	}

	public void setBASELINE_GROSS_PROFIT(Double bASELINE_GROSS_PROFIT) {
		BASELINE_GROSS_PROFIT = bASELINE_GROSS_PROFIT;
	}

	public Double getPROMOTION_VOLUME_BEFORE() {
		return PROMOTION_VOLUME_BEFORE;
	}

	public void setPROMOTION_VOLUME_BEFORE(Double pROMOTION_VOLUME_BEFORE) {
		PROMOTION_VOLUME_BEFORE = pROMOTION_VOLUME_BEFORE;
	}

	public Double getPROMOTION_VOLUME_DURING() {
		return PROMOTION_VOLUME_DURING;
	}

	public void setPROMOTION_VOLUME_DURING(Double pROMOTION_VOLUME_DURING) {
		PROMOTION_VOLUME_DURING = pROMOTION_VOLUME_DURING;
	}

	public Double getPROMOTION_VOLUME_AFTER() {
		return PROMOTION_VOLUME_AFTER;
	}

	public void setPROMOTION_VOLUME_AFTER(Double pROMOTION_VOLUME_AFTER) {
		PROMOTION_VOLUME_AFTER = pROMOTION_VOLUME_AFTER;
	}

	public Double getPLANNED_GSV() {
		return PLANNED_GSV;
	}

	public void setPLANNED_GSV(Double pLANNED_GSV) {
		PLANNED_GSV = pLANNED_GSV;
	}

	public Double getPLANNED_TURNOVER() {
		return PLANNED_TURNOVER;
	}

	public void setPLANNED_TURNOVER(Double pLANNED_TURNOVER) {
		PLANNED_TURNOVER = pLANNED_TURNOVER;
	}

	public String getPLANNED_INVESTMENT_AMOUNT() {
		return PLANNED_INVESTMENT_AMOUNT;
	}

	public void setPLANNED_INVESTMENT_AMOUNT(String pLANNED_INVESTMENT_AMOUNT) {
		PLANNED_INVESTMENT_AMOUNT = pLANNED_INVESTMENT_AMOUNT;
	}

	public Double getPLANNED_UPLIFT() {
		return PLANNED_UPLIFT;
	}

	public void setPLANNED_UPLIFT(Double pLANNED_UPLIFT) {
		PLANNED_UPLIFT = pLANNED_UPLIFT;
	}

	public Double getPLANNED_INCREMENTAL_GROSS_PROFIT() {
		return PLANNED_INCREMENTAL_GROSS_PROFIT;
	}

	public void setPLANNED_INCREMENTAL_GROSS_PROFIT(Double pLANNED_INCREMENTAL_GROSS_PROFIT) {
		PLANNED_INCREMENTAL_GROSS_PROFIT = pLANNED_INCREMENTAL_GROSS_PROFIT;
	}

	public Double getPLANNED_GROSS_PROFIT() {
		return PLANNED_GROSS_PROFIT;
	}

	public void setPLANNED_GROSS_PROFIT(Double pLANNED_GROSS_PROFIT) {
		PLANNED_GROSS_PROFIT = pLANNED_GROSS_PROFIT;
	}

	public Double getPLANNED_INCREMENTAL_TURNOVER() {
		return PLANNED_INCREMENTAL_TURNOVER;
	}

	public void setPLANNED_INCREMENTAL_TURNOVER(Double pLANNED_INCREMENTAL_TURNOVER) {
		PLANNED_INCREMENTAL_TURNOVER = pLANNED_INCREMENTAL_TURNOVER;
	}

	public Double getPLANNED_CUSTOMER_ROI() {
		return PLANNED_CUSTOMER_ROI;
	}

	public void setPLANNED_CUSTOMER_ROI(Double pLANNED_CUSTOMER_ROI) {
		PLANNED_CUSTOMER_ROI = pLANNED_CUSTOMER_ROI;
	}

	public Double getPLANNED_COST_PRICE_BASED_ROI() {
		return PLANNED_COST_PRICE_BASED_ROI;
	}

	public void setPLANNED_COST_PRICE_BASED_ROI(Double pLANNED_COST_PRICE_BASED_ROI) {
		PLANNED_COST_PRICE_BASED_ROI = pLANNED_COST_PRICE_BASED_ROI;
	}

	public Double getPLANNED_PROMOTION_ROI() {
		return PLANNED_PROMOTION_ROI;
	}

	public void setPLANNED_PROMOTION_ROI(Double pLANNED_PROMOTION_ROI) {
		PLANNED_PROMOTION_ROI = pLANNED_PROMOTION_ROI;
	}

	public Double getACTUAL_QUANTITY() {
		return ACTUAL_QUANTITY;
	}

	public void setACTUAL_QUANTITY(Double aCTUAL_QUANTITY) {
		ACTUAL_QUANTITY = aCTUAL_QUANTITY;
	}

	public Double getACTUAL_GSV() {
		return ACTUAL_GSV;
	}

	public void setACTUAL_GSV(Double aCTUAL_GSV) {
		ACTUAL_GSV = aCTUAL_GSV;
	}

	public Double getACTUAL_TURNOVER() {
		return ACTUAL_TURNOVER;
	}

	public void setACTUAL_TURNOVER(Double aCTUAL_TURNOVER) {
		ACTUAL_TURNOVER = aCTUAL_TURNOVER;
	}

	public Double getACTUAL_INVESTMENT_AMOUNT() {
		return ACTUAL_INVESTMENT_AMOUNT;
	}

	public void setACTUAL_INVESTMENT_AMOUNT(Double aCTUAL_INVESTMENT_AMOUNT) {
		ACTUAL_INVESTMENT_AMOUNT = aCTUAL_INVESTMENT_AMOUNT;
	}

	public Double getACTUAL_UPLIFT() {
		return ACTUAL_UPLIFT;
	}

	public void setACTUAL_UPLIFT(Double aCTUAL_UPLIFT) {
		ACTUAL_UPLIFT = aCTUAL_UPLIFT;
	}

	public Double getACTUAL_INCREMENTAL_GROSS_PROFIT() {
		return ACTUAL_INCREMENTAL_GROSS_PROFIT;
	}

	public void setACTUAL_INCREMENTAL_GROSS_PROFIT(Double aCTUAL_INCREMENTAL_GROSS_PROFIT) {
		ACTUAL_INCREMENTAL_GROSS_PROFIT = aCTUAL_INCREMENTAL_GROSS_PROFIT;
	}

	public Double getACTUAL_GROSS_PROFIT() {
		return ACTUAL_GROSS_PROFIT;
	}

	public void setACTUAL_GROSS_PROFIT(Double aCTUAL_GROSS_PROFIT) {
		ACTUAL_GROSS_PROFIT = aCTUAL_GROSS_PROFIT;
	}

	public Double getACTUAL_INCREMENTAL_TURNOVER() {
		return ACTUAL_INCREMENTAL_TURNOVER;
	}

	public void setACTUAL_INCREMENTAL_TURNOVER(Double aCTUAL_INCREMENTAL_TURNOVER) {
		ACTUAL_INCREMENTAL_TURNOVER = aCTUAL_INCREMENTAL_TURNOVER;
	}

	public Double getACTUAL_CUSTOMER_ROI() {
		return ACTUAL_CUSTOMER_ROI;
	}

	public void setACTUAL_CUSTOMER_ROI(Double aCTUAL_CUSTOMER_ROI) {
		ACTUAL_CUSTOMER_ROI = aCTUAL_CUSTOMER_ROI;
	}

	public Double getACTUAL_COST_PRICE_BASED_ROI() {
		return ACTUAL_COST_PRICE_BASED_ROI;
	}

	public void setACTUAL_COST_PRICE_BASED_ROI(Double aCTUAL_COST_PRICE_BASED_ROI) {
		ACTUAL_COST_PRICE_BASED_ROI = aCTUAL_COST_PRICE_BASED_ROI;
	}

	public Double getACTUAL_PROMOTION_ROI() {
		return ACTUAL_PROMOTION_ROI;
	}

	public void setACTUAL_PROMOTION_ROI(Double aCTUAL_PROMOTION_ROI) {
		ACTUAL_PROMOTION_ROI = aCTUAL_PROMOTION_ROI;
	}

	public String getUPLOAD_REFERENCE_NUMBER() {
		return UPLOAD_REFERENCE_NUMBER;
	}

	public void setUPLOAD_REFERENCE_NUMBER(String uPLOAD_REFERENCE_NUMBER) {
		UPLOAD_REFERENCE_NUMBER = uPLOAD_REFERENCE_NUMBER;
	}

	public String getIS_DUPLICATE() {
		return IS_DUPLICATE;
	}

	public void setIS_DUPLICATE(String iS_DUPLICATE) {
		IS_DUPLICATE = iS_DUPLICATE;
	}
	
	

}
