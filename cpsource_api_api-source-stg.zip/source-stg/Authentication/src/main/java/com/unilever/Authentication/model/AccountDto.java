package com.unilever.Authentication.model;

import java.io.Serializable;
import java.util.List;

public class AccountDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5196474057475796251L;
	
	 
    private List<String> accountNames;
    private String accountCategoryMapping;
	
    
    public AccountDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<String> getAccountNames() {
		return accountNames;
	}


	public void setAccountNames(List<String> accountNames) {
		this.accountNames = accountNames;
	}


	public String getAccountCategoryMapping() {
		return accountCategoryMapping;
	}


	public void setAccountCategoryMapping(String accountCategoryMapping) {
		this.accountCategoryMapping = accountCategoryMapping;
	}

   




	

}
