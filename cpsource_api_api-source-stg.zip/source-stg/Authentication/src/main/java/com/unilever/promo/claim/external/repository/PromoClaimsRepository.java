package com.unilever.promo.claim.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaims;

@Repository
public interface PromoClaimsRepository extends JpaRepository<PromoClaims, Integer>{
	
	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".PROMO_CLAIMS pcfm where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNoOfPromoClaims(@Param("accountName") String accountName, @Param("moc") String moc);


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".PROMO_CLAIMS  pcfm set pcfm.WORKFLOW_STAGE_ID=:stageID  where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updatePromoClaimsByAccountMocFileNo(@Param("stageID") Integer stageID,@Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".PROMO_CLAIMS pcfm  where pcfm.ACCOUNT_NAME=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Page<PromoClaims> findClaimFileDetailsByAcntAndMoc(@Param("accountName") String accountName,@Param("moc") String moc,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".PROMO_CLAIMS pcfm  where pcfm.ACCOUNT_NAME=:account and pcfm.MOC=:moc", nativeQuery = true)
	List<PromoClaims> findCountByAccountAndMoc(@Param("account") String account,@Param("moc") String moc);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".PROMO_CLAIMS pcfm  where pcfm.ACCOUNT_NAME=:account and pcfm.MOC=:moc", nativeQuery = true)
	Page<PromoClaims> findPromoClaimsFileDetailsByAcntAndMoc(@Param("account") String account,@Param("moc") String moc,Pageable pageable);
		

//	@Transactional
//	@Procedure(procedureName = "sp_AggregateCLAIMData")
//	void insertIntoPromoClaim();
	
	@Transactional
	@Procedure(procedureName = "sp_AggregateCLAIMData")
	void insertIntoPromoClaim(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
	
	//Added By Sarin Jun2021
	@Transactional 
    @Query(value ="select distinct SOL_CODE_ALL AS SOL_CODE from "+GlobalVariables.schemaName+".PROMO_CLAIMS pcfm where pcfm.ACCOUNT_NAME=:account and pcfm.MOC=:moc and (SOL_CODE_ALL LIKE '%/%' OR SOL_CODE_ALL LIKE '%,%' OR SOL_CODE_ALL LIKE '%&%' OR SOL_CODE_ALL LIKE '%-%' OR SOL_CODE_ALL LIKE '%;%')", nativeQuery = true)
	List<String> findMultiSOLCodeByAccountAndMoc(@Param("account") String account,@Param("moc") String moc);

}
