package com.unilever.promo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.promo.commb2c.model.CurrentMocPromoB2cViewDto;
import com.unilever.promo.commb2c.model.NextMocPromoB2cViewDto;
import com.unilever.promo.commb2c.model.PreviousMocPromoB2cViewDto;
import com.unilever.promo.commb2c.service.CommB2CPromoService;
import com.unilever.promo.kam.model.CurrentMocPromoViewDto;
import com.unilever.promo.kam.model.NextMocPromoViewDto;
import com.unilever.promo.kam.model.PreviousMocPromoViewDto;
import com.unilever.promo.kam.service.KamPromoService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CommB2CPromoController {
	
	@Autowired
	CommB2CPromoService commB2CPromoService;

	//======================================= Current MOC View==================================================

		@GetMapping("/getPromoB2cCommCurrentMocView")
		public List<CurrentMocPromoB2cViewDto> getPromoCurrentMocView(@RequestParam("region") List<String> region,@RequestParam("accounts") List<String> accounts,
													  @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
													  @RequestParam(defaultValue = "10") Integer pageSize){
			
	    List<CurrentMocPromoB2cViewDto> currentPromoMocViewDetails = new ArrayList<>();
			
			try{
				 	currentPromoMocViewDetails = commB2CPromoService.getPromoCurrentMocView(region,accounts,moc,category,pageNo,pageSize);
				
			    }
			catch(Exception e){
				e.printStackTrace();
			}
			return currentPromoMocViewDetails;

		}

		



		//======================================= Previous MOC View==================================================
		@GetMapping("/getPromoB2cCommPreviousMocView")
		public List<PreviousMocPromoB2cViewDto> getPromoPreviousMocView(@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			    @RequestParam(defaultValue = "10") Integer pageSize){

			List<PreviousMocPromoB2cViewDto> previousPromoMocDetails = new ArrayList<>();
			try{
				
					previousPromoMocDetails = commB2CPromoService.getPromoPreviousMocView(region,accounts, moc, category,pageNo,pageSize);
			
			   }
			catch(Exception e){
				e.printStackTrace();
			}
			return previousPromoMocDetails;

		}
		
		//======================================= Next MOC View==================================================
				@GetMapping("/getPromoB2cCommNextMocView")
				public List<NextMocPromoB2cViewDto> getPromoNextMocView(@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
					    @RequestParam(defaultValue = "10") Integer pageSize){

					List<NextMocPromoB2cViewDto> nextPromoMocDetails = new ArrayList<>();
					try{
						
						nextPromoMocDetails = commB2CPromoService.getPromoNextMocView(region,accounts, moc, category,pageNo,pageSize);
					
					   }
					catch(Exception e){
						e.printStackTrace();
					}
					return nextPromoMocDetails;

				}
		

}
