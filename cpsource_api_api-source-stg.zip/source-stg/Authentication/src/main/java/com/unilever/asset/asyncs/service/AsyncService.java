package com.unilever.asset.asyncs.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.unilever.asset.commercialB2C.model.CommB2CCompliedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CCompliedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDeployedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CDeployedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetValueNext;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CDepotConnectedAssetVolumeNext;
import com.unilever.asset.commercialB2C.model.CommB2CNotCompliedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CNotCompliedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetValue;
import com.unilever.asset.commercialB2C.model.CommB2CPlannedAssetVolume;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalCount;
import com.unilever.asset.commercialB2C.model.CommB2CStoreListTotalValue;
import com.unilever.asset.commercialB2C.model.CommB2CTotalaAssetCreatedValue;
import com.unilever.asset.commercialB2C.model.CommB2CTotalaAssetCreatedVolume;
import com.unilever.asset.commercialB2C.service.CommercialB2CNextMocService;
import com.unilever.asset.commercialB2C.service.CommercialB2CService;
import com.unilever.asset.external.model.CustomerNonCompliantValue;
import com.unilever.asset.external.model.CustomerNonCompliantVolume;
import com.unilever.asset.external.model.ExternalCustomerNonCompliedAssetValuePrev;
import com.unilever.asset.external.model.ExternalCustomerNonCompliedAssetVolumePrev;
import com.unilever.asset.external.model.ExternalOtherIssuseValuePrev;
import com.unilever.asset.external.model.ExternalOtherIssuseVolumePrev;
import com.unilever.asset.external.model.OtherIssuesValue;
import com.unilever.asset.external.model.OtherIssuesVolume;
import com.unilever.asset.external.model.StoreListCount;
import com.unilever.asset.external.model.StoreListValue;
import com.unilever.asset.external.model.TotalAssetPlannedValue;
import com.unilever.asset.external.model.TotalAssetPlannedVolume;
import com.unilever.asset.external.model.TotalAssetValueExternal;
import com.unilever.asset.external.model.TotalAssetVolumeExternal;
import com.unilever.asset.external.model.TrackAndCompliedValue;
import com.unilever.asset.external.model.TrackAndCompliedVolume;
import com.unilever.asset.external.service.ExternalAssetService;
import com.unilever.asset.kam.model.CompliedAssetValue;
import com.unilever.asset.kam.model.CompliedAssetVolume;
import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetValueNext;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetVolumeNext;
import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetVolume;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.service.KamAssetService;
import com.unilever.asset.kam.service.KamNextMocAssetService;
import com.unilever.global.GlobalVariables;

@Service
public class AsyncService {

	private static Logger log = LoggerFactory.getLogger(AsyncService.class);
	
	

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	KamAssetService kamAssetService;

	@Autowired
	KamNextMocAssetService kamNextMocAssetService;
	
	@Autowired
	CommercialB2CService commercialB2CService;
	
	@Autowired
	CommercialB2CNextMocService commercialB2CNextMocService;
	
	@Autowired
	ExternalAssetService externalAssetService;
	
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	


	@Async("asyncExecutor")
	public CompletableFuture<TotalAssetCreatedValue> getTotalAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAssetCreatedValue totalAssetValueData = new TotalAssetCreatedValue();	      

		try{

			log.info("Total Asset Create Value starts");

			//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllTotalAssetValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, TotalAssetCreatedValue.class);
			totalAssetValueData = kamAssetService.getTotalAssetCreatedValue(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<TotalAssetCreatedVolume> getTotalAssetCreatedVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		TotalAssetCreatedVolume totalAssetCreatedVolumeData = new TotalAssetCreatedVolume();
		try{

			log.info("Total Asset Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllTotalAssetVolume?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, TotalAssetCreatedVolume.class);
			totalAssetCreatedVolumeData = kamAssetService.getTotalAssetCreatedVolume(username, region, account, moc, category);
			log.info("totalAssetCreatedVolumeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetCreatedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}

	// ============================== Start Depot connected Asset ==========================================    
	@Async("asyncExecutor")
	public CompletableFuture<DepotConnectedAssetValue> getAllDepotConnectedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		DepotConnectedAssetValue totalAssetValueData = new DepotConnectedAssetValue();
		try{

			log.info("Total Depot Connected Asset Value starts");

			//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllDepotConnectedAssetValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetValue.class);
			totalAssetValueData = kamAssetService.getAllDepotConnectedAssetValue(username, region, account, moc, category);
			log.info("totaDepotlAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<DepotConnectedAssetVolume> getAllDepotConnectedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		DepotConnectedAssetVolume totalAssetCreatedVolumeData = new  DepotConnectedAssetVolume();
		try{

			log.info("Total Depot Asset Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllDepotConnectedAssetVolume?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetVolume.class);
			totalAssetCreatedVolumeData = kamAssetService.getAllDepotConnectedAssetVolume(username, region, account, moc, category);
			log.info("totalDepotAssetCreatedVolumeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetCreatedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}


	//========================================================== Start Deployed Asset ==============================================================    


	@Async("asyncExecutor")
	public CompletableFuture<DeployedAssetValue> getAllDeployedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		DeployedAssetValue totalAssetValueData = new DeployedAssetValue();
		try{
			log.info("Total Depot Connected Asset Value starts");

			//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllDeployedAssetValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, DeployedAssetValue.class);
			totalAssetValueData = kamAssetService.getDeployedAssetValue(username, region, account, moc, category);
			log.info("deployedlAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("deployedlAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<DepolyedAssetVolume> getAllDeployedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{  
		DepolyedAssetVolume totalAssetCreatedVolumeData = new DepolyedAssetVolume();
		try{
			log.info("Total Depot Asset Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllDeployedAssetVolume?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepolyedAssetVolume.class);
			totalAssetCreatedVolumeData  = kamAssetService.getAllDeployedAssetVolume(username, region, account, moc, category);
			log.info("totalDeployedAssetVolumeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalDeployedAssetVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}

//===================================================Start Complied Asset===================================================

	@Async("asyncExecutor")
	public CompletableFuture<CompliedAssetValue> getAllCompliedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CompliedAssetValue totalAssetValueData = new CompliedAssetValue();
		try{
			log.info("Total Complied Asset Value starts");

			//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCompliedAssetValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, CompliedAssetValue.class);
			totalAssetValueData = kamAssetService.getCompliedAssetValue(username, region, account, moc, category);
			log.info("CompliedAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("CompliedAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<CompliedAssetVolume> getAllCompliedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{  
		CompliedAssetVolume totalAssetCreatedVolumeData = new CompliedAssetVolume();
		try{
			log.info("Total Complied Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCompliedAssetVolume?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, CompliedAssetVolume.class);
			totalAssetCreatedVolumeData = kamAssetService.getAllCompliedAssetVolume(username, region, account, moc, category);
			log.info("totalCompliedAssetVolumeeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalCompliedAssetVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}




	//===================================================Start Not Complied Asset===================================================

	@Async("asyncExecutor")
	public CompletableFuture<NotCompliedAssetValue> getAllNotCompliedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		NotCompliedAssetValue totalAssetValueData = new NotCompliedAssetValue();
		try{
			log.info("Total Not Complied Asset Value starts");

		//	totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllNotCompliedAssetValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, NotCompliedAssetValue.class);
			totalAssetValueData = kamAssetService.getNotCompliedAssetValue(username, region, account, moc, category);
			log.info("NotCompliedAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("NotCompliedAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<NotCompliedAssetVolume> getAllNotCompliedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{  
		NotCompliedAssetVolume totalAssetCreatedVolumeData = new NotCompliedAssetVolume();
		try{
			log.info("Total Not Complied Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllNotCompliedAssetVolume?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, NotCompliedAssetVolume.class);
			totalAssetCreatedVolumeData = kamAssetService.getNotCompliedAssetVolume(username, region, account, moc, category);
			log.info("totalNotCompliedAssetVolumeeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalNotCompliedAssetVolumeeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}
//===========================================kam Next Moc Asset===================================================================


	@Async("asyncExecutor")
	public CompletableFuture<StoreListTotalCount> getAllStoreListTotalCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{   
		StoreListTotalCount storeListTotalCountData = new StoreListTotalCount();
		try{
			log.info("Store List Count starts");

			//storeListTotalCountData = restTemplate.getForObject(GlobalVariables.URL+"getAllStoreListTotalCount?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, StoreListTotalCount.class);
			storeListTotalCountData = kamNextMocAssetService.getStoreListTotalCount(username, region, account, moc, category);
			log.info("storeListTotalCountData, {}", storeListTotalCountData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("storeListTotalCountData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(storeListTotalCountData);
	} 


	@Async("asyncExecutor")
	public CompletableFuture<StoreListTotalValue> getAllStoreListTotalValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{   
		StoreListTotalValue storeListTotalValueData = new StoreListTotalValue();
		try{
			log.info("Store List Value starts");

			//storeListTotalValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllStoreListTotalValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, StoreListTotalValue.class);
			storeListTotalValueData = kamNextMocAssetService.getStoreListTotalValue(username, region, account, moc, category);
			
			log.info("storeListTotalValueData, {}", storeListTotalValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("storeListTotalCountData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(storeListTotalValueData);
	} 


	@Async("asyncExecutor")
	public CompletableFuture<PlannedAssetValue> getAllPlannedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{   
		PlannedAssetValue plannedAssetValueData = new PlannedAssetValue();
		try{
			log.info("Planned Asset Value starts");

			//plannedAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllPlannedAssetValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, PlannedAssetValue.class);
			plannedAssetValueData = kamNextMocAssetService.getAllPlannedAssetValue(username, region, account, moc, category);
			log.info("plannedAssetValueData, {}", plannedAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("plannedAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(plannedAssetValueData);
	} 

	
	

	@Async("asyncExecutor")
	public CompletableFuture<PlannedAssetVolume> getAllPlannedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{   
		PlannedAssetVolume plannedAssetVolumeData = new PlannedAssetVolume();
		try{
			log.info("Store List Value starts");

			//plannedAssetVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllPlannedAssetVolume?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, PlannedAssetVolume.class);
			plannedAssetVolumeData = kamNextMocAssetService.getAllPlannedAssetVolume(username, region, account, moc, category);
			log.info("plannedAssetVolumeData, {}", plannedAssetVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("plannedAssetVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(plannedAssetVolumeData);
	} 

	@Async("asyncExecutor")
	public CompletableFuture<DepotConnectedAssetValueNext> getAllNextMocDepotConnectedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		DepotConnectedAssetValueNext totalAssetValueData = new DepotConnectedAssetValueNext();
		try{

			log.info("Total Depot Connected Asset Value starts");

			//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllDepotConnectedAssetValue?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetValue.class);
			totalAssetValueData = kamNextMocAssetService.getNextMocAllDepotConnectedAssetValueNext(username, region, account, moc, category);
			log.info("totaDepotlAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<DepotConnectedAssetVolumeNext> getAllNextMocDepotConnectedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		DepotConnectedAssetVolumeNext totalAssetCreatedVolumeData = new  DepotConnectedAssetVolumeNext();
		try{

			log.info("Total Depot Asset Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllDepotConnectedAssetVolume?username="+username+"&region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetVolume.class);
			totalAssetCreatedVolumeData = kamNextMocAssetService.getNextMocAllDepotConnectedAssetVolumeNext(username, region, account, moc, category);
			log.info("totalDepotAssetCreatedVolumeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetCreatedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}


 //===========================================Extenal Part Start =====================================================
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAssetValueExternal> getAllExtenalTotalAssetValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{ 
		TotalAssetValueExternal totalAssetExternalValueData = new TotalAssetValueExternal();
		try{
			log.info("Total External Asset Create Value starts");

			//totalAssetExternalValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllExtenalTotalAssetValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, TotalAssetValueExternal.class);
			totalAssetExternalValueData = externalAssetService.getExternalTotalAssetCreatedValue(username, region, moc, category);
			log.info("totalAssetExternalValueData, {}", totalAssetExternalValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetExternalValueData);
	}	    

	@Async("asyncExecutor")
	public CompletableFuture<TotalAssetVolumeExternal> getAllExtenalTotalAssetCreatedVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		TotalAssetVolumeExternal totalAssetExternalCreatedVolumeData = new TotalAssetVolumeExternal();
		try{
			log.info("Total External Asset Created Volume starts");

			//totalAssetExternalCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalTotalAssetVolume?username="+username+"&region="+region+"&moc="+moc+"&category="+category, TotalAssetVolumeExternal.class);
			totalAssetExternalCreatedVolumeData = externalAssetService.getExternalTotalAssetCreatedVolume(username, region, moc, category);
			log.info("totalAssetExternalCreatedVolumeData, {}", totalAssetExternalCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetCreatedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetExternalCreatedVolumeData);
	} 

   /////==================================================Track And Compiled Asset===========================================

	@Async("asyncExecutor")
	public CompletableFuture<TrackAndCompliedValue> getAllExtenalTrackAndCompliedValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		TrackAndCompliedValue trackAndCompliedValueData = new TrackAndCompliedValue();
		try{
			log.info("TrackAndCompliedValue starts");

			//trackAndCompliedValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalTrackAndCompliedAssetValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, TrackAndCompliedValue.class);
			trackAndCompliedValueData = externalAssetService.getExternalTrackAndCompliedValue(username, region, moc, category);
			
					log.info("trackAndCompliedValueData, {}", trackAndCompliedValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("trackAndCompliedValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(trackAndCompliedValueData);
	} 
	
	
	@Async("asyncExecutor")
	public CompletableFuture<TrackAndCompliedVolume> getAllExtenalTrackAndCompliedVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		TrackAndCompliedVolume trackAndCompliedVolumeData = new TrackAndCompliedVolume();
		try{
			log.info("TrackAndCompliedVolume starts");

			//trackAndCompliedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalTrackAndCompliedAssetVolume?username="+username+"&region="+region+"&moc="+moc+"&category="+category, TrackAndCompliedVolume.class);
			trackAndCompliedVolumeData = externalAssetService.getExternalTrackAndCompliedVolume(username, region, moc, category);
			log.info("trackAndCompliedVolumeData, {}", trackAndCompliedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("trackAndCompliedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(trackAndCompliedVolumeData);
	} 

	
//=======================================Customer Non Complience Asset=======================================
	
	
	@Async("asyncExecutor")
	public CompletableFuture<CustomerNonCompliantValue> getAllExtenalCustomerNonCompliantValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		CustomerNonCompliantValue customerCompliedValueData = new CustomerNonCompliantValue();
		try{
			log.info("CustomerCompliedValueData starts");

			//customerCompliedValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalCustomerNonComplienceAssetValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, CustomerNonCompliantValue.class);
			customerCompliedValueData = externalAssetService.getExternalCustomerNonCompliantValueValue(username, region, moc, category);
			log.info("customerCompliedValueData, {}", customerCompliedValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("customerCompliedValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(customerCompliedValueData);
	} 
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<CustomerNonCompliantVolume> getAllExtenalCustomerNonCompliantVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		CustomerNonCompliantVolume customerCompliedVolumeData = new CustomerNonCompliantVolume();
		try{
			log.info("CustomerCompliedVolumeData starts");

			//customerCompliedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalCustomerNonComplienceAssetVolume?username="+username+"&region="+region+"&moc="+moc+"&category="+category, CustomerNonCompliantVolume.class);
			customerCompliedVolumeData = externalAssetService.getExternalCustomerNonCompliantVolume(username, region, moc, category);
			log.info("customerCompliedVolumeData, {}", customerCompliedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("customerCompliedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(customerCompliedVolumeData);
	} 
	
	
	
	//=======================================Other Issuse=======================================
		
	
	@Async("asyncExecutor")
	public CompletableFuture<OtherIssuesValue> getAllExtenalOtherIssuesValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		OtherIssuesValue otherIssuesValueData = new OtherIssuesValue();
		try{
			log.info("CustomerCompliedValueData starts");

			//otherIssuesValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalOtherIssusetValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, OtherIssuesValue.class);
			otherIssuesValueData = externalAssetService.getExternalOtherIssuesValue(username, region, moc, category);
			log.info("otherIssuesValueData, {}", otherIssuesValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("otherIssuesValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(otherIssuesValueData);
	} 
	
	
	@Async("asyncExecutor")
	public CompletableFuture<OtherIssuesVolume> getAllExtenalOtherIssuesVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		OtherIssuesVolume otherIssuesVolumeData = new OtherIssuesVolume();
		try{
			log.info("otherIssuesVolumeData starts");

			//otherIssuesVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalOtherIssuseVolume?username="+username+"&region="+region+"&moc="+moc+"&category="+category, OtherIssuesVolume.class);
			otherIssuesVolumeData = externalAssetService.getExternalOtherIssuesVolume(username, region, moc, category);
			log.info("otherIssuesVolumeData, {}", otherIssuesVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("otherIssuesVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(otherIssuesVolumeData);
	} 
	
	
//==============================================================Previous kpi for external=======================================================	
	
	@Async("asyncExecutor")
	public CompletableFuture<ExternalCustomerNonCompliedAssetValuePrev> getAllPrevExtenalCustomerNonCompliantValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		ExternalCustomerNonCompliedAssetValuePrev customerCompliedValueData = new ExternalCustomerNonCompliedAssetValuePrev();
		try{
			log.info("CustomerCompliedValueData starts");

			//customerCompliedValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalCustomerNonComplienceAssetValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, CustomerNonCompliantValue.class);
			customerCompliedValueData = externalAssetService.getPrevExternalCustomerNonCompliantValueValue(username, region, moc, category);
			log.info("customerCompliedValueData, {}", customerCompliedValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("customerCompliedValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(customerCompliedValueData);
	} 
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<ExternalCustomerNonCompliedAssetVolumePrev> getAllPrevExtenalCustomerNonCompliantVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		ExternalCustomerNonCompliedAssetVolumePrev customerCompliedVolumeData = new ExternalCustomerNonCompliedAssetVolumePrev();
		try{
			log.info("CustomerCompliedVolumeData starts");

			//customerCompliedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalCustomerNonComplienceAssetVolume?username="+username+"&region="+region+"&moc="+moc+"&category="+category, CustomerNonCompliantVolume.class);
			customerCompliedVolumeData = externalAssetService.getPrevExternalCustomerNonCompliantVolume(username, region, moc, category);
			log.info("customerCompliedVolumeData, {}", customerCompliedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("customerCompliedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(customerCompliedVolumeData);
	} 
	
	
	@Async("asyncExecutor")
	public CompletableFuture<ExternalOtherIssuseValuePrev> getAllPrevExtenalOtherIssuesValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		ExternalOtherIssuseValuePrev otherIssuesValueData = new ExternalOtherIssuseValuePrev();
		try{
			log.info("CustomerCompliedValueData starts");

			//otherIssuesValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalOtherIssusetValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, OtherIssuesValue.class);
			otherIssuesValueData = externalAssetService.getPrevExternalOtherIssuesValue(username, region, moc, category);
			log.info("otherIssuesValueData, {}", otherIssuesValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("otherIssuesValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(otherIssuesValueData);
	} 
	
	
	@Async("asyncExecutor")
	public CompletableFuture<ExternalOtherIssuseVolumePrev> getAllPrevExtenalOtherIssuesVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{   
		ExternalOtherIssuseVolumePrev otherIssuesVolumeData = new ExternalOtherIssuseVolumePrev();
		try{
			log.info("otherIssuesVolumeData starts");

			//otherIssuesVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalOtherIssuseVolume?username="+username+"&region="+region+"&moc="+moc+"&category="+category, OtherIssuesVolume.class);
			otherIssuesVolumeData = externalAssetService.getPrevExternalOtherIssuesVolume(username, region, moc, category);
			log.info("otherIssuesVolumeData, {}", otherIssuesVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("otherIssuesVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(otherIssuesVolumeData);
	} 
	
	
	
	
//=============================================================Store List==============================================================



	@Async("asyncExecutor")
	public CompletableFuture<StoreListCount> getAllExtenalStoreListCount(String username,List<String> region,List<String>  moc,List<String>  category) throws InterruptedException 
	{   
		StoreListCount storeListCountData = new StoreListCount();
		try{
			log.info("storeListCountData starts");

			//storeListCountData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalStoreListCount?username="+username+"&region="+region+"&moc="+moc+"&category="+category, StoreListCount.class);
			  storeListCountData = externalAssetService.getExternalStoreListCount(username, region, moc, category);
			log.info("storeListCountData, {}", storeListCountData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("storeListCountData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(storeListCountData);
	} 




	@Async("asyncExecutor")
	public CompletableFuture<StoreListValue> getAllExtenalStoreListValue(String username,List<String> region,List<String>  moc,List<String>  category) throws InterruptedException 
	{   
		StoreListValue storeListValueData = new StoreListValue();
		try{
			log.info("storeListValueData starts");

			//storeListValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalStoreListValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, StoreListValue.class);
			storeListValueData = externalAssetService.getExternalStoreListValuee(username, region, moc, category);
			
			log.info("storeListValueData, {}", storeListValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("storeListValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(storeListValueData);
	} 


//=================================================================Planned Asset Value=========================================================================

	@Async("asyncExecutor")
	public CompletableFuture<TotalAssetPlannedValue> getAllExtenalTotalAssetPlannedValue(String username,List<String> region,List<String>  moc,List<String>  category) throws InterruptedException 
	{   
		TotalAssetPlannedValue totalAssetPlannedValue = new TotalAssetPlannedValue();
		try{
			log.info("totalAssetPlannedValue starts");

			//totalAssetPlannedValue = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalTotalPlannedAssetValue?username="+username+"&region="+region+"&moc="+moc+"&category="+category, TotalAssetPlannedValue.class);
			totalAssetPlannedValue = externalAssetService.getExternalTotalAssetPlannedValue(username, region, moc, category);
			
			log.info("totalAssetPlannedValue, {}", totalAssetPlannedValue);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetPlannedValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetPlannedValue);
	} 


	@Async("asyncExecutor")
	public CompletableFuture<TotalAssetPlannedVolume> getAllExtenalTotalAssetTotalAssetPlannedVolume(String username,List<String> region,List<String>  moc,List<String>  category) throws InterruptedException 
	{   
		TotalAssetPlannedVolume totalAssetPlannedVolume = new TotalAssetPlannedVolume();
		try{
			log.info("totalAssetPlannedVolume starts");

			//totalAssetPlannedVolume = restTemplate.getForObject(GlobalVariables.URL+"getAllExternalTotalPlannedAssetVolume?username="+username+"&region="+region+"&moc="+moc+"&category="+category, TotalAssetPlannedVolume.class);
			totalAssetPlannedVolume = externalAssetService.getExternalTotalAssetPlannedVolume(username, region, moc, category);
			
			log.info("totalAssetPlannedVolume, {}", totalAssetPlannedVolume);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetPlannedVolume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetPlannedVolume);
	} 


//======================================Commercial And B2c Start ============================================================

	@Async("asyncExecutor")
	public CompletableFuture<CommB2CTotalaAssetCreatedValue> getCommercialAndB2cTotalAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		CommB2CTotalaAssetCreatedValue totalAssetValueData = new CommB2CTotalaAssetCreatedValue();	      

		try{

			log.info("Total Asset Create Value starts");

			//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CTotalAssetValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, TotalAssetCreatedValue.class);
			totalAssetValueData = commercialB2CService.getTotalAssetCreatedValue(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	@Async("asyncExecutor")
	public CompletableFuture<CommB2CTotalaAssetCreatedVolume> getCommercialB2CTotalAssetCreatedVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CTotalaAssetCreatedVolume totalAssetCreatedVolumeData = new CommB2CTotalaAssetCreatedVolume();
		try{

			log.info("Total Asset Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CTotalAssetVolume?region="+region+"&account="+account+"&moc="+moc+"&category="+category, TotalAssetCreatedVolume.class);
			totalAssetCreatedVolumeData = commercialB2CService.getTotalAssetCreatedVolume(region, account, moc, category);
			log.info("totalAssetCreatedVolumeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetCreatedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}

	// ============================== Start Depot connected Asset ==========================================    
	@Async("asyncExecutor")
	public CompletableFuture<CommB2CDepotConnectedAssetValue> getAllCommercialB2CDepotConnectedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CDepotConnectedAssetValue totalAssetValueData = new CommB2CDepotConnectedAssetValue();
		try{

			log.info("Total Depot Connected Asset Value starts");

			//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CDepotConnectedAssetValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetValue.class);
			totalAssetValueData = commercialB2CService.getAllDepotConnectedAssetValue(region, account, moc, category);
			log.info("totaDepotlAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<CommB2CDepotConnectedAssetVolume> getAllCommercialB2CDepotConnectedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
	{
		CommB2CDepotConnectedAssetVolume totalAssetCreatedVolumeData = new  CommB2CDepotConnectedAssetVolume();
		try{

			log.info("Total Depot Asset Created Volume starts");

			//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CDepotConnectedAssetVolume?region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetVolume.class);
			totalAssetCreatedVolumeData = commercialB2CService.getAllDepotConnectedAssetVolume(region, account, moc, category);
			log.info("totalDepotAssetCreatedVolumeData, {}", totalAssetCreatedVolumeData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetCreatedVolumeData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
	}

	//========================================================== Start Deployed Asset ==============================================================    


		@Async("asyncExecutor")
		public CompletableFuture<CommB2CDeployedAssetValue> getAllCommercialB2CDeployedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{
			CommB2CDeployedAssetValue totalAssetValueData = new CommB2CDeployedAssetValue();
			try{
				log.info("Total Depot Connected Asset Value starts");

				//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CDeployedAssetValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, DeployedAssetValue.class);
				totalAssetValueData = commercialB2CService.getDeployedAssetValue(region, account, moc, category);
				log.info("deployedlAssetValueData, {}", totalAssetValueData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("deployedlAssetValueData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetValueData);
		}

		@Async("asyncExecutor")
		public CompletableFuture<CommB2CDeployedAssetVolume> getAllCommercialB2CDeployedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{  
			CommB2CDeployedAssetVolume totalAssetCreatedVolumeData = new CommB2CDeployedAssetVolume();
			try{
				log.info("Total Depot Asset Created Volume starts");

				//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CDeployedAssetVolume?region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepolyedAssetVolume.class);
				totalAssetCreatedVolumeData = commercialB2CService.getAllDeployedAssetVolume(region, account, moc, category);
				log.info("totalDeployedAssetVolumeData, {}", totalAssetCreatedVolumeData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalDeployedAssetVolumeData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
		}
		
		
		//===================================================Start Complied Asset===================================================

		@Async("asyncExecutor")
		public CompletableFuture<CommB2CCompliedAssetValue> getAllCommercialB2CCompliedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{
			CommB2CCompliedAssetValue totalAssetValueData = new CommB2CCompliedAssetValue();
			try{
				log.info("Total Complied Asset Value starts");

				//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CCompliedAssetValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, CompliedAssetValue.class);
				totalAssetValueData = commercialB2CService.getCompliedAssetValue(region, account, moc, category);
				log.info("CompliedAssetValueData, {}", totalAssetValueData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("CompliedAssetValueData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetValueData);
		}

		@Async("asyncExecutor")
		public CompletableFuture<CommB2CCompliedAssetVolume> getAllCommercialB2CCompliedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{  
			CommB2CCompliedAssetVolume totalAssetCreatedVolumeData = new CommB2CCompliedAssetVolume();
			try{
				log.info("Total Complied Created Volume starts");

				//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CCompliedAssetVolume?region="+region+"&account="+account+"&moc="+moc+"&category="+category, CompliedAssetVolume.class);
				totalAssetCreatedVolumeData = commercialB2CService.getAllCompliedAssetVolume(region, account, moc, category);
				log.info("totalCompliedAssetVolumeeData, {}", totalAssetCreatedVolumeData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalCompliedAssetVolumeData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
		}


		//===================================================Start Not Complied Asset===================================================

		@Async("asyncExecutor")
		public CompletableFuture<CommB2CNotCompliedAssetValue> getAllCommercialB2CNotCompliedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{
			CommB2CNotCompliedAssetValue totalAssetValueData = new CommB2CNotCompliedAssetValue();
			try{
				log.info("Total Not Complied Asset Value starts");

				//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CNotCompliedAssetValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, NotCompliedAssetValue.class);
				totalAssetValueData = commercialB2CService.getNotCompliedAssetValue(region, account, moc, category);
				log.info("NotCompliedAssetValueData, {}", totalAssetValueData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("NotCompliedAssetValueData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetValueData);
		}

		@Async("asyncExecutor")
		public CompletableFuture<CommB2CNotCompliedAssetVolume> getAllCommercialB2CNotCompliedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{  
			CommB2CNotCompliedAssetVolume totalAssetCreatedVolumeData = new CommB2CNotCompliedAssetVolume();
			try{
				log.info("Total Not Complied Created Volume starts");

				//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CNotCompliedAssetVolume?region="+region+"&account="+account+"&moc="+moc+"&category="+category, NotCompliedAssetVolume.class);
				totalAssetCreatedVolumeData = commercialB2CService.getNotCompliedAssetVolume(region, account, moc, category);
				log.info("totalNotCompliedAssetVolumeeData, {}", totalAssetCreatedVolumeData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalNotCompliedAssetVolumeeData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
		}
		
		
		//===========================================Commercial/B2C Next Moc Asset===================================================================


		@Async("asyncExecutor")
		public CompletableFuture<CommB2CStoreListTotalCount> getAllCommercialB2CStoreListTotalCount(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{   
			CommB2CStoreListTotalCount storeListTotalCountData = new CommB2CStoreListTotalCount();
			try{
				log.info("Store List Count starts");

				//storeListTotalCountData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CStoreListTotalCount?region="+region+"&account="+account+"&moc="+moc+"&category="+category, StoreListTotalCount.class);
				storeListTotalCountData = commercialB2CNextMocService.getStoreListTotalCount(region, account, moc, category);
				log.info("storeListTotalCountData, {}", storeListTotalCountData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("storeListTotalCountData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(storeListTotalCountData);
		} 


		@Async("asyncExecutor")
		public CompletableFuture<CommB2CStoreListTotalValue> getAllCommercialB2CStoreListTotalValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{   
			CommB2CStoreListTotalValue storeListTotalValueData = new CommB2CStoreListTotalValue();
			try{
				log.info("Store List Value starts");

				//storeListTotalValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CStoreListTotalValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, StoreListTotalValue.class);
				storeListTotalValueData = commercialB2CNextMocService.getStoreListTotalValue(region, account, moc, category);
				log.info("storeListTotalValueData, {}", storeListTotalValueData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("storeListTotalCountData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(storeListTotalValueData);
		} 


		@Async("asyncExecutor")
		public CompletableFuture<CommB2CPlannedAssetValue> getAllCommercialB2CPlannedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{   
			CommB2CPlannedAssetValue plannedAssetValueData = new CommB2CPlannedAssetValue();
			try{
				log.info("Planned Asset Value starts");

				//plannedAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CPlannedAssetValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, PlannedAssetValue.class);
				plannedAssetValueData = commercialB2CNextMocService.getAllPlannedAssetValue(region, account, moc, category);
				log.info("plannedAssetValueData, {}", plannedAssetValueData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("plannedAssetValueData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(plannedAssetValueData);
		} 

		
		

		@Async("asyncExecutor")
		public CompletableFuture<CommB2CPlannedAssetVolume> getAllCommercialB2CPlannedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{   
			CommB2CPlannedAssetVolume plannedAssetVolumeData = new CommB2CPlannedAssetVolume();
			try{
				log.info("Store List Value starts");

				//plannedAssetVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CPlannedAssetVolume?region="+region+"&account="+account+"&moc="+moc+"&category="+category, PlannedAssetVolume.class);
				plannedAssetVolumeData = commercialB2CNextMocService.getAllPlannedAssetVolume(region, account, moc, category);
				log.info("plannedAssetVolumeData, {}", plannedAssetVolumeData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("plannedAssetVolumeData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(plannedAssetVolumeData);
		} 

		public CompletableFuture<CommB2CDepotConnectedAssetValueNext> getAllCommercilB2CDepotConnectedAssetValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{
			CommB2CDepotConnectedAssetValueNext totalAssetValueData = new CommB2CDepotConnectedAssetValueNext();
			try{

				log.info("Total Depot Connected Asset Value starts");

				//totalAssetValueData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CDepotConnectedAssetValue?region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetValue.class);
				totalAssetValueData = commercialB2CNextMocService.getNextMocAllDepotConnectedAssetValue(region, account, moc, category);
				log.info("totaDepotlAssetValueData, {}", totalAssetValueData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalAssetValueData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetValueData);
		}

		@Async("asyncExecutor")
		public CompletableFuture<CommB2CDepotConnectedAssetVolumeNext> getAllCCommercialB2CDepotConnectedAssetVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException 
		{
			CommB2CDepotConnectedAssetVolumeNext totalAssetCreatedVolumeData = new  CommB2CDepotConnectedAssetVolumeNext();
			try{

				log.info("Total Depot Asset Created Volume starts");

				//totalAssetCreatedVolumeData = restTemplate.getForObject(GlobalVariables.URL+"getAllCommercialB2CDepotConnectedAssetVolume?region="+region+"&account="+account+"&moc="+moc+"&category="+category, DepotConnectedAssetVolume.class);
				totalAssetCreatedVolumeData = commercialB2CNextMocService.getNextMocAllDepotConnectedAssetVolume(region, account, moc, category);
				log.info("totalDepotAssetCreatedVolumeData, {}", totalAssetCreatedVolumeData);
				//Thread.sleep(1000L);    //Intentional delay
				log.info("totalAssetCreatedVolumeData completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			return CompletableFuture.completedFuture(totalAssetCreatedVolumeData);
		}


}
