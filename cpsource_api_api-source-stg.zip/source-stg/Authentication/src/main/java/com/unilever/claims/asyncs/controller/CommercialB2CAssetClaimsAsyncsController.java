package com.unilever.claims.asyncs.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.claims.asyncs.service.AssetClaimAsyncsService;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPayableCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPlannedCommb2c;
import com.unilever.claims.kam.model.ApprovedExceptionClaimValue;
import com.unilever.claims.kam.model.ApprovedExceptionClaimVolume;
import com.unilever.claims.kam.model.AssetClaimsJsonObj;
import com.unilever.claims.kam.model.ClaimsRaised;
import com.unilever.claims.kam.model.GreenClaimValue;
import com.unilever.claims.kam.model.GreenClaimVolume;
import com.unilever.claims.kam.model.RedClaimValue;
import com.unilever.claims.kam.model.RedClaimVolume;
import com.unilever.claims.kam.model.TotalAmountPaid;
import com.unilever.claims.kam.model.TotalAmountPayable;
import com.unilever.claims.kam.model.TotalAmountPending;
import com.unilever.claims.kam.model.TotalAmountPlanned;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CommercialB2CAssetClaimsAsyncsController {
	
	private static Logger log = LoggerFactory.getLogger(CommercialB2CAssetClaimsAsyncsController.class);
	
	@Autowired
	private AssetClaimAsyncsService assetClaimAsyncsService;
	
	
	@GetMapping("/getCommercialB2CClaimData")
	public String getCommercialB2CClaimData(@RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			
			CompletableFuture<TotalAmountPlannedCommb2c> totalAmountPlanned = assetClaimAsyncsService.getCommercialB2CTotalAmountPlanned(region, account, moc, category);
			CompletableFuture<GreenClaimsValueCommb2c> greenClaimValue = assetClaimAsyncsService.getCommercialB2CGreenClaimValue(region, account, moc, category);
			CompletableFuture<GreenClaimsVolumeCommb2c> greenClaimVolume = assetClaimAsyncsService.getCommercialB2CGreenClaimVolume(region, account, moc, category);
			CompletableFuture<ApprovedExceptionClaimsValueCommb2c> approvedExceptionClaimValue = assetClaimAsyncsService.getCommercialB2CApprovedExceptionClaimValue(region, account, moc, category);
			CompletableFuture<ApprovedExceptionClaimsVolumeCommb2c> approvedExceptionClaimVolume = assetClaimAsyncsService.getCommercialB2CApprovedExceptionClaimVolume(region, account, moc, category);
			CompletableFuture<RedClaimsValueCommb2c> redClaimValue = assetClaimAsyncsService.getCommercialB2CRedClaimValue(region, account, moc, category);
			CompletableFuture<RedClaimsVolumeCommb2c> redClaimVolume = assetClaimAsyncsService.getcommercialB2CRedClaimVolume(region, account, moc, category);
			CompletableFuture<TotalAmountPayableCommb2c> totalAmountPayable = assetClaimAsyncsService.getcommercialB2CTotalAmountPayable(region, account, moc, category);
//	        CompletableFuture<TotalAmountPending> totalAmountPending = assetClaimAsyncsService.getcommercialB2CTotalAmountPending(region, account, moc, category);
			CompletableFuture<Double> claimsRaised = assetClaimAsyncsService.getClaimsRaised(region, account, moc, category);
			CompletableFuture<Double> totalAmountPaid = assetClaimAsyncsService.getTotalAmountPaid(region, account, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(totalAmountPlanned,greenClaimValue,greenClaimVolume,approvedExceptionClaimValue,approvedExceptionClaimVolume,redClaimValue,redClaimVolume,totalAmountPayable).join();

			log.info("totalAmountPlanned--> " + totalAmountPlanned.get());
			log.info("greenClaimValue--> " + greenClaimValue.get());
			log.info("greenClaimVolume--> " + greenClaimVolume.get());
			log.info("approvedExceptionClaimValue--> " + approvedExceptionClaimValue.get());
			log.info("approvedExceptionClaimVolume--> " + approvedExceptionClaimVolume.get());
			log.info("redClaimValue--> " + redClaimValue.get());
			log.info("redClaimVolume--> " + redClaimVolume.get());
			log.info("totalAmountPayable--> " + totalAmountPayable.get());
			log.info("totalAmountPaid--> " + totalAmountPaid.get());
//			log.info("totalAmountPending--> " + totalAmountPending.get());
			log.info("claimsRaised--> " + claimsRaised.get());

			AssetClaimsJsonObj obj = new AssetClaimsJsonObj();
			Gson gson = new Gson();

			obj.setTotalAmountPlanned(totalAmountPlanned.get().getTotalAmountPlanned());
			obj.setGreenClaimValue(greenClaimValue.get().getGreenClaimValue());
			obj.setGreenClaimVolume(greenClaimVolume.get().getGreenClaimVolume());
			obj.setApprovedExceptnClaimValue(approvedExceptionClaimValue.get().getApprovedExceptionClaimValue());
			obj.setApprovedExceptnClaimVolume(approvedExceptionClaimVolume.get().getApprovedExceptionClaimVolume());
			obj.setRedClaimValue(redClaimValue.get().getRedClaimValue());
			obj.setRedClaimVolume(redClaimVolume.get().getRedClaimVolume());
			obj.setTotalAmountPayable(totalAmountPayable.get().getTotalAmountPayable());
     		obj.setTotalAmountPaid(totalAmountPaid.get().doubleValue());
//			obj.setTotalAmountPending(totalAmountPending.get().getTotalAmountPending());
			obj.setTotalClaimsRaised(claimsRaised.get().doubleValue());

			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}


}
