package com.unilever.promo.kam.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.kam.model.CurrentMocPromoView;
import com.unilever.promo.kam.model.PreviousMocPromoView;

@Repository
public interface PreviousMocPromoViewRepository extends PagingAndSortingRepository<PreviousMocPromoView, String> {
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.USERNAME = :username", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMoc(@Param("username") String username,@Param("moc") List<String> moc,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm where icm.MOC in :moc and icm.USERNAME = :username", nativeQuery = true)
	List<PreviousMocPromoView> findCountByMoc(@Param("username") String username,@Param("moc") List<String> moc);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMocCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm where icm.MOC in :moc and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	List<PreviousMocPromoView> findCountByMocCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.USERNAME = :username", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMocAccount(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.USERNAME = :username", nativeQuery = true)
	List<PreviousMocPromoView> findCountByAccount(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMocAccountCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	List<PreviousMocPromoView> findCountByAccountMocCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMocRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm where icm.MOC in :moc and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	List<PreviousMocPromoView> findCountByMocRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMocAccountRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CLUSTER in :region and icm.USERNAME = :username", nativeQuery = true)
	List<PreviousMocPromoView> findCountByAccountMocRegion(@Param("username") String username,@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMocRegionCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.CATEGORY in :category and icm.USERNAME = :username", nativeQuery = true)
	List<PreviousMocPromoView> findAllCountPreviousMocViewByMocRegionCategory(@Param("username") String username,@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.L2_CUSTOMER in :account and icm.CLUSTER in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<PreviousMocPromoView> findAllPreviousMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_PREV_PROMO icm  where icm.MOC in :moc and icm.L2_CUSTOMER in :account and icm.CLUSTER in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<PreviousMocPromoView> findAllCountPreviousMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);
	

}
