package com.unilever.claims.extenal.model;

import java.io.Serializable;

public class CpsMtFinanceDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8954935993229251180L;
	
	private String accountName;
	private String solCode;
	private String state;
	private String moc;
	private String invoiceNo;
	private Double totalPayableAmt;
	private Double claimRaised;
	private Double paidAmt;
	private Double pendingAmt;
	private Double baseAmt;
	private Double taxAmt;
	private Integer totalRecords;
	
	public CpsMtFinanceDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	
	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}


	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}


	public String getSolCode() {
		return solCode;
	}

	public void setSolCode(String solCode) {
		this.solCode = solCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getTotalPayableAmt() {
		return totalPayableAmt;
	}

	public void setTotalPayableAmt(Double totalPayableAmt) {
		this.totalPayableAmt = totalPayableAmt;
	}

	public Double getClaimRaised() {
		return claimRaised;
	}

	public void setClaimRaised(Double claimRaised) {
		this.claimRaised = claimRaised;
	}

	public Double getPaidAmt() {
		return paidAmt;
	}

	public void setPaidAmt(Double paidAmt) {
		this.paidAmt = paidAmt;
	}

	public Double getPendingAmt() {
		return pendingAmt;
	}

	public void setPendingAmt(Double pendingAmt) {
		this.pendingAmt = pendingAmt;
	}


	public Double getBaseAmt() {
		return baseAmt;
	}


	public void setBaseAmt(Double baseAmt) {
		this.baseAmt = baseAmt;
	}


	public Double getTaxAmt() {
		return taxAmt;
	}


	public void setTaxAmt(Double taxAmt) {
		this.taxAmt = taxAmt;
	}


	public Integer getTotalRecords() {
		return totalRecords;
	}


	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	
	
}
