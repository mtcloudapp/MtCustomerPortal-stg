package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALLOCATED_TOTAL_VALUE")
public class PoAllocatedValueB2c implements Serializable {
private static final long serialVersionUID = 3064910868034743996L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
	@Column(name="BRANCH")
	private String Branch;
	
	@Column(name="CATEGORY")
	private String Category;
	
	@Column(name="ACCOUNT")
	private String Account;
	
	@Column(name="MOC")
	private String Moc;

	@Column(name="ALLOCATED_VALUE")
	private Double AllocatedValue;

	public PoAllocatedValueB2c() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PoAllocatedValueB2c(Integer rECORD_ID, String branch, String category, String account, String moc,
			Double allocatedValue) {
		super();
		RECORD_ID = rECORD_ID;
		Branch = branch;
		Category = category;
		Account = account;
		Moc = moc;
		AllocatedValue = allocatedValue;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getBranch() {
		return Branch;
	}

	public void setBranch(String branch) {
		Branch = branch;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getAccount() {
		return Account;
	}

	public void setAccount(String account) {
		Account = account;
	}

	public String getMoc() {
		return Moc;
	}

	public void setMoc(String moc) {
		Moc = moc;
	}

	public Double getAllocatedValue() {
		return AllocatedValue;
	}

	public void setAllocatedValue(Double allocatedValue) {
		AllocatedValue = allocatedValue;
	}
	
	

}
