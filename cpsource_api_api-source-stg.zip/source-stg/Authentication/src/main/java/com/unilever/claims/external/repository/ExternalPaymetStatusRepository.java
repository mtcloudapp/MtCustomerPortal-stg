package com.unilever.claims.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.extenal.model.ExternalPaymentStatus;
import com.unilever.global.GlobalVariables;

@Repository
public interface ExternalPaymetStatusRepository extends JpaRepository<ExternalPaymentStatus, String>{

	//===============================================================Paid Claim Kpi For External====================================================================
	
		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT)  from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where cmf.MOC in :moc and cmf.ACCOUNT=:account", nativeQuery = true)
		Double findClaimRaisedByMoc(@Param("moc") List<String> moc,@Param("account") String account);
		
		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT) from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where "
	    		+ "cmf.MOC in :moc and cmf.CATEGORY in :category and cmf.ACCOUNT=:account", nativeQuery = true)
		Double findClaimRaisedByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,@Param("account") String account);
		
		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT) from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where "
	    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.ACCOUNT=:account", nativeQuery = true)
		Double findClaimRaisedByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("account") String account);
		
		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT) from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where "
	    		+ "cmf.MOC in :moc and cmf.REGION in :region and cmf.CATEGORY in :category and cmf.ACCOUNT=:account", nativeQuery = true)
		Double findClaimRaisedByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,@Param("account") String account);
		
		
		//===============================================================Paid Claim Kpi For Internal/KAM====================================================================
		
		
		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT) from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf "
	    		+ "where cmf.MOC in :moc and cmf.ACCOUNT in :account", nativeQuery = true)
		Double findKamClaimRaisedByMoc(@Param("moc") List<String> moc,@Param("account") List<String> account);
		
		
		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT) from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf "
	    		+ "where cmf.MOC in :moc and cmf.ACCOUNT in :account and cmf.CATEGORY in :category", nativeQuery = true)
		Double findKamClaimRaisedByMocCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
		
		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT) from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf "
	    		+ "where cmf.MOC in :moc and cmf.ACCOUNT in :account and cmf.REGION in :region", nativeQuery = true)
		Double findKamClaimRaisedByMocRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
		

		@Transactional 
	    @Query(value ="select sum(cmf.UPDATED_PAID_AMT) from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf "
	    		+ "where cmf.MOC in :moc and cmf.ACCOUNT in :account and cmf.REGION in :region and cmf.CATEGORY in :category", nativeQuery = true)
		Double findKamClaimRaisedByMocRegionCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);
		


}
