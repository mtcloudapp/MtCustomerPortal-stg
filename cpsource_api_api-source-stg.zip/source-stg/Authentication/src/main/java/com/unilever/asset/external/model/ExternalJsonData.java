package com.unilever.asset.external.model;

public class ExternalJsonData {
	
	private Double trackAndCompliedValue;
	private Double trackAndCompliedVolume;
	private Integer totalAssetValue;
	private Integer totalAssetVolume;
	private Double customerNonComplienceValue;
	private Double customerNonComplienceVolume;
	private Double otherIssuseValue;
	private Double otherIssuseVolume;
	
	public ExternalJsonData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Double getTrackAndCompliedValue() {
		return trackAndCompliedValue;
	}
	public void setTrackAndCompliedValue(Double trackAndCompliedValue) {
		this.trackAndCompliedValue = trackAndCompliedValue;
	}
	public Double getTrackAndCompliedVolume() {
		return trackAndCompliedVolume;
	}
	public void setTrackAndCompliedVolume(Double trackAndCompliedVolume) {
		this.trackAndCompliedVolume = trackAndCompliedVolume;
	}
	public Integer getTotalAssetValue() {
		return totalAssetValue;
	}
	public void setTotalAssetValue(Integer totalAssetValue) {
		this.totalAssetValue = totalAssetValue;
	}
	public Integer getTotalAssetVolume() {
		return totalAssetVolume;
	}
	public void setTotalAssetVolume(Integer totalAssetVolume) {
		this.totalAssetVolume = totalAssetVolume;
	}
	public Double getCustomerNonComplienceValue() {
		return customerNonComplienceValue;
	}
	public void setCustomerNonComplienceValue(Double customerNonComplienceValue) {
		this.customerNonComplienceValue = customerNonComplienceValue;
	}
	public Double getCustomerNonComplienceVolume() {
		return customerNonComplienceVolume;
	}
	public void setCustomerNonComplienceVolume(Double customerNonComplienceVolume) {
		this.customerNonComplienceVolume = customerNonComplienceVolume;
	}
	public Double getOtherIssuseValue() {
		return otherIssuseValue;
	}
	public void setOtherIssuseValue(Double otherIssuseValue) {
		this.otherIssuseValue = otherIssuseValue;
	}
	public Double getOtherIssuseVolume() {
		return otherIssuseVolume;
	}
	public void setOtherIssuseVolume(Double otherIssuseVolume) {
		this.otherIssuseVolume = otherIssuseVolume;
	}
	
	

}
