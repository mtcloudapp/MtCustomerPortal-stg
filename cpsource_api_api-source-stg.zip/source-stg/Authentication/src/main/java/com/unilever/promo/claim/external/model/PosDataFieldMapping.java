package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "POS_DATA_FIELDS_MAPPING")
public class PosDataFieldMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6915909353655308806L;
	
	@Id
	@Column(name="RECORD_ID")
	private int recordID;
	
	@Column(name="ACCOUNT_NAME")
	private String accountName;
	
	@Column(name="FIELD_NAME")
	private String fieldName;
	
	@Column(name="SOURCE_COLUMN_NAME")
	private String fieldValue;

	public PosDataFieldMapping() {
		
	}
	
	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	
	

}
