package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.CustomerNonCompliantVolume;
import com.unilever.global.GlobalVariables;

@Repository
public interface CustomerNonComplientVolumeRepository extends JpaRepository<CustomerNonCompliantVolume, Integer>{

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_NOT_COMPLIED_ASSETS_VOLUME etas where etas.USERNAME=:username", nativeQuery = true)
	List<CustomerNonCompliantVolume> findAllCustomerNonCompliantVolumeExternalDetails(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_NOT_COMPLIED_ASSETS_VOLUME etas where etas.USERNAME=:username and etas.MOC=:moc", nativeQuery = true)
	List<CustomerNonCompliantVolume> findAllCustomerNonCompliantVolumeExternalDetailsByMoc(@Param("username") String username,@Param("moc") String moc);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_NOT_COMPLIED_ASSETS_VOLUME etas where etas.USERNAME=:username and etas.MOC=:moc and etas.CATEGORY_NAME=:category", nativeQuery = true)
	List<CustomerNonCompliantVolume> findAllCustomerNonCompliantVolumeExternalDetailsByMocAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_NOT_COMPLIED_ASSETS_VOLUME etas where etas.USERNAME=:username and  etas.REGION_NAME=:region and etas.MOC=:moc", nativeQuery = true)
	List<CustomerNonCompliantVolume> findAllCustomerNonCompliantVolumeExternalDetailsByRegionAndMoc(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);


}
