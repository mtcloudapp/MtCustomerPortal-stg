package com.unilever.claims.commb2c.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsValueCommb2c;
import com.unilever.claims.kam.model.ApprovedExceptionClaimValue;
import com.unilever.global.GlobalVariables;

@Repository
public interface ApprovedExceptionClaimsValueCommb2cRepository extends JpaRepository<ApprovedExceptionClaimsValueCommb2c, Integer> {

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".COMMB2C_APPROVED_EXCEPTION_CLAIMS_VALUE tac", nativeQuery = true)
	List<ApprovedExceptionClaimsValueCommb2c> findAllApprovedExceptionClaimValue();
}
