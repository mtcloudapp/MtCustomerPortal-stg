package com.unilever.claims.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.kam.model.RedClaimValue;
import com.unilever.global.GlobalVariables;

@Repository
public interface RedClaimsValueRepository extends JpaRepository<RedClaimValue, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_RED_CLAIMS_VALUE tac where tac.USERNAME=:username", nativeQuery = true)
	List<RedClaimValue> findAllRedClaimValue(@Param("username") String username);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_RED_CLAIMS_VALUE", nativeQuery = true)
	List<RedClaimValue> findAllRedClaimValueDetails();
	
}
