package com.unilever.claims.b2c.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.extenal.model.ExternalPaymentStatus;
import com.unilever.global.GlobalVariables;

@Repository
public interface B2CClaimsRepository extends JpaRepository<ExternalPaymentStatus, String>{
	

	@Transactional
    @Modifying(clearAutomatically = true)
    @Query(value ="update "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS  cmf set cmf.UPDATED_PAID_AMT=:paidAmt, cmf.ACTUAL_PAID_AMOUNT=:actualPaidAmt  where cmf.INVOICE_NO=:invoiceNo", nativeQuery = true)
    void updatePaidAmt(@Param("invoiceNo") String invoiceNo,@Param("paidAmt") Double paidAmt, @Param("actualPaidAmt") Double actualPaidAmt);

	@Transactional 
    @Query(value ="select sum(cmf.BASE_AMOUNT+cmf.TAX_AMOUNT)  from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where cmf.INVOICE_NO=:invoiceNo", nativeQuery = true)
	Double findBaseAmtTaxAmtByInvoiceNo(@Param("invoiceNo") String invoiceNo);
	
	@Transactional 
    @Query(value ="select sum(cmf.UPDATED_PAID_AMT)  from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where cmf.SOL_CODE=:solecode and cmf.STATE=:state", nativeQuery = true)
	Double findPaidAmtBySolcodeAndState(@Param("solecode") String solecode,@Param("state") String state);
	
	@Transactional 
    @Query(value ="select cmf.UPDATED_PAID_AMT  from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where cmf.INVOICE_NO=:invoiceNo", nativeQuery = true)
	Double findPaidAmtByInvoiceNo(@Param("invoiceNo") String invoiceNo);
	
	@Transactional 
    @Query(value ="select cmf.ACTUAL_PAID_AMOUNT  from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf where cmf.INVOICE_NO=:invoiceNo", nativeQuery = true)
	Double findActualPaidAmtByInvoiceNo(@Param("invoiceNo") String invoiceNo);
	
	@Transactional 
    @Query(value ="select *  from "+GlobalVariables.schemaName+".EXT_PAYMENT_STATUS cmf", nativeQuery = true)
    List<ExternalPaymentStatus> findExternalPymentDetails();
}
