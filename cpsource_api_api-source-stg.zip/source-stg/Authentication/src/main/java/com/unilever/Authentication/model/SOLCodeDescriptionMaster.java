package com.unilever.Authentication.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "SOL_CODE_DESCRIPTION_MASTER")
public class SOLCodeDescriptionMaster implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4925351295302890981L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
	@Column(name="SOL_CODE")
    private Integer solCode;
  	
  	@Column(name="ARTICLE_CODE")
    private Integer articleCode;
  	
  	@Column(name="BASEPACK")
    private Integer basepack;
  	
  	@Column(name="ACCOUNT_NAME")
    private String accountName;
  	
  	@Column(name="MOC")
    private String moc;
	
  	@Column(name="SOL_CODE_DESCRIPTION_NEW")
    private String solCodeDescriptionNew;

	public SOLCodeDescriptionMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SOLCodeDescriptionMaster(Integer rECORD_ID, Integer solCode, Integer articleCode, Integer basepack,
			String accountName, String moc, String solCodeDescriptionNew) {
		super();
		RECORD_ID = rECORD_ID;
		this.solCode = solCode;
		this.articleCode = articleCode;
		this.basepack = basepack;
		this.accountName = accountName;
		this.moc = moc;
		this.solCodeDescriptionNew = solCodeDescriptionNew;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getSolCodeDescriptionNew() {
		return solCodeDescriptionNew;
	}

	public void setSolCodeDescriptionNew(String solCodeDescriptionNew) {
		this.solCodeDescriptionNew = solCodeDescriptionNew;
	}
  	
  	
	

}
