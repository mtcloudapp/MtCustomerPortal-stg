package com.unilever.promo.external.model;

import java.io.Serializable;

import javax.persistence.Column;

public class PreviousMocExternalPromoViewDto  implements Serializable {
	
	private static final long serialVersionUID = -5922087877145840252L;
	
	private Integer sol_code;
	
	private String promo_description;
	
	private String l1_customer;
	
	private String l2_customer;
	
	private String article_code;
	
	private String category;
	
	private String brand;
	
	private String region;
	
	private Integer total_planned_volume;
	
	private Double utilized_volume;
	
	private String moc;
	
	private Integer totalRecords;

	public PreviousMocExternalPromoViewDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public PreviousMocExternalPromoViewDto(Integer sol_code, String promo_description, String l1_customer,
			String l2_customer, String article_code, String category, String brand, String region,
			Integer total_planned_volume, Double utilized_volume, String moc, Integer totalRecords) {
		super();
		this.sol_code = sol_code;
		this.promo_description = promo_description;
		this.l1_customer = l1_customer;
		this.l2_customer = l2_customer;
		this.article_code = article_code;
		this.category = category;
		this.brand = brand;
		this.region = region;
		this.total_planned_volume = total_planned_volume;
		this.utilized_volume = utilized_volume;
		this.moc = moc;
		this.totalRecords = totalRecords;
	}


	public Integer getSol_code() {
		return sol_code;
	}


	public void setSol_code(Integer sol_code) {
		this.sol_code = sol_code;
	}


	public String getPromo_description() {
		return promo_description;
	}


	public void setPromo_description(String promo_description) {
		this.promo_description = promo_description;
	}


	public String getL1_customer() {
		return l1_customer;
	}


	public void setL1_customer(String l1_customer) {
		this.l1_customer = l1_customer;
	}


	public String getL2_customer() {
		return l2_customer;
	}


	public void setL2_customer(String l2_customer) {
		this.l2_customer = l2_customer;
	}


	


	public String getArticle_code() {
		return article_code;
	}


	public void setArticle_code(String article_code) {
		this.article_code = article_code;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public Integer getTotal_planned_volume() {
		return total_planned_volume;
	}


	public void setTotal_planned_volume(Integer total_planned_volume) {
		this.total_planned_volume = total_planned_volume;
	}


	public Double getUtilized_volume() {
		return utilized_volume;
	}


	public void setUtilized_volume(Double utilized_volume) {
		this.utilized_volume = utilized_volume;
	}


	public String getMoc() {
		return moc;
	}


	public void setMoc(String moc) {
		this.moc = moc;
	}


	public Integer getTotalRecords() {
		return totalRecords;
	}


	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}


	
	

}
