package com.unilever.promo.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.kam.model.KamTotalUtilizedVolume;

@Repository
public interface KamTotalUtilizedVolumeRepository  extends JpaRepository<KamTotalUtilizedVolume, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_UTILIZED_VOLUME tac where tac.USERNAME=:username", nativeQuery = true)
	List<KamTotalUtilizedVolume> findAllTotalUtilizedVolume(@Param("username") String username);
	
}
