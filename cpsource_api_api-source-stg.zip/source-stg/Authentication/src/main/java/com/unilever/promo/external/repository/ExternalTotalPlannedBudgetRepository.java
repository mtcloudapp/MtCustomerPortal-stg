package com.unilever.promo.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.external.model.ExternalTotalPlannedBudget;


@Repository
public interface ExternalTotalPlannedBudgetRepository extends JpaRepository<ExternalTotalPlannedBudget, Integer>{
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_TOTAL_PLANNED_BUDGET etas where etas.USERNAME=:username", nativeQuery = true)
	List<ExternalTotalPlannedBudget> findAllTotalPlannedBudget(@Param("username") String username);
	

}
