package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.global.GlobalVariables;

@Repository
public interface DeployedAssetValueRepository extends JpaRepository<DeployedAssetValue, Integer>{

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValue(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValueByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValueByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValueByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValueByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValueByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValueByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<DeployedAssetValue> findAllDeployedAssetValueByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);

	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueDetails();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where  tac.MOC=:moc", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_DEPLOYED_ASSETS_VALUE tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<DeployedAssetValue> findAllDeployedAssetValueByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		








}
