package com.unilever.sales.model;

import java.io.Serializable;
import java.util.List;

public class DroppedPODto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 13568030555908703L;

	public DroppedPODto() {
		super();
		// TODO Auto-generated constructor stub
	}
	private List<String>reasonList;
	private List<Integer> countList;
	
	

	public List<String> getReasonList() {
		return reasonList;
	}

	public void setReasonList(List<String> reasonList) {
		this.reasonList = reasonList;
	}

	public List<Integer> getCountList() {
		return countList;
	}

	public void setCountList(List<Integer> countList) {
		this.countList = countList;
	}

	
	

}
