package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.DroppedDataStage;

@Repository
public interface DroppedDataRepository extends JpaRepository<DroppedDataStage, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".DROP_DATA_DOWNLOAD s where s.ACCOUNT in :account and s.MOC in :moc and s.BRANCH in :branch", nativeQuery = true)
	List<DroppedDataStage> findDroppedDataList(@Param("account") List<String> account,@Param("moc") List<String> moc,
			@Param("branch") List<String> branch);

}
