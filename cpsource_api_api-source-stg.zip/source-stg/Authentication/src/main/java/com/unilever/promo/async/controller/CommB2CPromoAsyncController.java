package com.unilever.promo.async.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.promo.async.service.CommB2CPromoAsyncService;
import com.unilever.promo.commb2c.model.CommB2CNoOfPromotion;
import com.unilever.promo.commb2c.model.CommB2CPromoCurrJsonObj;
import com.unilever.promo.commb2c.model.CommB2CPromoPrevJsonObj;
import com.unilever.promo.commb2c.model.CommB2CSolCodeReleased;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedBudget;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedPromoValue;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedPromoVolume;
import com.unilever.promo.commb2c.model.CommB2CTotalUtilizedValue;
import com.unilever.promo.commb2c.model.CommB2CTotalUtilizedVolume;
import com.unilever.promo.commb2c.model.CommB2CUtilizedBudget;
import com.unilever.promo.kam.model.PromoJsonObj;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CommB2CPromoAsyncController {
	
private static Logger log = LoggerFactory.getLogger(CommB2CPromoAsyncController.class);
	
	@Autowired
	private  CommB2CPromoAsyncService commB2CPromoAsyncService;
	
	@GetMapping("/getCommB2CCurrentMocPromoData")
	public String getCommB2CCurrentMocPromoData(@RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		
		try{
			
			CompletableFuture<Integer> noOfPromotion = commB2CPromoAsyncService.getNoOfPromotion(region, account, moc, category);
			CompletableFuture<Integer> solCodeReleased = commB2CPromoAsyncService.getSolCodeReleased(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedBudget> totalPlannedBudget = commB2CPromoAsyncService.getTotalPlannedBudget(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedPromoValue> totalPlannedPromoValue = commB2CPromoAsyncService.getTotalPlannedPromoValue(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedPromoVolume> totalPlannedPromoVolume = commB2CPromoAsyncService.getTotalPlannedPromovolume(region, account, moc, category);
			CompletableFuture<CommB2CTotalUtilizedValue> totalUtilizedValue = commB2CPromoAsyncService.getTotalUtilizedValue(region, account, moc, category);
			CompletableFuture<CommB2CTotalUtilizedVolume> totalUtilizedVolume = commB2CPromoAsyncService.getTotalUtilizeddVolume(region, account, moc, category);
			CompletableFuture<CommB2CUtilizedBudget> utilizedBudget = commB2CPromoAsyncService.getUtilizedBudget(region, account, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfPromotion,solCodeReleased,totalPlannedBudget,totalPlannedPromoValue,totalPlannedPromoVolume,totalUtilizedValue,totalUtilizedVolume,utilizedBudget).join();

			log.info("noOfPromotion--> " + noOfPromotion.get());
			log.info("solCodeReleased--> " + solCodeReleased.get());
			log.info("totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("totalPlannedPromoValue--> " + totalPlannedPromoValue.get());
			log.info("totalPlannedPromoVolume--> " + totalPlannedPromoVolume.get());
			log.info("totalUtilizedValue--> " + totalUtilizedValue.get());
			log.info("totalUtilizedVolume--> " + totalUtilizedVolume.get());
			log.info("utilizedBudget--> " + utilizedBudget.get());
			
		    JSONObject myJson = new JSONObject();
			myJson.put("noOfPromotion", noOfPromotion.get().intValue());
			myJson.put("solCodeReleased", solCodeReleased.get().intValue());
			myJson.put("totalPlannedBudget", totalPlannedBudget.get().getTotalPlannedBudget());
			myJson.put("totalPlannedPromoValue", totalPlannedPromoValue.get().getTotalPlannedPromoValue());
			myJson.put("totalPlannedPromoVolume", totalPlannedPromoVolume.get().getTotalPlannedPromoVolume());
			myJson.put("totalUtilizedValue", totalUtilizedValue.get().getTotalUtilizedValue());
//			myJson.put("totalUtilizedVolume", utilizedBudget.get().getUtilizedBudget());
			myJson.put("totalUtilizedVolume", totalUtilizedVolume.get().getTotalUtilizedVolume());
			myJson.put("utilizedBudget", utilizedBudget.get().getUtilizedBudget());
			
			json = myJson.toString();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	@GetMapping("/getCommB2CPreviousMocPromoData")
	public String getCommB2CPreviousMocPromoData(@RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		

		try{
			
			CompletableFuture<Integer> noOfPromotion = commB2CPromoAsyncService.getNoOfPromotion(region, account, moc, category);
			CompletableFuture<Integer> solCodeReleased = commB2CPromoAsyncService.getSolCodeReleased(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedBudget> totalPlannedBudget = commB2CPromoAsyncService.getTotalPlannedBudget(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedPromoValue> totalPlannedPromoValue = commB2CPromoAsyncService.getTotalPlannedPromoValue(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedPromoVolume> totalPlannedPromoVolume = commB2CPromoAsyncService.getTotalPlannedPromovolume(region, account, moc, category);
			CompletableFuture<CommB2CTotalUtilizedValue> totalUtilizedValue = commB2CPromoAsyncService.getTotalUtilizedValue(region, account, moc, category);
			CompletableFuture<CommB2CTotalUtilizedVolume> totalUtilizedVolume = commB2CPromoAsyncService.getTotalUtilizeddVolume(region, account, moc, category);
			CompletableFuture<CommB2CUtilizedBudget> utilizedBudget = commB2CPromoAsyncService.getUtilizedBudget(region, account, moc, category);
		
			// Wait until they are all done
			CompletableFuture.allOf(noOfPromotion,solCodeReleased,totalPlannedBudget,totalPlannedPromoValue,totalPlannedPromoVolume,totalUtilizedValue,totalUtilizedVolume,utilizedBudget).join();

			log.info("noOfPromotion--> " + noOfPromotion.get());
			log.info("solCodeReleased--> " + solCodeReleased.get());
			log.info("totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("totalPlannedPromoValue--> " + totalPlannedPromoValue.get());
			log.info("totalPlannedPromoVolume--> " + totalPlannedPromoVolume.get());
			log.info("totalUtilizedValue--> " + totalUtilizedValue.get());
			log.info("totalUtilizedVolume--> " + totalUtilizedVolume.get());
			log.info("utilizedBudget--> " + utilizedBudget.get());
			
		    JSONObject myJson = new JSONObject();
			myJson.put("noOfPromotion", noOfPromotion.get().intValue());
			myJson.put("solCodeReleased", solCodeReleased.get().intValue());
			myJson.put("totalPlannedBudget", totalPlannedBudget.get().getTotalPlannedBudget());
			myJson.put("totalPlannedPromoValue", totalPlannedPromoValue.get().getTotalPlannedPromoValue());
			myJson.put("totalPlannedPromoVolume", totalPlannedPromoVolume.get().getTotalPlannedPromoVolume());
			myJson.put("totalUtilizedValue", totalUtilizedValue.get().getTotalUtilizedValue());
			myJson.put("totalUtilizedVolume", totalUtilizedVolume.get().getTotalUtilizedVolume());
			myJson.put("utilizedBudget", utilizedBudget.get().getUtilizedBudget());
			
			json = myJson.toString();
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	@GetMapping("/getCommB2CNextMocPromoData")
	public String getCommB2CNextMocPromoData(@RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			
			CompletableFuture<Integer> noOfPromotion = commB2CPromoAsyncService.getNoOfPromotion(region, account, moc, category);
			CompletableFuture<Integer> solCodeReleased = commB2CPromoAsyncService.getSolCodeReleased(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedBudget> totalPlannedBudget = commB2CPromoAsyncService.getTotalPlannedBudget(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedPromoValue> totalPlannedPromoValue = commB2CPromoAsyncService.getTotalPlannedPromoValue(region, account, moc, category);
			CompletableFuture<CommB2CTotalPlannedPromoVolume> totalPlannedPromoVolume = commB2CPromoAsyncService.getTotalPlannedPromovolume(region, account, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(noOfPromotion,solCodeReleased,totalPlannedBudget,totalPlannedPromoValue,totalPlannedPromoVolume).join();

			log.info("noOfPromotion--> " + noOfPromotion.get());
			log.info("solCodeReleased--> " + solCodeReleased.get());
			log.info("totalPlannedBudget--> " + totalPlannedBudget.get());
			log.info("totalPlannedPromoValue--> " + totalPlannedPromoValue.get());
			log.info("totalPlannedPromoVolume--> " + totalPlannedPromoVolume.get());
			
			PromoJsonObj obj = new PromoJsonObj();
			Gson gson = new Gson();

			obj.setNoOfPromotion(noOfPromotion.get().intValue());
			obj.setSolCodeReleased(solCodeReleased.get().intValue());
			obj.setTotalPlannedBudget(totalPlannedBudget.get().getTotalPlannedBudget());
			obj.setTotalPlannedPromoValue(totalPlannedPromoValue.get().getTotalPlannedPromoValue());
			obj.setTotalPlannedPromoVolume(totalPlannedPromoVolume.get().getTotalPlannedPromoVolume());
			
			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	
	

	
	

}
