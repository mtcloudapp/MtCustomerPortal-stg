package com.unilever.promo.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.kam.model.KamTotalPlannedBudget;

@Repository
public interface KamTotalPlannedBudgetRepository extends JpaRepository<KamTotalPlannedBudget, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_TOTAL_PLANNED_BUDGET tac where tac.USERNAME=:username", nativeQuery = true)
	List<KamTotalPlannedBudget> findAllTotalPlannedBudget(@Param("username") String username);

}
