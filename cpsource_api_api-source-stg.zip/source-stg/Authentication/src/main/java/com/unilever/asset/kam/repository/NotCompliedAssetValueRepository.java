package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.global.GlobalVariables;

public interface NotCompliedAssetValueRepository extends JpaRepository<NotCompliedAssetValue, Integer> {

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValue(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValueByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValueByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValueByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValueByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValueByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValueByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<NotCompliedAssetValue> findAllNotCompliedAssetValueByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);


	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueDetails();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where  tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_NOT_COMPLIED_ASSETS_VALUE tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<NotCompliedAssetValue> findAllNotCompliedAssetValueByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		








}
