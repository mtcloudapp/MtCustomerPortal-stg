package com.unilever.claims.asyncs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.ApprovedExceptionClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.GreenClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsValueCommb2c;
import com.unilever.claims.commb2c.model.RedClaimsVolumeCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPayableCommb2c;
import com.unilever.claims.commb2c.model.TotalAmountPlannedCommb2c;
import com.unilever.claims.commecialB2C.service.CommercialB2CClaimsService;
import com.unilever.claims.extenal.model.ApprovedExceptionClaimsValueExternal;
import com.unilever.claims.extenal.model.ApprovedExceptionClaimsVolumeExternal;
import com.unilever.claims.extenal.model.PaidClaimsValueExternal;
import com.unilever.claims.extenal.model.RejectedClaimValueExternal;
import com.unilever.claims.extenal.model.RejectedClaimVolumeExternal;
import com.unilever.claims.extenal.model.UnpaidClaimsValueExternal;
import com.unilever.claims.external.service.ExternalAssetClaimsService;
import com.unilever.claims.kam.model.ApprovedExceptionClaimValue;
import com.unilever.claims.kam.model.ApprovedExceptionClaimVolume;
import com.unilever.claims.kam.model.ClaimsRaised;
import com.unilever.claims.kam.model.GreenClaimValue;
import com.unilever.claims.kam.model.GreenClaimVolume;
import com.unilever.claims.kam.model.RedClaimValue;
import com.unilever.claims.kam.model.RedClaimVolume;
import com.unilever.claims.kam.model.TotalAmountPaid;
import com.unilever.claims.kam.model.TotalAmountPayable;
import com.unilever.claims.kam.model.TotalAmountPending;
import com.unilever.claims.kam.model.TotalAmountPlanned;
import com.unilever.claims.kam.service.AssetClaimsService;

@Service
public class AssetClaimAsyncsService {
	
	private static Logger log = LoggerFactory.getLogger(AssetClaimAsyncsService.class);
	
	
	@Autowired
	AssetClaimsService assetClaimsService;
	
	@Autowired
	CommercialB2CClaimsService commercialB2CService;
	
	@Autowired
	ExternalAssetClaimsService externalAssetClaimsService;
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAmountPlanned> getTotalAmountPlanned(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAmountPlanned totalAssetValueData = new TotalAmountPlanned();	      

		try{

			log.info("Total Amount Planned starts");

				totalAssetValueData = assetClaimsService.getTotalAmountPlanned(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAmountPlanned completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}


	@Async("asyncExecutor")
	public CompletableFuture<GreenClaimValue> getGreenClaimValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		GreenClaimValue totalAssetValueData = new GreenClaimValue();	      

		try{

			log.info("Green Claim Value starts");

			totalAssetValueData = assetClaimsService.getGreenClaimsValue(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Green Claim Value completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	
	@Async("asyncExecutor")
	public CompletableFuture<GreenClaimVolume> getGreenClaimVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		GreenClaimVolume totalAssetValueData = new GreenClaimVolume();	      

		try{

			log.info("Green Claim Volume starts");

			totalAssetValueData = assetClaimsService.getGreenClaimsVolume(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Green Claim Volume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<ApprovedExceptionClaimValue> getApprovedExceptionClaimValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		ApprovedExceptionClaimValue totalAssetValueData = new ApprovedExceptionClaimValue();	      

		try{

			log.info("Approved Exception Claim Value starts");

			totalAssetValueData = assetClaimsService.getApprovedExceptionClaimValue(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Approved Exception Claim Value completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<ApprovedExceptionClaimVolume> getApprovedExceptionClaimVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		ApprovedExceptionClaimVolume totalAssetValueData = new ApprovedExceptionClaimVolume();	      

		try{

			log.info("Approved Exception Claim Volume starts");

			totalAssetValueData = assetClaimsService.getApprovedExceptionClaimVolume(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Approved Exception Claim Volume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<RedClaimValue> getRedClaimValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		RedClaimValue totalAssetValueData = new RedClaimValue();	      

		try{

			log.info("Red Claim Value starts");

			totalAssetValueData = assetClaimsService.getRedClaimValue(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Red Claim Value completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<RedClaimVolume> getRedClaimVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		RedClaimVolume totalAssetValueData = new RedClaimVolume();	      

		try{

			log.info("Red Claim Volume starts");

			totalAssetValueData = assetClaimsService.getRedClaimVolume(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Red Claim Volume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAmountPayable> getTotalAmountPayable(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAmountPayable totalAssetValueData = new TotalAmountPayable();	      

		try{

			log.info("Total Amount Payable starts");

			totalAssetValueData = assetClaimsService.getTotalAmountPayable(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Total Amount Payable completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Double> getTotalAmountPaid(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalAssetValueData = 0.00;	      

		try{

			log.info("Total Amount Paid starts");

			totalAssetValueData = assetClaimsService.getTotalAmountPaid(region, account, moc, category);
			if(totalAssetValueData == null){
				totalAssetValueData = 0.00;
			}
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Total Amount Paid completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAmountPending> getTotalAmountPending(String username,List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAmountPending totalAssetValueData = new TotalAmountPending();	      

		try{

			log.info("Total Amount Paid starts");

			totalAssetValueData = assetClaimsService.getTotalAmountPending(username, region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Total Amount Pending completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<Double> getClaimsRaised (List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalAssetValueData = 0.00;	      
       
		try{

			log.info("Claims Raised starts");

			totalAssetValueData = assetClaimsService.getClaimsRaised(region, account, moc, category);
			
			if(totalAssetValueData == null){
				totalAssetValueData = 0.00;
			}
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Claims Raised completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
//==========================================================================Commercial/B2C Service Start=======================================================
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAmountPlannedCommb2c> getCommercialB2CTotalAmountPlanned(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAmountPlannedCommb2c totalAssetValueData = new TotalAmountPlannedCommb2c();	      

		try{

			log.info("Total Amount Planned starts");

				totalAssetValueData = commercialB2CService.getTotalAmountPlanned(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAmountPlanned completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}


	@Async("asyncExecutor")
	public CompletableFuture<GreenClaimsValueCommb2c> getCommercialB2CGreenClaimValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		GreenClaimsValueCommb2c totalAssetValueData = new GreenClaimsValueCommb2c();	      

		try{

			log.info("Green Claim Value starts");

			totalAssetValueData = commercialB2CService.getGreenClaimsValue(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Green Claim Value completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	
	@Async("asyncExecutor")
	public CompletableFuture<GreenClaimsVolumeCommb2c> getCommercialB2CGreenClaimVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		GreenClaimsVolumeCommb2c totalAssetValueData = new GreenClaimsVolumeCommb2c();	      

		try{

			log.info("Green Claim Volume starts");

			totalAssetValueData = commercialB2CService.getGreenClaimsVolume(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Green Claim Volume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}

	@Async("asyncExecutor")
	public CompletableFuture<ApprovedExceptionClaimsValueCommb2c> getCommercialB2CApprovedExceptionClaimValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		ApprovedExceptionClaimsValueCommb2c totalAssetValueData = new ApprovedExceptionClaimsValueCommb2c();	      

		try{

			log.info("Approved Exception Claim Value starts");

			totalAssetValueData = commercialB2CService.getApprovedExceptionClaimValue(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Approved Exception Claim Value completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<ApprovedExceptionClaimsVolumeCommb2c> getCommercialB2CApprovedExceptionClaimVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		ApprovedExceptionClaimsVolumeCommb2c totalAssetValueData = new ApprovedExceptionClaimsVolumeCommb2c();	      

		try{

			log.info("Approved Exception Claim Volume starts");

			totalAssetValueData = commercialB2CService.getApprovedExceptionClaimVolume(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Approved Exception Claim Volume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<RedClaimsValueCommb2c> getCommercialB2CRedClaimValue(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		RedClaimsValueCommb2c totalAssetValueData = new RedClaimsValueCommb2c();	      

		try{

			log.info("Red Claim Value starts");

			totalAssetValueData = commercialB2CService.getRedClaimValue(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Red Claim Value completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<RedClaimsVolumeCommb2c> getcommercialB2CRedClaimVolume(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		RedClaimsVolumeCommb2c totalAssetValueData = new RedClaimsVolumeCommb2c();	      

		try{

			log.info("Red Claim Volume starts");

			totalAssetValueData = commercialB2CService.getRedClaimVolume(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Red Claim Volume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAmountPayableCommb2c> getcommercialB2CTotalAmountPayable(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAmountPayableCommb2c totalAssetValueData = new TotalAmountPayableCommb2c();	      

		try{

			log.info("Total Amount Payable starts");

			totalAssetValueData = commercialB2CService.getTotalAmountPayable(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Total Amount Payable completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAmountPaid> getcommercialB2CTotalAmountPaid(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAmountPaid totalAssetValueData = new TotalAmountPaid();	      

		try{

			log.info("Total Amount Paid starts");

			totalAssetValueData = commercialB2CService.getTotalAmountPaid(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Total Amount Paid completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<TotalAmountPending> getcommercialB2CTotalAmountPending(List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		TotalAmountPending totalAssetValueData = new TotalAmountPending();	      

		try{

			log.info("Total Amount Paid starts");

			totalAssetValueData = commercialB2CService.getTotalAmountPending(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Total Amount Pending completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<ClaimsRaised> getcommercialB2CClaimsRaised (List<String> region,List<String> account,List<String> moc,List<String> category) throws InterruptedException{ 

		ClaimsRaised totalAssetValueData = new ClaimsRaised();	      

		try{

			log.info("Claims Raised starts");

			totalAssetValueData = commercialB2CService.getClaimsRaised(region, account, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Claims Raised completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
//=======================================================================External Service Start============================================================================	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<ApprovedExceptionClaimsValueExternal> getApprovedExceptionClaimsValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		ApprovedExceptionClaimsValueExternal totalAssetValueData = new ApprovedExceptionClaimsValueExternal();	      

		try{

			log.info("Approved Exception Claims Value External");

				totalAssetValueData = externalAssetClaimsService.getExternalApprovedExceptionClaimsValue(username, region, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Approved Exception Claims Value completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<ApprovedExceptionClaimsVolumeExternal> getApprovedExceptionClaimsVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		ApprovedExceptionClaimsVolumeExternal totalAssetValueData = new ApprovedExceptionClaimsVolumeExternal();	      

		try{

			log.info("Approved Exception Claims Volume External");

				totalAssetValueData = externalAssetClaimsService.getExternalApprovedExceptionClaimsVolume(username, region, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("Approved Exception Claims Volume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<RejectedClaimValueExternal> getRejectedClaimValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		RejectedClaimValueExternal totalAssetValueData = new RejectedClaimValueExternal();	      

		try{

			log.info("RejectedClaimValue External");

				totalAssetValueData = externalAssetClaimsService.getExternalRejectedClaimValue(username, region, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("RejectedClaimValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<RejectedClaimVolumeExternal> getRejectedClaimVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		RejectedClaimVolumeExternal totalAssetValueData = new RejectedClaimVolumeExternal();	      

		try{

			log.info("RejectedClaimVolume External");

				totalAssetValueData = externalAssetClaimsService.getExternalRejectedClaimVolume(username, region, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("RejectedClaimVolume completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	@Async("asyncExecutor")
	public CompletableFuture<com.unilever.claims.extenal.model.TotalAmountPlannedExternal> getTotalAmountPlaned(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		com.unilever.claims.extenal.model.TotalAmountPlannedExternal totalAssetValueData = new com.unilever.claims.extenal.model.TotalAmountPlannedExternal();	      

		try{

			log.info("totalAmountPlanned External");

				totalAssetValueData = externalAssetClaimsService.getExternalTotalAmountPlanned(username, region, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAmountPlanned completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	
	@Async("asyncExecutor")
	public CompletableFuture<Double> getClaimRaised(String account,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalAssetValueData = 0.00;	      

		try{

			log.info("ClaimsRaised External");

				totalAssetValueData = externalAssetClaimsService.getExternalClaimsRaised(account, region, moc, category);
			    
				if(totalAssetValueData == null){
					totalAssetValueData = 0.00;
				}
			
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("ClaimsRaised completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	
	public CompletableFuture<Double> getPaidClaimsValue(String account,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		Double totalAssetValueData = 0.00;	      

		try{

			log.info("PaidClaimsValue External");

				totalAssetValueData = externalAssetClaimsService.getExternalPaidClaimsValue(account, region, moc, category);
			  if(totalAssetValueData == null){
				  totalAssetValueData=0.00;
			  }
				log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("PaidClaimsValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	
	public CompletableFuture<UnpaidClaimsValueExternal> getUnpaidClaimsValue(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException{ 

		UnpaidClaimsValueExternal totalAssetValueData = new UnpaidClaimsValueExternal();	      

		try{

			log.info("UnpaidClaimsValue External");

				totalAssetValueData = externalAssetClaimsService.getExternalUnpaidClaimsValue(username, region, moc, category);
			log.info("totalAssetValueData, {}", totalAssetValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("UnpaidClaimsValue completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetValueData);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
