package com.unilever.sales.async.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.claims.asyncs.controller.KamAssetClaimsAsyncsController;
import com.unilever.claims.asyncs.service.AssetClaimAsyncsService;
import com.unilever.claims.kam.model.ApprovedExceptionClaimValue;
import com.unilever.claims.kam.model.ApprovedExceptionClaimVolume;
import com.unilever.claims.kam.model.AssetClaimsJsonObj;
import com.unilever.claims.kam.model.GreenClaimValue;
import com.unilever.claims.kam.model.GreenClaimVolume;
import com.unilever.claims.kam.model.RedClaimValue;
import com.unilever.claims.kam.model.RedClaimVolume;
import com.unilever.claims.kam.model.TotalAmountPayable;
import com.unilever.claims.kam.model.TotalAmountPlanned;
import com.unilever.sales.async.service.SalesAsyncService;
import com.unilever.sales.model.SalesJsonObj;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class KamSalesAsyncController {
	
	private static Logger log = LoggerFactory.getLogger(KamAssetClaimsAsyncsController.class);

	@Autowired
	private SalesAsyncService salesAsyncService;
	
	@GetMapping("/getKamSalesData")
	public String getKamSalesData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam("isAll") boolean isAll) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			CompletableFuture<Integer> totalPoCount = salesAsyncService.getTotalPoCount(username, region, account, moc, category);
			CompletableFuture<Integer> totalPoLineCount = salesAsyncService.getTotalPoLineCount(username, region, account, moc, category);
			CompletableFuture<Integer> totalPoValue = salesAsyncService.getTotalPoValueCount(username, region, account, moc, category);
			CompletableFuture<Integer> totalPoDroppedCount = salesAsyncService.getTotalPoDroppedCount(username, region, account, moc, category,isAll);
			CompletableFuture<Integer> totalPoInvoicedCount = salesAsyncService.getTotalPoInvoicedCount(username, region, account, moc, category);
			CompletableFuture<Double> totalPoInvoicedValue = salesAsyncService.getTotalPoInvoicedValue(username, region, account, moc, category);
			CompletableFuture<Integer> totalPoAllocatedCount = salesAsyncService.getTotalPoAllocatedCount(username, region, account, moc, category);
			CompletableFuture<Double> totalPoAllocatedValue = salesAsyncService.getTotalPoAllocatedValue(username, region, account, moc, category);

			// Wait until they are all done
			CompletableFuture.allOf(totalPoCount,totalPoLineCount,totalPoValue,totalPoDroppedCount,totalPoInvoicedCount,totalPoInvoicedValue,totalPoAllocatedCount,totalPoAllocatedValue).join();

			log.info("totalPoCount--> " + totalPoCount.get());
			log.info("totalPoLineCount--> " + totalPoLineCount.get());
			log.info("totalPoValue--> " + totalPoValue.get());
			log.info("totalPoDroppedCount--> " + totalPoDroppedCount.get());
			log.info("totalPoInvoicedCount--> " + totalPoInvoicedCount.get());
			log.info("totalPoInvoicedValue--> " + totalPoInvoicedValue.get());
			log.info("totalPoAllocatedCount--> " + totalPoAllocatedCount.get());
			log.info("totalPoAllocatedValue--> " + totalPoAllocatedValue.get());
			
			SalesJsonObj obj = new SalesJsonObj();
			Gson gson = new Gson();

			obj.setTotalPoCount(totalPoCount.get());
			obj.setTotalPoLineCount(totalPoLineCount.get());
			obj.setTotalPoValue(totalPoValue.get());
			obj.setTotalPoDroppedCount(totalPoDroppedCount.get());
			obj.setTotalPoAllocatedCount(totalPoAllocatedCount.get());
			obj.setTotalPoAllocatedValue(totalPoAllocatedValue.get());
			obj.setTotalPoInvoicedCount(totalPoInvoicedCount.get());
			obj.setTotalPoInvoicedValue(totalPoInvoicedValue.get());

			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}

	@GetMapping("/getB2cSalesData")
	public String getB2cSalesData(@RequestParam("region") List<String>region,@RequestParam("account") List<String>account, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam("isAll") boolean isAll) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			CompletableFuture<Integer> totalPoCount = salesAsyncService.getTotalPoCountB2c(region, account, moc, category);
			CompletableFuture<Integer> totalPoLineCount = salesAsyncService.getTotalPoLineCountB2c(region, account, moc, category);
			CompletableFuture<Integer> totalPoValue = salesAsyncService.getTotalPoValueCountB2c(region, account, moc, category);
			CompletableFuture<Integer> totalPoDroppedCount = salesAsyncService.getTotalPoDroppedCountB2c(region, account, moc, category,isAll);
			CompletableFuture<Integer> totalPoInvoicedCount = salesAsyncService.getTotalPoInvoicedCountB2c(region, account, moc, category);
			CompletableFuture<Double> totalPoInvoicedValue = salesAsyncService.getTotalPoInvoicedValueB2c(region, account, moc, category);
			CompletableFuture<Integer> totalPoAllocatedCount = salesAsyncService.getTotalPoAllocatedCountB2c(region, account, moc, category);
			CompletableFuture<Double> totalPoAllocatedValue = salesAsyncService.getTotalPoAllocatedValueB2c(region, account, moc, category);

			// Wait until they are all done
			CompletableFuture.allOf(totalPoCount,totalPoLineCount,totalPoValue,totalPoDroppedCount,totalPoInvoicedCount,totalPoInvoicedValue,totalPoAllocatedCount,totalPoAllocatedValue).join();

			log.info("totalPoCount--> " + totalPoCount.get());
			log.info("totalPoLineCount--> " + totalPoLineCount.get());
			log.info("totalPoValue--> " + totalPoValue.get());
			log.info("totalPoDroppedCount--> " + totalPoDroppedCount.get());
			log.info("totalPoInvoicedCount--> " + totalPoInvoicedCount.get());
			log.info("totalPoInvoicedValue--> " + totalPoInvoicedValue.get());
			log.info("totalPoAllocatedCount--> " + totalPoAllocatedCount.get());
			log.info("totalPoAllocatedValue--> " + totalPoAllocatedValue.get());
			
			SalesJsonObj obj = new SalesJsonObj();
			Gson gson = new Gson();

			obj.setTotalPoCount(totalPoCount.get());
			obj.setTotalPoLineCount(totalPoLineCount.get());
			obj.setTotalPoValue(totalPoValue.get());
			obj.setTotalPoDroppedCount(totalPoDroppedCount.get());
			obj.setTotalPoAllocatedCount(totalPoAllocatedCount.get());
			obj.setTotalPoAllocatedValue(totalPoAllocatedValue.get());
			obj.setTotalPoInvoicedCount(totalPoInvoicedCount.get());
			obj.setTotalPoInvoicedValue(totalPoInvoicedValue.get());

			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	@GetMapping("/getExtSalesData")
	public String getExtSalesData(@RequestParam("username") String username, @RequestParam("region") List<String>region,@RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam("isAll") boolean isAll) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			CompletableFuture<Integer> totalPoCount = salesAsyncService.getTotalPoCountExternal(username, region, moc, category);
			CompletableFuture<Integer> totalPoLineCount = salesAsyncService.getTotalPoLineCountExternal(username, region,  moc, category);
			CompletableFuture<Integer> totalPoValue = salesAsyncService.getTotalPoValueCountExternal(username, region,  moc, category);
			CompletableFuture<Integer> totalPoDroppedCount = salesAsyncService.getTotalPoDroppedCountExternal(username, region, moc, category,isAll);
			CompletableFuture<Integer> totalPoInvoicedCount = salesAsyncService.getTotalPoInvoicedCountExternal(username, region, moc, category);
			CompletableFuture<Double> totalPoInvoicedValue = salesAsyncService.getTotalPoInvoicedValueExternal(username, region,  moc, category);
			CompletableFuture<Integer> totalPoAllocatedCount = salesAsyncService.getTotalPoAllocatedCountExternal(username, region, moc, category);
			CompletableFuture<Double> totalPoAllocatedValue = salesAsyncService.getTotalPoAllocatedValueExternal(username, region, moc, category);

			// Wait until they are all done
			CompletableFuture.allOf(totalPoCount,totalPoLineCount,totalPoValue,totalPoDroppedCount,totalPoInvoicedCount,totalPoInvoicedValue,totalPoAllocatedCount,totalPoAllocatedValue).join();

			log.info("totalPoCount--> " + totalPoCount.get());
			log.info("totalPoLineCount--> " + totalPoLineCount.get());
			log.info("totalPoValue--> " + totalPoValue.get());
			log.info("totalPoDroppedCount--> " + totalPoDroppedCount.get());
			log.info("totalPoInvoicedCount--> " + totalPoInvoicedCount.get());
			log.info("totalPoInvoicedValue--> " + totalPoInvoicedValue.get());
			log.info("totalPoAllocatedCount--> " + totalPoAllocatedCount.get());
			log.info("totalPoAllocatedValue--> " + totalPoAllocatedValue.get());
			
			SalesJsonObj obj = new SalesJsonObj();
			Gson gson = new Gson();

			obj.setTotalPoCount(totalPoCount.get());
			obj.setTotalPoLineCount(totalPoLineCount.get());
			obj.setTotalPoValue(totalPoValue.get());
			obj.setTotalPoDroppedCount(totalPoDroppedCount.get());
			obj.setTotalPoAllocatedCount(totalPoAllocatedCount.get());
			obj.setTotalPoAllocatedValue(totalPoAllocatedValue.get());
			obj.setTotalPoInvoicedCount(totalPoInvoicedCount.get());
			obj.setTotalPoInvoicedValue(totalPoInvoicedValue.get());

			json = gson.toJson(obj); 
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
}
