package com.unilever.asset.kam.model;

import java.io.Serializable;


public class CurrentMocViewDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4974948638643604065L;

	private String region;

	private String branch;

	private String account;

	private String visiRefNo;

	private String hulCode;

	private String moc;

	private String category;

	private String city;

	private String assetType;

	private String assetDescription;

	private String createdOn;

	private String depotConnectOn;

	private String deployedOn;

	private Integer compliance;

	private String lossTree;
	
	private String godownCode;
    
	private Integer totalRecords;

	
	public CurrentMocViewDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getVisiRefNo() {
		return visiRefNo;
	}

	public void setVisiRefNo(String visiRefNo) {
		this.visiRefNo = visiRefNo;
	}

	public String getHulCode() {
		return hulCode;
	}

	public void setHulCode(String hulCode) {
		this.hulCode = hulCode;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getAssetDescription() {
		return assetDescription;
	}

	public void setAssetDescription(String assetDescription) {
		this.assetDescription = assetDescription;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getDepotConnectOn() {
		return depotConnectOn;
	}

	public void setDepotConnectOn(String depotConnectOn) {
		this.depotConnectOn = depotConnectOn;
	}

	public String getDeployedOn() {
		return deployedOn;
	}

	public void setDeployedOn(String deployedOn) {
		this.deployedOn = deployedOn;
	}


	public Integer getCompliance() {
		return compliance;
	}

	public void setCompliance(Integer compliance) {
		this.compliance = compliance;
	}

	public String getLossTree() {
		return lossTree;
	}

	public void setLossTree(String lossTree) {
		this.lossTree = lossTree;
	}

	public String getGodownCode() {
		return godownCode;
	}

	public void setGodownCode(String godownCode) {
		this.godownCode = godownCode;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	

}
