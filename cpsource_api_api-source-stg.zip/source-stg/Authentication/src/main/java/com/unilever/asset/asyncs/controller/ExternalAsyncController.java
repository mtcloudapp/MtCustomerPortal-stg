package com.unilever.asset.asyncs.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.unilever.asset.asyncs.service.AsyncService;
import com.unilever.asset.external.model.CustomerNonCompliantValue;
import com.unilever.asset.external.model.CustomerNonCompliantVolume;
import com.unilever.asset.external.model.ExternalCustomerNonCompliedAssetValuePrev;
import com.unilever.asset.external.model.ExternalCustomerNonCompliedAssetVolumePrev;
import com.unilever.asset.external.model.ExternalJsonData;
import com.unilever.asset.external.model.ExternalNextMocData;
import com.unilever.asset.external.model.ExternalOtherIssuseValuePrev;
import com.unilever.asset.external.model.ExternalOtherIssuseVolumePrev;
import com.unilever.asset.external.model.OtherIssuesValue;
import com.unilever.asset.external.model.OtherIssuesVolume;
import com.unilever.asset.external.model.StoreListCount;
import com.unilever.asset.external.model.StoreListValue;
import com.unilever.asset.external.model.TotalAssetPlannedValue;
import com.unilever.asset.external.model.TotalAssetPlannedVolume;
import com.unilever.asset.external.model.TotalAssetValueExternal;
import com.unilever.asset.external.model.TotalAssetVolumeExternal;
import com.unilever.asset.external.model.TrackAndCompliedValue;
import com.unilever.asset.external.model.TrackAndCompliedVolume;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class ExternalAsyncController {

	private static Logger log = LoggerFactory.getLogger(ExternalAsyncController.class);


	@Autowired
	private AsyncService externalAsyncService;




	@RequestMapping(value = "/getCurrentMOCExternalAssetsData", method = RequestMethod.GET)
	public String getCurrentMOCExternalAssetsData(@RequestParam("username") String username, @RequestParam("region") List<String> region, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
	   
		try{
			 
			CompletableFuture<TotalAssetValueExternal> totalAssetValues = externalAsyncService.getAllExtenalTotalAssetValue(username, region, moc, category);
			CompletableFuture<TotalAssetVolumeExternal> totalAssetVolumes = externalAsyncService.getAllExtenalTotalAssetCreatedVolume(username, region, moc, category);
			CompletableFuture<TrackAndCompliedValue> trackAndCompliedValue = externalAsyncService.getAllExtenalTrackAndCompliedValue(username, region, moc, category);
			CompletableFuture<TrackAndCompliedVolume> trackAndCompliedVolumes = externalAsyncService.getAllExtenalTrackAndCompliedVolume(username, region, moc, category);
			CompletableFuture<CustomerNonCompliantValue> customerNonCompliantValue = externalAsyncService.getAllExtenalCustomerNonCompliantValue(username, region, moc, category);
			CompletableFuture<CustomerNonCompliantVolume> customerNonCompliantVolume = externalAsyncService.getAllExtenalCustomerNonCompliantVolume(username, region, moc, category);
			CompletableFuture<OtherIssuesValue> otherIssuesValue = externalAsyncService.getAllExtenalOtherIssuesValue(username, region, moc, category);
			CompletableFuture<OtherIssuesVolume> otherIssuesVolume = externalAsyncService.getAllExtenalOtherIssuesVolume(username, region, moc, category);

			// Wait until they are all done
			CompletableFuture.allOf(totalAssetValues, totalAssetVolumes,trackAndCompliedValue,trackAndCompliedVolumes,customerNonCompliantValue,customerNonCompliantVolume,otherIssuesValue,otherIssuesVolume).join();

			log.info("External Total Asset Values--> " + totalAssetValues.get());
			log.info("External Total Asset Volumes--> " + totalAssetVolumes.get());
			log.info("External TrackAndCompliedValue--> " + trackAndCompliedValue.get());
			log.info("External TrackAndCompliedVolume--> " + trackAndCompliedVolumes.get());
			log.info("External CustomerNonCompliantValue--> " + customerNonCompliantValue.get());
			log.info("External CustomerNonCompliantVolume--> " + customerNonCompliantVolume.get());
			log.info("External OtherIssuesValue--> " + otherIssuesValue.get());
			log.info("External OtherIssuesVolume--> " + otherIssuesVolume.get());

			ExternalJsonData obj = new ExternalJsonData();
			Gson gson = new Gson();

			obj.setTotalAssetValue(totalAssetValues.get().getTotalAssetCreatedValue());
			obj.setTotalAssetVolume(totalAssetVolumes.get().getTotalAssetCreatedVolume());
			obj.setTrackAndCompliedValue(trackAndCompliedValue.get().getCompliedAssetValue());
			obj.setTrackAndCompliedVolume(trackAndCompliedVolumes.get().getCompliedAssetVolume());
			obj.setCustomerNonComplienceValue(customerNonCompliantValue.get().getNonCompliedAssetValue());
			obj.setCustomerNonComplienceVolume(customerNonCompliantVolume.get().getNonCompliedAssetVolume());
			obj.setOtherIssuseValue(otherIssuesValue.get().getOtheIssuesValue());
			obj.setOtherIssuseVolume(otherIssuesVolume.get().getOtheIssuesVolume());
			
			json = gson.toJson(obj); 

		}  catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	@RequestMapping(value = "/getPreviousMOCExternalAssetsData", method = RequestMethod.GET)
	public String getPreviousMOCExternalAssetsData(@RequestParam("username") String username, @RequestParam("region") List<String> region, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		
		try{
			
			CompletableFuture<TotalAssetValueExternal> totalAssetValues = externalAsyncService.getAllExtenalTotalAssetValue(username, region, moc, category);
			CompletableFuture<TotalAssetVolumeExternal> totalAssetVolumes = externalAsyncService.getAllExtenalTotalAssetCreatedVolume(username, region, moc, category);
			CompletableFuture<TrackAndCompliedValue> trackAndCompliedValue = externalAsyncService.getAllExtenalTrackAndCompliedValue(username, region, moc, category);
			CompletableFuture<TrackAndCompliedVolume> trackAndCompliedVolumes = externalAsyncService.getAllExtenalTrackAndCompliedVolume(username, region, moc, category);
			CompletableFuture<ExternalCustomerNonCompliedAssetValuePrev> customerNonCompliantValue = externalAsyncService.getAllPrevExtenalCustomerNonCompliantValue(username, region, moc, category);
			CompletableFuture<ExternalCustomerNonCompliedAssetVolumePrev> customerNonCompliantVolume = externalAsyncService.getAllPrevExtenalCustomerNonCompliantVolume(username, region, moc, category);
			CompletableFuture<ExternalOtherIssuseValuePrev> otherIssuesValue = externalAsyncService.getAllPrevExtenalOtherIssuesValue(username, region, moc, category);
			CompletableFuture<ExternalOtherIssuseVolumePrev> otherIssuesVolume = externalAsyncService.getAllPrevExtenalOtherIssuesVolume(username, region, moc, category);

			// Wait until they are all done
			CompletableFuture.allOf(totalAssetValues, totalAssetVolumes,trackAndCompliedValue,trackAndCompliedVolumes,customerNonCompliantValue,customerNonCompliantVolume,otherIssuesValue,otherIssuesVolume).join();

			log.info("External Total Asset Values--> " + totalAssetValues.get());
			log.info("External Total Asset Volumes--> " + totalAssetVolumes.get());
			log.info("External TrackAndCompliedValue--> " + trackAndCompliedValue.get());
			log.info("External TrackAndCompliedVolume--> " + trackAndCompliedVolumes.get());
			log.info("External CustomerNonCompliantValue--> " + customerNonCompliantValue.get());
			log.info("External CustomerNonCompliantVolume--> " + customerNonCompliantVolume.get());
			log.info("External OtherIssuesValue--> " + otherIssuesValue.get());
			log.info("External OtherIssuesVolume--> " + otherIssuesVolume.get());

			ExternalJsonData obj = new ExternalJsonData();
			Gson gson = new Gson();

			obj.setTotalAssetValue(totalAssetValues.get().getTotalAssetCreatedValue());
			obj.setTotalAssetVolume(totalAssetVolumes.get().getTotalAssetCreatedVolume());
			obj.setTrackAndCompliedValue(trackAndCompliedValue.get().getCompliedAssetValue());
			obj.setTrackAndCompliedVolume(trackAndCompliedVolumes.get().getCompliedAssetVolume());
			obj.setCustomerNonComplienceValue(customerNonCompliantValue.get().getNonCompliedAssetValue());
			obj.setCustomerNonComplienceVolume(customerNonCompliantVolume.get().getNonCompliedAssetVolume());
			obj.setOtherIssuseValue(otherIssuesValue.get().getOtheIssuesValue());
			obj.setOtherIssuseVolume(otherIssuesVolume.get().getOtheIssuesVolume());
			
			json = gson.toJson(obj); 

		}  catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}
	
	
	
	@RequestMapping(value = "/getNextMOCExternalAssetsData", method = RequestMethod.GET)
	public String getNextMOCExternalAssetsData(@RequestParam("username") String username, @RequestParam("region") List<String> region, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category) throws InterruptedException, ExecutionException 
	{
		String json = null;
		try{
			 

			CompletableFuture<StoreListCount> storeListCount = externalAsyncService.getAllExtenalStoreListCount(username, region, moc, category);
			CompletableFuture<StoreListValue> storeListValue = externalAsyncService.getAllExtenalStoreListValue(username, region, moc, category);
			CompletableFuture<TotalAssetPlannedValue> totalAssetPlannedValue = externalAsyncService.getAllExtenalTotalAssetPlannedValue(username, region, moc, category);
			CompletableFuture<TotalAssetPlannedVolume> totalAssetPlannedVolume = externalAsyncService.getAllExtenalTotalAssetTotalAssetPlannedVolume(username, region, moc, category);
			
			// Wait until they are all done
			CompletableFuture.allOf(storeListCount, storeListValue,totalAssetPlannedValue,totalAssetPlannedVolume).join();

			log.info("External storeListValue--> " + storeListCount.get());
			log.info("External storeListValue--> " + storeListValue.get());
			log.info("External totalAssetPlannedValue--> " + totalAssetPlannedValue.get());
			log.info("External totalAssetPlannedVolume--> " + totalAssetPlannedVolume.get());
			
			ExternalNextMocData obj = new ExternalNextMocData();
			Gson gson = new Gson();

			obj.setStoreListCount(storeListCount.get().getStoreListTotalCount());
			obj.setStoreListValue(storeListValue.get().getStoreListTotalValue());
			obj.setTotalPlannedAssetValue(totalAssetPlannedValue.get().getPlannedAssetValue());
			obj.setTotalPlannedAssetVolume(totalAssetPlannedVolume.get().getPlannedAssetVolume());
		
			json = gson.toJson(obj); 

		}  catch(Exception e){
			e.printStackTrace();
		}

		return json;
	}

	
	
	
	
	

}
