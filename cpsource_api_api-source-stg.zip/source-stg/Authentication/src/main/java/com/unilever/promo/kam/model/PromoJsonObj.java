package com.unilever.promo.kam.model;

public class PromoJsonObj {

	private Integer noOfPromotion;
	private Integer solCodeReleased;
	private Double totalPlannedBudget;
	private Double totalPlannedPromoValue;
	private Double totalPlannedPromoVolume;
	private Double totalUtilizedValue;
	private Double totalUtilizedVolume;
	private Double utilizedBudget;
	
	
	public PromoJsonObj() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Integer getNoOfPromotion() {
		return noOfPromotion;
	}


	public void setNoOfPromotion(Integer noOfPromotion) {
		this.noOfPromotion = noOfPromotion;
	}

	public Integer getSolCodeReleased() {
		return solCodeReleased;
	}


	public void setSolCodeReleased(Integer solCodeReleased) {
		this.solCodeReleased = solCodeReleased;
	}


	public Double getTotalPlannedBudget() {
		return totalPlannedBudget;
	}


	public void setTotalPlannedBudget(Double totalPlannedBudget) {
		this.totalPlannedBudget = totalPlannedBudget;
	}


	public Double getTotalPlannedPromoValue() {
		return totalPlannedPromoValue;
	}


	public void setTotalPlannedPromoValue(Double totalPlannedPromoValue) {
		this.totalPlannedPromoValue = totalPlannedPromoValue;
	}


	public Double getTotalPlannedPromoVolume() {
		return totalPlannedPromoVolume;
	}


	public void setTotalPlannedPromoVolume(Double totalPlannedPromoVolume) {
		this.totalPlannedPromoVolume = totalPlannedPromoVolume;
	}


	public Double getTotalUtilizedValue() {
		return totalUtilizedValue;
	}


	public void setTotalUtilizedValue(Double totalUtilizedValue) {
		this.totalUtilizedValue = totalUtilizedValue;
	}


	public Double getTotalUtilizedVolume() {
		return totalUtilizedVolume;
	}


	public void setTotalUtilizedVolume(Double totalUtilizedVolume) {
		this.totalUtilizedVolume = totalUtilizedVolume;
	}


	public Double getUtilizedBudget() {
		return utilizedBudget;
	}


	public void setUtilizedBudget(Double utilizedBudget) {
		this.utilizedBudget = utilizedBudget;
	}
	
	
	
}
