package com.unilever.asset.kam.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.unilever.global.GlobalVariables;

@Entity
@Table(name="viewtable", schema=GlobalVariables.schemaName)
public class ViewTableModel implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8123735591588571643L;
	
	
	@Id
	private String id;

	@Column(name="REGION")	
	private String region;

	@Column(name="BRANCH")
	private String branch;

	@Column(name="ACCOUNT")
	private String account;

	@Column(name="MOC")
	private String moc;
	
	

	public ViewTableModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ViewTableModel(String id, String region, String branch, String account, String moc) {
		super();
		this.id = id;
		this.region = region;
		this.branch = branch;
		this.account = account;
		this.moc = moc;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}
 
	

}
