package com.unilever.sales.model;

import java.io.Serializable;
import java.util.List;

public class LossTreeCFinalReasonDto implements Serializable{
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3613225419011663325L;
	
	private List<String> cFinalReason;
	private List<Double> orderValue;
	private List<Double> allocatedValue;
	private List<Double> invoicedValue;
	private Integer count;
	
	public LossTreeCFinalReasonDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<String> getcFinalReason() {
		return cFinalReason;
	}

	public void setcFinalReason(List<String> cFinalReason) {
		this.cFinalReason = cFinalReason;
	}

	public List<Double> getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(List<Double> orderValue) {
		this.orderValue = orderValue;
	}

	public List<Double> getAllocatedValue() {
		return allocatedValue;
	}

	public void setAllocatedValue(List<Double> allocatedValue) {
		this.allocatedValue = allocatedValue;
	}

	public List<Double> getInvoicedValue() {
		return invoicedValue;
	}

	public void setInvoicedValue(List<Double> invoicedValue) {
		this.invoicedValue = invoicedValue;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
	

	
}
