package com.unilever.Authentication.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PPM_EXTRACT_MOC")
public class PPMExtractMOC implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 7381250608467216362L;
	
	@Id
	private Integer PROMOTION_ID;
	
	@Column(name="PROMOTION_NAME")
    private String PROMOTION_NAME;
	
	@Column(name="MOC")
    private String MOC;
	
	@Column(name="PRODUCT")
    private String PRODUCT;
	
	@Column(name="BUDGET")
    private Double BUDGET;

	public PPMExtractMOC() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PPMExtractMOC(Integer pROMOTION_ID, String pROMOTION_NAME, String mOC, String pRODUCT, Double bUDGET) {
		super();
		PROMOTION_ID = pROMOTION_ID;
		PROMOTION_NAME = pROMOTION_NAME;
		MOC = mOC;
		PRODUCT = pRODUCT;
		BUDGET = bUDGET;
	}

	public Integer getPROMOTION_ID() {
		return PROMOTION_ID;
	}

	public void setPROMOTION_ID(Integer pROMOTION_ID) {
		PROMOTION_ID = pROMOTION_ID;
	}

	public String getPROMOTION_NAME() {
		return PROMOTION_NAME;
	}

	public void setPROMOTION_NAME(String pROMOTION_NAME) {
		PROMOTION_NAME = pROMOTION_NAME;
	}

	public String getMOC() {
		return MOC;
	}

	public void setMOC(String mOC) {
		MOC = mOC;
	}

	public String getPRODUCT() {
		return PRODUCT;
	}

	public void setPRODUCT(String pRODUCT) {
		PRODUCT = pRODUCT;
	}

	public Double getBUDGET() {
		return BUDGET;
	}

	public void setBUDGET(Double bUDGET) {
		BUDGET = bUDGET;
	}
	
	
	

}
