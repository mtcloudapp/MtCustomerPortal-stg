package com.unilever.promo.commb2c.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.unilever.promo.commb2c.model.CommB2CNoOfPromotion;
import com.unilever.promo.commb2c.model.CommB2CSolCodeReleased;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedBudget;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedPromoValue;
import com.unilever.promo.commb2c.model.CommB2CTotalPlannedPromoVolume;
import com.unilever.promo.commb2c.model.CommB2CTotalUtilizedValue;
import com.unilever.promo.commb2c.model.CommB2CTotalUtilizedVolume;
import com.unilever.promo.commb2c.model.CommB2CUtilizedBudget;
import com.unilever.promo.commb2c.model.CurrentMocPromoB2cView;
import com.unilever.promo.commb2c.repository.CommB2CCurrMocPromoViewRepository;
import com.unilever.promo.commb2c.repository.CommB2CNextMocPromoViewRepository;
import com.unilever.promo.commb2c.repository.CommB2CNoOfPromotionRepository;
import com.unilever.promo.commb2c.repository.CommB2CPrevMocPromoViewRepository;
import com.unilever.promo.commb2c.repository.CommB2CSolCodeReleasedRepository;
import com.unilever.promo.commb2c.repository.CommB2CTotalPlannedBudgetRepository;
import com.unilever.promo.commb2c.repository.CommB2CTotalPlannedPromoValueRepository;
import com.unilever.promo.commb2c.repository.CommB2CTotalPlannedPromoVolumeRepository;
import com.unilever.promo.commb2c.repository.CommB2CTotalUtilizedValueRepository;
import com.unilever.promo.commb2c.repository.CommB2CTotalUtilizedVolumeRepository;
import com.unilever.promo.commb2c.repository.CommB2CUtilizedBudgetRepository;
import com.unilever.promo.kam.model.CurrentMocPromoView;
import com.unilever.promo.commb2c.model.CurrentMocPromoB2cViewDto;
import com.unilever.promo.commb2c.model.NextMocPromoB2cViewDto;
import com.unilever.promo.commb2c.model.PreviousMocPromoB2cView;
import com.unilever.promo.commb2c.model.NextMocPromoB2cView;
import com.unilever.promo.kam.model.PreviousMocPromoView;
import com.unilever.promo.commb2c.model.PreviousMocPromoB2cViewDto;

@Service
public class CommB2CPromoService {
	
	@Autowired
	CommB2CNoOfPromotionRepository commB2CNoOfPromotionRepository;
	
	@Autowired
	CommB2CSolCodeReleasedRepository commB2CSolCodeReleasedRepository;
	
	@Autowired
	CommB2CTotalPlannedBudgetRepository commB2CTotalPlannedBudgetRepository;
	
	@Autowired
	CommB2CTotalPlannedPromoValueRepository commB2CTotalPlannedPromoValueRepository;
	
	@Autowired
	CommB2CTotalPlannedPromoVolumeRepository commB2CTotalPlannedPromoVolumeRepository;
	
	@Autowired
	CommB2CTotalUtilizedValueRepository commB2CTotalUtilizedValueRepository;
	
	@Autowired
	CommB2CTotalUtilizedVolumeRepository commB2CTotalUtilizedVolumeRepository;
	
	@Autowired
	CommB2CUtilizedBudgetRepository commB2CUtilizedBudgetRepository;
	
	@Autowired
	CommB2CCurrMocPromoViewRepository commB2CCurrMocPromoViewRepository;
	
	@Autowired
	CommB2CPrevMocPromoViewRepository commB2CPrevMocPromoViewRepository;
	
	@Autowired
	CommB2CNextMocPromoViewRepository commB2CNextMocPromoViewRepository;
	
	

	
	
	
	//=======================================================No of Promomotion start==============================================================
	
	
//	public CommB2CNoOfPromotion getNoOfPromotion(List<String> region,List<String> account,List<String> moc,List<String> category){
//
//
//		double totalAssetAmount = 0.00;
//		//Integer totalAssetAmountSum = 0;
//		CommB2CNoOfPromotion totalAssetAmountSum = new CommB2CNoOfPromotion();
//
//
//		try{
//			List<CommB2CNoOfPromotion> totalAssetValues = new ArrayList<CommB2CNoOfPromotion>();
//			List<CommB2CNoOfPromotion> totalAssetValuesByUsername = new ArrayList<CommB2CNoOfPromotion>();
//			List<CommB2CNoOfPromotion> mocList = new ArrayList<CommB2CNoOfPromotion>();
//			
//			totalAssetValuesByUsername = commB2CNoOfPromotionRepository.findAllNoOfPromotion();
//            
//			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//				
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CNoOfPromotion mocc : totalAssetValuesByUsername){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//				
//				for(CommB2CNoOfPromotion t : mocList){
//					totalAssetAmount += t.getNoOfPromotion();
//
//				}
//
//				totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//
//			}
//
//			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//				List<CommB2CNoOfPromotion> categoryList = new ArrayList<CommB2CNoOfPromotion>();
//				
//				//filtered by category
//
//				for(String c : category){
//					for(CommB2CNoOfPromotion cat : totalAssetValuesByUsername){
//						if(c.equals(cat.getCategoryNaame())){
//							categoryList.add(cat);
//						}
//
//					}
//
//				}
//
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CNoOfPromotion mocc : categoryList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//				
//				
//				totalAssetValues.addAll(mocList);
//				for(CommB2CNoOfPromotion t : totalAssetValues){
//					totalAssetAmount += t.getNoOfPromotion();
//
//				}
//				totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//			}
//
//			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//				List<CommB2CNoOfPromotion> accountList = new ArrayList<CommB2CNoOfPromotion>();
//				
//				
//				for(String accnt : account){
//					for(CommB2CNoOfPromotion acc : totalAssetValuesByUsername){
//						if(accnt.equals(acc.getAccountName())){
//							accountList.add(acc);
//						}
//
//					}
//
//				}
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CNoOfPromotion mocc : accountList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//
//				totalAssetValues.addAll(mocList);
//
//				for(CommB2CNoOfPromotion t : totalAssetValues){
//					totalAssetAmount += t.getNoOfPromotion();
//
//				}
//				totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//			}
//
//			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//				List<CommB2CNoOfPromotion> accountList = new ArrayList<CommB2CNoOfPromotion>();
//				List<CommB2CNoOfPromotion> filteredAccountCategoryList = new ArrayList<CommB2CNoOfPromotion>();
//				
//
//				//filterd by account
//				for(String accnt : account){
//					for(CommB2CNoOfPromotion acc : totalAssetValuesByUsername){
//						if(accnt.equals(acc.getAccountName())){
//							accountList.add(acc);
//						}
//
//					}
//
//				}
//
//				//filtered by category
//				for(String c : category){
//					for(CommB2CNoOfPromotion cat : accountList){
//						if(c.equals(cat.getCategoryNaame())){
//							filteredAccountCategoryList.add(cat);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CNoOfPromotion mocc : filteredAccountCategoryList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//
//				totalAssetValues.addAll(mocList);
//
//				for(CommB2CNoOfPromotion t : totalAssetValues){
//					totalAssetAmount += t.getNoOfPromotion();
//				}
//				totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//			}
//
//			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//				List<CommB2CNoOfPromotion> regionList = new ArrayList<CommB2CNoOfPromotion>();
//				
//				
//				//filter by region
//				for(String regon : region){
//					for(CommB2CNoOfPromotion reg : totalAssetValuesByUsername){
//						if(regon.equals(reg.getRegionName())){
//							regionList.add(reg);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CNoOfPromotion mocc : regionList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//				totalAssetValues.addAll(mocList);
//				for(CommB2CNoOfPromotion t : totalAssetValues){
//					totalAssetAmount += t.getNoOfPromotion();
//				}
//
//				totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//			}
//			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//				List<CommB2CNoOfPromotion> regionList = new ArrayList<CommB2CNoOfPromotion>();
//				List<CommB2CNoOfPromotion> filteredRegionAccountList = new ArrayList<CommB2CNoOfPromotion>();
//				
//				
//				//filter by region
//				for(String regon : region){
//					for(CommB2CNoOfPromotion reg : totalAssetValuesByUsername){
//						if(regon.equals(reg.getRegionName())){
//							regionList.add(reg);
//						}
//
//					}
//
//				}
//
//				//filtered by account
//
//				for(String accnt : account){
//					for(CommB2CNoOfPromotion acc : regionList){
//						if(accnt.equals(acc.getAccountName())){
//							filteredRegionAccountList.add(acc);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CNoOfPromotion mocc : filteredRegionAccountList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//				totalAssetValues.addAll(mocList);
//
//				for(CommB2CNoOfPromotion t : totalAssetValues){
//					totalAssetAmount += t.getNoOfPromotion();
//
//				}
//				totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//			}
//
//
//			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//				List<CommB2CNoOfPromotion> regionList = new ArrayList<CommB2CNoOfPromotion>();
//				List<CommB2CNoOfPromotion> filteredRegionCategoryList = new ArrayList<CommB2CNoOfPromotion>();
//				
//				//filterd by region
//
//				for(String regon : region){
//					for(CommB2CNoOfPromotion reg : totalAssetValuesByUsername){
//						if(regon.equals(reg.getRegionName())){
//							regionList.add(reg);
//						}
//
//					}
//
//				}
//
//				//filtered by category
//
//				for(String c : category){
//					for(CommB2CNoOfPromotion cat : regionList){
//						if(c.equals(cat.getCategoryNaame())){
//							filteredRegionCategoryList.add(cat);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CNoOfPromotion mocc : filteredRegionCategoryList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//				totalAssetValues.addAll(mocList);
//				for(CommB2CNoOfPromotion t : totalAssetValues){
//					totalAssetAmount += t.getNoOfPromotion();
//				}
//				totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//			}	
//
//			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//				List<CommB2CNoOfPromotion> regionList = new ArrayList<CommB2CNoOfPromotion>();
//				List<CommB2CNoOfPromotion> accountList = new ArrayList<CommB2CNoOfPromotion>();
//				List<CommB2CNoOfPromotion> filteredRegionCategoryList = new ArrayList<CommB2CNoOfPromotion>();
//				
//				if(totalAssetValuesByUsername !=null)	{
//					//-----filter by region------//
//
//					for(String regon : region){
//						for(CommB2CNoOfPromotion reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//
//
//					//-----filter by account------//
//
//					for(String accnt : account){
//						for(CommB2CNoOfPromotion acc : regionList){
//							if(accnt.equals(acc.getAccountName())){
//								accountList.add(acc);
//							}
//
//						}
//
//					}
//
//
//					//-----filter by category------//
//
//					for(String c : category){
//						for(CommB2CNoOfPromotion cat : accountList){
//							if(c.equals(cat.getCategoryNaame())){
//								filteredRegionCategoryList.add(cat);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(CommB2CNoOfPromotion mocc : filteredRegionCategoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//
//					for(CommB2CNoOfPromotion t : totalAssetValues){
//						totalAssetAmount += t.getNoOfPromotion();
//					}
//
//					totalAssetAmountSum.setNoOfPromotion(totalAssetAmount);
//
//				}//end of if
//
//			}// end of else if
//
//		}//end of try
//		catch(Exception e){
//			e.printStackTrace();
//		}
//
//
//		return totalAssetAmountSum;
//
//	}
	
	//============================== previous sol code released =======================================================//
		public Integer getSolCodeReleased(List<String> region,List<String> account,List<String> moc,List<String> category){


			 List<String> solCodeReleased = new ArrayList<>();
			 Integer distinctSolCodeReleased =0;

			try{
				solCodeReleased = commB2CSolCodeReleasedRepository.findDistinctSolCodeReleased(account, moc, region, category);
				distinctSolCodeReleased = (int) solCodeReleased.stream().distinct().count();
	     
			}
			catch(Exception e){
				e.printStackTrace();
			}


			return distinctSolCodeReleased;

		}
	
	//============================== previous no of promotions start =======================================================//
	public Integer getNoOfPromotion(List<String> region,List<String> account,List<String> moc,List<String> category){


		 List<String> noOfPromotion= new ArrayList<>();
		 Integer distinctNoOfPromotions =0;

		try{
			noOfPromotion = commB2CNoOfPromotionRepository.findDistinctNoOfPromotion(account, moc, region, category);
			distinctNoOfPromotions = (int) noOfPromotion.stream().distinct().count();
     
		}
		catch(Exception e){
			e.printStackTrace();
		}


		return distinctNoOfPromotions;

	}
	
	
	//=======================================================Solcode Released start==============================================================
	
//	public CommB2CSolCodeReleased getSolCodeReleased(List<String> region,List<String> account,List<String> moc,List<String> category){
//
//
//		double totalAssetAmount = 0.00;
//		//Integer totalAssetAmountSum = 0;
//		CommB2CSolCodeReleased totalAssetAmountSum = new CommB2CSolCodeReleased();
//
//
//		try{
//			List<CommB2CSolCodeReleased> totalAssetValues = new ArrayList<CommB2CSolCodeReleased>();
//			List<CommB2CSolCodeReleased> totalAssetValuesByUsername = new ArrayList<CommB2CSolCodeReleased>();
//			List<CommB2CSolCodeReleased> mocList = new ArrayList<CommB2CSolCodeReleased>();
//			
//			totalAssetValuesByUsername = commB2CSolCodeReleasedRepository.findAllSolcodeReleased();
//            
//			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//				
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CSolCodeReleased mocc : totalAssetValuesByUsername){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//				
//				for(CommB2CSolCodeReleased t : mocList){
//					totalAssetAmount += t.getSolCodeReleased();
//
//				}
//
//				totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//
//			}
//
//			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//				List<CommB2CSolCodeReleased> categoryList = new ArrayList<CommB2CSolCodeReleased>();
//				
//				//filtered by category
//
//				for(String c : category){
//					for(CommB2CSolCodeReleased cat : totalAssetValuesByUsername){
//						if(c.equals(cat.getCategoryNaame())){
//							categoryList.add(cat);
//						}
//
//					}
//
//				}
//
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CSolCodeReleased mocc : categoryList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//				
//				
//				totalAssetValues.addAll(mocList);
//				for(CommB2CSolCodeReleased t : totalAssetValues){
//					totalAssetAmount += t.getSolCodeReleased();
//
//				}
//				totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//			}
//
//			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//				List<CommB2CSolCodeReleased> accountList = new ArrayList<CommB2CSolCodeReleased>();
//				
//				
//				for(String accnt : account){
//					for(CommB2CSolCodeReleased acc : totalAssetValuesByUsername){
//						if(accnt.equals(acc.getAccountName())){
//							accountList.add(acc);
//						}
//
//					}
//
//				}
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CSolCodeReleased mocc : accountList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//
//				totalAssetValues.addAll(mocList);
//
//				for(CommB2CSolCodeReleased t : totalAssetValues){
//					totalAssetAmount += t.getSolCodeReleased();
//
//				}
//				totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//			}
//
//			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//				List<CommB2CSolCodeReleased> accountList = new ArrayList<CommB2CSolCodeReleased>();
//				List<CommB2CSolCodeReleased> filteredAccountCategoryList = new ArrayList<CommB2CSolCodeReleased>();
//				
//
//				//filterd by account
//				for(String accnt : account){
//					for(CommB2CSolCodeReleased acc : totalAssetValuesByUsername){
//						if(accnt.equals(acc.getAccountName())){
//							accountList.add(acc);
//						}
//
//					}
//
//				}
//
//				//filtered by category
//				for(String c : category){
//					for(CommB2CSolCodeReleased cat : accountList){
//						if(c.equals(cat.getCategoryNaame())){
//							filteredAccountCategoryList.add(cat);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CSolCodeReleased mocc : filteredAccountCategoryList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//
//				totalAssetValues.addAll(mocList);
//
//				for(CommB2CSolCodeReleased t : totalAssetValues){
//					totalAssetAmount += t.getSolCodeReleased();
//				}
//				totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//			}
//
//			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//				List<CommB2CSolCodeReleased> regionList = new ArrayList<CommB2CSolCodeReleased>();
//				
//				
//				//filter by region
//				for(String regon : region){
//					for(CommB2CSolCodeReleased reg : totalAssetValuesByUsername){
//						if(regon.equals(reg.getRegionName())){
//							regionList.add(reg);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CSolCodeReleased mocc : regionList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//				totalAssetValues.addAll(mocList);
//				for(CommB2CSolCodeReleased t : totalAssetValues){
//					totalAssetAmount += t.getSolCodeReleased();
//				}
//
//				totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//			}
//			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//				List<CommB2CSolCodeReleased> regionList = new ArrayList<CommB2CSolCodeReleased>();
//				List<CommB2CSolCodeReleased> filteredRegionAccountList = new ArrayList<CommB2CSolCodeReleased>();
//				
//				
//				//filter by region
//				for(String regon : region){
//					for(CommB2CSolCodeReleased reg : totalAssetValuesByUsername){
//						if(regon.equals(reg.getRegionName())){
//							regionList.add(reg);
//						}
//
//					}
//
//				}
//
//				//filtered by account
//
//				for(String accnt : account){
//					for(CommB2CSolCodeReleased acc : regionList){
//						if(accnt.equals(acc.getAccountName())){
//							filteredRegionAccountList.add(acc);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CSolCodeReleased mocc : filteredRegionAccountList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//				totalAssetValues.addAll(mocList);
//
//				for(CommB2CSolCodeReleased t : totalAssetValues){
//					totalAssetAmount += t.getSolCodeReleased();
//
//				}
//				totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//			}
//
//
//			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//				List<CommB2CSolCodeReleased> regionList = new ArrayList<CommB2CSolCodeReleased>();
//				List<CommB2CSolCodeReleased> filteredRegionCategoryList = new ArrayList<CommB2CSolCodeReleased>();
//				
//				//filterd by region
//
//				for(String regon : region){
//					for(CommB2CSolCodeReleased reg : totalAssetValuesByUsername){
//						if(regon.equals(reg.getRegionName())){
//							regionList.add(reg);
//						}
//
//					}
//
//				}
//
//				//filtered by category
//
//				for(String c : category){
//					for(CommB2CSolCodeReleased cat : regionList){
//						if(c.equals(cat.getCategoryNaame())){
//							filteredRegionCategoryList.add(cat);
//						}
//
//					}
//
//				}
//				
//				//filtered by MOC
//				for(String m : moc){
//					for(CommB2CSolCodeReleased mocc : filteredRegionCategoryList){
//						if(m.equals(mocc.getMoc())){
//							mocList.add(mocc);
//						}
//
//					}
//
//				}
//
//				totalAssetValues.addAll(mocList);
//				for(CommB2CSolCodeReleased t : totalAssetValues){
//					totalAssetAmount += t.getSolCodeReleased();
//				}
//				totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//			}	
//
//			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//				List<CommB2CSolCodeReleased> regionList = new ArrayList<CommB2CSolCodeReleased>();
//				List<CommB2CSolCodeReleased> accountList = new ArrayList<CommB2CSolCodeReleased>();
//				List<CommB2CSolCodeReleased> filteredRegionCategoryList = new ArrayList<CommB2CSolCodeReleased>();
//				
//				if(totalAssetValuesByUsername !=null)	{
//					//-----filter by region------//
//
//					for(String regon : region){
//						for(CommB2CSolCodeReleased reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//
//
//					//-----filter by account------//
//
//					for(String accnt : account){
//						for(CommB2CSolCodeReleased acc : regionList){
//							if(accnt.equals(acc.getAccountName())){
//								accountList.add(acc);
//							}
//
//						}
//
//					}
//
//
//					//-----filter by category------//
//
//					for(String c : category){
//						for(CommB2CSolCodeReleased cat : accountList){
//							if(c.equals(cat.getCategoryNaame())){
//								filteredRegionCategoryList.add(cat);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(CommB2CSolCodeReleased mocc : filteredRegionCategoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//
//					for(CommB2CSolCodeReleased t : totalAssetValues){
//						totalAssetAmount += t.getSolCodeReleased();
//					}
//
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//
//				}//end of if
//
//			}// end of else if
//
//		}//end of try
//		catch(Exception e){
//			e.printStackTrace();
//		}
//
//
//		return totalAssetAmountSum;
//
//	}
	
	
	//=======================================================Total planned Budget start==============================================================
	
	public CommB2CTotalPlannedBudget getTotalPlannedBudget(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CTotalPlannedBudget totalAssetAmountSum = new CommB2CTotalPlannedBudget();


		try{
			List<CommB2CTotalPlannedBudget> totalAssetValues = new ArrayList<CommB2CTotalPlannedBudget>();
			List<CommB2CTotalPlannedBudget> totalAssetValuesByUsername = new ArrayList<CommB2CTotalPlannedBudget>();
			List<CommB2CTotalPlannedBudget> mocList = new ArrayList<CommB2CTotalPlannedBudget>();
			
			totalAssetValuesByUsername = commB2CTotalPlannedBudgetRepository.findAllTotalPlannedBudget();
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedBudget mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CTotalPlannedBudget t : mocList){
					totalAssetAmount += t.getTotalPlannedBudget();

				}

				totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CTotalPlannedBudget> categoryList = new ArrayList<CommB2CTotalPlannedBudget>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CTotalPlannedBudget cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedBudget mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedBudget t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedBudget();

				}
				totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CTotalPlannedBudget> accountList = new ArrayList<CommB2CTotalPlannedBudget>();
				
				
				for(String accnt : account){
					for(CommB2CTotalPlannedBudget acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedBudget mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedBudget t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedBudget();

				}
				totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CTotalPlannedBudget> accountList = new ArrayList<CommB2CTotalPlannedBudget>();
				List<CommB2CTotalPlannedBudget> filteredAccountCategoryList = new ArrayList<CommB2CTotalPlannedBudget>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CTotalPlannedBudget acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CTotalPlannedBudget cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedBudget mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedBudget t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedBudget();
				}
				totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CTotalPlannedBudget> regionList = new ArrayList<CommB2CTotalPlannedBudget>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalPlannedBudget reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedBudget mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedBudget t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedBudget();
				}

				totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CTotalPlannedBudget> regionList = new ArrayList<CommB2CTotalPlannedBudget>();
				List<CommB2CTotalPlannedBudget> filteredRegionAccountList = new ArrayList<CommB2CTotalPlannedBudget>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalPlannedBudget reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CTotalPlannedBudget acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedBudget mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedBudget t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedBudget();

				}
				totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CTotalPlannedBudget> regionList = new ArrayList<CommB2CTotalPlannedBudget>();
				List<CommB2CTotalPlannedBudget> filteredRegionCategoryList = new ArrayList<CommB2CTotalPlannedBudget>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CTotalPlannedBudget reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CTotalPlannedBudget cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedBudget mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedBudget t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedBudget();
				}
				totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CTotalPlannedBudget> regionList = new ArrayList<CommB2CTotalPlannedBudget>();
				List<CommB2CTotalPlannedBudget> accountList = new ArrayList<CommB2CTotalPlannedBudget>();
				List<CommB2CTotalPlannedBudget> filteredRegionCategoryList = new ArrayList<CommB2CTotalPlannedBudget>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CTotalPlannedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CTotalPlannedBudget acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CTotalPlannedBudget cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CTotalPlannedBudget mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CTotalPlannedBudget t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedBudget();
					}

					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	
	//=======================================================Total planned Promo value start==============================================================
	
	public CommB2CTotalPlannedPromoValue getTotalPlannedPromoValue(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CTotalPlannedPromoValue totalAssetAmountSum = new CommB2CTotalPlannedPromoValue();


		try{
			List<CommB2CTotalPlannedPromoValue> totalAssetValues = new ArrayList<CommB2CTotalPlannedPromoValue>();
			List<CommB2CTotalPlannedPromoValue> totalAssetValuesByUsername = new ArrayList<CommB2CTotalPlannedPromoValue>();
			List<CommB2CTotalPlannedPromoValue> mocList = new ArrayList<CommB2CTotalPlannedPromoValue>();
			
			totalAssetValuesByUsername = commB2CTotalPlannedPromoValueRepository.findAllTotalPalannedPromoValue();
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoValue mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CTotalPlannedPromoValue t : mocList){
					totalAssetAmount += t.getTotalPlannedPromoValue();

				}

				totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CTotalPlannedPromoValue> categoryList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CTotalPlannedPromoValue cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedPromoValue t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoValue();

				}
				totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CTotalPlannedPromoValue> accountList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				
				
				for(String accnt : account){
					for(CommB2CTotalPlannedPromoValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedPromoValue t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoValue();

				}
				totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CTotalPlannedPromoValue> accountList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				List<CommB2CTotalPlannedPromoValue> filteredAccountCategoryList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CTotalPlannedPromoValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CTotalPlannedPromoValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedPromoValue t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoValue();
				}
				totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CTotalPlannedPromoValue> regionList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalPlannedPromoValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedPromoValue t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoValue();
				}

				totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CTotalPlannedPromoValue> regionList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				List<CommB2CTotalPlannedPromoValue> filteredRegionAccountList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalPlannedPromoValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CTotalPlannedPromoValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedPromoValue t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoValue();

				}
				totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CTotalPlannedPromoValue> regionList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				List<CommB2CTotalPlannedPromoValue> filteredRegionCategoryList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CTotalPlannedPromoValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CTotalPlannedPromoValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedPromoValue t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoValue();
				}
				totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CTotalPlannedPromoValue> regionList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				List<CommB2CTotalPlannedPromoValue> accountList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				List<CommB2CTotalPlannedPromoValue> filteredRegionCategoryList = new ArrayList<CommB2CTotalPlannedPromoValue>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CTotalPlannedPromoValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CTotalPlannedPromoValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CTotalPlannedPromoValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CTotalPlannedPromoValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CTotalPlannedPromoValue t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoValue();
					}

					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	//=======================================================Total planned Promo volume start==============================================================
	
	public CommB2CTotalPlannedPromoVolume getTotalPlannedPromovolume(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CTotalPlannedPromoVolume totalAssetAmountSum = new CommB2CTotalPlannedPromoVolume();


		try{
			List<CommB2CTotalPlannedPromoVolume> totalAssetValues = new ArrayList<CommB2CTotalPlannedPromoVolume>();
			List<CommB2CTotalPlannedPromoVolume> totalAssetValuesByUsername = new ArrayList<CommB2CTotalPlannedPromoVolume>();
			List<CommB2CTotalPlannedPromoVolume> mocList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
			
			totalAssetValuesByUsername = commB2CTotalPlannedPromoVolumeRepository.findAllTotalPalannedPromoVolume();
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoVolume mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CTotalPlannedPromoVolume t : mocList){
					totalAssetAmount += t.getTotalPlannedPromoVolume();

				}

				totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CTotalPlannedPromoVolume> categoryList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CTotalPlannedPromoVolume cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedPromoVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoVolume();

				}
				totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CTotalPlannedPromoVolume> accountList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				
				
				for(String accnt : account){
					for(CommB2CTotalPlannedPromoVolume acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedPromoVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoVolume();

				}
				totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CTotalPlannedPromoVolume> accountList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				List<CommB2CTotalPlannedPromoVolume> filteredAccountCategoryList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CTotalPlannedPromoVolume acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CTotalPlannedPromoVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedPromoVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoVolume();
				}
				totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CTotalPlannedPromoVolume> regionList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalPlannedPromoVolume reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedPromoVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoVolume();
				}

				totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CTotalPlannedPromoVolume> regionList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				List<CommB2CTotalPlannedPromoVolume> filteredRegionAccountList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalPlannedPromoVolume reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CTotalPlannedPromoVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CTotalPlannedPromoVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoVolume();

				}
				totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CTotalPlannedPromoVolume> regionList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				List<CommB2CTotalPlannedPromoVolume> filteredRegionCategoryList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CTotalPlannedPromoVolume reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CTotalPlannedPromoVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalPlannedPromoVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalPlannedPromoVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalPlannedPromoVolume();
				}
				totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CTotalPlannedPromoVolume> regionList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				List<CommB2CTotalPlannedPromoVolume> accountList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				List<CommB2CTotalPlannedPromoVolume> filteredRegionCategoryList = new ArrayList<CommB2CTotalPlannedPromoVolume>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CTotalPlannedPromoVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CTotalPlannedPromoVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CTotalPlannedPromoVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CTotalPlannedPromoVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CTotalPlannedPromoVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoVolume();
					}

					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	//=======================================================Utilized value start==============================================================
	
	public CommB2CTotalUtilizedValue getTotalUtilizedValue(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CTotalUtilizedValue totalAssetAmountSum = new CommB2CTotalUtilizedValue();


		try{
			List<CommB2CTotalUtilizedValue> totalAssetValues = new ArrayList<CommB2CTotalUtilizedValue>();
			List<CommB2CTotalUtilizedValue> totalAssetValuesByUsername = new ArrayList<CommB2CTotalUtilizedValue>();
			List<CommB2CTotalUtilizedValue> mocList = new ArrayList<CommB2CTotalUtilizedValue>();
			
			totalAssetValuesByUsername = commB2CTotalUtilizedValueRepository.findAllTotalUtilizedValue();
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedValue mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CTotalUtilizedValue t : mocList){
					totalAssetAmount += t.getTotalUtilizedValue();

				}

				totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CTotalUtilizedValue> categoryList = new ArrayList<CommB2CTotalUtilizedValue>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CTotalUtilizedValue cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(CommB2CTotalUtilizedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedValue();

				}
				totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CTotalUtilizedValue> accountList = new ArrayList<CommB2CTotalUtilizedValue>();
				
				
				for(String accnt : account){
					for(CommB2CTotalUtilizedValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalUtilizedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedValue();

				}
				totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CTotalUtilizedValue> accountList = new ArrayList<CommB2CTotalUtilizedValue>();
				List<CommB2CTotalUtilizedValue> filteredAccountCategoryList = new ArrayList<CommB2CTotalUtilizedValue>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CTotalUtilizedValue acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CTotalUtilizedValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalUtilizedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedValue();
				}
				totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CTotalUtilizedValue> regionList = new ArrayList<CommB2CTotalUtilizedValue>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalUtilizedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedValue mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalUtilizedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedValue();
				}

				totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CTotalUtilizedValue> regionList = new ArrayList<CommB2CTotalUtilizedValue>();
				List<CommB2CTotalUtilizedValue> filteredRegionAccountList = new ArrayList<CommB2CTotalUtilizedValue>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalUtilizedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CTotalUtilizedValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedValue mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CTotalUtilizedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedValue();

				}
				totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CTotalUtilizedValue> regionList = new ArrayList<CommB2CTotalUtilizedValue>();
				List<CommB2CTotalUtilizedValue> filteredRegionCategoryList = new ArrayList<CommB2CTotalUtilizedValue>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CTotalUtilizedValue reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CTotalUtilizedValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedValue mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalUtilizedValue t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedValue();
				}
				totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CTotalUtilizedValue> regionList = new ArrayList<CommB2CTotalUtilizedValue>();
				List<CommB2CTotalUtilizedValue> accountList = new ArrayList<CommB2CTotalUtilizedValue>();
				List<CommB2CTotalUtilizedValue> filteredRegionCategoryList = new ArrayList<CommB2CTotalUtilizedValue>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CTotalUtilizedValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CTotalUtilizedValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CTotalUtilizedValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CTotalUtilizedValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CTotalUtilizedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedValue();
					}

					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	//=======================================================Utilized volume start==============================================================
	
	public CommB2CTotalUtilizedVolume getTotalUtilizeddVolume(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CTotalUtilizedVolume totalAssetAmountSum = new CommB2CTotalUtilizedVolume();


		try{
			List<CommB2CTotalUtilizedVolume> totalAssetValues = new ArrayList<CommB2CTotalUtilizedVolume>();
			List<CommB2CTotalUtilizedVolume> totalAssetValuesByUsername = new ArrayList<CommB2CTotalUtilizedVolume>();
			List<CommB2CTotalUtilizedVolume> mocList = new ArrayList<CommB2CTotalUtilizedVolume>();
			
			totalAssetValuesByUsername = commB2CTotalUtilizedVolumeRepository.findAllTotalUtilizedVolume();
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedVolume mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CTotalUtilizedVolume t : mocList){
					totalAssetAmount += t.getTotalUtilizedVolume();

				}

				totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CTotalUtilizedVolume> categoryList = new ArrayList<CommB2CTotalUtilizedVolume>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CTotalUtilizedVolume cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(CommB2CTotalUtilizedVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedVolume();

				}
				totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CTotalUtilizedVolume> accountList = new ArrayList<CommB2CTotalUtilizedVolume>();
				
				
				for(String accnt : account){
					for(CommB2CTotalUtilizedVolume acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalUtilizedVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedVolume();

				}
				totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CTotalUtilizedVolume> accountList = new ArrayList<CommB2CTotalUtilizedVolume>();
				List<CommB2CTotalUtilizedVolume> filteredAccountCategoryList = new ArrayList<CommB2CTotalUtilizedVolume>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CTotalUtilizedVolume acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CTotalUtilizedVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CTotalUtilizedVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedVolume();
				}
				totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CTotalUtilizedVolume> regionList = new ArrayList<CommB2CTotalUtilizedVolume>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalUtilizedVolume reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedVolume mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalUtilizedVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedVolume();
				}

				totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CTotalUtilizedVolume> regionList = new ArrayList<CommB2CTotalUtilizedVolume>();
				List<CommB2CTotalUtilizedVolume> filteredRegionAccountList = new ArrayList<CommB2CTotalUtilizedVolume>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CTotalUtilizedVolume reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CTotalUtilizedVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedVolume mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CTotalUtilizedVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedVolume();

				}
				totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CTotalUtilizedVolume> regionList = new ArrayList<CommB2CTotalUtilizedVolume>();
				List<CommB2CTotalUtilizedVolume> filteredRegionCategoryList = new ArrayList<CommB2CTotalUtilizedVolume>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CTotalUtilizedVolume reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CTotalUtilizedVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CTotalUtilizedVolume mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CTotalUtilizedVolume t : totalAssetValues){
					totalAssetAmount += t.getTotalUtilizedVolume();
				}
				totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CTotalUtilizedVolume> regionList = new ArrayList<CommB2CTotalUtilizedVolume>();
				List<CommB2CTotalUtilizedVolume> accountList = new ArrayList<CommB2CTotalUtilizedVolume>();
				List<CommB2CTotalUtilizedVolume> filteredRegionCategoryList = new ArrayList<CommB2CTotalUtilizedVolume>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CTotalUtilizedVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CTotalUtilizedVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CTotalUtilizedVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CTotalUtilizedVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CTotalUtilizedVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedVolume();
					}

					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	//=======================================================Utilized Budget start==============================================================
	
	public CommB2CUtilizedBudget getUtilizedBudget(List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		CommB2CUtilizedBudget totalAssetAmountSum = new CommB2CUtilizedBudget();


		try{
			List<CommB2CUtilizedBudget> totalAssetValues = new ArrayList<CommB2CUtilizedBudget>();
			List<CommB2CUtilizedBudget> totalAssetValuesByUsername = new ArrayList<CommB2CUtilizedBudget>();
			List<CommB2CUtilizedBudget> mocList = new ArrayList<CommB2CUtilizedBudget>();
			
			totalAssetValuesByUsername = commB2CUtilizedBudgetRepository.findAllUtilizedBudget();
            
			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
				
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CUtilizedBudget mocc : totalAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(CommB2CUtilizedBudget t : mocList){
					totalAssetAmount += t.getUtilizedBudget();

				}

				totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<CommB2CUtilizedBudget> categoryList = new ArrayList<CommB2CUtilizedBudget>();
				
				//filtered by category

				for(String c : category){
					for(CommB2CUtilizedBudget cat : totalAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(CommB2CUtilizedBudget mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				
				totalAssetValues.addAll(mocList);
				for(CommB2CUtilizedBudget t : totalAssetValues){
					totalAssetAmount += t.getUtilizedBudget();

				}
				totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<CommB2CUtilizedBudget> accountList = new ArrayList<CommB2CUtilizedBudget>();
				
				
				for(String accnt : account){
					for(CommB2CUtilizedBudget acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(CommB2CUtilizedBudget mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CUtilizedBudget t : totalAssetValues){
					totalAssetAmount += t.getUtilizedBudget();

				}
				totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<CommB2CUtilizedBudget> accountList = new ArrayList<CommB2CUtilizedBudget>();
				List<CommB2CUtilizedBudget> filteredAccountCategoryList = new ArrayList<CommB2CUtilizedBudget>();
				

				//filterd by account
				for(String accnt : account){
					for(CommB2CUtilizedBudget acc : totalAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(CommB2CUtilizedBudget cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CUtilizedBudget mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(CommB2CUtilizedBudget t : totalAssetValues){
					totalAssetAmount += t.getUtilizedBudget();
				}
				totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				List<CommB2CUtilizedBudget> regionList = new ArrayList<CommB2CUtilizedBudget>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CUtilizedBudget reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CUtilizedBudget mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CUtilizedBudget t : totalAssetValues){
					totalAssetAmount += t.getUtilizedBudget();
				}

				totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<CommB2CUtilizedBudget> regionList = new ArrayList<CommB2CUtilizedBudget>();
				List<CommB2CUtilizedBudget> filteredRegionAccountList = new ArrayList<CommB2CUtilizedBudget>();
				
				
				//filter by region
				for(String regon : region){
					for(CommB2CUtilizedBudget reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by account

				for(String accnt : account){
					for(CommB2CUtilizedBudget acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CUtilizedBudget mocc : filteredRegionAccountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(CommB2CUtilizedBudget t : totalAssetValues){
					totalAssetAmount += t.getUtilizedBudget();

				}
				totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<CommB2CUtilizedBudget> regionList = new ArrayList<CommB2CUtilizedBudget>();
				List<CommB2CUtilizedBudget> filteredRegionCategoryList = new ArrayList<CommB2CUtilizedBudget>();
				
				//filterd by region

				for(String regon : region){
					for(CommB2CUtilizedBudget reg : totalAssetValuesByUsername){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(CommB2CUtilizedBudget cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(CommB2CUtilizedBudget mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(CommB2CUtilizedBudget t : totalAssetValues){
					totalAssetAmount += t.getUtilizedBudget();
				}
				totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<CommB2CUtilizedBudget> regionList = new ArrayList<CommB2CUtilizedBudget>();
				List<CommB2CUtilizedBudget> accountList = new ArrayList<CommB2CUtilizedBudget>();
				List<CommB2CUtilizedBudget> filteredRegionCategoryList = new ArrayList<CommB2CUtilizedBudget>();
				
				if(totalAssetValuesByUsername !=null)	{
					//-----filter by region------//

					for(String regon : region){
						for(CommB2CUtilizedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}


					//-----filter by account------//

					for(String accnt : account){
						for(CommB2CUtilizedBudget acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(CommB2CUtilizedBudget cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(CommB2CUtilizedBudget mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(CommB2CUtilizedBudget t : totalAssetValues){
						totalAssetAmount += t.getUtilizedBudget();
					}

					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}
	
	//----------------------------------------current moc view-------------------------------------------//
			public List<CurrentMocPromoB2cViewDto> getPromoCurrentMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
				List<CurrentMocPromoB2cViewDto> filteredViewList = new ArrayList<>();
				List<CurrentMocPromoB2cView> totalRecords = new ArrayList<>();

				try{
					Pageable paging = PageRequest.of(pageNo, pageSize);
					Integer pagestart = 0, pageend = 0;
					if (pageNo == 0) {
						pageNo = 1;
					}
					pagestart = (pageSize + 1);
					pageend = (pageNo * pageSize) + 1000;
					
					//Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
					System.out.println("currentMocViewDetails 1");
					Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocRegionAccountCategory(moc, account, region, category, pagestart, pageend, paging);
					System.out.println("currentMocViewDetails 2");
					totalRecords = commB2CCurrMocPromoViewRepository.findAllCountCurrentMocViewByMocRegionAccountCategory(moc, account, region, category);

					for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
						CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();

						CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
						CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
						CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
						CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
						CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
						CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
						CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
						CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
						CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
						CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
						CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
						CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
						CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
						CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
						CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
						CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());

						filteredViewList.add(CurrentMocPromoB2cViewDto);
					}

//					if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMoc(moc, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findCountByMoc(moc);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//					}
//
//
//					else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocCategory(moc,category, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findCountByMocCategory(moc,category);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//
//					}
//
//					else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocAccount(moc,account, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findCountByAccount(moc,account);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//
//					}
//
//					else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocAccountCategory(moc, account, category, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findCountByAccountMocCategory(moc, account, category);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//
//					}
//
//					else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocRegion(moc, region, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findCountByMocRegion(moc, region);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//
//
//
//					}
//
//					else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocAccountRegion(moc, account, region, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findCountByAccountMocRegion(moc, account, region);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//
//
//
//
//					}
//
//					else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocRegionCategory(moc, region, category, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findAllCountCurrentMocViewByMocRegionCategory(moc, region, category);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//
//
//					}
//
//					else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//						Page<CurrentMocPromoB2cView> currentMocViewDetails = commB2CCurrMocPromoViewRepository.findAllCurrentMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
//						totalRecords = commB2CCurrMocPromoViewRepository.findAllCountCurrentMocViewByMocRegionAccountCategory(moc, account, region, category);
//
//						for(CurrentMocPromoB2cView c : currentMocViewDetails.getContent()){
//							CurrentMocPromoB2cViewDto CurrentMocPromoB2cViewDto = new CurrentMocPromoB2cViewDto();
//
//							CurrentMocPromoB2cViewDto.setCluster(c.getCluster());
//							CurrentMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							CurrentMocPromoB2cViewDto.setBrand(c.getBrand());
//							CurrentMocPromoB2cViewDto.setCategory(c.getCategory());
//							CurrentMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							CurrentMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							CurrentMocPromoB2cViewDto.setMoc(c.getMoc());
//							CurrentMocPromoB2cViewDto.setOffer(c.getOffer());
//							CurrentMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							CurrentMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							CurrentMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							CurrentMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							CurrentMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							CurrentMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							CurrentMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							CurrentMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(CurrentMocPromoB2cViewDto);
//						}
//					}


				}catch(Exception e){
					e.printStackTrace();
				}
				return filteredViewList;
			}

		//=========================Previous Moc View==========================================================================
			
			public List<PreviousMocPromoB2cViewDto> getPromoPreviousMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
				List<PreviousMocPromoB2cViewDto> filteredViewList = new ArrayList<>();
				List<PreviousMocPromoB2cView> totalRecords = new ArrayList<>();

				try{
					Pageable paging = PageRequest.of(pageNo, pageSize);

					Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
					totalRecords = commB2CPrevMocPromoViewRepository.findAllCountPreviousMocViewByMocRegionAccountCategory(moc, account, region, category);

					for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
						PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();

						PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
						PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
						PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
						PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
						PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
						PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
						PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
						PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
						PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
						PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
						PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
						PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
						PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
						PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
						PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
						PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());

						filteredViewList.add(PreviousMocPromoB2cViewDto);
					}
//					if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMoc(moc, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findCountByMoc(moc);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//					}
//
//					else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocCategory(moc,category, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findCountByMocCategory(moc,category);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//
//					}
//
//					else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocAccount(moc,account, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findCountByAccount(moc,account);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//
//					}
//
//					else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocAccountCategory(moc, account, category, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findCountByAccountMocCategory(moc, account, category);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//
//					}	
//
//					else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocRegion(moc, region, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findCountByMocRegion(moc, region);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//
//
//					}
//
//					else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocAccountRegion(moc, account, region, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findCountByAccountMocRegion(moc, account, region);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//
//					}
//					else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocRegionCategory(moc, region, category, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findAllCountPreviousMocViewByMocRegionCategory(moc, region, category);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//
//
//					}
//
//					else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//						Page<PreviousMocPromoB2cView> previousMocViewDetails = commB2CPrevMocPromoViewRepository.findAllPreviousMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
//						totalRecords = commB2CPrevMocPromoViewRepository.findAllCountPreviousMocViewByMocRegionAccountCategory(moc, account, region, category);
//
//						for(PreviousMocPromoB2cView c : previousMocViewDetails.getContent()){
//							PreviousMocPromoB2cViewDto PreviousMocPromoB2cViewDto = new PreviousMocPromoB2cViewDto();
//
//							PreviousMocPromoB2cViewDto.setCluster(c.getCluster());
//							PreviousMocPromoB2cViewDto.setBasepack(c.getBasepack());
//							PreviousMocPromoB2cViewDto.setBrand(c.getBrand());
//							PreviousMocPromoB2cViewDto.setCategory(c.getCategory());
//							PreviousMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//							PreviousMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//							PreviousMocPromoB2cViewDto.setMoc(c.getMoc());
//							PreviousMocPromoB2cViewDto.setOffer(c.getOffer());
//							PreviousMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//							PreviousMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//							PreviousMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//							PreviousMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//							PreviousMocPromoB2cViewDto.setSol_code(c.getSol_code());
//							PreviousMocPromoB2cViewDto.setUtilized_budget(c.getUtilized_budget());
//							PreviousMocPromoB2cViewDto.setUtilized_volume(c.getUtilized_volume());
//							PreviousMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//							filteredViewList.add(PreviousMocPromoB2cViewDto);
//						}
//					}

				}catch(Exception e){
					e.printStackTrace();
				}
				return filteredViewList;
			}


			//=========================Next Moc View==========================================================================
			
					public List<NextMocPromoB2cViewDto> getPromoNextMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
						List<NextMocPromoB2cViewDto> filteredViewList = new ArrayList<>();
						List<NextMocPromoB2cView> totalRecords = new ArrayList<>();

						try{
							Pageable paging = PageRequest.of(pageNo, pageSize);
							Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
							totalRecords = commB2CNextMocPromoViewRepository.findAllCountNextMocViewByMocRegionAccountCategory(moc, account, region, category);

							for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
								NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();

								NextMocPromoB2cViewDto.setCluster(c.getCluster());
								NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
								NextMocPromoB2cViewDto.setBrand(c.getBrand());
								NextMocPromoB2cViewDto.setCategory(c.getCategory());
								NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
								NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
								NextMocPromoB2cViewDto.setMoc(c.getMoc());
								NextMocPromoB2cViewDto.setOffer(c.getOffer());
								NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
								NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
								NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
								NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
								NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
								NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());

								filteredViewList.add(NextMocPromoB2cViewDto);
							}

//							if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMoc(moc, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findCountByMoc(moc);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//							}
//
//							else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocCategory(moc,category, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findCountByMocCategory(moc,category);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//
//							}
//
//							else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocAccount(moc,account, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findCountByAccount(moc,account);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//
//							}
//
//							else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocAccountCategory(moc, account, category, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findCountByAccountMocCategory(moc, account, category);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//
//							}	
//
//							else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocRegion(moc, region, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findCountByMocRegion(moc, region);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//
//
//							}
//
//							else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocAccountRegion(moc, account, region, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findCountByAccountMocRegion(moc, account, region);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//
//							}
//							else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocRegionCategory(moc, region, category, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findAllCountNextMocViewByMocRegionCategory(moc, region, category);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//
//
//							}
//
//							else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//								Page<NextMocPromoB2cView> nextMocViewDetails = commB2CNextMocPromoViewRepository.findAllNextMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
//								totalRecords = commB2CNextMocPromoViewRepository.findAllCountNextMocViewByMocRegionAccountCategory(moc, account, region, category);
//
//								for(NextMocPromoB2cView c : nextMocViewDetails.getContent()){
//									NextMocPromoB2cViewDto NextMocPromoB2cViewDto = new NextMocPromoB2cViewDto();
//
//									NextMocPromoB2cViewDto.setCluster(c.getCluster());
//									NextMocPromoB2cViewDto.setBasepack(c.getBasepack());
//									NextMocPromoB2cViewDto.setBrand(c.getBrand());
//									NextMocPromoB2cViewDto.setCategory(c.getCategory());
//									NextMocPromoB2cViewDto.setL1_customer(c.getL1_customer());
//									NextMocPromoB2cViewDto.setL2_customer(c.getL2_customer());
//									NextMocPromoB2cViewDto.setMoc(c.getMoc());
//									NextMocPromoB2cViewDto.setOffer(c.getOffer());
//									NextMocPromoB2cViewDto.setPlanned_volume(c.getPlanned_volume());
//									NextMocPromoB2cViewDto.setPromo_description(c.getPromo_description());
//									NextMocPromoB2cViewDto.setPromo_id(c.getPromo_id());
//									NextMocPromoB2cViewDto.setSol_code(c.getSol_code());
//									NextMocPromoB2cViewDto.setPlanned_budget(c.getPlanned_budget());
//									NextMocPromoB2cViewDto.setTotalRecords(totalRecords.size());
//
//									filteredViewList.add(NextMocPromoB2cViewDto);
//								}
//							}

						}catch(Exception e){
							e.printStackTrace();
						}
						return filteredViewList;
					}

	
	

}
