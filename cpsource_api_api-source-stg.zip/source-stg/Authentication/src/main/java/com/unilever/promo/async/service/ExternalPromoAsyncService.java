package com.unilever.promo.async.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.unilever.promo.external.model.ExtenalTotalUtilizeVolume;
import com.unilever.promo.external.model.ExternalNoOfPromotion;
import com.unilever.promo.external.model.ExternalTotalPlannedBudget;
import com.unilever.promo.external.model.ExternalTotalPlannedPromoVolume;
import com.unilever.promo.external.service.ExternalPromoService;


@Service
public class ExternalPromoAsyncService {
	
	private static Logger log = LoggerFactory.getLogger(ExternalPromoAsyncService.class);
	
	@Autowired
	ExternalPromoService externalPromoService;

	@Async("asyncExecutor")
	public CompletableFuture<Integer> getAllExternalNoOfPromotion(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{ 
		Integer totalAssetExternalValueData=0;
		try{
			log.info("Total External No Of promotion start starts");

			totalAssetExternalValueData = externalPromoService.getExternalNoOfPromotionValue(username, region, moc, category);
			log.info("totalAssetExternalValueData, {}", totalAssetExternalValueData);
			//Thread.sleep(1000L);    //Intentional delay
			log.info("totalAssetValueData completed");
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetExternalValueData);
	}	    
	
	@Async("asyncExecutor")
	public CompletableFuture<ExternalTotalPlannedBudget> getAllExternalTotalPlannedBudget(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{ 
		ExternalTotalPlannedBudget totalAssetExternalValueData = new ExternalTotalPlannedBudget();
		try{
			log.info("Total External Total Planned Budget starts");
			totalAssetExternalValueData = externalPromoService.getExternalTotalPlannedBudget(username, region, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetExternalValueData);
	}	 
	
	@Async("asyncExecutor")
	public CompletableFuture<ExternalTotalPlannedPromoVolume> getAllExternalTotalPlannedPromoVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{ 
		ExternalTotalPlannedPromoVolume totalAssetExternalValueData = new ExternalTotalPlannedPromoVolume();
		try{
			log.info("External Total Planned Promo Volume starts");
			totalAssetExternalValueData = externalPromoService.getExternalTotalPlannedPromoVolume(username, region, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetExternalValueData);
	}	 
	
	@Async("asyncExecutor")
	public CompletableFuture<ExtenalTotalUtilizeVolume> getAllExtenalTotalUtilizeVolume(String username,List<String> region,List<String> moc,List<String> category) throws InterruptedException 
	{ 
		ExtenalTotalUtilizeVolume totalAssetExternalValueData = new ExtenalTotalUtilizeVolume();
		try{
			log.info("Extenal Total Utilize Volume starts");
			totalAssetExternalValueData = externalPromoService.getExternalTotalUtilizedVolume(username, region, moc, category);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return CompletableFuture.completedFuture(totalAssetExternalValueData);
	}	 
	

}
