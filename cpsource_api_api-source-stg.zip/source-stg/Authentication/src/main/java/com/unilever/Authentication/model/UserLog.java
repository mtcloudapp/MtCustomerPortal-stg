package com.unilever.Authentication.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_LOG")
public class UserLog implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -568194596011010265L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer ID;
	
	
	@Column(name= "USERNAME")
    private String username;

	@Column(name= "IS_LOGGED_IN")
    private String isLogggedIn;

	@Column(name= "LOG_TIME")
    private String logTime;
	
	@Column(name= "ROLE_TYPE")
    private String roleType;

	public UserLog() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public UserLog(Integer iD, String username, String isLogggedIn, String logTime, String roleType) {
		super();
		ID = iD;
		this.username = username;
		this.isLogggedIn = isLogggedIn;
		this.logTime = logTime;
		this.roleType = roleType;
	}



	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIsLogggedIn() {
		return isLogggedIn;
	}

	public void setIsLogggedIn(String isLogggedIn) {
		this.isLogggedIn = isLogggedIn;
	}

	public String getLogTime() {
		return logTime;
	}

	public void setLogTime(String logTime) {
		this.logTime = logTime;
	}



	public String getRoleType() {
		return roleType;
	}



	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	
	
}
