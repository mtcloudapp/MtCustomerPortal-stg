package com.unilever.promo.claim.soa.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.external.model.PromoClaimMultiSOLCodeStage;
import com.unilever.promo.claim.external.model.PromoClaimsExceptionAttachment;
import com.unilever.promo.claim.external.repository.BaseWorkingRepository;
import com.unilever.promo.claim.external.repository.OverrunClaimRepository;
import com.unilever.promo.claim.external.repository.POSDataRepository;
import com.unilever.promo.claim.external.repository.POS_VS_PrimaryrRepository;
import com.unilever.promo.claim.external.repository.PosDataMasterRepository;
import com.unilever.promo.claim.external.repository.PosFileUploadMasterRepository;
import com.unilever.promo.claim.external.repository.PromoClaimMasterRepository;
import com.unilever.promo.claim.external.repository.PromoClaimMultiSOLCodeStageRepository;
import com.unilever.promo.claim.external.repository.PromoClaimSummaryRepository;
import com.unilever.promo.claim.external.repository.PromoClaimsExceptionAttachmntRepository;
import com.unilever.promo.claim.external.repository.PromoClaimsRepository;
import com.unilever.promo.claim.external.repository.PrompClaimsFileUploadMasterRepository;
import com.unilever.promo.claim.external.service.PromoClaimExcelHelper;

@Service
public class SOAWorkflowService {


	private static final Logger LOGGER = LoggerFactory.getLogger(SOAWorkflowService.class);


	@Autowired
	private AmazonS3 amazonS3;


	@Value("${aws.s3.bucket_promo_claims_supporting_doc}")
	private String bucketName;


	@Autowired
	BaseWorkingRepository baseWorkingRepository;

	@Autowired
	POS_VS_PrimaryrRepository pos_VS_PrimaryrRepository;

	@Autowired
	OverrunClaimRepository overrunClaimRepository;

	@Autowired
	PromoClaimSummaryRepository promoClaimSummaryRepository;

	@Autowired
	PrompClaimsFileUploadMasterRepository prompClaimsFileUploadMasterRepository;

	@Autowired
	PromoClaimMasterRepository promoClaimMasterRepository;

	@Autowired
	PromoClaimsRepository promoClaimsRepository;

	@Autowired
	PosFileUploadMasterRepository posFileUploadMasterRepository;

	@Autowired
	PosDataMasterRepository posDataMasterRepository;

	@Autowired
	POSDataRepository posDataRepository;

	@Autowired
	PromoClaimsExceptionAttachmntRepository promoClaimsExceptionAttachmntRepository;
	
	//Added By Sarin Jun2021
	@Autowired
	PromoClaimMultiSOLCodeStageRepository promoClaimMultiSOLCodeStageRepository;

	public ResponseMessage signOffWithExceptionByB2C(String account,String moc) {

		ResponseMessage resps = new ResponseMessage();
		
		try{
			
			overrunClaimRepository.updateOverrunClaim(account, moc, "B2C", "EXCEPTION", null);
			resps.setMessage("Success");
		}

		catch(Exception e){
			e.printStackTrace();
		}
		return resps;

	}
	public ResponseMessage signOffByB2C(String account,String moc,String username) {

		ResponseMessage resps = new ResponseMessage();
		
		try{
			
			overrunClaimRepository.updateOverrunClaimFinal(account, moc, username, "NORMAL");
			resps.setMessage("Success");
		}

		catch(Exception e){
			e.printStackTrace();
		}
		return resps;

	}
	
	public ResponseMessage finalPublishByB2C(String account,String moc,String username) {

		ResponseMessage resps = new ResponseMessage();
		
		try{
			
			overrunClaimRepository.updateOverrunClaimFinal(account, moc, username, "NORMAL");
			resps.setMessage("Success");
		}

		catch(Exception e){
			e.printStackTrace();
		}
		return resps;

	}

	public ResponseMessage save(final MultipartFile multipartFile,String account,String moc,String response){

		ResponseMessage resps = new ResponseMessage();

		try{

			String uploadDate = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

			PromoClaimsExceptionAttachment promoClaimsExceptionAttachment = new PromoClaimsExceptionAttachment();

			//promoClaimsExceptionAttachment.setAttachmentFileNo(attachmentFileNo);
			promoClaimsExceptionAttachment.setAccountName(account);
			promoClaimsExceptionAttachment.setMoc(moc);
			promoClaimsExceptionAttachment.setUploadDate(uploadDate);
			promoClaimsExceptionAttachment.setUploadedFileName(multipartFile.getOriginalFilename());

			promoClaimsExceptionAttachmntRepository.save(promoClaimsExceptionAttachment);
			uploadFile(multipartFile,account,moc);
			resps.setMessage("Success");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return resps;


	}


	@Async
	public void uploadFile(final MultipartFile multipartFile,String account,String moc) {
		LOGGER.info("File upload in progress.");


		try {
			final File file = convertMultiPartFileToFile(multipartFile);
			uploadFileToS3Bucket(bucketName, file,account,moc);
			LOGGER.info("File upload is completed.");
			file.delete();	// To remove the file locally created in the project folder.
		} catch (final AmazonServiceException ex) {
			LOGGER.info("File upload is failed.");
			LOGGER.error("Error= {} while uploading file.", ex.getMessage());
		}

	}


	private File convertMultiPartFileToFile(final MultipartFile multipartFile) {
		final File file = new File(multipartFile.getOriginalFilename());
		try (final FileOutputStream outputStream = new FileOutputStream(file)) {
			outputStream.write(multipartFile.getBytes());
		} catch (final IOException ex) {
			LOGGER.error("Error converting the multi-part file to file= ", ex.getMessage());
		}
		return file;
	}

	private void uploadFileToS3Bucket(final String bucketName, final File file,String account,String moc) {
		final String uniqueFileName = account+"_"+"_"+moc+"_"+file.getName();
		LOGGER.info("Uploading file with name= " + uniqueFileName);
		final PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, uniqueFileName, file);
		amazonS3.putObject(putObjectRequest);
	}


	public InputStream downloadFileAsStream(String bucketName, String objectKey) {


		try {
			GetObjectRequest s3ObjectReq = new GetObjectRequest(bucketName, objectKey);
			long startTime=System.currentTimeMillis();
			S3Object downlodedObjectMD = amazonS3.getObject(s3ObjectReq);
			LOGGER.info("Time to load Stream is "+(System.currentTimeMillis()-startTime)+" ms");
			return downlodedObjectMD.getObjectContent();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//Added By Sarin Jun2021
	public ByteArrayInputStream getMultiSOLCodePromoDetails(String account, String moc) {
		//List<String> multiSOLCodeList = promoClaimsRepository.findMultiSOLCodeByAccountAndMoc(account, moc);
		List<String> multiSOLCodeList = baseWorkingRepository.findMultiAndErrorSOLCodeByAccountAndMoc(account, moc);
		ByteArrayInputStream in = PromoClaimExcelHelper.generatePromoClaimMultiSOLCodeDataToExcel(multiSOLCodeList);
		return in;
	}
	
	//Added By Sarin Jun2021
	public ResponseMessage saveMultiSolCodeStage(MultipartFile file, String accountName, String moc) {
		ResponseMessage resps = new ResponseMessage();
		
		try {
			
			promoClaimMultiSOLCodeStageRepository.deletePromoClaimMultiSolStage();
			List<PromoClaimMultiSOLCodeStage> promoClaimMultiSOLCodeStageDetails = PromoClaimExcelHelper.excelToPromoClaimMultiSOLCodeStage(file.getInputStream(), accountName, moc);
			//Integer multiSolStageCount = promoClaimMultiSOLCodeStageRepository.findCountPromoClaimMultiSolCodeStage();
			
			if (promoClaimMultiSOLCodeStageDetails.size() > 0) {
				LOGGER.info("INSERT INTO PROMO CLAIM MULTI SOL STAGE TABLE STARTS HERE");
				promoClaimMultiSOLCodeStageRepository.saveAll(promoClaimMultiSOLCodeStageDetails);
				LOGGER.info("INSERT INTO PROMO CLAIM MULTI SOL STAGE TABLE ENDS HERE");
			}
			
			Integer multiSolStageCount = promoClaimMultiSOLCodeStageRepository.findCountPromoClaimMultiSolCodeStage(accountName, moc);
			if (multiSolStageCount > 0) {
				LOGGER.info("INSERT INTO PROMO CLAIM MULTI SOL MASTER TABLE STARTS HERE");
				promoClaimMultiSOLCodeStageRepository.insertPromoClaimMultiSolCodeDataByAccountName();
				LOGGER.info("INSERT INTO PROMO CLAIM MULTI SOL MASTER TABLE ENDS HERE");
				
				LOGGER.info("base woeking store procs starts");
				baseWorkingRepository.insertIntoBaseworking(accountName,moc);
				LOGGER.info("base woeking store procs end");
				
				resps.setMessage("Calculation Completed For "+accountName+" "+moc);
			} else{
				resps.setMessage("Incorrect file upload For "+accountName+" "+moc);
			}
			
		} catch(Exception e){
			resps.setMessage("Error while file upload For "+accountName+" "+moc);
			e.printStackTrace();
		}
		
		return resps;
	}

}
