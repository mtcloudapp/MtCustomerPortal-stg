package com.unilever.promo.kam.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.unilever.asset.kam.model.CurrentMocView;
import com.unilever.asset.kam.model.CurrentMocViewDto;
import com.unilever.asset.kam.model.PreviousMocView;
import com.unilever.asset.kam.model.PreviousMocViewDto;
import com.unilever.promo.kam.model.CurrentMocPromoView;
import com.unilever.promo.kam.model.CurrentMocPromoViewDto;
import com.unilever.promo.kam.model.KamNoOfPromotion;
import com.unilever.promo.kam.model.KamSolCodeReleased;
import com.unilever.promo.kam.model.KamTotalPlannedBudget;
import com.unilever.promo.kam.model.KamTotalPlannedPromVolume;
import com.unilever.promo.kam.model.KamTotalPlannedPromoValue;
import com.unilever.promo.kam.model.KamTotalUtilizedValue;
import com.unilever.promo.kam.model.KamTotalUtilizedVolume;
import com.unilever.promo.kam.model.KamUtilizedBudget;
import com.unilever.promo.kam.model.NextMocPromoView;
import com.unilever.promo.kam.model.NextMocPromoViewDto;
import com.unilever.promo.kam.model.PreviousMocPromoView;
import com.unilever.promo.kam.model.PreviousMocPromoViewDto;
import com.unilever.promo.kam.repository.CurrentMocPromoViewRepository;
import com.unilever.promo.kam.repository.KamNoOfPromotionRepository;
import com.unilever.promo.kam.repository.KamSolCodesReleasedRepository;
import com.unilever.promo.kam.repository.KamTotalPlannedBudgetRepository;
import com.unilever.promo.kam.repository.KamTotalPlannedPromoValueRepository;
import com.unilever.promo.kam.repository.KamTotalPlannedPromoVolumeRepository;
import com.unilever.promo.kam.repository.KamTotalUtilizedValueRepository;
import com.unilever.promo.kam.repository.KamTotalUtilizedVolumeRepository;
import com.unilever.promo.kam.repository.KamUtilizedBudgetRepository;
import com.unilever.promo.kam.repository.NextMocPromoViewRepository;
import com.unilever.promo.kam.repository.PreviousMocPromoViewRepository;

@Service
public class KamPromoService {

	@Autowired
	KamNoOfPromotionRepository kamNoOfPromotionRepository;
	
	@Autowired
	KamSolCodesReleasedRepository kamSolCodesReleasedRepository;
	
	@Autowired
	KamTotalPlannedBudgetRepository kamTotalPlannedBudgetRepository;
	
	@Autowired
	KamTotalPlannedPromoValueRepository kamTotalPlannedPromoValueRepository;
	
	@Autowired
	KamTotalPlannedPromoVolumeRepository kamTotalPlannedPromoVolumeRepository;
	
	@Autowired
	KamTotalUtilizedValueRepository kamTotalUtilizedValueRepository;
	
	@Autowired
	KamTotalUtilizedVolumeRepository kamTotalUtilizedVolumeRepository;
	
	@Autowired
	KamUtilizedBudgetRepository kamUtilizedBudgetRepository;
	
	@Autowired
	CurrentMocPromoViewRepository currentMocPromoViewRepository;
	
	@Autowired
	PreviousMocPromoViewRepository previousMocPromoViewRepository;
	
	@Autowired
	NextMocPromoViewRepository nextMocPromoViewRepository;
	
	
	
	
	
	
	
	
//	//=========================================================No Of Promotion Start========================================================================
//	
//		public KamNoOfPromotion getNoOfPromotions(String username,List<String> region,List<String> account,List<String> moc,List<String> category){
//
//
//			double totalAssetAmount = 0.00;
//			//Integer totalAssetAmountSum = 0;
//			KamNoOfPromotion totalAssetAmountSum = new KamNoOfPromotion();
//
//
//			try{
//				List<KamNoOfPromotion> totalAssetValues = new ArrayList<KamNoOfPromotion>();
//				List<KamNoOfPromotion> totalAssetValuesByUsername = new ArrayList<KamNoOfPromotion>();
//				List<KamNoOfPromotion> mocList = new ArrayList<KamNoOfPromotion>();
//				
//				totalAssetValuesByUsername = kamNoOfPromotionRepository.findAllNoOfPromotion(username);
//	            
//				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//					
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamNoOfPromotion mocc : totalAssetValuesByUsername){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//					
//					for(KamNoOfPromotion t : mocList){
//						totalAssetAmount += t.getNoOfPromotions();
//
//					}
//
//					totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//
//				}
//
//				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//					List<KamNoOfPromotion> categoryList = new ArrayList<KamNoOfPromotion>();
//					
//					//filtered by category
//
//					for(String c : category){
//						for(KamNoOfPromotion cat : totalAssetValuesByUsername){
//							if(c.equals(cat.getCategoryNaame())){
//								categoryList.add(cat);
//							}
//
//						}
//
//					}
//
//					//filtered by MOC
//					for(String m : moc){
//						for(KamNoOfPromotion mocc : categoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//					
//					
//					totalAssetValues.addAll(mocList);
//					for(KamNoOfPromotion t : totalAssetValues){
//						totalAssetAmount += t.getNoOfPromotions();
//
//					}
//					totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//					List<KamNoOfPromotion> accountList = new ArrayList<KamNoOfPromotion>();
//					
//					
//					for(String accnt : account){
//						for(KamNoOfPromotion acc : totalAssetValuesByUsername){
//							if(accnt.equals(acc.getAccountName())){
//								accountList.add(acc);
//							}
//
//						}
//
//					}
//					//filtered by MOC
//					for(String m : moc){
//						for(KamNoOfPromotion mocc : accountList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//
//					totalAssetValues.addAll(mocList);
//
//					for(KamNoOfPromotion t : totalAssetValues){
//						totalAssetAmount += t.getNoOfPromotions();
//
//					}
//					totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//					List<KamNoOfPromotion> accountList = new ArrayList<KamNoOfPromotion>();
//					List<KamNoOfPromotion> filteredAccountCategoryList = new ArrayList<KamNoOfPromotion>();
//					
//
//					//filterd by account
//					for(String accnt : account){
//						for(KamNoOfPromotion acc : totalAssetValuesByUsername){
//							if(accnt.equals(acc.getAccountName())){
//								accountList.add(acc);
//							}
//
//						}
//
//					}
//
//					//filtered by category
//					for(String c : category){
//						for(KamNoOfPromotion cat : accountList){
//							if(c.equals(cat.getCategoryNaame())){
//								filteredAccountCategoryList.add(cat);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamNoOfPromotion mocc : filteredAccountCategoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//
//					totalAssetValues.addAll(mocList);
//
//					for(KamNoOfPromotion t : totalAssetValues){
//						totalAssetAmount += t.getNoOfPromotions();
//					}
//					totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//				}
//
//				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//					List<KamNoOfPromotion> regionList = new ArrayList<KamNoOfPromotion>();
//					
//					
//					//filter by region
//					for(String regon : region){
//						for(KamNoOfPromotion reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamNoOfPromotion mocc : regionList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//					for(KamNoOfPromotion t : totalAssetValues){
//						totalAssetAmount += t.getNoOfPromotions();
//					}
//
//					totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//				}
//				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//					List<KamNoOfPromotion> regionList = new ArrayList<KamNoOfPromotion>();
//					List<KamNoOfPromotion> filteredRegionAccountList = new ArrayList<KamNoOfPromotion>();
//					
//					
//					//filter by region
//					for(String regon : region){
//						for(KamNoOfPromotion reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//
//					//filtered by account
//
//					for(String accnt : account){
//						for(KamNoOfPromotion acc : regionList){
//							if(accnt.equals(acc.getAccountName())){
//								filteredRegionAccountList.add(acc);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamNoOfPromotion mocc : filteredRegionAccountList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//
//					for(KamNoOfPromotion t : totalAssetValues){
//						totalAssetAmount += t.getNoOfPromotions();
//
//					}
//					totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//				}
//
//
//				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//					List<KamNoOfPromotion> regionList = new ArrayList<KamNoOfPromotion>();
//					List<KamNoOfPromotion> filteredRegionCategoryList = new ArrayList<KamNoOfPromotion>();
//					
//					//filterd by region
//
//					for(String regon : region){
//						for(KamNoOfPromotion reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//
//					//filtered by category
//
//					for(String c : category){
//						for(KamNoOfPromotion cat : regionList){
//							if(c.equals(cat.getCategoryNaame())){
//								filteredRegionCategoryList.add(cat);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamNoOfPromotion mocc : filteredRegionCategoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//					for(KamNoOfPromotion t : totalAssetValues){
//						totalAssetAmount += t.getNoOfPromotions();
//					}
//					totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//				}	
//
//				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//					List<KamNoOfPromotion> regionList = new ArrayList<KamNoOfPromotion>();
//					List<KamNoOfPromotion> accountList = new ArrayList<KamNoOfPromotion>();
//					List<KamNoOfPromotion> filteredRegionCategoryList = new ArrayList<KamNoOfPromotion>();
//					
//					if(totalAssetValuesByUsername !=null)	{
//						//-----filter by region------//
//
//						for(String regon : region){
//							for(KamNoOfPromotion reg : totalAssetValuesByUsername){
//								if(regon.equals(reg.getRegionName())){
//									regionList.add(reg);
//								}
//
//							}
//
//						}
//
//
//						//-----filter by account------//
//
//						for(String accnt : account){
//							for(KamNoOfPromotion acc : regionList){
//								if(accnt.equals(acc.getAccountName())){
//									accountList.add(acc);
//								}
//
//							}
//
//						}
//
//
//						//-----filter by category------//
//
//						for(String c : category){
//							for(KamNoOfPromotion cat : accountList){
//								if(c.equals(cat.getCategoryNaame())){
//									filteredRegionCategoryList.add(cat);
//								}
//
//							}
//
//						}
//						
//						//filtered by MOC
//						for(String m : moc){
//							for(KamNoOfPromotion mocc : filteredRegionCategoryList){
//								if(m.equals(mocc.getMoc())){
//									mocList.add(mocc);
//								}
//
//							}
//
//						}
//
//						totalAssetValues.addAll(mocList);
//
//						for(KamNoOfPromotion t : totalAssetValues){
//							totalAssetAmount += t.getNoOfPromotions();
//						}
//
//						totalAssetAmountSum.setNoOfPromotions(totalAssetAmount);
//
//					}//end of if
//
//				}// end of else if
//
//			}//end of try
//			catch(Exception e){
//				e.printStackTrace();
//			}
//
//
//			return totalAssetAmountSum;
//
//		}
	
	//============================== previous no of promotions start =======================================================//
		public Integer getNoOfPromotion(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


			 List<String> noOfPromotion= new ArrayList<>();
			 Integer distinctNoOfPromotions =0;

			try{
				noOfPromotion = kamNoOfPromotionRepository.findDistinctkamNoOfPromotion(account, moc, region, category,username);
				distinctNoOfPromotions = (int) noOfPromotion.stream().distinct().count();
	     
			}
			catch(Exception e){
				e.printStackTrace();
			}


			return distinctNoOfPromotions;

		}
		
		//============================== previous solcode released =======================================================//
				public Integer getSolCodeReleased(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


					 List<String> solCodeReleased = new ArrayList<>();
					 Integer distinctSolCodeReleased =0;

					try{
						solCodeReleased = kamSolCodesReleasedRepository.findDistinctkamSolCodeReleased(account, moc, region, category, username);
						distinctSolCodeReleased = (int) solCodeReleased.stream().distinct().count();
			     
					}
					catch(Exception e){
						e.printStackTrace();
					}


					return distinctSolCodeReleased;

				}
	
	
//		//=========================================================Solcode Released  Start========================================================================
//		
//		public KamSolCodeReleased getSoleCodeReleased(String username,List<String> region,List<String> account,List<String> moc,List<String> category){
//
//
//			double totalAssetAmount = 0.00;
//			//Integer totalAssetAmountSum = 0;
//			KamSolCodeReleased totalAssetAmountSum = new KamSolCodeReleased();
//
//
//			try{
//				List<KamSolCodeReleased> totalAssetValues = new ArrayList<KamSolCodeReleased>();
//				List<KamSolCodeReleased> totalAssetValuesByUsername = new ArrayList<KamSolCodeReleased>();
//				List<KamSolCodeReleased> mocList = new ArrayList<KamSolCodeReleased>();
//				
//				totalAssetValuesByUsername = kamSolCodesReleasedRepository.findAllSolCodeReleased(username);
//	            
//				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//					
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamSolCodeReleased mocc : totalAssetValuesByUsername){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//					
//					for(KamSolCodeReleased t : mocList){
//						totalAssetAmount += t.getSolCodeReleased();
//
//					}
//
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//
//				}
//
//				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//					List<KamSolCodeReleased> categoryList = new ArrayList<KamSolCodeReleased>();
//					
//					//filtered by category
//
//					for(String c : category){
//						for(KamSolCodeReleased cat : totalAssetValuesByUsername){
//							if(c.equals(cat.getCategoryNaame())){
//								categoryList.add(cat);
//							}
//
//						}
//
//					}
//
//					//filtered by MOC
//					for(String m : moc){
//						for(KamSolCodeReleased mocc : categoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//					
//					
//					totalAssetValues.addAll(mocList);
//					for(KamSolCodeReleased t : totalAssetValues){
//						totalAssetAmount += t.getSolCodeReleased();
//
//					}
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//					List<KamSolCodeReleased> accountList = new ArrayList<KamSolCodeReleased>();
//					
//					
//					for(String accnt : account){
//						for(KamSolCodeReleased acc : totalAssetValuesByUsername){
//							if(accnt.equals(acc.getAccountName())){
//								accountList.add(acc);
//							}
//
//						}
//
//					}
//					//filtered by MOC
//					for(String m : moc){
//						for(KamSolCodeReleased mocc : accountList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//
//					totalAssetValues.addAll(mocList);
//
//					for(KamSolCodeReleased t : totalAssetValues){
//						totalAssetAmount += t.getSolCodeReleased();
//
//					}
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//					List<KamSolCodeReleased> accountList = new ArrayList<KamSolCodeReleased>();
//					List<KamSolCodeReleased> filteredAccountCategoryList = new ArrayList<KamSolCodeReleased>();
//					
//
//					//filterd by account
//					for(String accnt : account){
//						for(KamSolCodeReleased acc : totalAssetValuesByUsername){
//							if(accnt.equals(acc.getAccountName())){
//								accountList.add(acc);
//							}
//
//						}
//
//					}
//
//					//filtered by category
//					for(String c : category){
//						for(KamSolCodeReleased cat : accountList){
//							if(c.equals(cat.getCategoryNaame())){
//								filteredAccountCategoryList.add(cat);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamSolCodeReleased mocc : filteredAccountCategoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//
//					totalAssetValues.addAll(mocList);
//
//					for(KamSolCodeReleased t : totalAssetValues){
//						totalAssetAmount += t.getSolCodeReleased();
//					}
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//				}
//
//				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//					List<KamSolCodeReleased> regionList = new ArrayList<KamSolCodeReleased>();
//					
//					
//					//filter by region
//					for(String regon : region){
//						for(KamSolCodeReleased reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamSolCodeReleased mocc : regionList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//					for(KamSolCodeReleased t : totalAssetValues){
//						totalAssetAmount += t.getSolCodeReleased();
//					}
//
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//				}
//				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//					List<KamSolCodeReleased> regionList = new ArrayList<KamSolCodeReleased>();
//					List<KamSolCodeReleased> filteredRegionAccountList = new ArrayList<KamSolCodeReleased>();
//					
//					
//					//filter by region
//					for(String regon : region){
//						for(KamSolCodeReleased reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//
//					//filtered by account
//
//					for(String accnt : account){
//						for(KamSolCodeReleased acc : regionList){
//							if(accnt.equals(acc.getAccountName())){
//								filteredRegionAccountList.add(acc);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamSolCodeReleased mocc : filteredRegionAccountList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//
//					for(KamSolCodeReleased t : totalAssetValues){
//						totalAssetAmount += t.getSolCodeReleased();
//
//					}
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//				}
//
//
//				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//					List<KamSolCodeReleased> regionList = new ArrayList<KamSolCodeReleased>();
//					List<KamSolCodeReleased> filteredRegionCategoryList = new ArrayList<KamSolCodeReleased>();
//					
//					//filterd by region
//
//					for(String regon : region){
//						for(KamSolCodeReleased reg : totalAssetValuesByUsername){
//							if(regon.equals(reg.getRegionName())){
//								regionList.add(reg);
//							}
//
//						}
//
//					}
//
//					//filtered by category
//
//					for(String c : category){
//						for(KamSolCodeReleased cat : regionList){
//							if(c.equals(cat.getCategoryNaame())){
//								filteredRegionCategoryList.add(cat);
//							}
//
//						}
//
//					}
//					
//					//filtered by MOC
//					for(String m : moc){
//						for(KamSolCodeReleased mocc : filteredRegionCategoryList){
//							if(m.equals(mocc.getMoc())){
//								mocList.add(mocc);
//							}
//
//						}
//
//					}
//
//					totalAssetValues.addAll(mocList);
//					for(KamSolCodeReleased t : totalAssetValues){
//						totalAssetAmount += t.getSolCodeReleased();
//					}
//					totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//				}	
//
//				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//					List<KamSolCodeReleased> regionList = new ArrayList<KamSolCodeReleased>();
//					List<KamSolCodeReleased> accountList = new ArrayList<KamSolCodeReleased>();
//					List<KamSolCodeReleased> filteredRegionCategoryList = new ArrayList<KamSolCodeReleased>();
//					
//					if(totalAssetValuesByUsername !=null)	{
//						//-----filter by region------//
//
//						for(String regon : region){
//							for(KamSolCodeReleased reg : totalAssetValuesByUsername){
//								if(regon.equals(reg.getRegionName())){
//									regionList.add(reg);
//								}
//
//							}
//
//						}
//
//
//						//-----filter by account------//
//
//						for(String accnt : account){
//							for(KamSolCodeReleased acc : regionList){
//								if(accnt.equals(acc.getAccountName())){
//									accountList.add(acc);
//								}
//
//							}
//
//						}
//
//
//						//-----filter by category------//
//
//						for(String c : category){
//							for(KamSolCodeReleased cat : accountList){
//								if(c.equals(cat.getCategoryNaame())){
//									filteredRegionCategoryList.add(cat);
//								}
//
//							}
//
//						}
//						
//						//filtered by MOC
//						for(String m : moc){
//							for(KamSolCodeReleased mocc : filteredRegionCategoryList){
//								if(m.equals(mocc.getMoc())){
//									mocList.add(mocc);
//								}
//
//							}
//
//						}
//
//						totalAssetValues.addAll(mocList);
//
//						for(KamSolCodeReleased t : totalAssetValues){
//							totalAssetAmount += t.getSolCodeReleased();
//						}
//
//						totalAssetAmountSum.setSolCodeReleased(totalAssetAmount);
//
//					}//end of if
//
//				}// end of else if
//
//			}//end of try
//			catch(Exception e){
//				e.printStackTrace();
//			}
//
//
//			return totalAssetAmountSum;
//
//		}



		//=========================================================Total Planned Budget Start========================================================================
		
		public KamTotalPlannedBudget getTotalPlannedBudget(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			KamTotalPlannedBudget totalAssetAmountSum = new KamTotalPlannedBudget();


			try{
				List<KamTotalPlannedBudget> totalAssetValues = new ArrayList<KamTotalPlannedBudget>();
				List<KamTotalPlannedBudget> totalAssetValuesByUsername = new ArrayList<KamTotalPlannedBudget>();
				List<KamTotalPlannedBudget> mocList = new ArrayList<KamTotalPlannedBudget>();
				
				totalAssetValuesByUsername = kamTotalPlannedBudgetRepository.findAllTotalPlannedBudget(username);
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedBudget mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(KamTotalPlannedBudget t : mocList){
						totalAssetAmount += t.getTotalPlannedBudget();

					}

					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<KamTotalPlannedBudget> categoryList = new ArrayList<KamTotalPlannedBudget>();
					
					//filtered by category

					for(String c : category){
						for(KamTotalPlannedBudget cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedBudget mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedBudget t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedBudget();

					}
					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<KamTotalPlannedBudget> accountList = new ArrayList<KamTotalPlannedBudget>();
					
					
					for(String accnt : account){
						for(KamTotalPlannedBudget acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedBudget mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedBudget t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedBudget();

					}
					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<KamTotalPlannedBudget> accountList = new ArrayList<KamTotalPlannedBudget>();
					List<KamTotalPlannedBudget> filteredAccountCategoryList = new ArrayList<KamTotalPlannedBudget>();
					

					//filterd by account
					for(String accnt : account){
						for(KamTotalPlannedBudget acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(KamTotalPlannedBudget cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedBudget mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedBudget t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedBudget();
					}
					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<KamTotalPlannedBudget> regionList = new ArrayList<KamTotalPlannedBudget>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalPlannedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedBudget mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedBudget t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedBudget();
					}

					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<KamTotalPlannedBudget> regionList = new ArrayList<KamTotalPlannedBudget>();
					List<KamTotalPlannedBudget> filteredRegionAccountList = new ArrayList<KamTotalPlannedBudget>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalPlannedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(KamTotalPlannedBudget acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedBudget mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedBudget t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedBudget();

					}
					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<KamTotalPlannedBudget> regionList = new ArrayList<KamTotalPlannedBudget>();
					List<KamTotalPlannedBudget> filteredRegionCategoryList = new ArrayList<KamTotalPlannedBudget>();
					
					//filterd by region

					for(String regon : region){
						for(KamTotalPlannedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(KamTotalPlannedBudget cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedBudget mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedBudget t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedBudget();
					}
					totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<KamTotalPlannedBudget> regionList = new ArrayList<KamTotalPlannedBudget>();
					List<KamTotalPlannedBudget> accountList = new ArrayList<KamTotalPlannedBudget>();
					List<KamTotalPlannedBudget> filteredRegionCategoryList = new ArrayList<KamTotalPlannedBudget>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(KamTotalPlannedBudget reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(KamTotalPlannedBudget acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(KamTotalPlannedBudget cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(KamTotalPlannedBudget mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(KamTotalPlannedBudget t : totalAssetValues){
							totalAssetAmount += t.getTotalPlannedBudget();
						}

						totalAssetAmountSum.setTotalPlannedBudget(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}


		//=========================================================Total Planned Promo Value Start========================================================================
		
		public KamTotalPlannedPromoValue getTotalPlannedPromoValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			KamTotalPlannedPromoValue totalAssetAmountSum = new KamTotalPlannedPromoValue();


			try{
				List<KamTotalPlannedPromoValue> totalAssetValues = new ArrayList<KamTotalPlannedPromoValue>();
				List<KamTotalPlannedPromoValue> totalAssetValuesByUsername = new ArrayList<KamTotalPlannedPromoValue>();
				List<KamTotalPlannedPromoValue> mocList = new ArrayList<KamTotalPlannedPromoValue>();
				
				totalAssetValuesByUsername = kamTotalPlannedPromoValueRepository.findAllPlaneedPromoValue(username);
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromoValue mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(KamTotalPlannedPromoValue t : mocList){
						totalAssetAmount += t.getTotalPlannedPromoValue();

					}

					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<KamTotalPlannedPromoValue> categoryList = new ArrayList<KamTotalPlannedPromoValue>();
					
					//filtered by category

					for(String c : category){
						for(KamTotalPlannedPromoValue cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromoValue mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedPromoValue t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoValue();

					}
					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<KamTotalPlannedPromoValue> accountList = new ArrayList<KamTotalPlannedPromoValue>();
					
					
					for(String accnt : account){
						for(KamTotalPlannedPromoValue acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromoValue mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedPromoValue t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoValue();

					}
					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<KamTotalPlannedPromoValue> accountList = new ArrayList<KamTotalPlannedPromoValue>();
					List<KamTotalPlannedPromoValue> filteredAccountCategoryList = new ArrayList<KamTotalPlannedPromoValue>();
					

					//filterd by account
					for(String accnt : account){
						for(KamTotalPlannedPromoValue acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(KamTotalPlannedPromoValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromoValue mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedPromoValue t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoValue();
					}
					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<KamTotalPlannedPromoValue> regionList = new ArrayList<KamTotalPlannedPromoValue>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalPlannedPromoValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromoValue mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedPromoValue t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoValue();
					}

					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<KamTotalPlannedPromoValue> regionList = new ArrayList<KamTotalPlannedPromoValue>();
					List<KamTotalPlannedPromoValue> filteredRegionAccountList = new ArrayList<KamTotalPlannedPromoValue>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalPlannedPromoValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(KamTotalPlannedPromoValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromoValue mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedPromoValue t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoValue();

					}
					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<KamTotalPlannedPromoValue> regionList = new ArrayList<KamTotalPlannedPromoValue>();
					List<KamTotalPlannedPromoValue> filteredRegionCategoryList = new ArrayList<KamTotalPlannedPromoValue>();
					
					//filterd by region

					for(String regon : region){
						for(KamTotalPlannedPromoValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(KamTotalPlannedPromoValue cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromoValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedPromoValue t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoValue();
					}
					totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<KamTotalPlannedPromoValue> regionList = new ArrayList<KamTotalPlannedPromoValue>();
					List<KamTotalPlannedPromoValue> accountList = new ArrayList<KamTotalPlannedPromoValue>();
					List<KamTotalPlannedPromoValue> filteredRegionCategoryList = new ArrayList<KamTotalPlannedPromoValue>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(KamTotalPlannedPromoValue reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(KamTotalPlannedPromoValue acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(KamTotalPlannedPromoValue cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(KamTotalPlannedPromoValue mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(KamTotalPlannedPromoValue t : totalAssetValues){
							totalAssetAmount += t.getTotalPlannedPromoValue();
						}

						totalAssetAmountSum.setTotalPlannedPromoValue(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}


		//=========================================================Total Planned Promo Volume Start========================================================================
		
		public KamTotalPlannedPromVolume getTotalPlannedPromoVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			KamTotalPlannedPromVolume totalAssetAmountSum = new KamTotalPlannedPromVolume();


			try{
				List<KamTotalPlannedPromVolume> totalAssetValues = new ArrayList<KamTotalPlannedPromVolume>();
				List<KamTotalPlannedPromVolume> totalAssetValuesByUsername = new ArrayList<KamTotalPlannedPromVolume>();
				List<KamTotalPlannedPromVolume> mocList = new ArrayList<KamTotalPlannedPromVolume>();
				
				totalAssetValuesByUsername = kamTotalPlannedPromoVolumeRepository.findAllTotalPlannedPromoVolume(username);
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromVolume mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(KamTotalPlannedPromVolume t : mocList){
						totalAssetAmount += t.getTotalPlannedPromoVolume();

					}

					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<KamTotalPlannedPromVolume> categoryList = new ArrayList<KamTotalPlannedPromVolume>();
					
					//filtered by category

					for(String c : category){
						for(KamTotalPlannedPromVolume cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromVolume mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedPromVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoVolume();

					}
					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<KamTotalPlannedPromVolume> accountList = new ArrayList<KamTotalPlannedPromVolume>();
					
					
					for(String accnt : account){
						for(KamTotalPlannedPromVolume acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromVolume mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedPromVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoVolume();

					}
					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<KamTotalPlannedPromVolume> accountList = new ArrayList<KamTotalPlannedPromVolume>();
					List<KamTotalPlannedPromVolume> filteredAccountCategoryList = new ArrayList<KamTotalPlannedPromVolume>();
					

					//filterd by account
					for(String accnt : account){
						for(KamTotalPlannedPromVolume acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(KamTotalPlannedPromVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromVolume mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedPromVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoVolume();
					}
					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<KamTotalPlannedPromVolume> regionList = new ArrayList<KamTotalPlannedPromVolume>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalPlannedPromVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromVolume mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedPromVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoVolume();
					}

					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<KamTotalPlannedPromVolume> regionList = new ArrayList<KamTotalPlannedPromVolume>();
					List<KamTotalPlannedPromVolume> filteredRegionAccountList = new ArrayList<KamTotalPlannedPromVolume>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalPlannedPromVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(KamTotalPlannedPromVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromVolume mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(KamTotalPlannedPromVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoVolume();

					}
					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<KamTotalPlannedPromVolume> regionList = new ArrayList<KamTotalPlannedPromVolume>();
					List<KamTotalPlannedPromVolume> filteredRegionCategoryList = new ArrayList<KamTotalPlannedPromVolume>();
					
					//filterd by region

					for(String regon : region){
						for(KamTotalPlannedPromVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(KamTotalPlannedPromVolume cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalPlannedPromVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalPlannedPromVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalPlannedPromoVolume();
					}
					totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<KamTotalPlannedPromVolume> regionList = new ArrayList<KamTotalPlannedPromVolume>();
					List<KamTotalPlannedPromVolume> accountList = new ArrayList<KamTotalPlannedPromVolume>();
					List<KamTotalPlannedPromVolume> filteredRegionCategoryList = new ArrayList<KamTotalPlannedPromVolume>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(KamTotalPlannedPromVolume reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(KamTotalPlannedPromVolume acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(KamTotalPlannedPromVolume cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(KamTotalPlannedPromVolume mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(KamTotalPlannedPromVolume t : totalAssetValues){
							totalAssetAmount += t.getTotalPlannedPromoVolume();
						}

						totalAssetAmountSum.setTotalPlannedPromoVolume(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}


		//=========================================================Total Utilized Value Start========================================================================
		
		public KamTotalUtilizedValue getTotalUtilizedValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			KamTotalUtilizedValue totalAssetAmountSum = new KamTotalUtilizedValue();


			try{
				List<KamTotalUtilizedValue> totalAssetValues = new ArrayList<KamTotalUtilizedValue>();
				List<KamTotalUtilizedValue> totalAssetValuesByUsername = new ArrayList<KamTotalUtilizedValue>();
				List<KamTotalUtilizedValue> mocList = new ArrayList<KamTotalUtilizedValue>();
				
				totalAssetValuesByUsername = kamTotalUtilizedValueRepository.findAllTotalUtilizedValue(username);
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedValue mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(KamTotalUtilizedValue t : mocList){
						totalAssetAmount += t.getTotalUtilizedValue();

					}

					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<KamTotalUtilizedValue> categoryList = new ArrayList<KamTotalUtilizedValue>();
					
					//filtered by category

					for(String c : category){
						for(KamTotalUtilizedValue cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedValue mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(KamTotalUtilizedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedValue();

					}
					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<KamTotalUtilizedValue> accountList = new ArrayList<KamTotalUtilizedValue>();
					
					
					for(String accnt : account){
						for(KamTotalUtilizedValue acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedValue mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalUtilizedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedValue();

					}
					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<KamTotalUtilizedValue> accountList = new ArrayList<KamTotalUtilizedValue>();
					List<KamTotalUtilizedValue> filteredAccountCategoryList = new ArrayList<KamTotalUtilizedValue>();
					

					//filterd by account
					for(String accnt : account){
						for(KamTotalUtilizedValue acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(KamTotalUtilizedValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedValue mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalUtilizedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedValue();
					}
					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<KamTotalUtilizedValue> regionList = new ArrayList<KamTotalUtilizedValue>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalUtilizedValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedValue mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalUtilizedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedValue();
					}

					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<KamTotalUtilizedValue> regionList = new ArrayList<KamTotalUtilizedValue>();
					List<KamTotalUtilizedValue> filteredRegionAccountList = new ArrayList<KamTotalUtilizedValue>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalUtilizedValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(KamTotalUtilizedValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedValue mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(KamTotalUtilizedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedValue();

					}
					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<KamTotalUtilizedValue> regionList = new ArrayList<KamTotalUtilizedValue>();
					List<KamTotalUtilizedValue> filteredRegionCategoryList = new ArrayList<KamTotalUtilizedValue>();
					
					//filterd by region

					for(String regon : region){
						for(KamTotalUtilizedValue reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(KamTotalUtilizedValue cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedValue mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalUtilizedValue t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedValue();
					}
					totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<KamTotalUtilizedValue> regionList = new ArrayList<KamTotalUtilizedValue>();
					List<KamTotalUtilizedValue> accountList = new ArrayList<KamTotalUtilizedValue>();
					List<KamTotalUtilizedValue> filteredRegionCategoryList = new ArrayList<KamTotalUtilizedValue>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(KamTotalUtilizedValue reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(KamTotalUtilizedValue acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(KamTotalUtilizedValue cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(KamTotalUtilizedValue mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(KamTotalUtilizedValue t : totalAssetValues){
							totalAssetAmount += t.getTotalUtilizedValue();
						}

						totalAssetAmountSum.setTotalUtilizedValue(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}



		//=========================================================Total Utilized Volume Start========================================================================
		
		public KamTotalUtilizedVolume getTotalUtilizedVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			KamTotalUtilizedVolume totalAssetAmountSum = new KamTotalUtilizedVolume();


			try{
				List<KamTotalUtilizedVolume> totalAssetValues = new ArrayList<KamTotalUtilizedVolume>();
				List<KamTotalUtilizedVolume> totalAssetValuesByUsername = new ArrayList<KamTotalUtilizedVolume>();
				List<KamTotalUtilizedVolume> mocList = new ArrayList<KamTotalUtilizedVolume>();
				
				totalAssetValuesByUsername = kamTotalUtilizedVolumeRepository.findAllTotalUtilizedVolume(username);
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedVolume mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(KamTotalUtilizedVolume t : mocList){
						totalAssetAmount += t.getTotalUtilizedVolume();

					}

					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<KamTotalUtilizedVolume> categoryList = new ArrayList<KamTotalUtilizedVolume>();
					
					//filtered by category

					for(String c : category){
						for(KamTotalUtilizedVolume cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedVolume mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(KamTotalUtilizedVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedVolume();

					}
					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<KamTotalUtilizedVolume> accountList = new ArrayList<KamTotalUtilizedVolume>();
					
					
					for(String accnt : account){
						for(KamTotalUtilizedVolume acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedVolume mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalUtilizedVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedVolume();

					}
					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<KamTotalUtilizedVolume> accountList = new ArrayList<KamTotalUtilizedVolume>();
					List<KamTotalUtilizedVolume> filteredAccountCategoryList = new ArrayList<KamTotalUtilizedVolume>();
					

					//filterd by account
					for(String accnt : account){
						for(KamTotalUtilizedVolume acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(KamTotalUtilizedVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedVolume mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamTotalUtilizedVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedVolume();
					}
					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<KamTotalUtilizedVolume> regionList = new ArrayList<KamTotalUtilizedVolume>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalUtilizedVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedVolume mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalUtilizedVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedVolume();
					}

					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<KamTotalUtilizedVolume> regionList = new ArrayList<KamTotalUtilizedVolume>();
					List<KamTotalUtilizedVolume> filteredRegionAccountList = new ArrayList<KamTotalUtilizedVolume>();
					
					
					//filter by region
					for(String regon : region){
						for(KamTotalUtilizedVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(KamTotalUtilizedVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedVolume mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(KamTotalUtilizedVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedVolume();

					}
					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<KamTotalUtilizedVolume> regionList = new ArrayList<KamTotalUtilizedVolume>();
					List<KamTotalUtilizedVolume> filteredRegionCategoryList = new ArrayList<KamTotalUtilizedVolume>();
					
					//filterd by region

					for(String regon : region){
						for(KamTotalUtilizedVolume reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(KamTotalUtilizedVolume cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamTotalUtilizedVolume mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamTotalUtilizedVolume t : totalAssetValues){
						totalAssetAmount += t.getTotalUtilizedVolume();
					}
					totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<KamTotalUtilizedVolume> regionList = new ArrayList<KamTotalUtilizedVolume>();
					List<KamTotalUtilizedVolume> accountList = new ArrayList<KamTotalUtilizedVolume>();
					List<KamTotalUtilizedVolume> filteredRegionCategoryList = new ArrayList<KamTotalUtilizedVolume>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(KamTotalUtilizedVolume reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(KamTotalUtilizedVolume acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(KamTotalUtilizedVolume cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(KamTotalUtilizedVolume mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(KamTotalUtilizedVolume t : totalAssetValues){
							totalAssetAmount += t.getTotalUtilizedVolume();
						}

						totalAssetAmountSum.setTotalUtilizedVolume(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}




		//=========================================================Utilized Budget  Start========================================================================
		
		public KamUtilizedBudget getUtilizedBudget(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


			double totalAssetAmount = 0.00;
			//Integer totalAssetAmountSum = 0;
			KamUtilizedBudget totalAssetAmountSum = new KamUtilizedBudget();


			try{
				List<KamUtilizedBudget> totalAssetValues = new ArrayList<KamUtilizedBudget>();
				List<KamUtilizedBudget> totalAssetValuesByUsername = new ArrayList<KamUtilizedBudget>();
				List<KamUtilizedBudget> mocList = new ArrayList<KamUtilizedBudget>();
				
				totalAssetValuesByUsername = kamUtilizedBudgetRepository.findAllUtilizedBudget(username);
	            
				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
					
					
					//filtered by MOC
					for(String m : moc){
						for(KamUtilizedBudget mocc : totalAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					for(KamUtilizedBudget t : mocList){
						totalAssetAmount += t.getUtilizedBudget();

					}

					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);

				}

				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

					List<KamUtilizedBudget> categoryList = new ArrayList<KamUtilizedBudget>();
					
					//filtered by category

					for(String c : category){
						for(KamUtilizedBudget cat : totalAssetValuesByUsername){
							if(c.equals(cat.getCategoryNaame())){
								categoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(KamUtilizedBudget mocc : categoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}
					
					
					totalAssetValues.addAll(mocList);
					for(KamUtilizedBudget t : totalAssetValues){
						totalAssetAmount += t.getUtilizedBudget();

					}
					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

					List<KamUtilizedBudget> accountList = new ArrayList<KamUtilizedBudget>();
					
					
					for(String accnt : account){
						for(KamUtilizedBudget acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}
					//filtered by MOC
					for(String m : moc){
						for(KamUtilizedBudget mocc : accountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamUtilizedBudget t : totalAssetValues){
						totalAssetAmount += t.getUtilizedBudget();

					}
					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
				}

				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
					List<KamUtilizedBudget> accountList = new ArrayList<KamUtilizedBudget>();
					List<KamUtilizedBudget> filteredAccountCategoryList = new ArrayList<KamUtilizedBudget>();
					

					//filterd by account
					for(String accnt : account){
						for(KamUtilizedBudget acc : totalAssetValuesByUsername){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}

					//filtered by category
					for(String c : category){
						for(KamUtilizedBudget cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredAccountCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamUtilizedBudget mocc : filteredAccountCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}


					totalAssetValues.addAll(mocList);

					for(KamUtilizedBudget t : totalAssetValues){
						totalAssetAmount += t.getUtilizedBudget();
					}
					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
				}

				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

					List<KamUtilizedBudget> regionList = new ArrayList<KamUtilizedBudget>();
					
					
					//filter by region
					for(String regon : region){
						for(KamUtilizedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamUtilizedBudget mocc : regionList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamUtilizedBudget t : totalAssetValues){
						totalAssetAmount += t.getUtilizedBudget();
					}

					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
				}
				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

					List<KamUtilizedBudget> regionList = new ArrayList<KamUtilizedBudget>();
					List<KamUtilizedBudget> filteredRegionAccountList = new ArrayList<KamUtilizedBudget>();
					
					
					//filter by region
					for(String regon : region){
						for(KamUtilizedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by account

					for(String accnt : account){
						for(KamUtilizedBudget acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								filteredRegionAccountList.add(acc);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamUtilizedBudget mocc : filteredRegionAccountList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);

					for(KamUtilizedBudget t : totalAssetValues){
						totalAssetAmount += t.getUtilizedBudget();

					}
					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
				}


				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

					List<KamUtilizedBudget> regionList = new ArrayList<KamUtilizedBudget>();
					List<KamUtilizedBudget> filteredRegionCategoryList = new ArrayList<KamUtilizedBudget>();
					
					//filterd by region

					for(String regon : region){
						for(KamUtilizedBudget reg : totalAssetValuesByUsername){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(KamUtilizedBudget cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					//filtered by MOC
					for(String m : moc){
						for(KamUtilizedBudget mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					totalAssetValues.addAll(mocList);
					for(KamUtilizedBudget t : totalAssetValues){
						totalAssetAmount += t.getUtilizedBudget();
					}
					totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);
				}	

				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

					List<KamUtilizedBudget> regionList = new ArrayList<KamUtilizedBudget>();
					List<KamUtilizedBudget> accountList = new ArrayList<KamUtilizedBudget>();
					List<KamUtilizedBudget> filteredRegionCategoryList = new ArrayList<KamUtilizedBudget>();
					
					if(totalAssetValuesByUsername !=null)	{
						//-----filter by region------//

						for(String regon : region){
							for(KamUtilizedBudget reg : totalAssetValuesByUsername){
								if(regon.equals(reg.getRegionName())){
									regionList.add(reg);
								}

							}

						}


						//-----filter by account------//

						for(String accnt : account){
							for(KamUtilizedBudget acc : regionList){
								if(accnt.equals(acc.getAccountName())){
									accountList.add(acc);
								}

							}

						}


						//-----filter by category------//

						for(String c : category){
							for(KamUtilizedBudget cat : accountList){
								if(c.equals(cat.getCategoryNaame())){
									filteredRegionCategoryList.add(cat);
								}

							}

						}
						
						//filtered by MOC
						for(String m : moc){
							for(KamUtilizedBudget mocc : filteredRegionCategoryList){
								if(m.equals(mocc.getMoc())){
									mocList.add(mocc);
								}

							}

						}

						totalAssetValues.addAll(mocList);

						for(KamUtilizedBudget t : totalAssetValues){
							totalAssetAmount += t.getUtilizedBudget();
						}

						totalAssetAmountSum.setUtilizedBudget(totalAssetAmount);

					}//end of if

				}// end of else if

			}//end of try
			catch(Exception e){
				e.printStackTrace();
			}


			return totalAssetAmountSum;

		}
		
		//----------------------------------------current moc view-------------------------------------------//
		public List<CurrentMocPromoViewDto> getPromoCurrentMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
			List<CurrentMocPromoViewDto> filteredViewList = new ArrayList<>();
			List<CurrentMocPromoView> totalRecords = new ArrayList<>();

			try{
				Pageable paging = PageRequest.of(pageNo, pageSize);
				
				Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
				totalRecords = currentMocPromoViewRepository.findAllCountCurrentMocViewByMocRegionAccountCategory(moc, account, region, category);

				for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
					CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();

					currentMocPromoViewDto.setCluster(c.getCluster());
					currentMocPromoViewDto.setBasepack(c.getBasepack());
					currentMocPromoViewDto.setBrand(c.getBrand());
					currentMocPromoViewDto.setCategory(c.getCategory());
					currentMocPromoViewDto.setL1_customer(c.getL1_customer());
					currentMocPromoViewDto.setL2_customer(c.getL2_customer());
					currentMocPromoViewDto.setMoc(c.getMoc());
					currentMocPromoViewDto.setOffer(c.getOffer());
					currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
					currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
					currentMocPromoViewDto.setPromo_description(c.getPromo_description());
					currentMocPromoViewDto.setPromo_id(c.getPromo_id());
					currentMocPromoViewDto.setSol_code(c.getSol_code());
					currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
					currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
					currentMocPromoViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(currentMocPromoViewDto);
				}

//				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMoc(username,moc, paging);
//					totalRecords = currentMocPromoViewRepository.findCountByMoc(username,moc);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//				}
//
//
//				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocCategory(username,moc,category, paging);
//					totalRecords = currentMocPromoViewRepository.findCountByMocCategory(username,moc,category);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocAccount(username,moc,account, paging);
//					totalRecords = currentMocPromoViewRepository.findCountByAccount(username,moc,account);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocAccountCategory(username,moc, account, category, paging);
//					totalRecords = currentMocPromoViewRepository.findCountByAccountMocCategory(username,moc, account, category);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//
//				}
//
//				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocRegion(username,moc, region, paging);
//					totalRecords = currentMocPromoViewRepository.findCountByMocRegion(username,moc, region);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//
//
//
//				}
//
//				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocAccountRegion(username,moc, account, region, paging);
//					totalRecords = currentMocPromoViewRepository.findCountByAccountMocRegion(username,moc, account, region);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//
//
//
//
//				}
//
//				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocRegionCategory(username,moc, region, category, paging);
//					totalRecords = currentMocPromoViewRepository.findAllCountCurrentMocViewByMocRegionCategory(username,moc, region, category);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//
//
//				}
//
//				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//					Page<CurrentMocPromoView> currentMocViewDetails = currentMocPromoViewRepository.findAllCurrentMocViewByMocRegionAccountCategory(username,moc, account, region, category, paging);
//					totalRecords = currentMocPromoViewRepository.findAllCountCurrentMocViewByMocRegionAccountCategory(username,moc, account, region, category);
//
//					for(CurrentMocPromoView c : currentMocViewDetails.getContent()){
//						CurrentMocPromoViewDto currentMocPromoViewDto = new CurrentMocPromoViewDto();
//
//						currentMocPromoViewDto.setCluster(c.getCluster());
//						currentMocPromoViewDto.setBasepack(c.getBasepack());
//						currentMocPromoViewDto.setBrand(c.getBrand());
//						currentMocPromoViewDto.setCategory(c.getCategory());
//						currentMocPromoViewDto.setL1_customer(c.getL1_customer());
//						currentMocPromoViewDto.setL2_customer(c.getL2_customer());
//						currentMocPromoViewDto.setMoc(c.getMoc());
//						currentMocPromoViewDto.setOffer(c.getOffer());
//						currentMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						currentMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						currentMocPromoViewDto.setPromo_description(c.getPromo_description());
//						currentMocPromoViewDto.setPromo_id(c.getPromo_id());
//						currentMocPromoViewDto.setSol_code(c.getSol_code());
//						currentMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						currentMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						currentMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(currentMocPromoViewDto);
//					}
//				}


			}catch(Exception e){
				e.printStackTrace();
			}
			return filteredViewList;
		}

	//=========================Previous Moc View==========================================================================
		
		public List<PreviousMocPromoViewDto> getPromoPreviousMocView(List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
			List<PreviousMocPromoViewDto> filteredViewList = new ArrayList<>();
			List<PreviousMocPromoView> totalRecords = new ArrayList<>();

			try{
				Pageable paging = PageRequest.of(pageNo, pageSize);

				Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocRegionAccountCategory(moc, account, region, category, paging);
				totalRecords = previousMocPromoViewRepository.findAllCountPreviousMocViewByMocRegionAccountCategory(moc, account, region, category);
				
				for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
					PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();

					previousMocPromoViewDto.setCluster(c.getCluster());
					previousMocPromoViewDto.setBasepack(c.getBasepack());
					previousMocPromoViewDto.setBrand(c.getBrand());
					previousMocPromoViewDto.setCategory(c.getCategory());
					previousMocPromoViewDto.setL1_customer(c.getL1_customer());
					previousMocPromoViewDto.setL2_customer(c.getL2_customer());
					previousMocPromoViewDto.setMoc(c.getMoc());
					previousMocPromoViewDto.setOffer(c.getOffer());
					previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
					previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
					previousMocPromoViewDto.setPromo_description(c.getPromo_description());
					previousMocPromoViewDto.setPromo_id(c.getPromo_id());
					previousMocPromoViewDto.setSol_code(c.getSol_code());
					previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
					previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
					previousMocPromoViewDto.setTotalRecords(totalRecords.size());

					filteredViewList.add(previousMocPromoViewDto);
					}
//				if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMoc(username,moc, paging);
//					totalRecords = previousMocPromoViewRepository.findCountByMoc(username,moc);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//				}
//
//				else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocCategory(username,moc,category, paging);
//					totalRecords = previousMocPromoViewRepository.findCountByMocCategory(username,moc,category);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocAccount(username,moc,account, paging);
//					totalRecords = previousMocPromoViewRepository.findCountByAccount(username,moc,account);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//
//				}
//
//				else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocAccountCategory(username,moc, account, category, paging);
//					totalRecords = previousMocPromoViewRepository.findCountByAccountMocCategory(username,moc, account, category);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//
//				}	
//
//				else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocRegion(username,moc, region, paging);
//					totalRecords = previousMocPromoViewRepository.findCountByMocRegion(username,moc, region);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//
//
//				}
//
//				else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocAccountRegion(username,moc, account, region, paging);
//					totalRecords = previousMocPromoViewRepository.findCountByAccountMocRegion(username,moc, account, region);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//
//				}
//				else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocRegionCategory(username,moc, region, category, paging);
//					totalRecords = previousMocPromoViewRepository.findAllCountPreviousMocViewByMocRegionCategory(username,moc, region, category);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//
//
//				}
//
//				else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//					Page<PreviousMocPromoView> previousMocViewDetails = previousMocPromoViewRepository.findAllPreviousMocViewByMocRegionAccountCategory(username,moc, account, region, category, paging);
//					totalRecords = previousMocPromoViewRepository.findAllCountPreviousMocViewByMocRegionAccountCategory(username,moc, account, region, category);
//
//					for(PreviousMocPromoView c : previousMocViewDetails.getContent()){
//						PreviousMocPromoViewDto previousMocPromoViewDto = new PreviousMocPromoViewDto();
//
//						previousMocPromoViewDto.setCluster(c.getCluster());
//						previousMocPromoViewDto.setBasepack(c.getBasepack());
//						previousMocPromoViewDto.setBrand(c.getBrand());
//						previousMocPromoViewDto.setCategory(c.getCategory());
//						previousMocPromoViewDto.setL1_customer(c.getL1_customer());
//						previousMocPromoViewDto.setL2_customer(c.getL2_customer());
//						previousMocPromoViewDto.setMoc(c.getMoc());
//						previousMocPromoViewDto.setOffer(c.getOffer());
//						previousMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//						previousMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//						previousMocPromoViewDto.setPromo_description(c.getPromo_description());
//						previousMocPromoViewDto.setPromo_id(c.getPromo_id());
//						previousMocPromoViewDto.setSol_code(c.getSol_code());
//						previousMocPromoViewDto.setUtilized_budget(c.getUtilized_budget());
//						previousMocPromoViewDto.setUtilized_volume(c.getUtilized_volume());
//						previousMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//						filteredViewList.add(previousMocPromoViewDto);
//					}
//				}

			}catch(Exception e){
				e.printStackTrace();
			}
			return filteredViewList;
		}


		//=========================Next Moc View==========================================================================
		
				public List<NextMocPromoViewDto> getPromoNextMocView(String username,List<String> region,List<String> account,List<String> moc,List<String>category,Integer pageNo, Integer pageSize){
					List<NextMocPromoViewDto> filteredViewList = new ArrayList<>();
					List<NextMocPromoView> totalRecords = new ArrayList<>();

					try{
						Pageable paging = PageRequest.of(pageNo, pageSize);
						
						Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocRegionAccountCategory(username,moc, account, region, category, paging);
						totalRecords = nextMocPromoViewRepository.findAllCountNextMocViewByMocRegionAccountCategory(username,moc, account, region, category);

						for(NextMocPromoView c : nextMocViewDetails.getContent()){
							NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();

							nextMocPromoViewDto.setCluster(c.getCluster());
							nextMocPromoViewDto.setBasepack(c.getBasepack());
							nextMocPromoViewDto.setBrand(c.getBrand());
							nextMocPromoViewDto.setCategory(c.getCategory());
							nextMocPromoViewDto.setL1_customer(c.getL1_customer());
							nextMocPromoViewDto.setL2_customer(c.getL2_customer());
							nextMocPromoViewDto.setMoc(c.getMoc());
							nextMocPromoViewDto.setOffer(c.getOffer());
							nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
							nextMocPromoViewDto.setPromo_description(c.getPromo_description());
							nextMocPromoViewDto.setPromo_id(c.getPromo_id());
							nextMocPromoViewDto.setSol_code(c.getSol_code());
							nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
							nextMocPromoViewDto.setTotalRecords(totalRecords.size());

							filteredViewList.add(nextMocPromoViewDto);
						}

//						if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMoc(username,moc, paging);
//							totalRecords = nextMocPromoViewRepository.findCountByMoc(username,moc);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//						}
//
//						else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2
//
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocCategory(username,moc,category, paging);
//							totalRecords = nextMocPromoViewRepository.findCountByMocCategory(username,moc,category);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//
//						}
//
//						else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3
//
//
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocAccount(username,moc,account, paging);
//							totalRecords = nextMocPromoViewRepository.findCountByAccount(username,moc,account);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//
//						}
//
//						else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
//
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocAccountCategory(username,moc, account, category, paging);
//							totalRecords = nextMocPromoViewRepository.findCountByAccountMocCategory(username,moc, account, category);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//
//						}	
//
//						else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5
//
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocRegion(username,moc, region, paging);
//							totalRecords = nextMocPromoViewRepository.findCountByMocRegion(username,moc, region);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//
//
//						}
//
//						else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6
//
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocAccountRegion(username,moc, account, region, paging);
//							totalRecords = nextMocPromoViewRepository.findCountByAccountMocRegion(username,moc, account, region);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//
//						}
//						else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
//
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocRegionCategory(username,moc, region, category, paging);
//							totalRecords = nextMocPromoViewRepository.findAllCountNextMocViewByMocRegionCategory(username,moc, region, category);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//
//
//						}
//
//						else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
//
//							Page<NextMocPromoView> nextMocViewDetails = nextMocPromoViewRepository.findAllNextMocViewByMocRegionAccountCategory(username,moc, account, region, category, paging);
//							totalRecords = nextMocPromoViewRepository.findAllCountNextMocViewByMocRegionAccountCategory(username,moc, account, region, category);
//
//							for(NextMocPromoView c : nextMocViewDetails.getContent()){
//								NextMocPromoViewDto nextMocPromoViewDto = new NextMocPromoViewDto();
//
//								nextMocPromoViewDto.setCluster(c.getCluster());
//								nextMocPromoViewDto.setBasepack(c.getBasepack());
//								nextMocPromoViewDto.setBrand(c.getBrand());
//								nextMocPromoViewDto.setCategory(c.getCategory());
//								nextMocPromoViewDto.setL1_customer(c.getL1_customer());
//								nextMocPromoViewDto.setL2_customer(c.getL2_customer());
//								nextMocPromoViewDto.setMoc(c.getMoc());
//								nextMocPromoViewDto.setOffer(c.getOffer());
//								nextMocPromoViewDto.setPlanned_volume(c.getPlanned_volume());
//								nextMocPromoViewDto.setPromo_description(c.getPromo_description());
//								nextMocPromoViewDto.setPromo_id(c.getPromo_id());
//								nextMocPromoViewDto.setSol_code(c.getSol_code());
//								nextMocPromoViewDto.setPlanned_budget(c.getPlanned_budget());
//								nextMocPromoViewDto.setTotalRecords(totalRecords.size());
//
//								filteredViewList.add(nextMocPromoViewDto);
//							}
//						}

					}catch(Exception e){
						e.printStackTrace();
					}
					return filteredViewList;
				}








}
