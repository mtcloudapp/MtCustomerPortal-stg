package com.unilever.promo.claim.view.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.external.model.BaseWorking;
import com.unilever.promo.claim.external.repository.BaseWorkingRepository;
import com.unilever.promo.claim.external.repository.OverrunClaimRepository;
import com.unilever.promo.claim.external.repository.PromoClaimSummaryRepository;
import com.unilever.promo.claim.external.service.PromoClaimExcelHelper;

@Service
public class PromoClaimB2CBaseworkingService {

	@Autowired
	BaseWorkingRepository baseWorkingRepository;
	
	@Autowired
	OverrunClaimRepository overrunClaimRepository;
	
	@Autowired
	PromoClaimSummaryRepository promoClaimSummaryRepository;

	public ResponseMessage updateBaseWorkingByB2C(Integer solcode,Integer basepack,Integer articleCode,Double netClaimValueRevised,
			 Double netClaimQtyRevised,Double promotionAmtRevised,Double claimAmtPerUnitRevised,Double claimPosPrimaryQtyRevised,
			 Double custClaimMinQtyRevised,Double diffInCustomerClaimRevised,Double hulClaimRevised,Double netClaimRevised,
			 Double diffClaimsRevised) {

		ResponseMessage response = new ResponseMessage();
	
		try{
			if(solcode !=null && basepack !=null && articleCode !=null){
				baseWorkingRepository.updateBaseWorkingBySolCodeBasepackArticleCode(netClaimValueRevised, netClaimQtyRevised, promotionAmtRevised,
											claimAmtPerUnitRevised, claimPosPrimaryQtyRevised, custClaimMinQtyRevised, diffInCustomerClaimRevised, 
											 hulClaimRevised, netClaimRevised, diffClaimsRevised, solcode, basepack, articleCode);
				response.setMessage("Success");
			}else{
				response.setMessage("Please Provide Solcode,basepack,article code before update");
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return response;
	
	}
	
	public ResponseMessage updateOverrunclaimByB2C(Integer solcode,String account,String moc,Double approvedOverrunPercentage){

		ResponseMessage response = new ResponseMessage();
		try{
			if(solcode !=null && account !=moc && approvedOverrunPercentage !=null){
				overrunClaimRepository.updateOverrunClaimByAccountMocSolcode(approvedOverrunPercentage, account, moc, solcode);
				response.setMessage("Success");
			}else{
				response.setMessage("Please Provide Solcode,account,moc,approvedOverrunPercentage  before update");
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}
	
	public ResponseMessage approveOverrunClaim(String account,String moc,String username,String overrun) {

		ResponseMessage resps = new ResponseMessage();
		
		try{
			overrunClaimRepository.updateOverrunClaimFinal(account, moc, username, "EXCEPTION",overrun);
			promoClaimSummaryRepository.insertIntoPromoClaimSummary(account, moc);
			resps.setMessage("Success");
		}

		catch(Exception e){
			e.printStackTrace();
		}
		return resps;

	}
	
	public ByteArrayInputStream getBaseWorkingDetails(String accountName, String moc) {

		List<BaseWorking> baseWorkingActualData = baseWorkingRepository.findCountByAccountAndMoc(accountName,moc);

		ByteArrayInputStream in = PromoClaimExcelHelper.generateDataToExcel(baseWorkingActualData);
		getRevisedBaseWorkingDetails(accountName,moc);
		return in;
		}



		public ByteArrayInputStream getRevisedBaseWorkingDetails(String accountName, String moc) {

		List<BaseWorking> baseWorkingRevisedData = baseWorkingRepository.findCountByAccountAndMoc(accountName,moc);
		ByteArrayInputStream in = PromoClaimExcelHelper.generateRevisedDataToExcel(baseWorkingRevisedData);
		return in;
		}
		
	
}
