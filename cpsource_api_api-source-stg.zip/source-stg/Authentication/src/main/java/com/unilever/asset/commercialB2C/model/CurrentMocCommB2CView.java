package com.unilever.asset.commercialB2C.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.unilever.global.GlobalVariables;
@Entity
@Table(name="vw_INT_CURR_MOC_B2C", schema=GlobalVariables.schemaName)
public class CurrentMocCommB2CView implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5922087877145840252L;
	
@Id
private String id;

@Column(name="REGION")	
private String region;

@Column(name="BRANCH")
private String branch;

@Column(name="ACCOUNT")
private String account;

@Column(name="VISI REFERENCE NO")
private String visiRefNo;

@Column(name="HUL CODE")
private String hulCode;

@Column(name="MOC")
private String moc;

@Column(name="CATEGORY")
private String category;

@Column(name="CITY")
private String city;

@Column(name="ASSET TYPE")
private String assetType;

@Column(name="ASSET DESCRIPTION")
private String assetDescription;

@Column(name="CREATED ON")
private String createdOn;


@Column(name="DEPOT CONNECTED ON")
private String depotConnectOn;

@Column(name="DEPLOYED ON")
private String deployedOn;

@Column(name="COMPLIANCE")
private Integer compliance;

@Column(name="LOSS TREE")
private String lossTree;

@Column(name="GODOWN CODE")
private String godownCode;

public CurrentMocCommB2CView() {
	super();
	// TODO Auto-generated constructor stub
}


public CurrentMocCommB2CView(String id, String region, String branch, String account, String visiRefNo, String hulCode,
		String moc, String category, String city, String assetType, String assetDescription, String createdOn,
		String depotConnectOn, String deployedOn, Integer compliance, String lossTree, String godownCode) {
	super();
	this.id = id;
	this.region = region;
	this.branch = branch;
	this.account = account;
	this.visiRefNo = visiRefNo;
	this.hulCode = hulCode;
	this.moc = moc;
	this.category = category;
	this.city = city;
	this.assetType = assetType;
	this.assetDescription = assetDescription;
	this.createdOn = createdOn;
	this.depotConnectOn = depotConnectOn;
	this.deployedOn = deployedOn;
	this.compliance = compliance;
	this.lossTree = lossTree;
	this.godownCode = godownCode;
}






public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getRegion() {
	return region;
}

public void setRegion(String region) {
	this.region = region;
}

public String getBranch() {
	return branch;
}

public void setBranch(String branch) {
	this.branch = branch;
}
public String getAccount() {
	return account;
}

public void setAccount(String account) {
	this.account = account;
}

public String getVisiRefNo() {
	return visiRefNo;
}

public void setVisiRefNo(String visiRefNo) {
	this.visiRefNo = visiRefNo;
}

public String getHulCode() {
	return hulCode;
}

public void setHulCode(String hulCode) {
	this.hulCode = hulCode;
}

public String getMoc() {
	return moc;
}

public void setMoc(String moc) {
	this.moc = moc;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public String getAssetType() {
	return assetType;
}

public void setAssetType(String assetType) {
	this.assetType = assetType;
}

public String getAssetDescription() {
	return assetDescription;
}

public void setAssetDescription(String assetDescription) {
	this.assetDescription = assetDescription;
}

public String getCreatedOn() {
	return createdOn;
}

public void setCreatedOn(String createdOn) {
	this.createdOn = createdOn;
}

public String getDepotConnectOn() {
	return depotConnectOn;
}

public void setDepotConnectOn(String depotConnectOn) {
	this.depotConnectOn = depotConnectOn;
}

public String getDeployedOn() {
	return deployedOn;
}

public void setDeployedOn(String deployedOn) {
	this.deployedOn = deployedOn;
}

public Integer getCompliance() {
	return compliance;
}

public void setCompliance(Integer compliance) {
	this.compliance = compliance;
}

public String getLossTree() {
	return lossTree;
}

public void setLossTree(String lossTree) {
	this.lossTree = lossTree;
}


public String getGodownCode() {
	return godownCode;
}


public void setGodownCode(String godownCode) {
	this.godownCode = godownCode;
}



}
