package com.unilever.promo.claim.view.model;

import java.io.Serializable;

public class OverrunClaimDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6075397445936250818L;
	
	private Integer solCode;
	
	private String solCode_all;
	
	private String solCode_name;
	
	private Double budget;

	private Double customerClaimAmountt;

	private Double b2cSignedOffAmount;

	private Double remainingBudget;
	
	private Double overrunAmt;
	
    private Double overrunPercentage;
	
	private Double approvedOverrunPercentage;
	
	private Double approvedOverrunAmount;
	
	private Double approvedOverrun;
	
	private String overrunApprover;
	
	private String remarks;
	
	private Integer totalRecords;

	public OverrunClaimDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}

	public Double getBudget() {
		return budget;
	}

	public void setBudget(Double budget) {
		this.budget = budget;
	}

	public Double getCustomerClaimAmountt() {
		return customerClaimAmountt;
	}

	public void setCustomerClaimAmountt(Double customerClaimAmountt) {
		this.customerClaimAmountt = customerClaimAmountt;
	}

	public Double getB2cSignedOffAmount() {
		return b2cSignedOffAmount;
	}

	public void setB2cSignedOffAmount(Double b2cSignedOffAmount) {
		this.b2cSignedOffAmount = b2cSignedOffAmount;
	}

	public Double getRemainingBudget() {
		return remainingBudget;
	}

	public void setRemainingBudget(Double remainingBudget) {
		this.remainingBudget = remainingBudget;
	}

	public Double getOverrunAmt() {
		return overrunAmt;
	}

	public void setOverrunAmt(Double overrunAmt) {
		this.overrunAmt = overrunAmt;
	}

	public Double getApprovedOverrun() {
		return approvedOverrun;
	}

	public void setApprovedOverrun(Double approvedOverrun) {
		this.approvedOverrun = approvedOverrun;
	}

	public String getOverrunApprover() {
		return overrunApprover;
	}

	public void setOverrunApprover(String overrunApprover) {
		this.overrunApprover = overrunApprover;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	public Double getOverrunPercentage() {
		return overrunPercentage;
	}

	public void setOverrunPercentage(Double overrunPercentage) {
		this.overrunPercentage = overrunPercentage;
	}

	public Double getApprovedOverrunPercentage() {
		return approvedOverrunPercentage;
	}

	public void setApprovedOverrunPercentage(Double approvedOverrunPercentage) {
		this.approvedOverrunPercentage = approvedOverrunPercentage;
	}

	public Double getApprovedOverrunAmount() {
		return approvedOverrunAmount;
	}

	public void setApprovedOverrunAmount(Double approvedOverrunAmount) {
		this.approvedOverrunAmount = approvedOverrunAmount;
	}

	public String getSolCode_all() {
		return solCode_all;
	}

	public void setSolCode_all(String solCode_all) {
		this.solCode_all = solCode_all;
	}

	public String getSolCode_name() {
		return solCode_name;
	}

	public void setSolCode_name(String solCode_name) {
		this.solCode_name = solCode_name;
	}

	
	
	

	

}
