package com.unilever.asset.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.external.model.OtherIssuesVolume;
import com.unilever.global.GlobalVariables;

@Repository
public interface OtherIssuseVolumeRepository extends JpaRepository<OtherIssuesVolume, Integer>{

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_OTHER_ISSUES_VOLUME etas where etas.USERNAME=:username", nativeQuery = true)
	List<OtherIssuesVolume> findAllOtherIssuesVolumeExternalDetails(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_OTHER_ISSUES_VOLUME etas where etas.USERNAME=:username and etas.MOC=:moc", nativeQuery = true)
	List<OtherIssuesVolume> findAllOtherIssuesVolumeExternalDetailsByMoc(@Param("username") String username,@Param("moc") String moc);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_OTHER_ISSUES_VOLUME etas where etas.USERNAME=:username and etas.MOC=:moc and etas.CATEGORY_NAME=:category", nativeQuery = true)
	List<OtherIssuesVolume> findAllOtherIssuesVolumeExternalDetailsByMocAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_OTHER_ISSUES_VOLUME etas where etas.USERNAME=:username and  etas.REGION_NAME=:region and etas.MOC=:moc", nativeQuery = true)
	List<OtherIssuesVolume> findAllOtherIssuesVolumeExternalDetailsByRegionAndMoc(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);

}
