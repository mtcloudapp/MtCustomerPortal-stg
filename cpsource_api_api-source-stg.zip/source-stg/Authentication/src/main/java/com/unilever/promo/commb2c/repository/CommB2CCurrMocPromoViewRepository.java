package com.unilever.promo.commb2c.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.commb2c.model.CurrentMocPromoB2cView;


@Repository
public interface CommB2CCurrMocPromoViewRepository extends PagingAndSortingRepository<CurrentMocPromoB2cView, String> {
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMoc(@Param("moc") List<String> moc,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm where icm.MOC in :moc", nativeQuery = true)
	List<CurrentMocPromoB2cView> findCountByMoc(@Param("moc") List<String> moc);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm where icm.MOC in :moc and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocPromoB2cView> findCountByMocCategory(@Param("moc") List<String> moc,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocAccount(@Param("moc") List<String> moc,@Param("account") List<String> account,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account", nativeQuery = true)
	List<CurrentMocPromoB2cView> findCountByAccount(@Param("moc") List<String> moc,@Param("account") List<String> account);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocPromoB2cView> findCountByAccountMocCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.CLUSTER in :region", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region,Pageable pageable);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm where icm.MOC in :moc and icm.CLUSTER in :region", nativeQuery = true)
	List<CurrentMocPromoB2cView> findCountByMocRegion(@Param("moc") List<String> moc,@Param("region") List<String> region);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CLUSTER in :region", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocAccountRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm where icm.MOC in :moc and icm.L1_CUSTOMER in :account and icm.CLUSTER in :region", nativeQuery = true)
	List<CurrentMocPromoB2cView> findCountByAccountMocRegion(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.CLUSTER in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocPromoB2cView> findAllCountCurrentMocViewByMocRegionCategory(@Param("moc") List<String> moc,@Param("region") List<String> region,@Param("category") List<String> category);
	

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.L2_CUSTOMER in :account and icm.CLUSTER in :region and icm.CATEGORY in :category", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,Pageable pageable);
	
	//Sarin Changes - Performance Jun21
	@Transactional
	@Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.L2_CUSTOMER in :account and icm.CLUSTER in :region and icm.CATEGORY in :category AND ROW_NUM BETWEEN :pagestart AND :pageend ", nativeQuery = true)
	Page<CurrentMocPromoB2cView> findAllCurrentMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category,@Param("pagestart") Integer pagestart,@Param("pageend") Integer pageend,Pageable pageable);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".vw_INT_CURR_PROMO_B2C icm  where icm.MOC in :moc and icm.L2_CUSTOMER in :account and icm.CLUSTER in :region and icm.CATEGORY in :category", nativeQuery = true)
	List<CurrentMocPromoB2cView> findAllCountCurrentMocViewByMocRegionAccountCategory(@Param("moc") List<String> moc,@Param("account") List<String> account,@Param("region") List<String> region,@Param("category") List<String> category);
	
	

}
