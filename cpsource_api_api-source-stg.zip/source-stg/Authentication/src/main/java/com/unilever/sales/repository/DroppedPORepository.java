package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.AvailablePO;
import com.unilever.sales.model.DroppedPO;

@Repository
public interface DroppedPORepository extends JpaRepository<DroppedPO, Integer>{
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category", nativeQuery = true)
	Integer findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.REASON=:reason and tac.PO_NUMBER in :poNumber", nativeQuery = true)
	List<Integer> findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,
		@Param("branch") List<String> branch,@Param("reason") String reason,@Param("poNumber") List<String> poNumber);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.REASON=:reason", nativeQuery = true)
	List<Integer> findNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,
		@Param("branch") List<String> branch,@Param("reason") String reason);
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch", nativeQuery = true)
	Integer findDroppedPONoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch);
	
	//=====================================================================================================================
	@Transactional
    @Query(value ="select DISTINCT tac.REASON from "+GlobalVariables.schemaName+".DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch", nativeQuery = true)
	List<String> findReason(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch);
	
	@Transactional
    @Query(value ="select DISTINCT tac.REASON from "+GlobalVariables.schemaName+".DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.PO_NUMBER in :poNumber", nativeQuery = true)
	List<String> findReasonByPoNumber(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("poNumber") List<String> poNumber);
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".DROPPED_PO", nativeQuery = true)
	List<DroppedPO> findDroppedPoList();
}
