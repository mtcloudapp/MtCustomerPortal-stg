package com.unilever.promo.claim.external.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaimMultiSOLCodeStage;

@Repository
public interface PromoClaimMultiSOLCodeStageRepository extends JpaRepository<PromoClaimMultiSOLCodeStage, Integer> {

	@Transactional
    @Query(value ="select count(1) from "+GlobalVariables.schemaName+".PROMO_CLAIM_MULTI_SOLCODE_STAGE where ACCOUNT_NAME = :accountName and MOC = :moc", nativeQuery = true)
	Integer findCountPromoClaimMultiSolCodeStage(@Param("accountName") String accountName, @Param("moc") String moc);
	
	@Modifying
	@Transactional
    @Query(value ="truncate table "+GlobalVariables.schemaName+".PROMO_CLAIM_MULTI_SOLCODE_STAGE", nativeQuery = true)
    void deletePromoClaimMultiSolStage();
	
	@Transactional
	@Query(value = "CALL sp_LoadPromoClaimMultiSolCodeDetails();", nativeQuery = true)
	void insertPromoClaimMultiSolCodeDataByAccountName();
	
}
