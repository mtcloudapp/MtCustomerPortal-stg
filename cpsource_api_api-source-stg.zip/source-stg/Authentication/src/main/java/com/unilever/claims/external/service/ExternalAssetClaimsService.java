package com.unilever.claims.external.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unilever.claims.extenal.model.ApprovedExceptionClaimsValueExternal;
import com.unilever.claims.extenal.model.ApprovedExceptionClaimsVolumeExternal;
import com.unilever.claims.extenal.model.ClaimsRaisedExternal;
import com.unilever.claims.extenal.model.CpsMtFinaceView;
import com.unilever.claims.extenal.model.CpsMtFinanceDto;
import com.unilever.claims.extenal.model.PaidClaimsValueExternal;
import com.unilever.claims.extenal.model.RejectedClaimValueExternal;
import com.unilever.claims.extenal.model.RejectedClaimVolumeExternal;
import com.unilever.claims.extenal.model.TotalAmountPlannedExternal;
import com.unilever.claims.extenal.model.UnpaidClaimsValueExternal;
import com.unilever.claims.external.repository.ApprovedExceptionClaimValueExternalRepository;
import com.unilever.claims.external.repository.ApprovedExceptionClaimVolumeExternalRepository;
import com.unilever.claims.external.repository.ClaimsRaisedExternalRepository;
import com.unilever.claims.external.repository.ExternalPaymetStatusRepository;
import com.unilever.claims.external.repository.ExternalServiceNoteMasterRepository;
import com.unilever.claims.external.repository.PaidClaimValueExternalRepository;
import com.unilever.claims.external.repository.RejectedClaimValueExternalRepository;
import com.unilever.claims.external.repository.RejectedClaimVolumesExternalRepository;
import com.unilever.claims.external.repository.ExternalServiceNoteRepository;
import com.unilever.claims.external.repository.TotalAmountPlannedExternalRepository;
import com.unilever.claims.external.repository.UnpaidClaimValueExternalRepository;


@Service
public class ExternalAssetClaimsService {

	@Autowired
	ApprovedExceptionClaimValueExternalRepository approvedExceptionClaimValueRepository;

	@Autowired
	ApprovedExceptionClaimVolumeExternalRepository approvedExceptionClaimVolumeRepository;

	@Autowired
	ClaimsRaisedExternalRepository claimsRaisedRepository;

	@Autowired
	PaidClaimValueExternalRepository paidClaimValueRepository;

	@Autowired
	RejectedClaimValueExternalRepository rejectedClaimValueRepository;

	@Autowired
	RejectedClaimVolumesExternalRepository rejectedClaimVolumesRepository;

	@Autowired
	TotalAmountPlannedExternalRepository totalAmountPlannedRepository;

	@Autowired
	UnpaidClaimValueExternalRepository unpaidClaimValueRepository;

	@Autowired
	private ExternalServiceNoteMasterRepository externalServiceNoteMasterRepository;

	@Autowired
	ExternalPaymetStatusRepository externalPaymetStatusRepository;

	//================================================================Start Approve Exception Claims Value===========================================================


	public ApprovedExceptionClaimsValueExternal getExternalApprovedExceptionClaimsValue(String username,List<String> region,List<String> moc,List<String> category){


		Double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		ApprovedExceptionClaimsValueExternal totalAssetAmountSum = new ApprovedExceptionClaimsValueExternal();


		try{

			List<ApprovedExceptionClaimsValueExternal> totalAssetValues = new ArrayList<ApprovedExceptionClaimsValueExternal>();
			List<ApprovedExceptionClaimsValueExternal> totalExternalData = new ArrayList<ApprovedExceptionClaimsValueExternal>();
			List<ApprovedExceptionClaimsValueExternal> mocList = new ArrayList<ApprovedExceptionClaimsValueExternal>();

			totalExternalData = approvedExceptionClaimValueRepository.findAllApprovedExceptionClaimValueExternalDetails(username);



			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimsValueExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(ApprovedExceptionClaimsValueExternal t : mocList){
					totalAssetAmount += t.getApprovedExceptionClaimsValue();
				}

				totalAssetAmountSum.setApprovedExceptionClaimsValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<ApprovedExceptionClaimsValueExternal> categoryList = new ArrayList<ApprovedExceptionClaimsValueExternal>();

				//filtered by category

				for(String c : category){
					for(ApprovedExceptionClaimsValueExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimsValueExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(ApprovedExceptionClaimsValueExternal t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimsValue();
				}

				totalAssetAmountSum.setApprovedExceptionClaimsValue(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<ApprovedExceptionClaimsValueExternal> regionList = new ArrayList<ApprovedExceptionClaimsValueExternal>();

				//filter by region
				for(String regon : region){
					for(ApprovedExceptionClaimsValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimsValueExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(ApprovedExceptionClaimsValueExternal t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimsValue();
				}

				totalAssetAmountSum.setApprovedExceptionClaimsValue(totalAssetAmount);

			}
			else if(region != null && moc !=null && category !=null  ){  //4
				List<ApprovedExceptionClaimsValueExternal> regionList = new ArrayList<ApprovedExceptionClaimsValueExternal>();
				List<ApprovedExceptionClaimsValueExternal> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimsValueExternal>();

				//filterd by region

				for(String regon : region){
					for(ApprovedExceptionClaimsValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(ApprovedExceptionClaimsValueExternal cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimsValueExternal mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(ApprovedExceptionClaimsValueExternal t : totalAssetValues){
					totalAssetAmount += t.getApprovedExceptionClaimsValue();
				}
				totalAssetAmountSum.setApprovedExceptionClaimsValue(totalAssetAmount);
			}//end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	//================================================================Start Approve Exception Claims Volume===========================================================


	public ApprovedExceptionClaimsVolumeExternal getExternalApprovedExceptionClaimsVolume(String username,List<String> region,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		ApprovedExceptionClaimsVolumeExternal totalAssetVolumeSum= new ApprovedExceptionClaimsVolumeExternal();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<ApprovedExceptionClaimsVolumeExternal> totalExternalData = new ArrayList<ApprovedExceptionClaimsVolumeExternal>();
			List<ApprovedExceptionClaimsVolumeExternal> mocList = new ArrayList<ApprovedExceptionClaimsVolumeExternal>();
			List<ApprovedExceptionClaimsVolumeExternal> filteredList = new ArrayList<ApprovedExceptionClaimsVolumeExternal>();


			totalExternalData = approvedExceptionClaimVolumeRepository.findAllApprovedExceptionClaimsVolumeExternalDetails(username);


			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimsVolumeExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				for(ApprovedExceptionClaimsVolumeExternal t : mocList){
					totalAssetVolume += t.getApprovedExceptionClaimsVolume();
				}

				totalAssetVolumeSum.setApprovedExceptionClaimsVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<ApprovedExceptionClaimsVolumeExternal> categoryList = new ArrayList<ApprovedExceptionClaimsVolumeExternal>();


				//filtered by category

				for(String c : category){
					for(ApprovedExceptionClaimsVolumeExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimsVolumeExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(ApprovedExceptionClaimsVolumeExternal t : filteredList){
					totalAssetVolume += t.getApprovedExceptionClaimsVolume();
				}

				totalAssetVolumeSum.setApprovedExceptionClaimsVolume(totalAssetVolume);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<ApprovedExceptionClaimsVolumeExternal> regionList = new ArrayList<ApprovedExceptionClaimsVolumeExternal>();

				//filter by region
				for(String regon : region){
					for(ApprovedExceptionClaimsVolumeExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(ApprovedExceptionClaimsVolumeExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);
				for(ApprovedExceptionClaimsVolumeExternal t : filteredList){
					totalAssetVolume += t.getApprovedExceptionClaimsVolume();
				}

				totalAssetVolumeSum.setApprovedExceptionClaimsVolume(totalAssetVolume);

			}


			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{
					List<ApprovedExceptionClaimsVolumeExternal> regionList = new ArrayList<ApprovedExceptionClaimsVolumeExternal>();
					List<ApprovedExceptionClaimsVolumeExternal> filteredRegionCategoryList = new ArrayList<ApprovedExceptionClaimsVolumeExternal>();

					//filterd by region

					for(String regon : region){
						for(ApprovedExceptionClaimsVolumeExternal reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(ApprovedExceptionClaimsVolumeExternal cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(ApprovedExceptionClaimsVolumeExternal mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);
					for(ApprovedExceptionClaimsVolumeExternal t : filteredList){
						totalAssetVolume += t.getApprovedExceptionClaimsVolume();
					}

					totalAssetVolumeSum.setApprovedExceptionClaimsVolume(totalAssetVolume);

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}//Done


	//================================================================Rejected Claims Value===========================================================


	public RejectedClaimValueExternal getExternalRejectedClaimValue(String username,List<String> region,List<String> moc,List<String> category){


		Double totalAssetAmount = 0.0;
		//Integer totalAssetAmountSum = 0;
		RejectedClaimValueExternal totalAssetAmountSum = new RejectedClaimValueExternal();


		try{

			List<RejectedClaimValueExternal> totalAssetValues = new ArrayList<RejectedClaimValueExternal>();
			List<RejectedClaimValueExternal> totalExternalData = new ArrayList<RejectedClaimValueExternal>();
			List<RejectedClaimValueExternal> mocList = new ArrayList<RejectedClaimValueExternal>();

			totalExternalData = rejectedClaimValueRepository.findAllRejectedClaimValueExternalDetails(username);



			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(RejectedClaimValueExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(RejectedClaimValueExternal t : mocList){
					totalAssetAmount += t.getRejectedClaimsValue();
				}

				totalAssetAmountSum.setRejectedClaimsValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<RejectedClaimValueExternal> categoryList = new ArrayList<RejectedClaimValueExternal>();

				//filtered by category

				for(String c : category){
					for(RejectedClaimValueExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(RejectedClaimValueExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(RejectedClaimValueExternal t : totalAssetValues){
					totalAssetAmount += t.getRejectedClaimsValue();
				}

				totalAssetAmountSum.setRejectedClaimsValue(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<RejectedClaimValueExternal> regionList = new ArrayList<RejectedClaimValueExternal>();

				//filter by region
				for(String regon : region){
					for(RejectedClaimValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(RejectedClaimValueExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(RejectedClaimValueExternal t : totalAssetValues){
					totalAssetAmount += t.getRejectedClaimsValue();
				}

				totalAssetAmountSum.setRejectedClaimsValue(totalAssetAmount);

			}
			else if(region != null && moc !=null && category !=null  ){  //4
				List<RejectedClaimValueExternal> regionList = new ArrayList<RejectedClaimValueExternal>();
				List<RejectedClaimValueExternal> filteredRegionCategoryList = new ArrayList<RejectedClaimValueExternal>();

				//filterd by region

				for(String regon : region){
					for(RejectedClaimValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(RejectedClaimValueExternal cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(RejectedClaimValueExternal mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(RejectedClaimValueExternal t : totalAssetValues){
					totalAssetAmount += t.getRejectedClaimsValue();
				}
				totalAssetAmountSum.setRejectedClaimsValue(totalAssetAmount);
			}//end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}

	//================================================================Rejected Claims Volume===========================================================


	public RejectedClaimVolumeExternal getExternalRejectedClaimVolume(String username,List<String> region,List<String> moc,List<String> category){

		Double totalAssetVolume = 0.00;
		RejectedClaimVolumeExternal totalAssetVolumeSum= new RejectedClaimVolumeExternal();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<RejectedClaimVolumeExternal> totalExternalData = new ArrayList<RejectedClaimVolumeExternal>();
			List<RejectedClaimVolumeExternal> mocList = new ArrayList<RejectedClaimVolumeExternal>();
			List<RejectedClaimVolumeExternal> filteredList = new ArrayList<RejectedClaimVolumeExternal>();


			totalExternalData = rejectedClaimVolumesRepository.findAllRejectedClaimVolumeExternalDetails(username);


			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(RejectedClaimVolumeExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				for(RejectedClaimVolumeExternal t : mocList){
					totalAssetVolume += t.getRejectedClaimsVolume();
				}

				totalAssetVolumeSum.setRejectedClaimsVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<RejectedClaimVolumeExternal> categoryList = new ArrayList<RejectedClaimVolumeExternal>();


				//filtered by category

				for(String c : category){
					for(RejectedClaimVolumeExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(RejectedClaimVolumeExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				filteredList.addAll(mocList);

				for(RejectedClaimVolumeExternal t : filteredList){
					totalAssetVolume += t.getRejectedClaimsVolume();
				}

				totalAssetVolumeSum.setRejectedClaimsVolume(totalAssetVolume);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<RejectedClaimVolumeExternal> regionList = new ArrayList<RejectedClaimVolumeExternal>();

				//filter by region
				for(String regon : region){
					for(RejectedClaimVolumeExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(RejectedClaimVolumeExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				filteredList.addAll(mocList);
				for(RejectedClaimVolumeExternal t : filteredList){
					totalAssetVolume += t.getRejectedClaimsVolume();
				}

				totalAssetVolumeSum.setRejectedClaimsVolume(totalAssetVolume);

			}


			else if(region != null && moc !=null && category !=null  ){  //4


				if(totalExternalData !=null)	{
					List<RejectedClaimVolumeExternal> regionList = new ArrayList<RejectedClaimVolumeExternal>();
					List<RejectedClaimVolumeExternal> filteredRegionCategoryList = new ArrayList<RejectedClaimVolumeExternal>();

					//filterd by region

					for(String regon : region){
						for(RejectedClaimVolumeExternal reg : totalExternalData){
							if(regon.equals(reg.getRegionName())){
								regionList.add(reg);
							}

						}

					}

					//filtered by category

					for(String c : category){
						for(RejectedClaimVolumeExternal cat : regionList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					//filtered by MOC
					for(String m : moc){
						for(RejectedClaimVolumeExternal mocc : filteredRegionCategoryList){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}

					}

					filteredList.addAll(mocList);
					for(RejectedClaimVolumeExternal t : filteredList){
						totalAssetVolume += t.getRejectedClaimsVolume();
					}

					totalAssetVolumeSum.setRejectedClaimsVolume(totalAssetVolume);

				}//end of if

			}//end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}//Done


	//================================================================Total Amount Planned===========================================================


	public TotalAmountPlannedExternal getExternalTotalAmountPlanned(String username,List<String> region,List<String> moc,List<String> category){


		Double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		TotalAmountPlannedExternal totalAssetAmountSum = new TotalAmountPlannedExternal();


		try{

			List<TotalAmountPlannedExternal> totalAssetValues = new ArrayList<TotalAmountPlannedExternal>();
			List<TotalAmountPlannedExternal> totalExternalData = new ArrayList<TotalAmountPlannedExternal>();
			List<TotalAmountPlannedExternal> mocList = new ArrayList<TotalAmountPlannedExternal>();

			totalExternalData = totalAmountPlannedRepository.findAllTotalAmountPlannedExternalDetails(username);



			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlannedExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(TotalAmountPlannedExternal t : mocList){
					totalAssetAmount += t.getTotalAmountPlanned();
				}

				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<TotalAmountPlannedExternal> categoryList = new ArrayList<TotalAmountPlannedExternal>();

				//filtered by category

				for(String c : category){
					for(TotalAmountPlannedExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlannedExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(TotalAmountPlannedExternal t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();
				}

				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<TotalAmountPlannedExternal> regionList = new ArrayList<TotalAmountPlannedExternal>();

				//filter by region
				for(String regon : region){
					for(TotalAmountPlannedExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlannedExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPlannedExternal t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();
				}

				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);

			}
			else if(region != null && moc !=null && category !=null  ){  //4
				List<TotalAmountPlannedExternal> regionList = new ArrayList<TotalAmountPlannedExternal>();
				List<TotalAmountPlannedExternal> filteredRegionCategoryList = new ArrayList<TotalAmountPlannedExternal>();

				//filterd by region

				for(String regon : region){
					for(TotalAmountPlannedExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(TotalAmountPlannedExternal cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(TotalAmountPlannedExternal mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(TotalAmountPlannedExternal t : totalAssetValues){
					totalAssetAmount += t.getTotalAmountPlanned();
				}
				totalAssetAmountSum.setTotalAmountPlanned(totalAssetAmount);
			}//end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}



	//================================================================Claims Raised===========================================================


	public Double getExternalClaimsRaised(String account,List<String> region,List<String> moc,List<String> category){

		Double totalAssetAmount = 0.00;
		
		try{

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				totalAssetAmount = externalServiceNoteMasterRepository.findClaimRaisedByMoc(moc,account);

			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				totalAssetAmount = externalServiceNoteMasterRepository.findClaimRaisedByMocCategory(moc, category,account);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				totalAssetAmount = externalServiceNoteMasterRepository.findClaimRaisedByMocRegion(moc, region,account);

			}
			else if(region != null && moc !=null && category !=null  ){  //4

				totalAssetAmount = externalServiceNoteMasterRepository.findClaimRaisedByMocRegionCategory(moc, region, category,account);

			}//end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmount;

	}


	//================================================================Paid Claims Value===========================================================

	public Double getExternalPaidClaimsValue(String account,List<String> region,List<String> moc,List<String> category){


		Double totalAssetAmount = 0.00;
		

		try{

			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				totalAssetAmount = externalPaymetStatusRepository.findClaimRaisedByMoc(moc,account);

			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				totalAssetAmount = externalPaymetStatusRepository.findClaimRaisedByMocCategory(moc, category,account);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				totalAssetAmount = externalPaymetStatusRepository.findClaimRaisedByMocRegion(moc, region,account);

			}
			else if(region != null && moc !=null && category !=null  ){  //4

				totalAssetAmount = externalPaymetStatusRepository.findClaimRaisedByMocRegionCategory(moc, region, category,account);

			}//end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmount;

	}


	//================================================================Unpaid Claims Value===========================================================


	public UnpaidClaimsValueExternal getExternalUnpaidClaimsValue(String username,List<String> region,List<String> moc,List<String> category){


		Double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		UnpaidClaimsValueExternal totalAssetAmountSum = new UnpaidClaimsValueExternal();


		try{

			List<UnpaidClaimsValueExternal> totalAssetValues = new ArrayList<UnpaidClaimsValueExternal>();
			List<UnpaidClaimsValueExternal> totalExternalData = new ArrayList<UnpaidClaimsValueExternal>();
			List<UnpaidClaimsValueExternal> mocList = new ArrayList<UnpaidClaimsValueExternal>();

			totalExternalData = unpaidClaimValueRepository.findAllUnpaidClaimsValueExternalDetails(username);



			if(region.get(0).equals("All") && moc !=null && category.get(0).equals("All") ){    //1

				//filtered by MOC
				for(String m : moc){
					for(UnpaidClaimsValueExternal mocc : totalExternalData){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(UnpaidClaimsValueExternal t : mocList){
					totalAssetAmount += t.getUnpaidClaimsValue();
				}

				totalAssetAmountSum.setUnpaidClaimsValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && moc !=null && category !=null ){   //2

				List<UnpaidClaimsValueExternal> categoryList = new ArrayList<UnpaidClaimsValueExternal>();

				//filtered by category

				for(String c : category){
					for(UnpaidClaimsValueExternal cat : totalExternalData){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(UnpaidClaimsValueExternal mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);

				for(UnpaidClaimsValueExternal t : totalAssetValues){
					totalAssetAmount += t.getUnpaidClaimsValue();
				}

				totalAssetAmountSum.setUnpaidClaimsValue(totalAssetAmount);
			}
			else if(region !=null && moc !=null && category.get(0).equals("All")){    //3

				List<UnpaidClaimsValueExternal> regionList = new ArrayList<UnpaidClaimsValueExternal>();

				//filter by region
				for(String regon : region){
					for(UnpaidClaimsValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(UnpaidClaimsValueExternal mocc : regionList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(UnpaidClaimsValueExternal t : totalAssetValues){
					totalAssetAmount += t.getUnpaidClaimsValue();
				}

				totalAssetAmountSum.setUnpaidClaimsValue(totalAssetAmount);

			}
			else if(region != null && moc !=null && category !=null  ){  //4
				List<UnpaidClaimsValueExternal> regionList = new ArrayList<UnpaidClaimsValueExternal>();
				List<UnpaidClaimsValueExternal> filteredRegionCategoryList = new ArrayList<UnpaidClaimsValueExternal>();

				//filterd by region

				for(String regon : region){
					for(UnpaidClaimsValueExternal reg : totalExternalData){
						if(regon.equals(reg.getRegionName())){
							regionList.add(reg);
						}

					}

				}

				//filtered by category

				for(String c : category){
					for(UnpaidClaimsValueExternal cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(UnpaidClaimsValueExternal mocc : filteredRegionCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(UnpaidClaimsValueExternal t : totalAssetValues){
					totalAssetAmount += t.getUnpaidClaimsValue();
				}
				totalAssetAmountSum.setUnpaidClaimsValue(totalAssetAmount);
			}//end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}



}
