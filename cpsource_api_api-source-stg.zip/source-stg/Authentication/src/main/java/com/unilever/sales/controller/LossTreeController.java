package com.unilever.sales.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.sales.model.LossTreeCActionDto;
import com.unilever.sales.model.LossTreeCFinalReasonDto;
import com.unilever.sales.model.LossTreeDto;
import com.unilever.sales.model.LossTreeHeader2Dto;
import com.unilever.sales.model.PieChartDto;
import com.unilever.sales.service.LossTreeService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class LossTreeController {
	
	@Autowired
	LossTreeService lossTreeService;


	@GetMapping("/getCFinalReasonHeaderOneByB2C")
	public LossTreeDto getCFinalReasonHeaderOneByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber){

		LossTreeDto lossTreeDto = new LossTreeDto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonHeaderOneByB2C(account, moc, branch, category, poNumber);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}


	@GetMapping("/getCFinalReasonHeaderTwoByB2C")
	public LossTreeHeader2Dto getCFinalReasonHeaderTwoByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne){

		LossTreeHeader2Dto lossTreeDto = new LossTreeHeader2Dto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonHeader2ByB2C(account, moc, branch, category, poNumber, headerOne);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}
	
	@GetMapping("/getCFinalReasonByB2C")
	public LossTreeCFinalReasonDto getCFinalReasonByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,@RequestParam("headerTwo") List<String> headerTwo){

		LossTreeCFinalReasonDto lossTreeDto = new LossTreeCFinalReasonDto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonByB2C(account, moc, branch, category, poNumber, headerOne, headerTwo);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}

	@GetMapping("/getActionByB2C")
	public LossTreeCActionDto getActionByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,
			@RequestParam("headerTwo") List<String> headerTwo,@RequestParam("finalReason") List<String> finalReason){

		LossTreeCActionDto lossTreeDto = new LossTreeCActionDto();
	
		try{

			lossTreeDto = lossTreeService.getActionReasonByB2C(account, moc, branch, category, poNumber, headerOne, headerTwo, finalReason);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}
	
	//==========================================================LOSS TREE FOR KAM=======================================================
	
	@GetMapping("/getCFinalReasonHeaderOneByKam")
	public LossTreeDto getCFinalReasonHeaderOneByKam(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber,@RequestParam("username") List<String> username){

		LossTreeDto lossTreeDto = new LossTreeDto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonHeaderOneByKam(account, moc, branch, category, poNumber,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}


	@GetMapping("/getCFinalReasonHeader2ByKam")
	public LossTreeHeader2Dto getCFinalReasonHeader2ByKam(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,@RequestParam("username") List<String> username){

		LossTreeHeader2Dto lossTreeDto = new LossTreeHeader2Dto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonHeader2ByKam(account, moc, branch, category, poNumber, headerOne,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}
	
	@GetMapping("/getCFinalReasonByKam")
	public LossTreeCFinalReasonDto getCFinalReasonByKam(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,@RequestParam("headerTwo") List<String> headerTwo,@RequestParam("username") List<String> username){

		LossTreeCFinalReasonDto lossTreeDto = new LossTreeCFinalReasonDto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonByKam(account, moc, branch, category, poNumber, headerOne, headerTwo,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}
	@GetMapping("/getActionReasonByKam")
	public LossTreeCActionDto getActionReasonByKam(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,
			@RequestParam("headerTwo") List<String> headerTwo,@RequestParam("finalReason") List<String> finalReason,@RequestParam("username") List<String> username){

		LossTreeCActionDto lossTreeDto = new LossTreeCActionDto();
	
		try{

			lossTreeDto = lossTreeService.getActionReasonByKam(account, moc, branch, category, poNumber, headerOne, headerTwo, finalReason,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}
	
	//======================================================================LOSS TREE FOR EXTERNAL==========================================
	
	@GetMapping("/getCFinalReasonHeaderOneByExternal")
	public LossTreeDto getCFinalReasonHeaderOneByExternal(@RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber,@RequestParam("username") List<String> username){

		LossTreeDto lossTreeDto = new LossTreeDto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonHeaderOneByExternal(moc, branch, category, poNumber,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}


	@GetMapping("/getCFinalReasonHeader2ByExternal")
	public LossTreeHeader2Dto getCFinalReasonHeader2ByExternal( @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,@RequestParam("username") List<String> username){

		LossTreeHeader2Dto lossTreeDto = new LossTreeHeader2Dto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonHeader2ByExternal(moc, branch, category, poNumber, headerOne,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}
	
	@GetMapping("/getCFinalReasonByExternal")
	public LossTreeCFinalReasonDto getCFinalReasonByExternal(@RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,@RequestParam("headerTwo") List<String> headerTwo,@RequestParam("username") List<String> username){

		LossTreeCFinalReasonDto lossTreeDto = new LossTreeCFinalReasonDto();
	
		try{

			lossTreeDto = lossTreeService.getCFinalReasonByExternal(moc, branch, category, poNumber, headerOne, headerTwo,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}
	@GetMapping("/getActionReasonByExternal")
	public LossTreeCActionDto getActionReasonByExternal(@RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,
			@RequestParam("poNumber") List<String> poNumber,@RequestParam("headerOne") List<String> headerOne,
			@RequestParam("headerTwo") List<String> headerTwo,@RequestParam("finalReason") List<String> finalReason,@RequestParam("username") List<String> username){

		LossTreeCActionDto lossTreeDto = new LossTreeCActionDto();
	
		try{

			lossTreeDto = lossTreeService.getActionReasonByExternal(moc, branch, category, poNumber, headerOne, headerTwo, finalReason,username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lossTreeDto;

	}

	//=========================================PIE CHART START ======================================================

	@GetMapping("/getPieChartDetailsByB2C")
	public PieChartDto getPieChartDetailsByB2C(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber){

		PieChartDto pieChartDto = new PieChartDto();
	
		try{

			pieChartDto = lossTreeService.getPieChartByB2C(account, moc, branch, category, poNumber);

		}
		catch(Exception e){
			e.printStackTrace(); 
		}
		return pieChartDto;

	}
	
	@GetMapping("/getPieChartDetailsByKam")
	public PieChartDto getPieChartDetailsByKam(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber,
			@RequestParam("username") List<String> username){

		PieChartDto pieChartDto = new PieChartDto();
	
		try{

			pieChartDto = lossTreeService.getPieChartByKam(account, moc, branch, category, poNumber, username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return pieChartDto;

	}
	
	@GetMapping("/getPieChartDetailsByExternal")
	public PieChartDto getPieChartDetailsByExternal(@RequestParam("account") List<String> account, @RequestParam("moc") List<String> moc,
			@RequestParam("branch")List<String> branch,@RequestParam("category")List<String>category,@RequestParam("poNumber") List<String> poNumber,@RequestParam("username") List<String> username){

		PieChartDto pieChartDto = new PieChartDto();
	
		try{

			pieChartDto = lossTreeService.getPieChartByExternal(account, moc, branch, category, poNumber, username);

		}
		catch(Exception e){
			e.printStackTrace();
		}
		return pieChartDto;

	}

	//===========================================PIE CHART END=========================================================
	
}
