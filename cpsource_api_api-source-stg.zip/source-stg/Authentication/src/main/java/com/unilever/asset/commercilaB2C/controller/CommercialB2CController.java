package com.unilever.asset.commercilaB2C.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.asset.commercialB2C.model.CurrentMocCommB2CViewDto;
import com.unilever.asset.commercialB2C.model.NextMocCommB2CViewDto;
import com.unilever.asset.commercialB2C.model.PreviousMocCommB2CViewDto;
import com.unilever.asset.commercialB2C.service.CommercialB2CService;
import com.unilever.asset.kam.model.CompliedAssetValue;
import com.unilever.asset.kam.model.CompliedAssetVolume;
import com.unilever.asset.kam.model.DeployedAssetValue;
import com.unilever.asset.kam.model.DepolyedAssetVolume;
import com.unilever.asset.kam.model.DepotConnectedAssetValue;
import com.unilever.asset.kam.model.DepotConnectedAssetVolume;
import com.unilever.asset.kam.model.NotCompliedAssetValue;
import com.unilever.asset.kam.model.NotCompliedAssetVolume;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.service.KamAssetService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CommercialB2CController {
	
	@Autowired
	CommercialB2CService commercialB2CService;
	
	@GetMapping("/getAllCommercialB2CTotalAssetValue")
	public TotalAssetCreatedValue getAllCommercialB2CTotalAssetValue( @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetValueSum=0;
		TotalAssetCreatedValue totalAssetValue = new TotalAssetCreatedValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	
	@GetMapping("/getAllCommercialB2CTotalAssetVolume")
	public TotalAssetCreatedVolume getAllCommercialB2CTotalAssetVolume( @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		int totalAssetVolume=0;
		TotalAssetCreatedVolume totalAssetCreatedVolumeSum = new TotalAssetCreatedVolume();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetCreatedVolumeSum;		
		
	}


	//====================================== Depot conected Asset Start=================================
	
    
		@GetMapping("/getAllCommercialB2CDepotConnectedAssetValue")
		public DepotConnectedAssetValue getAllCommercialB2CDepotConnectedAssetValue( @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
			int totalAssetValueSum=0;
			DepotConnectedAssetValue totalAssetValue = new DepotConnectedAssetValue();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
				 
			
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetValue;		
			
		}
		
		@GetMapping("/getAllCommercialB2CDepotConnectedAssetVolume")
		public DepotConnectedAssetVolume getAllCommercialB2CDepotConnectedAssetVolume(@RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
			int totalAssetVolume=0;
			DepotConnectedAssetVolume totalAssetCreatedVolumeSum = new DepotConnectedAssetVolume();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
				
			
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetCreatedVolumeSum;		
			
		}
		



		//=================================================================== Deployed Asset Start =====================================================

		@GetMapping("/getAllCommercialB2CDeployedAssetValue")
		public DeployedAssetValue getAllCommercialB2CDeployedAssetValue( @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
			int totalAssetValueSum=0;
			DeployedAssetValue totalAssetValue = new DeployedAssetValue();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
		
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetValue;		
			
		}
		
		@GetMapping("/getAllCommercialB2CDeployedAssetVolume")
		public DepolyedAssetVolume getAllCommercialB2CDeployedAssetVolume(@RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
			int totalAssetVolume=0;
			DepolyedAssetVolume totalAssetCreatedVolumeSum = new DepolyedAssetVolume();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
			
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetCreatedVolumeSum;		
			
		}

		//==========================================Complied Asset Start=============================================


		@GetMapping("/getAllCommercialB2CCompliedAssetValue")
		public CompliedAssetValue getAllCommercialB2CCompliedAssetValue( @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
			int totalAssetValueSum=0;
			CompliedAssetValue totalAssetValue = new CompliedAssetValue();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
				 
			
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetValue;		
			
		}
		
		@GetMapping("/getAllCommercialB2CCompliedAssetVolume")
		public CompliedAssetVolume getAllCommercialB2CCompliedAssetVolume( @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
			int totalAssetVolume=0;
			CompliedAssetVolume totalAssetCreatedVolumeSum = new CompliedAssetVolume();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
				
			
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetCreatedVolumeSum;		
			
		}



		//==========================================Not Complied Asset Start============================================

		@GetMapping("/getAllCommercialB2CNotCompliedAssetValue")
		public NotCompliedAssetValue getAllCommercialB2CNotCompliedAssetValue( @RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
			
			NotCompliedAssetValue totalAssetValue = new NotCompliedAssetValue();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
				 
			
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetValue;		
			
		}
		
		@GetMapping("/getAllCommercialB2CNotCompliedAssetVolume")
		public NotCompliedAssetVolume getAllCommercialB2CNotCompliedAssetVolume(@RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {

			NotCompliedAssetVolume totalAssetCreatedVolumeSum = new NotCompliedAssetVolume();
			try{
				String catgory = null;
				if(category.contains("%2B")){
					catgory = category.replace("%2B","+");
				}else{
					catgory = category;
				}
				
			
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return totalAssetCreatedVolumeSum;		
			
		}
		
		//======================================= Current MOC View==================================================

		@GetMapping("/getB2cCommCurrentMocView")
		public List<CurrentMocCommB2CViewDto> getCurrentMocView(@RequestParam("region") List<String> region,@RequestParam("accounts") List<String> accounts,
													  @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
													  @RequestParam(defaultValue = "10") Integer pageSize){
			
	    List<CurrentMocCommB2CViewDto> currentMocViewDetails = new ArrayList<CurrentMocCommB2CViewDto>();
			
			try{
				 	currentMocViewDetails = commercialB2CService.getCurrentMocView(region,accounts,moc,category,pageNo,pageSize);
				
			    }
			catch(Exception e){
				e.printStackTrace();
			}
			return currentMocViewDetails;

		}

		



		//======================================= Previous MOC View==================================================
		@GetMapping("/getB2cCommPreviousMocView")
		public List<PreviousMocCommB2CViewDto> getPreviousMocView(@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category,@RequestParam(defaultValue = "0") Integer pageNo, 
			    @RequestParam(defaultValue = "10") Integer pageSize){

			List<PreviousMocCommB2CViewDto> previousMocDetails = new ArrayList<>();
			try{
				
					previousMocDetails = commercialB2CService.getPreviousMocView(region,accounts, moc, category,pageNo,pageSize);
			
			   }
			catch(Exception e){
				e.printStackTrace();
			}
			return previousMocDetails;

		}


		
		//======================================= Next MOC View==================================================
				@GetMapping("/getB2cCommNextMocView")
				public List<NextMocCommB2CViewDto> getNextMocView(@RequestParam("region") List<String> region,@RequestParam("accounts")List<String> accounts, @RequestParam("moc") List<String> moc,@RequestParam("category") List<String> category){

					List<NextMocCommB2CViewDto> nextMocDetails = new ArrayList<NextMocCommB2CViewDto>();
					try{
					
							nextMocDetails = commercialB2CService.getNextMocView(region,accounts, moc, category);
					
					}
					catch(Exception e){
						e.printStackTrace();
					}
					return nextMocDetails;

				}








}
