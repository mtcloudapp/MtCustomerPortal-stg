package com.unilever.promo.claim.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OVERRUN_CLAIM")
public class OverrunClaim implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -2042084931507512119L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;

	@Column(name="FILE_NO")
	private Integer fileNo;

	@Column(name="WORKFLOW_STAGE_ID")
	private Integer workflowStageID;

	@Column(name="ACCOUNT")
	private String accountName;

	@Column(name="MOC")
	private String moc;

	@Column(name="SOL_CODE")
	private Integer solCode;
	
	@Column(name="SOL_CODE_NAME")
	private String solCode_name;
	
	@Column(name="SOL_CODE_ALL")
	private String solCode_all;	

	@Column(name="BUDGET")
	private Double budget;

	@Column(name="CUSTOMER_CLAIM_AMOUNT")
	private Double customerClaimAmt;

	@Column(name="B2C_SIGNED_OFF_AMOUNT")
	private Double b2cSignedOffAmt;

	@Column(name="REMAINING_BUDGET")
	private Double remainingBudget;

	@Column(name="OVERRUN_PERCENTAGE")
	private Double overrunPercentage;

	@Column(name="OVERRUN_AMOUNT")
	private Double overrunbAmt;

	@Column(name="APPROVED_OVERRUN_AMOUNT")
	private Double approvedOverrun;
	
	@Column(name="APPROVED_OVERRUN_PERCENTAGE")
	private Double approvedOverrunPercentage;

	@Column(name="OVERRUN_APPROVER")
	private String overrunApprover;

	@Column(name="REMARKS")
	private String remarks;
	
	@Column(name="APPROVAL_STATUS")
	private String approvalStatus;

	@Column(name="AUDIT_CREATE_DATE")
	private String auditCreateDate;

	@Column(name="AUDIT_MODIFIED_DATE")
	private String auditModifiedDate;

	public OverrunClaim() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OverrunClaim(Integer rECORD_ID, Integer fileNo, Integer workflowStageID, String accountName, String moc,
			Integer solCode, String solCode_name, String solCode_all, Double budget, Double customerClaimAmt,
			Double b2cSignedOffAmt, Double remainingBudget, Double overrunPercentage, Double overrunbAmt,
			Double approvedOverrun, Double approvedOverrunPercentage, String overrunApprover, String remarks,
			String approvalStatus, String auditCreateDate, String auditModifiedDate) {
		super();
		RECORD_ID = rECORD_ID;
		this.fileNo = fileNo;
		this.workflowStageID = workflowStageID;
		this.accountName = accountName;
		this.moc = moc;
		this.solCode = solCode;
		this.solCode_name = solCode_name;
		this.solCode_all = solCode_all;
		this.budget = budget;
		this.customerClaimAmt = customerClaimAmt;
		this.b2cSignedOffAmt = b2cSignedOffAmt;
		this.remainingBudget = remainingBudget;
		this.overrunPercentage = overrunPercentage;
		this.overrunbAmt = overrunbAmt;
		this.approvedOverrun = approvedOverrun;
		this.approvedOverrunPercentage = approvedOverrunPercentage;
		this.overrunApprover = overrunApprover;
		this.remarks = remarks;
		this.approvalStatus = approvalStatus;
		this.auditCreateDate = auditCreateDate;
		this.auditModifiedDate = auditModifiedDate;
	}







	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}

	public Integer getWorkflowStageID() {
		return workflowStageID;
	}

	public void setWorkflowStageID(Integer workflowStageID) {
		this.workflowStageID = workflowStageID;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}
	
	public String getSolCode_all() {
		return solCode_all;
	}

	public void setSolCode_all(String solCode_all) {
		this.solCode_all = solCode_all;
	}

	public Double getBudget() {
		return budget;
	}

	public void setBudget(Double budget) {
		this.budget = budget;
	}

	public Double getCustomerClaimAmt() {
		return customerClaimAmt;
	}

	public void setCustomerClaimAmt(Double customerClaimAmt) {
		this.customerClaimAmt = customerClaimAmt;
	}

	public Double getB2cSignedOffAmt() {
		return b2cSignedOffAmt;
	}

	public void setB2cSignedOffAmt(Double b2cSignedOffAmt) {
		this.b2cSignedOffAmt = b2cSignedOffAmt;
	}

	public Double getRemainingBudget() {
		return remainingBudget;
	}

	public void setRemainingBudget(Double remainingBudget) {
		this.remainingBudget = remainingBudget;
	}

	public Double getOverrunPercentage() {
		return overrunPercentage;
	}

	public void setOverrunPercentage(Double overrunPercentage) {
		this.overrunPercentage = overrunPercentage;
	}

	public Double getOverrunbAmt() {
		return overrunbAmt;
	}

	public void setOverrunbAmt(Double overrunbAmt) {
		this.overrunbAmt = overrunbAmt;
	}

	public Double getApprovedOverrun() {
		return approvedOverrun;
	}

	public void setApprovedOverrun(Double approvedOverrun) {
		this.approvedOverrun = approvedOverrun;
	}

	public String getOverrunApprover() {
		return overrunApprover;
	}

	public void setOverrunApprover(String overrunApprover) {
		this.overrunApprover = overrunApprover;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAuditCreateDate() {
		return auditCreateDate;
	}

	public void setAuditCreateDate(String auditCreateDate) {
		this.auditCreateDate = auditCreateDate;
	}

	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}

	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}

	public Double getApprovedOverrunPercentage() {
		return approvedOverrunPercentage;
	}

	public void setApprovedOverrunPercentage(Double approvedOverrunPercentage) {
		this.approvedOverrunPercentage = approvedOverrunPercentage;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getSolCode_name() {
		return solCode_name;
	}

	public void setSolCode_name(String solCode_name) {
		this.solCode_name = solCode_name;
	}

	
	
	

	
	
	
}
