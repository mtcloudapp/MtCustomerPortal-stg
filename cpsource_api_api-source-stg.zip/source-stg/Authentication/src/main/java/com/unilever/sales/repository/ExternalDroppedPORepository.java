package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.ExternalDroppedPO;

@Repository
public interface ExternalDroppedPORepository extends JpaRepository<ExternalDroppedPO, Integer>{
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_DROPPED_PO tac where tac.USERNAME in :username and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.REASON=:reason", nativeQuery = true)
	List<Integer> findExternalNoOfLinesCount(@Param("username") List<String> username,@Param("moc") List<String> moc,@Param("branch") List<String> branch,
			@Param("category") List<String> category,@Param("reason") String reason);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_DROPPED_PO tac where tac.USERNAME in :username and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and  tac.REASON=:reason", nativeQuery = true)
	List<Integer> findExternalNoOfLinesCount(@Param("username") List<String> username,@Param("moc") List<String> moc,@Param("branch") List<String> branch,
			@Param("reason") String reason);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_DROPPED_PO tac where tac.USERNAME in :username and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and  tac.REASON=:reason and tac.PO_NUMBER in :poNumber", nativeQuery = true)
	List<Integer> findExternalNoOfLinesCount(@Param("username") List<String> username,@Param("moc") List<String> moc,@Param("branch") List<String> branch,
			@Param("reason") String reason,@Param("poNumber") List<String> poNumber);
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_DROPPED_PO tac where tac.USERNAME in :username and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch", nativeQuery = true)
	Integer findExternalNoOfLinesCount(@Param("username") List<String> username,@Param("moc") List<String> moc,@Param("branch") List<String> branch);
	

	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_DROPPED_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch  and tac.USERNAME in :username", nativeQuery = true)
	Integer findExternalDroppedPONoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,
			@Param("username") List<String> username);
	
	//=====================================================================================================================
			@Transactional
		    @Query(value ="select DISTINCT tac.REASON from "+GlobalVariables.schemaName+".EXT_DROPPED_PO tac where  tac.MOC in :moc and"
		    		+ " tac.BRANCH in :branch and tac.USERNAME in :username", nativeQuery = true)
			List<String> findExternalReason(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("username") List<String> username);
			
			@Transactional
		    @Query(value ="select DISTINCT tac.REASON from "+GlobalVariables.schemaName+".EXT_DROPPED_PO tac where  tac.MOC in :moc and"
		    		+ " tac.BRANCH in :branch and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
			List<String> findExternalReasonByPoNumber(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);
			
	
}
