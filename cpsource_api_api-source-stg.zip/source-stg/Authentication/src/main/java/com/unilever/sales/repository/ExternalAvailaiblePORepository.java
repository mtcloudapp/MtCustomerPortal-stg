package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.ExternalAvailablePO;
@Repository
public interface ExternalAvailaiblePORepository  extends JpaRepository<ExternalAvailablePO, Integer>{
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalFInalReasonHeaderList(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalFInalReasonHeaderList(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER2 from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalFInalReasonHeader2List(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON_HEADER2 from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalFInalReasonHeader2List(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerOne") List<String> headerOne,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalFinalReasonList(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerTwo") List<String> headerTwo,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_FINAL_REASON from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalFinalReasonList(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("headerTwo") List<String> headerTwo,@Param("username") List<String> username);

	
	@Transactional
    @Query(value ="select DISTINCT tac.C_ACTION from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON in :finalReason and tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalCactionList(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("finalReason") List<String> finalReason,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select DISTINCT tac.C_ACTION from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and "
    		+ "tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON in :finalReason and tac.USERNAME in :username", nativeQuery = true)
	List<String> findExternalCactionList(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("finalReason") List<String> finalReason,@Param("username") List<String> username);
//=====================================================================================================================================================

	
	////////////////////////////////////////////////////////////////////////WIHOUT PONUMBER HEADER1`/////////////////////////////////////////////////////////
	
	@Transactional
	@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
	+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.USERNAME in :username", nativeQuery = true)
	Double findCountExternalOrderValue(@Param("moc") List<String> moc,@Param("branch") List<String> branch,
			@Param("category") List<String> category,@Param("headerOne") String headerOne,@Param("username") List<String> username);



	@Transactional
	@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
	+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.USERNAME in :username", nativeQuery = true)
	Double findCountExternalAllocatedValue(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
	@Param("headerOne") String headerOne,@Param("username") List<String> username);

	@Transactional
	@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
	+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.USERNAME in :username", nativeQuery = true)
	Double findCountExternalInvoicedValue(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
	@Param("headerOne") String headerOne,@Param("username") List<String> username);

	
	
////////////////////////////////////////////////////////////////////////WIH PONUMBER HEADER1`/////////////////////////////////////////////////////////
	
	@Transactional
	@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
	+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and  tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
	Double findCountExternalOrderValue(@Param("moc") List<String> moc,@Param("branch") List<String> branch,
			@Param("category") List<String> category,@Param("headerOne") String headerOne,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);



	@Transactional
	@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
	+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
	Double findCountExternalAllocatedValue(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
	@Param("headerOne") String headerOne,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);

	@Transactional
	@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
	+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER =:headerOne and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
	Double findCountExternalInvoicedValue(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
	@Param("headerOne") String headerOne,@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);

	
/////////////////////////////////////////////WITHOUT PONUMBER Header 2////////////////////////////////////////////////////////	
	
	
@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternaltOrderValueHeader2(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalAllocatedValueHeader2(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalInvoicedValueHeader2(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);



/////////////////////////////////////////////WITH PONUMBER Header 2////////////////////////////////////////////////////////

@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternaltOrderValueHeader2(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category  and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalAllocatedValueHeader2(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 =:headerTwo and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalInvoicedValueHeader2(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") String headerTwo,@Param("username") List<String> username);



/////////////////////////////////////////////WITHOUT PONUMBER FINAL REASON////////////////////////////////////////////////////////	


@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalOrderValueFinalReason(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalAllocatedValueFinalReason(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternaltInvoicedValueFinalReason(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);



/////////////////////////////////////////////WITH PONUMBER FINAL REASON////////////////////////////////////////////////////////	


@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalOrderValueFinalReason(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalAllocatedValueFinalReason(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON=:finalReason and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternaltInvoicedValueFinalReason(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") String finalReason,@Param("username") List<String> username);


//////////////////////////////////////////////////////////WITHOUT PONUMBER C_ACTION//////////////////////////////////////////////////////////

@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalOrderValueC_Action(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalAllocatedValueC_Action(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalInvoicedValueC_Action(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);



//////////////////////////////////////////////////////////WITH PONUMBER C_ACTION//////////////////////////////////////////////////////////

@Transactional
@Query(value ="select sum(tac.ORDER_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where  tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalOrderValueC_Action(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);


@Transactional
@Query(value ="select sum(tac.ALLOCATE_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and  tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalAllocatedValueC_Action(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);

@Transactional
@Query(value ="select sum(tac.INVOICED_VALUE) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where   tac.MOC in :moc and"
+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :finalReason and tac.C_ACTION=:cAction and tac.USERNAME in :username", nativeQuery = true)
Double findCountExternalInvoicedValueC_Action(@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("finalReason") List<String> finalReason,@Param("cAction") String cAction,@Param("username") List<String> username);






	
	
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.USERNAME in :username", nativeQuery = true)
	Integer findExternalNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.USERNAME in :username", nativeQuery = true)
	Integer findExternalNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.USERNAME in :username", nativeQuery = true)
	Integer findExternalNoOfLinesCountByHeaderOne(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("username") List<String> username);
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne and tac.C_FINAL_REASON_HEADER2 in :headerTwo  and tac.USERNAME in :username", nativeQuery = true)
	Integer findExternalCFinalReasonNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("username") List<String> username);
	
	
	@Transactional
    @Query(value ="select count(DISTINCT tac.PO_NUMBER, tac.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_AVAILABLE_PO tac where tac.ACCOUNT in :account and tac.MOC in :moc and"
    		+ " tac.BRANCH in :branch and tac.CATEGORY in :category and tac.PO_NUMBER in :poNumber and tac.C_FINAL_REASON_HEADER in :headerOne "
    		+ "and tac.C_FINAL_REASON_HEADER2 in :headerTwo and tac.C_FINAL_REASON in :cFinalReason and tac.USERNAME in :username", nativeQuery = true)
	Integer findExternalCActionNoOfLinesCount(@Param("account") List<String> account,@Param("moc") List<String> moc,@Param("branch") List<String> branch,@Param("category") List<String> category,
			@Param("poNumber") List<String> poNumber,@Param("headerOne") List<String> headerOne,@Param("headerTwo") List<String> headerTwo,@Param("cFinalReason") List<String> cFinalReason,@Param("username") List<String> username);
	


	
}
