package com.unilever.promo.claim.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.unilever.message.ResponseMessage;
import com.unilever.promo.claim.external.service.PromoClaimExcelHelper;
import com.unilever.promo.claim.external.service.PromoClaimStageService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class PromoClaimStageExternalController {
	
	@Value("${aws.s3.bucket_promo_claims}")
	private String bucketName;
	
	@Value("${aws.s3.bucket_pos_data}")
	private String posBucketName;
	
	@Value("${gcp.storage.bucket_promo_claims}")
	private String gcpBucketName;
	
	@Autowired
	PromoClaimStageService promoClaimStageService;

	
	@PostMapping(value= "/uploadPromoClaimByExternal")
	public ResponseEntity<ResponseMessage> uploadPromoClaimByExternal(@RequestParam("file") MultipartFile file, @RequestParam("moc") String moc, @RequestParam("accountName") String accountName)  throws IOException{
		String message = "";
		 ResponseMessage response = new ResponseMessage();
		
		
		 if (PromoClaimExcelHelper.hasExcelFormat(file)) {
				try {
				     response = promoClaimStageService.save(file,accountName,moc);
				     message = response.getMessage();
//				     if(response.getMessage().equals("Success")){
//						message = "Uploaded the file successfully: " + file.getOriginalFilename();
//
//					}else{
//						message = response.getMessage();
//					}

					return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
				} catch (Exception e) {
					e.printStackTrace();
					message = "Could not upload the file: " + file.getOriginalFilename() + "!";
					return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
				}
			}

			message = "Please upload an excel file!";
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	}
	
	
	
	@PostMapping(value= "/uploadPosFileByExternal")
	public ResponseEntity<ResponseMessage> uploadPosFileByExternal(@RequestParam("file") MultipartFile file, @RequestParam("moc") String moc, @RequestParam("accountName") String accountName)  throws IOException{
		String message = "";
		 ResponseMessage response = new ResponseMessage();
		 
		
		
		 if (PromoClaimExcelHelper.hasExcelFormat(file)) {
				try {
				     response = promoClaimStageService.savePosData(file,accountName,moc);
				     message = response.getMessage();
				     
//				     if(response.getMessage().equals("Success")){
//						message = "Uploaded the file successfully: " + file.getOriginalFilename();
//
//					}else{
//						message = response.getMessage();
//					}

					return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
				} catch (Exception e) {
					e.printStackTrace();
					message = "Could not upload the file: " + file.getOriginalFilename() + "!";
					return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
				}
			}

			message = "Please upload an excel file!";
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	}
	
	@GetMapping(value= "/validateFiles")
	public ResponseEntity<ResponseMessage> validateFiles(@RequestParam("moc") String moc, @RequestParam("accountName") String accountName) {

		String message = "";
		ResponseMessage response = new ResponseMessage();

		try{
			response = promoClaimStageService.validateFilesData(accountName, moc);
			message = response.getMessage();
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));

		}catch(Exception e){
			e.printStackTrace();
		}
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));

	}
	
	@GetMapping(path = "/downloadClaim")
    public ResponseEntity<ByteArrayResource> downloadClaim(@RequestParam(value = "file") String file,@RequestParam("accountName") String accountName,@RequestParam("moc") String moc) throws IOException {
        byte[] data = promoClaimStageService.downloadFile(bucketName,moc+"_"+accountName+"_"+file);
        ByteArrayResource resource = new ByteArrayResource(data);

        return ResponseEntity
                .ok()
                .contentLength(data.length)
                .header("Content-type", "application/octet-stream")
                .header("Content-disposition", "attachment; filename=\"" + accountName+"_"+moc+"_"+file + "\"")
                .body(resource);

    }
	
	
	@GetMapping(path = "/downloadPosFile")
    public ResponseEntity<ByteArrayResource> downloadPosFile(@RequestParam(value = "file") String file,@RequestParam("accountName") String accountName, @RequestParam("moc") String moc) throws IOException {
        byte[] data = promoClaimStageService.downloadFile(posBucketName,moc+"_"+accountName+"_"+file);
        ByteArrayResource resource = new ByteArrayResource(data);

        return ResponseEntity
                .ok()
                .contentLength(data.length)
                .header("Content-type", "application/octet-stream")
                .header("Content-disposition", "attachment; filename=\"" +accountName+"_"+moc+"_"+file + "\"")
                .body(resource);

    }
	
	
	//Added By Sarin Jun2021 - Excel file validation for Claim file
	@GetMapping("/downloadPromoClaimErrorFile")
	//public ResponseEntity<Resource> downloadSalesDataSheetByB2C() {  //Commented By Sarin Jun2022 - Excel file validation for POS file
	public ResponseEntity<Resource> downloadSalesDataSheetByB2C(@RequestParam("accountName") String accountName) { //Added By Sarin Jun2022 - Excel file validation for POS file
		
		String filename = "PromoClaimErrorFile.xlsx";

		//InputStreamResource file = new InputStreamResource(promoClaimStageService.getPromoClaimErrorDetails()); //Commented By Sarin Jun2022 - Excel file validation for POS file
		InputStreamResource file = new InputStreamResource(promoClaimStageService.getPromoClaimErrorDetails(accountName, "CLAIM"));  //Added By Sarin Jun2022 - Excel file validation for POS file

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
				.body(file);

	}
	
	//Added By Sarin Jun2022 - Excel file validation for POS file - Starts
	@GetMapping("/downloadPosDataErrorFile")
	public ResponseEntity<Resource> downloadPosDataErrorSheetByCustomer(@RequestParam("accountName") String accountName) {
			
		String filename = "PosDataErrorFile.xlsx";
		InputStreamResource file = new InputStreamResource(promoClaimStageService.getPromoClaimErrorDetails(accountName, "POS"));  //Added By Sarin Jun2022 - Excel file validation for POS file

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excell"))
				.body(file);

	}
	//Added By Sarin Jun2022 - Excel file validation for POS file - Ends
	
	//Added By Sarin Jul2021 - Claim File B2C Approval - Starts
	@PostMapping(value= "/updatePromoClaimPostB2CApproval")
	public ResponseEntity<ResponseMessage> updatePromoClaimPostB2CApproval(@RequestParam("moc") String moc, @RequestParam("account") String account, @RequestParam("claimType") String claimType) {
		String message = "";
		ResponseMessage response = new ResponseMessage();
		try {
			response = promoClaimStageService.calcPromoClaims(account, moc, claimType);
			message = response.getMessage();
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Could not initiate calculation For " + account + " " + moc;
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
		}
	}

	@GetMapping(path = "/downloadb2ClaimFile")
	public ResponseEntity<ByteArrayResource> downloadb2ClaimFile(@RequestParam(value = "file") String file,@RequestParam("accountName") String accountName,@RequestParam("moc") String moc, @RequestParam("fileType") String fileType) throws IOException {  //Paremeter fileType: ORIG-for OriginalFile; NEW-for Newly uploaded File
		byte[] data = promoClaimStageService.downloadFile(gcpBucketName, promoClaimStageService.getPromoClaimFile(accountName, moc, fileType));
		ByteArrayResource resource = new ByteArrayResource(data);

		return ResponseEntity
				.ok()
				.contentLength(data.length)
				.header("Content-type", "application/octet-stream")
				.header("Content-disposition", "attachment; filename=\"" + accountName+"_"+moc+"_"+file + "\"")
				.body(resource);

	}

	@GetMapping(path = "/downloadb2cPosFile")
	public ResponseEntity<ByteArrayResource> downloadb2cPosFile(@RequestParam(value = "file") String file,@RequestParam("accountName") String accountName, @RequestParam("moc") String moc, @RequestParam("fileType") String fileType) throws IOException {  //Paremeter fileType: ORIG-for OriginalFile; NEW-for Newly uploaded File
		byte[] data = promoClaimStageService.downloadFile(gcpBucketName, promoClaimStageService.getPromoPosFile(accountName, moc, fileType));
		ByteArrayResource resource = new ByteArrayResource(data);

		return ResponseEntity
				.ok()
				.contentLength(data.length)
				.header("Content-type", "application/octet-stream")
				.header("Content-disposition", "attachment; filename=\"" +accountName+"_"+moc+"_"+file + "\"")
				.body(resource);

	}
	
	@GetMapping(path = "/getb2cClaimNotification")
	public String getb2cClaimNotification(@RequestParam("accountName") String accountName, @RequestParam("moc") String moc) {
		return promoClaimStageService.getb2cClaimNotificationCount(accountName, moc);
	}
	
	@GetMapping(path = "/getb2cPosNotification")
	public String getb2cPosNotification(@RequestParam("accountName") String accountName, @RequestParam("moc") String moc) {
		return promoClaimStageService.getb2cPosNotificationCount(accountName, moc);
	}
	//Added By Sarin Jul2021 - Claim File B2C Approval - Ends
}
