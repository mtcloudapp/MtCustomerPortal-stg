package com.unilever.Authentication.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SOL_CODE_DESCRIPTION_TEMP")
public class SupportUser implements Serializable{
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 952609489724505913L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  	@Column(name="SOL_CODE")
    private Integer solCode;
  	
  	@Column(name="ACCOUNT_NAME")
    private String accountName;
  	
  	@Column(name="MOC")
    private String moc;
	
	@Column(name="SOL_CODE_DESCRIPTION_OLD")
    private String solCodeDescriptionOld;
	
	@Column(name="SOL_CODE_DESCRIPTION_NEW")
    private String solCodeDescriptionNew;
	
	@Column(name="AUDIT_MODIFIED_DATE")
    private String auditModifiedDate;

	public SupportUser() {
		super();
		// TODO Auto-generated constructor stub
	}



	public SupportUser(Integer rECORD_ID, Integer solCode, String accountName, String moc, String solCodeDescriptionOld,
			String solCodeDescriptionNew, String auditModifiedDate) {
		super();
		RECORD_ID = rECORD_ID;
		this.solCode = solCode;
		this.accountName = accountName;
		this.moc = moc;
		this.solCodeDescriptionOld = solCodeDescriptionOld;
		this.solCodeDescriptionNew = solCodeDescriptionNew;
		this.auditModifiedDate = auditModifiedDate;
	}


	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public Integer getSolCode() {
		return solCode;
	}

	public void setSolCode(Integer solCode) {
		this.solCode = solCode;
	}

	public String getSolCodeDescriptionOld() {
		return solCodeDescriptionOld;
	}

	public void setSolCodeDescriptionOld(String solCodeDescriptionOld) {
		this.solCodeDescriptionOld = solCodeDescriptionOld;
	}

	public String getSolCodeDescriptionNew() {
		return solCodeDescriptionNew;
	}

	public void setSolCodeDescriptionNew(String solCodeDescriptionNew) {
		this.solCodeDescriptionNew = solCodeDescriptionNew;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getMoc() {
		return moc;
	}


	public void setMoc(String moc) {
		this.moc = moc;
	}



	public String getAuditModifiedDate() {
		return auditModifiedDate;
	}



	public void setAuditModifiedDate(String auditModifiedDate) {
		this.auditModifiedDate = auditModifiedDate;
	}
	

	
}
