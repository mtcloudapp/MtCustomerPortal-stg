package com.unilever.sales.model;

import java.io.Serializable;
import java.util.List;

public class LossTreeDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -857156044498867917L;
	
	
	private List<String> reasonBucket_1;
	private List<Double> orderValue;
	private List<Double> allocatedValue;
	private List<Double> invoicedValue;
	
	private Integer count;
	
	public LossTreeDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public List<String> getReasonBucket_1() {
		return reasonBucket_1;
	}


	public void setReasonBucket_1(List<String> reasonBucket_1) {
		this.reasonBucket_1 = reasonBucket_1;
	}
	
	
	
	public List<Double> getOrderValue() {
		return orderValue;
	}


	public void setOrderValue(List<Double> orderValue) {
		this.orderValue = orderValue;
	}


	public List<Double> getAllocatedValue() {
		return allocatedValue;
	}


	public void setAllocatedValue(List<Double> allocatedValue) {
		this.allocatedValue = allocatedValue;
	}


	public List<Double> getInvoicedValue() {
		return invoicedValue;
	}


	public void setInvoicedValue(List<Double> invoicedValue) {
		this.invoicedValue = invoicedValue;
	}


	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}

	

}
