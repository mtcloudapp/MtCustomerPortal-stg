package com.unilever.promo.claim.external.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.promo.claim.external.model.PromoClaimSummary;

@Repository
public interface PromoClaimSummaryRepository  extends JpaRepository<PromoClaimSummary, Integer>{
	
	@Transactional
	@Query(value ="select max(pcfm.FILE_NO) from "+GlobalVariables.schemaName+".PROMO_CLAIMS_SUMMARY pcfm where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findFileNoOfPromoClaimSummary(@Param("accountName") String accountName, @Param("moc") String moc);


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value ="update "+GlobalVariables.schemaName+".PROMO_CLAIMS_SUMMARY  pcfm set pcfm.WORKFLOW_STAGE_ID=:stageID  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc and pcfm.FILE_NO=:fileNo", nativeQuery = true)
	void updatePromoClaimSummaryByAccountMocFileNo(@Param("stageID") Integer stageID,@Param("accountName") String accountName,@Param("moc") String moc,@Param("fileNo") Integer fileNo);

	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".PROMO_CLAIMS_SUMMARY pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Page<PromoClaimSummary> findPromoClaimsSummaryDetailsByAcntAndMoc(@Param("accountName") String accountName,@Param("moc") String moc,Pageable pageable);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".PROMO_CLAIMS_SUMMARY pcfm  where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	List<PromoClaimSummary> findCountByAccountAndMoc(@Param("accountName") String accountName,@Param("moc") String moc);
	
//	@Transactional
//	@Query(value = "CALL sp_Promo_claims_Topsheet();", nativeQuery = true)
//	void insertIntoPromoClaimSummary();
	
	@Transactional
	@Procedure(procedureName = "sp_Promo_claims_Topsheet")
	void insertIntoPromoClaimSummary(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
	
	@Transactional
	@Query(value ="select count(*) from "+GlobalVariables.schemaName+".PROMO_CLAIMS_SUMMARY pcfm where pcfm.ACCOUNT=:accountName and pcfm.MOC=:moc", nativeQuery = true)
	Integer findPromoClaimSummaryByAccountMOC(@Param("accountName") String accountName, @Param("moc") String moc);
	
	@Transactional
	@Procedure(procedureName = "sp_Promo_claims_Topsheet")
	void insertIntoPromoClaimSummaryByAccountMOC(@Param("p_AccountName") String accountName,@Param("p_MOC") String moc);
}

