package com.unilever.sales.model;

import java.io.Serializable;
import java.util.List;

public class LossTreeHeader2Dto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -3668745429912319310L;
	
	private List<String> reasonBucket_2;
	private List<Double> orderValue;
	private List<Double> allocatedValue;
	private List<Double> invoicedValue;
	private Integer count;
	
	public LossTreeHeader2Dto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public List<String> getReasonBucket_2() {
		return reasonBucket_2;
	}



	public void setReasonBucket_2(List<String> reasonBucket_2) {
		this.reasonBucket_2 = reasonBucket_2;
	}

	

	



	public List<Double> getOrderValue() {
		return orderValue;
	}



	public void setOrderValue(List<Double> orderValue) {
		this.orderValue = orderValue;
	}



	public List<Double> getAllocatedValue() {
		return allocatedValue;
	}



	public void setAllocatedValue(List<Double> allocatedValue) {
		this.allocatedValue = allocatedValue;
	}



	public List<Double> getInvoicedValue() {
		return invoicedValue;
	}



	public void setInvoicedValue(List<Double> invoicedValue) {
		this.invoicedValue = invoicedValue;
	}



	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
	
	

}
