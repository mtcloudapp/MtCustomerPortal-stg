package com.unilever.promo.claim.view.model;

import java.io.Serializable;

public class PromoClaimFileDto implements Serializable {

	private static final long serialVersionUID = -8621873133366806259L;
	
	private Integer parentSolCode;
	
	private Integer basepack;
	
	private Integer articleCode;
	
	private Integer claimQty;
	
	private Double mrp;
	
	private Integer claimPerUnit;
	
	private Double claimValue;
	
	private Integer totalRecords;
	
	public PromoClaimFileDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public PromoClaimFileDto(Integer parentSolCode, Integer basepack, Integer articleCode, Integer claimQty, Double mrp,
			Integer claimPerUnit, Double claimValue, Integer totalRecords) {
		super();
		this.parentSolCode = parentSolCode;
		this.basepack = basepack;
		this.articleCode = articleCode;
		this.claimQty = claimQty;
		this.mrp = mrp;
		this.claimPerUnit = claimPerUnit;
		this.claimValue = claimValue;
		this.totalRecords = totalRecords;
	}



	public Integer getBasepack() {
		return basepack;
	}

	public void setBasepack(Integer basepack) {
		this.basepack = basepack;
	}

	public Integer getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(Integer articleCode) {
		this.articleCode = articleCode;
	}

	public Integer getClaimQty() {
		return claimQty;
	}

	public void setClaimQty(Integer claimQty) {
		this.claimQty = claimQty;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}

	public Integer getClaimPerUnit() {
		return claimPerUnit;
	}

	public void setClaimPerUnit(Integer claimPerUnit) {
		this.claimPerUnit = claimPerUnit;
	}

	public Double getClaimValue() {
		return claimValue;
	}

	public void setClaimValue(Double claimValue) {
		this.claimValue = claimValue;
	}

	public Integer getParentSolCode() {
		return parentSolCode;
	}

	public void setParentSolCode(Integer parentSolCode) {
		this.parentSolCode = parentSolCode;
	}



	public Integer getTotalRecords() {
		return totalRecords;
	}



	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	
	
}
