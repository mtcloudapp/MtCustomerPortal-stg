package com.unilever.asset.commercilaB2C.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.asset.commercialB2C.service.CommercialB2CNextMocService;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetVolume;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalValue;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CommercialB2CNextMocController {
	
	@Autowired
	CommercialB2CNextMocService commercialB2CNextMocService;
	
	
	@GetMapping("/getAllCommercialB2CStoreListTotalCount")
	public StoreListTotalCount getAllCommercialB2CStoreListTotalCount(@RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		StoreListTotalCount totalAssetValue = new StoreListTotalCount();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			 //totalAssetValue = commercialB2CNextMocService.getStoreListTotalCount(region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	
	
	@GetMapping("/getAllCommercialB2CStoreListTotalValue")
	public StoreListTotalValue getAllCommercialB2CStoreListTotalValue(@RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		StoreListTotalValue totalAssetValue = new StoreListTotalValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			// totalAssetValue = commercialB2CNextMocService.getStoreListTotalValue(region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	@GetMapping("/getAllCommercialB2CPlannedAssetValue")
	public PlannedAssetValue getAllCommercialB2CPlannedAssetValue(@RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		PlannedAssetValue totalAssetValue = new PlannedAssetValue();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			// totalAssetValue = commercialB2CNextMocService.getAllPlannedAssetValue(region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}
	
	@GetMapping("/getAllCommercialB2CPlannedAssetVolume")
	public PlannedAssetVolume getAllCommercialB2CPlannedAssetVolume(@RequestParam("region") String region,@RequestParam("account") String account, @RequestParam("moc") String moc,@RequestParam("category") String category) {
		
		PlannedAssetVolume totalAssetValue = new PlannedAssetVolume();
		try{
			String catgory = null;
			if(category.contains("%2B")){
				catgory = category.replace("%2B","+");
			}else{
				catgory = category;
			}
			// totalAssetValue = commercialB2CNextMocService.getAllPlannedAssetVolume(region, account, moc, catgory);
			 
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return totalAssetValue;		
		
	}


}
