package com.unilever.asset.kam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.global.GlobalVariables;

public interface StoreListTotalValueRepository extends JpaRepository<StoreListTotalValue, Integer>{
	
	@Transactional
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValue(@Param("username") String username);
	
	@Transactional // for landing page
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValueByMOC(@Param("username") String username,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValueByMOCAndCategory(@Param("username") String username,@Param("moc") String moc,@Param("category") String category);
	
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValueByAccountAndMOC(@Param("username") String username,@Param("account") String account,@Param("moc") String moc);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username and tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValueByAccountAndMOCAndCategory(@Param("username") String username,@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValueByRegionAndMOC(@Param("username") String username,@Param("region") String region,@Param("moc") String moc);
	

	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValueByRegionAndAccountAndMOC(@Param("username") String username,@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
	
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.USERNAME=:username and tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
	List<StoreListTotalValue> findAllStoreListTotalValueByRegionAndMOCAndCategory(@Param("username") String username,@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);

	 //=====================================================Commercial/B2C=============================================================

		@Transactional
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueDetails();
		
		@Transactional // for landing page
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where  tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueByMOC(@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where  tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueByMOCAndCategory(@Param("moc") String moc,@Param("category") String category);
		
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueByAccountAndMOC(@Param("account") String account,@Param("moc") String moc);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where  tac.ACCOUNT_NAME=:account and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueByAccountAndMOCAndCategory(@Param("account") String account,@Param("moc") String moc,@Param("category") String category);
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where  tac.REGION_NAME=:region and tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueByRegionAndMOC(@Param("region") String region,@Param("moc") String moc);
		

		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where  tac.REGION_NAME=:region and tac.ACCOUNT_NAME=:account and tac.MOC=:moc", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueByRegionAndAccountAndMOC(@Param("region") String region,@Param("account") String account,@Param("moc") String moc);
		
		
		@Transactional 
	    @Query(value ="select * from "+GlobalVariables.schemaName+".INT_STORE_LIST_TOTAL_VALUE tac where tac.REGION_NAME=:region and tac.MOC=:moc and tac.CATEGORY_NAME=:category", nativeQuery = true)
		List<StoreListTotalValue> findAllStoreListTotalValueByRegionAndMOCAndCategory(@Param("region") String region ,@Param("moc") String moc,@Param("category") String category);
		









}
