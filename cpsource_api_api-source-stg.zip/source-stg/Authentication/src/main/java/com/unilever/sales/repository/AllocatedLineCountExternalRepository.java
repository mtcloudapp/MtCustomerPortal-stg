package com.unilever.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.global.GlobalVariables;
import com.unilever.sales.model.ExtPoAllocatedCount;
import com.unilever.sales.model.PoAllocatedCount;

@Repository
public interface AllocatedLineCountExternalRepository extends JpaRepository<ExtPoAllocatedCount, Integer> {

	@Transactional
    @Query(value ="select count(distinct etas.PO_NUMBER,etas.CIC_NUMBER) from "+GlobalVariables.schemaName+".EXT_ALLOCATED_LINES_COUNT etas  where etas.USERNAME=:username and etas.BRANCH in :region and etas.MOC in :moc and etas.CATEGORY in :category", nativeQuery = true)
	Integer findAllocatedCountOfPo(@Param("username") String username,@Param("region") List<String> region,@Param("moc") List<String> moc,@Param("category") List<String> category);

}
