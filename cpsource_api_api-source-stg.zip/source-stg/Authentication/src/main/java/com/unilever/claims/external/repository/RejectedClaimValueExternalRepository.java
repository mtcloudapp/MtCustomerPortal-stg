package com.unilever.claims.external.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unilever.claims.extenal.model.RejectedClaimValueExternal;
import com.unilever.global.GlobalVariables;

@Repository
public interface RejectedClaimValueExternalRepository extends JpaRepository<RejectedClaimValueExternal, Integer>{
	
	@Transactional 
    @Query(value ="select * from "+GlobalVariables.schemaName+".EXT_REJECTED_CLAIMS_VALUE etas where etas.USERNAME=:username", nativeQuery = true)
	List<RejectedClaimValueExternal> findAllRejectedClaimValueExternalDetails(@Param("username") String username);
	

}
