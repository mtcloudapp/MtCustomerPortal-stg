package com.unilever.promo.commb2c.model;

public class CommB2CPromoPrevJsonObj {
	
	private Double noOfPromotion;
	private Double solCodeReleased;
	private Double totalPlannedBudget;
	private Double totalPlannedPromoValue;
	private Double totalPlannedPromoVolume;
	private Double totalUtilizedValue;
	private Double totalUtilizedVolume;
	private Double utilizedBudget;
	
	
	public CommB2CPromoPrevJsonObj() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Double getNoOfPromotion() {
		return noOfPromotion;
	}


	public void setNoOfPromotion(Double noOfPromotion) {
		this.noOfPromotion = noOfPromotion;
	}


	public Double getSolCodeReleased() {
		return solCodeReleased;
	}


	public void setSolCodeReleased(Double solCodeReleased) {
		this.solCodeReleased = solCodeReleased;
	}


	public Double getTotalPlannedBudget() {
		return totalPlannedBudget;
	}


	public void setTotalPlannedBudget(Double totalPlannedBudget) {
		this.totalPlannedBudget = totalPlannedBudget;
	}


	public Double getTotalPlannedPromoValue() {
		return totalPlannedPromoValue;
	}


	public void setTotalPlannedPromoValue(Double totalPlannedPromoValue) {
		this.totalPlannedPromoValue = totalPlannedPromoValue;
	}


	public Double getTotalPlannedPromoVolume() {
		return totalPlannedPromoVolume;
	}


	public void setTotalPlannedPromoVolume(Double totalPlannedPromoVolume) {
		this.totalPlannedPromoVolume = totalPlannedPromoVolume;
	}


	public Double getTotalUtilizedValue() {
		return totalUtilizedValue;
	}


	public void setTotalUtilizedValue(Double totalUtilizedValue) {
		this.totalUtilizedValue = totalUtilizedValue;
	}


	public Double getTotalUtilizedVolume() {
		return totalUtilizedVolume;
	}


	public void setTotalUtilizedVolume(Double totalUtilizedVolume) {
		this.totalUtilizedVolume = totalUtilizedVolume;
	}


	public Double getUtilizedBudget() {
		return utilizedBudget;
	}


	public void setUtilizedBudget(Double utilizedBudget) {
		this.utilizedBudget = utilizedBudget;
	}
	
	

}
