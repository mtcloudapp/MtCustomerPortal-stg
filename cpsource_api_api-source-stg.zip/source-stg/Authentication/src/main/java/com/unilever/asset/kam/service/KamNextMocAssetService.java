package com.unilever.asset.kam.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unilever.asset.kam.model.DepotConnectedAssetValueNext;
import com.unilever.asset.kam.model.DepotConnectedAssetVolumeNext;
import com.unilever.asset.kam.model.PlannedAssetValue;
import com.unilever.asset.kam.model.PlannedAssetVolume;
import com.unilever.asset.kam.model.StoreListTotalCount;
import com.unilever.asset.kam.model.StoreListTotalValue;
import com.unilever.asset.kam.model.TotalAssetCreatedValue;
import com.unilever.asset.kam.model.TotalAssetCreatedVolume;
import com.unilever.asset.kam.repository.DepotConectedAssetValueNextRepository;
import com.unilever.asset.kam.repository.DepotConectedAssetVolumeNextRepository;
import com.unilever.asset.kam.repository.DepotConnetedAssetValueRepository;
import com.unilever.asset.kam.repository.DepotConnetedAssetVolumeRepository;
import com.unilever.asset.kam.repository.PlannedAssetValueRepository;
import com.unilever.asset.kam.repository.PlannedAssetVolumeRepository;
import com.unilever.asset.kam.repository.StoreListTotalCountRepository;
import com.unilever.asset.kam.repository.StoreListTotalValueRepository;
import com.unilever.asset.kam.repository.TotalAssetCreatedValueRepository;

@Service
public class KamNextMocAssetService {

	@Autowired
	StoreListTotalCountRepository storeListTotalCountRepository;

	@Autowired
	StoreListTotalValueRepository storeListTotalValueRepository;

	@Autowired
	PlannedAssetValueRepository plannedAssetValueRepository;

	@Autowired
	PlannedAssetVolumeRepository plannedAssetVolumeRepository;
	
	@Autowired
	DepotConnetedAssetValueRepository depotConnetedAssetValueRepository;

	@Autowired
	DepotConnetedAssetVolumeRepository depotConnetedAssetVolumeRepository;
	
	@Autowired
	DepotConectedAssetValueNextRepository depotConectedAssetValueNextRepository;

	@Autowired
	DepotConectedAssetVolumeNextRepository depotConectedAssetVolumeNextRepository;



	///======================================Start Store List Count=========================================

	public StoreListTotalCount getStoreListTotalCount(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		StoreListTotalCount totalAssetAmountSum = new StoreListTotalCount();


		try{

			List<StoreListTotalCount> totalAssetValues = new ArrayList<StoreListTotalCount>();
			List<StoreListTotalCount> totalStoreListCountByUsername = new ArrayList<StoreListTotalCount>();
			List<StoreListTotalCount> mocList = new ArrayList<StoreListTotalCount>();
			
			List<StoreListTotalCount> regionList = new ArrayList<StoreListTotalCount>();
			List<StoreListTotalCount> regionListOne = new ArrayList<StoreListTotalCount>();
			List<StoreListTotalCount> regionListTwo = new ArrayList<StoreListTotalCount>();
			List<StoreListTotalCount> regionListThree = new ArrayList<StoreListTotalCount>();
			List<StoreListTotalCount> regionListFour = new ArrayList<StoreListTotalCount>();
			List<StoreListTotalCount> regionListFive = new ArrayList<StoreListTotalCount>();
			


			totalStoreListCountByUsername = storeListTotalCountRepository.findAllStoreListTotalCount(username);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				for(StoreListTotalCount t : mocList){
					totalAssetAmount += t.getStoreListTotalCount();

				}

				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);

			}


			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<StoreListTotalCount> categoryList = new ArrayList<StoreListTotalCount>();

				//filtered by category

				for(String c : category){
					for(StoreListTotalCount cat : totalStoreListCountByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalCount mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetValues.addAll(mocList);
				for(StoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();

				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<StoreListTotalCount> accountList = new ArrayList<StoreListTotalCount>();

				for(String accnt : account){
					for(StoreListTotalCount acc : totalStoreListCountByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalCount mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(StoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();

				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<StoreListTotalCount> accountList = new ArrayList<StoreListTotalCount>();
				List<StoreListTotalCount> filteredAccountCategoryList = new ArrayList<StoreListTotalCount>();


				//filterd by account
				for(String accnt : account){
					for(StoreListTotalCount acc : totalStoreListCountByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(StoreListTotalCount cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalCount mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(StoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();
				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}
			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
		     // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListTotalCount reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if

	
				totalAssetValues.addAll(regionList);
				for(StoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();
				}

				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<StoreListTotalCount> filteredRegionAccountList = new ArrayList<StoreListTotalCount>();
				
				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListTotalCount reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					
					regionList.addAll(regionListOne);
                      
				
				}
				
				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							
							
							
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if

				

				//filtered by account

				for(String accnt : account){
					for(StoreListTotalCount acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				

				totalAssetValues.addAll(filteredRegionAccountList);

				for(StoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();

				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<StoreListTotalCount> filteredRegionCategoryList = new ArrayList<StoreListTotalCount>();
				
				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalCount mocc : totalStoreListCountByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListTotalCount reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					
					regionList.addAll(regionListOne);
                      
				
				}
				
				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							
							
							
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListTotalCount reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if


				//filtered by category

				for(String c : category){
					for(StoreListTotalCount cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				
				totalAssetValues.addAll(filteredRegionCategoryList);
				for(StoreListTotalCount t : totalAssetValues){
					totalAssetAmount += t.getStoreListTotalCount();
				}
				totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
				
				List<StoreListTotalCount> accountList = new ArrayList<StoreListTotalCount>();
				List<StoreListTotalCount> filteredRegionCategoryList = new ArrayList<StoreListTotalCount>();


				if(totalStoreListCountByUsername !=null)	{
					
					//filtered by MOC
					for(String m : moc){
						for(StoreListTotalCount mocc : totalStoreListCountByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(StoreListTotalCount reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						
						regionList.addAll(regionListOne);
	                      
					
					}
					
					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(StoreListTotalCount reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								
								
								
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(StoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(StoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(StoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(StoreListTotalCount reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if

					
					//-----filter by account------//

					for(String accnt : account){
						for(StoreListTotalCount acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(StoreListTotalCount cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					

					totalAssetValues.addAll(filteredRegionCategoryList);

					for(StoreListTotalCount t : totalAssetValues){
						totalAssetAmount += t.getStoreListTotalCount();
					}

					totalAssetAmountSum.setStoreListTotalCount(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}


		return totalAssetAmountSum;

	}


	//===========================================Start Store List Valuee==============================================	



	public StoreListTotalValue getStoreListTotalValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		double totalAssetVolume = 0.00;
		StoreListTotalValue totalAssetVolumeSum= new StoreListTotalValue();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<StoreListTotalValue> totalAssetVolumes = new ArrayList<StoreListTotalValue>();
			List<StoreListTotalValue> totalStoreListValueByUsername = new ArrayList<StoreListTotalValue>();
			List<StoreListTotalValue> mocList = new ArrayList<StoreListTotalValue>();
            
			List<StoreListTotalValue> regionList = new ArrayList<StoreListTotalValue>();
			List<StoreListTotalValue> regionListOne = new ArrayList<StoreListTotalValue>();
			List<StoreListTotalValue> regionListTwo = new ArrayList<StoreListTotalValue>();
			List<StoreListTotalValue> regionListThree = new ArrayList<StoreListTotalValue>();
			List<StoreListTotalValue> regionListFour = new ArrayList<StoreListTotalValue>();
			List<StoreListTotalValue> regionListFive = new ArrayList<StoreListTotalValue>();
			
			totalStoreListValueByUsername = storeListTotalValueRepository.findAllStoreListTotalValue(username);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(StoreListTotalValue t : mocList){
					totalAssetVolume += t.getStoreListTotalValue();

				}

				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<StoreListTotalValue> categoryList = new ArrayList<StoreListTotalValue>();


				//filtered by category

				for(String c : category){
					for(StoreListTotalValue cat : totalStoreListValueByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(StoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();

				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<StoreListTotalValue> accountList = new ArrayList<StoreListTotalValue>();

				for(String accnt : account){
					for(StoreListTotalValue acc : totalStoreListValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(StoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();

				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<StoreListTotalValue> accountList = new ArrayList<StoreListTotalValue>();
				List<StoreListTotalValue> filteredAccountCategoryList = new ArrayList<StoreListTotalValue>();


				//filterd by account
				for(String accnt : account){
					for(StoreListTotalValue acc : totalStoreListValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(StoreListTotalValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}



				totalAssetVolumes.addAll(mocList);

				for(StoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();
				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}



			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				
				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}

				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListTotalValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if

				
				totalAssetVolumes.addAll(regionList);
				for(StoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();
				}

				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<StoreListTotalValue> filteredRegionAccountList = new ArrayList<StoreListTotalValue>();
				

				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListTotalValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				

				//filtered by account

				for(String accnt : account){
					for(StoreListTotalValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				

				totalAssetVolumes.addAll(filteredRegionAccountList);

				for(StoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();

				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7
				
				List<StoreListTotalValue> filteredRegionCategoryList = new ArrayList<StoreListTotalValue>();
				
				//filtered by MOC
				for(String m : moc){
					for(StoreListTotalValue mocc : totalStoreListValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(StoreListTotalValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(StoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(StoreListTotalValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				

				

				//filtered by category

				for(String c : category){
					for(StoreListTotalValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				
				totalAssetVolumes.addAll(filteredRegionCategoryList);
				for(StoreListTotalValue t : totalAssetVolumes){
					totalAssetVolume += t.getStoreListTotalValue();
				}
				totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);
			}	

			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8
				List<StoreListTotalValue> accountList = new ArrayList<StoreListTotalValue>();
				List<StoreListTotalValue> filteredRegionCategoryList = new ArrayList<StoreListTotalValue>();

				if(totalStoreListValueByUsername !=null)	{
				
					//filtered by MOC
					for(String m : moc){
						for(StoreListTotalValue mocc : totalStoreListValueByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(StoreListTotalValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(StoreListTotalValue reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(StoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(StoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(StoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(StoreListTotalValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					

					//-----filter by account------//

					for(String accnt : account){
						for(StoreListTotalValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(StoreListTotalValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					

					totalAssetVolumes.addAll(filteredRegionCategoryList);

					for(StoreListTotalValue t : totalAssetVolumes){
						totalAssetVolume += t.getStoreListTotalValue();
					}

					totalAssetVolumeSum.setStoreListTotalValue(totalAssetVolume);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//=================================================Planned Asset Value===============================================
	public PlannedAssetValue getAllPlannedAssetValue(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		double totalAssetValue = 0.00;
		PlannedAssetValue totalAssetValueSum= new PlannedAssetValue();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<PlannedAssetValue> totalAssetVolumes = new ArrayList<PlannedAssetValue>();
			List<PlannedAssetValue> totalPlannedAssetValueByUsername = new ArrayList<PlannedAssetValue>();
			List<PlannedAssetValue> mocList = new ArrayList<PlannedAssetValue>();
			
			List<PlannedAssetValue> regionList = new ArrayList<PlannedAssetValue>();
			List<PlannedAssetValue> regionListOne = new ArrayList<PlannedAssetValue>();
			List<PlannedAssetValue> regionListTwo = new ArrayList<PlannedAssetValue>();
			List<PlannedAssetValue> regionListThree = new ArrayList<PlannedAssetValue>();
			List<PlannedAssetValue> regionListFour = new ArrayList<PlannedAssetValue>();
			List<PlannedAssetValue> regionListFive = new ArrayList<PlannedAssetValue>();
			

			totalPlannedAssetValueByUsername = plannedAssetValueRepository.findAllPlannedAssetValue(username);

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetValue mocc : totalPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(PlannedAssetValue t : mocList){
					totalAssetValue += t.getPlannedAssetValue();

				}

				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);

			}
			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<PlannedAssetValue> categoryList = new ArrayList<PlannedAssetValue>();

				//filtered by category

				for(String c : category){
					for(PlannedAssetValue cat : totalPlannedAssetValueByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC

				for(String m : moc){
					for(PlannedAssetValue mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(PlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();

				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<PlannedAssetValue> accountList = new ArrayList<PlannedAssetValue>();

				for(String accnt : account){
					for(PlannedAssetValue acc : totalPlannedAssetValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC

				for(String m : moc){
					for(PlannedAssetValue mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);

				for(PlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();

				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}



			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<PlannedAssetValue> accountList = new ArrayList<PlannedAssetValue>();
				List<PlannedAssetValue> filteredAccountCategoryList = new ArrayList<PlannedAssetValue>();



				//filterd by account
				for(String accnt : account){
					for(PlannedAssetValue acc : totalPlannedAssetValueByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(PlannedAssetValue cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC

				for(String m : moc){
					for(PlannedAssetValue mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}



				totalAssetVolumes.addAll(mocList);

				for(PlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();
				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}
			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				
				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetValue mocc : totalPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(PlannedAssetValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(PlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				
				
				
				
			

				totalAssetVolumes.addAll(regionList);
				for(PlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();
				}

				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<PlannedAssetValue> filteredRegionAccountList = new ArrayList<PlannedAssetValue>();
				
				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetValue mocc : totalPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(PlannedAssetValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(PlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				

				
				//filtered by account

				for(String accnt : account){
					for(PlannedAssetValue acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				totalAssetVolumes.addAll(filteredRegionAccountList);

				for(PlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();

				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}



			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<PlannedAssetValue> filteredRegionCategoryList = new ArrayList<PlannedAssetValue>();
				
				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetValue mocc : totalPlannedAssetValueByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(PlannedAssetValue reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(PlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(PlannedAssetValue reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				


				
				//filtered by category

				for(String c : category){
					for(PlannedAssetValue cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				totalAssetVolumes.addAll(filteredRegionCategoryList);
				for(PlannedAssetValue t : totalAssetVolumes){
					totalAssetValue += t.getPlannedAssetValue();
				}
				totalAssetValueSum.setPlannedAssetValue(totalAssetValue);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<PlannedAssetValue> accountList = new ArrayList<PlannedAssetValue>();
				List<PlannedAssetValue> filteredRegionCategoryList = new ArrayList<PlannedAssetValue>();

				if(totalPlannedAssetValueByUsername !=null)	{
					
					
					//filtered by MOC
					for(String m : moc){
						for(PlannedAssetValue mocc : totalPlannedAssetValueByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(PlannedAssetValue reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(PlannedAssetValue reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(PlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(PlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(PlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(PlannedAssetValue reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					

					
					
					
					
					//-----filter by account------//

					for(String accnt : account){
						for(PlannedAssetValue acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(PlannedAssetValue cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					
					totalAssetVolumes.addAll(filteredRegionCategoryList);

					for(PlannedAssetValue t : totalAssetVolumes){
						totalAssetValue += t.getPlannedAssetValue();
					}

					totalAssetValueSum.setPlannedAssetValue(totalAssetValue);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetValueSum;

	}


	//================================================Planned Asset Volume================================================

	public PlannedAssetVolume getAllPlannedAssetVolume(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Integer totalAssetVolume = 0;
		PlannedAssetVolume totalAssetVolumeSum= new PlannedAssetVolume();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<PlannedAssetVolume> totalAssetVolumes = new ArrayList<PlannedAssetVolume>();
			List<PlannedAssetVolume> totalPlannedAssetVolumeByUsername = new ArrayList<PlannedAssetVolume>();
			List<PlannedAssetVolume> mocList = new ArrayList<PlannedAssetVolume>();
			
			List<PlannedAssetVolume> regionList = new ArrayList<PlannedAssetVolume>();
			List<PlannedAssetVolume> regionListOne = new ArrayList<PlannedAssetVolume>();
			List<PlannedAssetVolume> regionListTwo = new ArrayList<PlannedAssetVolume>();
			List<PlannedAssetVolume> regionListThree = new ArrayList<PlannedAssetVolume>();
			List<PlannedAssetVolume> regionListFour = new ArrayList<PlannedAssetVolume>();
			List<PlannedAssetVolume> regionListFive = new ArrayList<PlannedAssetVolume>();
			

			totalPlannedAssetVolumeByUsername = plannedAssetVolumeRepository.findAllPlannedAssetVolume(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetVolume mocc : totalPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(PlannedAssetVolume t : mocList){
					totalAssetVolume += t.getPlannedAssetVolume();

				}

				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<PlannedAssetVolume> categoryList = new ArrayList<PlannedAssetVolume>();


				//filtered by category

				for(String c : category){
					for(PlannedAssetVolume cat : totalPlannedAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetVolume mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				totalAssetVolumes.addAll(mocList);
				for(PlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();

				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}
			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<PlannedAssetVolume> accountList = new ArrayList<PlannedAssetVolume>();

				for(String accnt : account){
					for(PlannedAssetVolume acc : totalPlannedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetVolume mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(PlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();

				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}

			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<PlannedAssetVolume> accountList = new ArrayList<PlannedAssetVolume>();
				List<PlannedAssetVolume> filteredAccountCategoryList = new ArrayList<PlannedAssetVolume>();

				//filterd by account
				for(String accnt : account){
					for(PlannedAssetVolume acc : totalPlannedAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(PlannedAssetVolume cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}

				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetVolume mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(PlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();
				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				
				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetVolume mocc : totalPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(PlannedAssetVolume reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(PlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				

				totalAssetVolumes.addAll(regionList);
				for(PlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();
				}

				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<PlannedAssetVolume> filteredRegionAccountList = new ArrayList<PlannedAssetVolume>();
				
				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetVolume mocc : totalPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(PlannedAssetVolume reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(PlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				

				

				//filtered by account

				for(String accnt : account){
					for(PlannedAssetVolume acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}

				
				totalAssetVolumes.addAll(filteredRegionAccountList);

				for(PlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();

				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<PlannedAssetVolume> filteredRegionCategoryList = new ArrayList<PlannedAssetVolume>();

				
				//filtered by MOC
				for(String m : moc){
					for(PlannedAssetVolume mocc : totalPlannedAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(PlannedAssetVolume reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(PlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(PlannedAssetVolume reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				

				
				
				
				
				
				
				
				//filtered by category

				for(String c : category){
					for(PlannedAssetVolume cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}

				

				totalAssetVolumes.addAll(filteredRegionCategoryList);
				for(PlannedAssetVolume t : totalAssetVolumes){
					totalAssetVolume += t.getPlannedAssetVolume();
				}
				totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<PlannedAssetVolume> accountList = new ArrayList<PlannedAssetVolume>();
				List<PlannedAssetVolume> filteredRegionCategoryList = new ArrayList<PlannedAssetVolume>();

				if(totalPlannedAssetVolumeByUsername !=null)	{
					//filtered by MOC
					for(String m : moc){
						for(PlannedAssetVolume mocc : totalPlannedAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(PlannedAssetVolume reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(PlannedAssetVolume reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(PlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(PlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(PlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(PlannedAssetVolume reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					


					//-----filter by account------//

					for(String accnt : account){
						for(PlannedAssetVolume acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(PlannedAssetVolume cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}

					

					totalAssetVolumes.addAll(filteredRegionCategoryList);

					for(PlannedAssetVolume t : totalAssetVolumes){
						totalAssetVolume += t.getPlannedAssetVolume();
					}

					totalAssetVolumeSum.setPlannedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if


		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}


	//=======================Start Depot connected Asset Value===========================================//


	public DepotConnectedAssetValueNext getNextMocAllDepotConnectedAssetValueNext(String username,List<String> region,List<String> account,List<String> moc,List<String> category){


		double totalAssetAmount = 0.00;
		//Integer totalAssetAmountSum = 0;
		DepotConnectedAssetValueNext totalAssetAmountSum = new DepotConnectedAssetValueNext();


		try{

			List<DepotConnectedAssetValueNext> totalAssetValues = new ArrayList<DepotConnectedAssetValueNext>();
			List<DepotConnectedAssetValueNext> totalDepotAssetValuesByUsername = new ArrayList<DepotConnectedAssetValueNext>();
			List<DepotConnectedAssetValueNext> mocList = new ArrayList<DepotConnectedAssetValueNext>();
			
			List<DepotConnectedAssetValueNext> regionList = new ArrayList<DepotConnectedAssetValueNext>();
			List<DepotConnectedAssetValueNext> regionListOne = new ArrayList<DepotConnectedAssetValueNext>();
			List<DepotConnectedAssetValueNext> regionListTwo = new ArrayList<DepotConnectedAssetValueNext>();
			List<DepotConnectedAssetValueNext> regionListThree = new ArrayList<DepotConnectedAssetValueNext>();
			List<DepotConnectedAssetValueNext> regionListFour = new ArrayList<DepotConnectedAssetValueNext>();
			List<DepotConnectedAssetValueNext> regionListFive = new ArrayList<DepotConnectedAssetValueNext>();
			
			
			totalDepotAssetValuesByUsername = depotConectedAssetValueNextRepository.findAllDepotConnectdAssetValue(username);
	           

			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				for(DepotConnectedAssetValueNext t : mocList){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}

				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<DepotConnectedAssetValueNext> categoryList = new ArrayList<DepotConnectedAssetValueNext>();
				
				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetValueNext cat : totalDepotAssetValuesByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValueNext mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);
				for(DepotConnectedAssetValueNext t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<DepotConnectedAssetValueNext> accountList = new ArrayList<DepotConnectedAssetValueNext>();
				
				for(String accnt : account){
					for(DepotConnectedAssetValueNext acc : totalDepotAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValueNext mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(DepotConnectedAssetValueNext t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<DepotConnectedAssetValueNext> accountList = new ArrayList<DepotConnectedAssetValueNext>();
				List<DepotConnectedAssetValueNext> filteredAccountCategoryList = new ArrayList<DepotConnectedAssetValueNext>();

				

				//filterd by account
				for(String accnt : account){
					for(DepotConnectedAssetValueNext acc : totalDepotAssetValuesByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(DepotConnectedAssetValueNext cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValueNext mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetValues.addAll(mocList);

				for(DepotConnectedAssetValueNext t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}


			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(DepotConnectedAssetValueNext reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(DepotConnectedAssetValueNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				
	
				
				totalAssetValues.addAll(regionList);
				for(DepotConnectedAssetValueNext t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}

				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<DepotConnectedAssetValueNext> filteredRegionAccountList = new ArrayList<DepotConnectedAssetValueNext>();
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(DepotConnectedAssetValueNext reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(DepotConnectedAssetValueNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				
				//filtered by account

				for(String accnt : account){
					for(DepotConnectedAssetValueNext acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				

				totalAssetValues.addAll(filteredRegionAccountList);

				for(DepotConnectedAssetValueNext t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();

				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}
			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<DepotConnectedAssetValueNext> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetValueNext>();
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(DepotConnectedAssetValueNext reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(DepotConnectedAssetValueNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(DepotConnectedAssetValueNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				
				
				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetValueNext cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
			


				totalAssetValues.addAll(filteredRegionCategoryList);
				for(DepotConnectedAssetValueNext t : totalAssetValues){
					totalAssetAmount += t.getDepotConnectedAssetValue();
				}
				totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);
			}	
			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<DepotConnectedAssetValueNext> accountList = new ArrayList<DepotConnectedAssetValueNext>();
				List<DepotConnectedAssetValueNext> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetValueNext>();
				
				if(totalDepotAssetValuesByUsername !=null)	{
					
					//filtered by MOC
					for(String m : moc){
						for(DepotConnectedAssetValueNext mocc : totalDepotAssetValuesByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(DepotConnectedAssetValueNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(DepotConnectedAssetValueNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(DepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(DepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(DepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(DepotConnectedAssetValueNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					

					//-----filter by account------//

					for(String accnt : account){
						for(DepotConnectedAssetValueNext acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(DepotConnectedAssetValueNext cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					

					totalAssetValues.addAll(filteredRegionCategoryList);

					for(DepotConnectedAssetValueNext t : totalAssetValues){
						totalAssetAmount += t.getDepotConnectedAssetValue();
					}

					totalAssetAmountSum.setDepotConnectedAssetValue(totalAssetAmount);

				}//end of if

			}// end of else if

		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetAmountSum;

	}


	//=======================Start Depot connected Asset Volume===========================================//

	public DepotConnectedAssetVolumeNext getNextMocAllDepotConnectedAssetVolumeNext(String username,List<String> region,List<String> account,List<String> moc,List<String> category){

		Integer totalAssetVolume = 0;
		DepotConnectedAssetVolumeNext totalAssetVolumeSum= new DepotConnectedAssetVolumeNext();
		//Integer totalAssetVolumeSum = 0;

		try{
			List<DepotConnectedAssetVolumeNext> totalAssetVolumes = new ArrayList<DepotConnectedAssetVolumeNext>();
			List<DepotConnectedAssetVolumeNext> totalDepotAssetVolumeByUsername = new ArrayList<DepotConnectedAssetVolumeNext>();
			List<DepotConnectedAssetVolumeNext> mocList = new ArrayList<DepotConnectedAssetVolumeNext>();
			
			List<DepotConnectedAssetVolumeNext> regionList = new ArrayList<DepotConnectedAssetVolumeNext>();
			List<DepotConnectedAssetVolumeNext> regionListOne = new ArrayList<DepotConnectedAssetVolumeNext>();
			List<DepotConnectedAssetVolumeNext> regionListTwo = new ArrayList<DepotConnectedAssetVolumeNext>();
			List<DepotConnectedAssetVolumeNext> regionListThree = new ArrayList<DepotConnectedAssetVolumeNext>();
			List<DepotConnectedAssetVolumeNext> regionListFour = new ArrayList<DepotConnectedAssetVolumeNext>();
			List<DepotConnectedAssetVolumeNext> regionListFive = new ArrayList<DepotConnectedAssetVolumeNext>();
			
			
			totalDepotAssetVolumeByUsername = depotConectedAssetVolumeNextRepository.findAllDepotConnectdAssetVolume(username);


			if(region.get(0).equals("All") && account.get(0).equals("All") && category.get(0).equals("All") && moc !=null){//1

				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}

				
				for(DepotConnectedAssetVolumeNext t : mocList){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}

				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);

			}

			else if(region.get(0).equals("All") && account.get(0).equals("All") && category !=null && moc !=null){//2

				List<DepotConnectedAssetVolumeNext> categoryList = new ArrayList<DepotConnectedAssetVolumeNext>();

				
				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetVolumeNext cat : totalDepotAssetVolumeByUsername){
						if(c.equals(cat.getCategoryNaame())){
							categoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolumeNext mocc : categoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				
				for(DepotConnectedAssetVolumeNext t : mocList){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}

				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);

			
			
			
			}

			else if(region.get(0).equals("All") && account !=null && category.get(0).equals("All")  && moc !=null){//3

				List<DepotConnectedAssetVolumeNext> accountList = new ArrayList<DepotConnectedAssetVolumeNext>();
				
				for(String accnt : account){
					for(DepotConnectedAssetVolumeNext acc : totalDepotAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolumeNext mocc : accountList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}
				


				totalAssetVolumes.addAll(mocList);

				for(DepotConnectedAssetVolumeNext t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}


			else if(region.get(0).equals("All") && account !=null && category !=null  && moc !=null){//4
				List<DepotConnectedAssetVolumeNext> accountList = new ArrayList<DepotConnectedAssetVolumeNext>();
				List<DepotConnectedAssetVolumeNext> filteredAccountCategoryList = new ArrayList<DepotConnectedAssetVolumeNext>();


				//filterd by account
				for(String accnt : account){
					for(DepotConnectedAssetVolumeNext acc : totalDepotAssetVolumeByUsername){
						if(accnt.equals(acc.getAccountName())){
							accountList.add(acc);
						}

					}

				}

				//filtered by category
				for(String c : category){
					for(DepotConnectedAssetVolumeNext cat : accountList){
						if(c.equals(cat.getCategoryNaame())){
							filteredAccountCategoryList.add(cat);
						}

					}

				}
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolumeNext mocc : filteredAccountCategoryList){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}

				}


				totalAssetVolumes.addAll(mocList);

				for(DepotConnectedAssetVolumeNext t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();
				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account.get(0).equals("All") && category.get(0).equals("All")  && moc !=null){//5

				
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(DepotConnectedAssetVolumeNext reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(DepotConnectedAssetVolumeNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				
				
				totalAssetVolumes.addAll(regionList);
				for(DepotConnectedAssetVolumeNext t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();
				}

				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}

			else if(region !=null && account !=null && category.get(0).equals("All")  && moc !=null){//6

				List<DepotConnectedAssetVolumeNext> filteredRegionAccountList = new ArrayList<DepotConnectedAssetVolumeNext>();
				
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(DepotConnectedAssetVolumeNext reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(DepotConnectedAssetVolumeNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				
				//filtered by account

				for(String accnt : account){
					for(DepotConnectedAssetVolumeNext acc : regionList){
						if(accnt.equals(acc.getAccountName())){
							filteredRegionAccountList.add(acc);
						}

					}

				}
				
				

				totalAssetVolumes.addAll(filteredRegionAccountList);

				for(DepotConnectedAssetVolumeNext t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();

				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}


			else if(region !=null && account.get(0).equals("All")  && category !=null  && moc !=null){//7

				List<DepotConnectedAssetVolumeNext> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetVolumeNext>();
			
				//filtered by MOC
				for(String m : moc){
					for(DepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
						if(m.equals(mocc.getMoc())){
							mocList.add(mocc);
						}

					}
					
				}
				 // filterd by region		

				if(region.size() == 1){
					//filter by region
					for(String regon : region){
						for(DepotConnectedAssetVolumeNext reg : mocList){
							Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
							Matcher matcher = pattern.matcher(reg.getRegionName());

							if(matcher.find()){
								regionListOne.add(reg); 
							}

						}

					}
					regionList.addAll(regionListOne);
                      
				}

				if(region.size()>1){
					int count =1;
					for(String regon : region){
						if(count==1){
							for(DepotConnectedAssetVolumeNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find() && count<mocList.size()){
									regionListOne.add(reg); 

								}
							}
							regionList.addAll(regionListOne);
						
							
						}

						if(count==2){
							regionList.clear();
							mocList.removeAll(regionListOne);

							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListTwo.add(reg1); 

								}	

							}
							
							regionListOne.addAll(regionListTwo);
							regionList.addAll(regionListOne);
							
						}

						if(count==3){
							regionList.clear();
							mocList.removeAll(regionListTwo);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListThree.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListThree);
							regionList.addAll(regionListOne);
							
						}

                       
						if(count==4){
							regionList.clear();
							mocList.removeAll(regionListThree);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFour.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFour);
							regionList.addAll(regionListOne);
							
						}


						if(count==5){
							regionList.clear();
							mocList.removeAll(regionListFour);
							for(DepotConnectedAssetVolumeNext reg1 : mocList){
								Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

								if(matcher1.find() ){
									regionListFive.add(reg1); 

								}	

							}
							regionListOne.addAll(regionListFive);
							regionList.addAll(regionListOne);
							
						}


						count++;
					
					}

				}// end of if
				
				

				//filtered by category

				for(String c : category){
					for(DepotConnectedAssetVolumeNext cat : regionList){
						if(c.equals(cat.getCategoryNaame())){
							filteredRegionCategoryList.add(cat);
						}

					}

				}
				
				
				totalAssetVolumes.addAll(filteredRegionCategoryList);
				for(DepotConnectedAssetVolumeNext t : totalAssetVolumes){
					totalAssetVolume += t.getDepotConnectedAssetVolume();
				}
				totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);
			}	


			else if(region !=null && account !=null  && category !=null  && moc !=null)	{//8

				List<DepotConnectedAssetVolumeNext> accountList = new ArrayList<DepotConnectedAssetVolumeNext>();
				List<DepotConnectedAssetVolumeNext> filteredRegionCategoryList = new ArrayList<DepotConnectedAssetVolumeNext>();
				
				if(totalDepotAssetVolumeByUsername !=null)	{
					
					//filtered by MOC
					for(String m : moc){
						for(DepotConnectedAssetVolumeNext mocc : totalDepotAssetVolumeByUsername){
							if(m.equals(mocc.getMoc())){
								mocList.add(mocc);
							}

						}
						
					}
					 // filterd by region		

					if(region.size() == 1){
						//filter by region
						for(String regon : region){
							for(DepotConnectedAssetVolumeNext reg : mocList){
								Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
								Matcher matcher = pattern.matcher(reg.getRegionName());

								if(matcher.find()){
									regionListOne.add(reg); 
								}

							}

						}
						regionList.addAll(regionListOne);
	                      
					}

					if(region.size()>1){
						int count =1;
						for(String regon : region){
							if(count==1){
								for(DepotConnectedAssetVolumeNext reg : mocList){
									Pattern pattern = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher = pattern.matcher(reg.getRegionName());

									if(matcher.find() && count<mocList.size()){
										regionListOne.add(reg); 

									}
								}
								regionList.addAll(regionListOne);
							
								
							}

							if(count==2){
								regionList.clear();
								mocList.removeAll(regionListOne);

								for(DepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListTwo.add(reg1); 

									}	

								}
								
								regionListOne.addAll(regionListTwo);
								regionList.addAll(regionListOne);
								
							}

							if(count==3){
								regionList.clear();
								mocList.removeAll(regionListTwo);
								for(DepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListThree.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListThree);
								regionList.addAll(regionListOne);
								
							}

	                       
							if(count==4){
								regionList.clear();
								mocList.removeAll(regionListThree);
								for(DepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFour.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFour);
								regionList.addAll(regionListOne);
								
							}


							if(count==5){
								regionList.clear();
								mocList.removeAll(regionListFour);
								for(DepotConnectedAssetVolumeNext reg1 : mocList){
									Pattern pattern1 = Pattern.compile("(^|,)"+regon+"(,|$)");
									Matcher matcher1 = pattern1.matcher(reg1.getRegionName());

									if(matcher1.find() ){
										regionListFive.add(reg1); 

									}	

								}
								regionListOne.addAll(regionListFive);
								regionList.addAll(regionListOne);
								
							}


							count++;
						
						}

					}// end of if
					
					
					
					
					//-----filter by account------//

					for(String accnt : account){
						for(DepotConnectedAssetVolumeNext acc : regionList){
							if(accnt.equals(acc.getAccountName())){
								accountList.add(acc);
							}

						}

					}


					//-----filter by category------//

					for(String c : category){
						for(DepotConnectedAssetVolumeNext cat : accountList){
							if(c.equals(cat.getCategoryNaame())){
								filteredRegionCategoryList.add(cat);
							}

						}

					}
					
					
					totalAssetVolumes.addAll(filteredRegionCategoryList);

					for(DepotConnectedAssetVolumeNext t : totalAssetVolumes){
						totalAssetVolume += t.getDepotConnectedAssetVolume();
					}

					totalAssetVolumeSum.setDepotConnectedAssetVolume(totalAssetVolume);

				}//end of if

			}// end of else if
		}//end of try
		catch(Exception e){
			e.printStackTrace();
		}

		return totalAssetVolumeSum;

	}









}
