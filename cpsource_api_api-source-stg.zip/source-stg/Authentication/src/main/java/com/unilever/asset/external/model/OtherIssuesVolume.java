package com.unilever.asset.external.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_OTHER_ISSUES_VOLUME")
public class OtherIssuesVolume implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -3221426911045104530L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer RECORD_ID;
	
  
	@Column(name="REGION_NAME")
    private String regionName;
	
	@Column(name="USERNAME")
    private String userName;
	
	@Column(name="CATEGORY_NAME")
    private String categoryNaame;
	
	
	@Column(name="MOC")
    private String moc;

	@Column(name="OTHER_ISSUES_VOLUME")
    private Double otheIssuesVolume;

	public OtherIssuesVolume() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OtherIssuesVolume(Integer rECORD_ID, String regionName, String userName, String categoryNaame, String moc,
			Double otheIssuesVolume) {
		super();
		RECORD_ID = rECORD_ID;
		this.regionName = regionName;
		this.userName = userName;
		this.categoryNaame = categoryNaame;
		this.moc = moc;
		this.otheIssuesVolume = otheIssuesVolume;
	}

	public Integer getRECORD_ID() {
		return RECORD_ID;
	}

	public void setRECORD_ID(Integer rECORD_ID) {
		RECORD_ID = rECORD_ID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCategoryNaame() {
		return categoryNaame;
	}

	public void setCategoryNaame(String categoryNaame) {
		this.categoryNaame = categoryNaame;
	}

	public String getMoc() {
		return moc;
	}

	public void setMoc(String moc) {
		this.moc = moc;
	}

	public Double getOtheIssuesVolume() {
		return otheIssuesVolume;
	}

	public void setOtheIssuesVolume(Double otheIssuesVolume) {
		this.otheIssuesVolume = otheIssuesVolume;
	}
	
	

}
