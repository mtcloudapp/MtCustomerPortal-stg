package com.unilever.sales.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity

public class DetailStatusView implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 6436378088855075996L;
	
	@Id
	@Column(name="min(RECORD_ID)")
	private Integer recordId;
	
	@Column(name="PO_NUMBER")
	private String poNumber;
	
	@Column(name="PO_DATE")
	private String poDate;
	
	@Column(name="DEPOT")
	private String depot;
	
	@Column(name="DELIVERY_DATE")
	private String delivaryDate;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="count(DISTINCT PO_NUMBER, CIC_NO)")
	private Integer lineCount;
	
	@Column(name="sum(ALLOCATED_SUM)")
	private Double allocatedSum;
	
	@Column(name="sum(INVOICED_SUM)")
	private Double invoicedSum;
	
	@Column(name="sum(PO_VALUE)")
	private Double poValue;

	
	public Integer getRecordId() {
		return recordId;
	}

	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoDate() {
		return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public String getDepot() {
		return depot;
	}

	public void setDepot(String depot) {
		this.depot = depot;
	}

	public String getDelivaryDate() {
		return delivaryDate;
	}

	public void setDelivaryDate(String delivaryDate) {
		this.delivaryDate = delivaryDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public Integer getLineCount() {
		return lineCount;
	}

	public void setLineCount(Integer lineCount) {
		this.lineCount = lineCount;
	}

	public Double getAllocatedSum() {
		return allocatedSum;
	}

	public void setAllocatedSum(Double allocatedSum) {
		this.allocatedSum = allocatedSum;
	}

	public Double getInvoicedSum() {
		return invoicedSum;
	}

	public void setInvoicedSum(Double invoicedSum) {
		this.invoicedSum = invoicedSum;
	}

	public Double getPoValue() {
		return poValue;
	}

	public void setPoValue(Double poValue) {
		this.poValue = poValue;
	}

	
	
	
}
